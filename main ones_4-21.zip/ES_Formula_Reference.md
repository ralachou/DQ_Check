# ES-Based Capital Formulas Under FRTB IMA — Quant Reference

*Three levels for each formula: regulatory notation, simplified, and plain English.*

---

## The Total Capital Charge

### Regulatory formula
```
Capital = mc × max( IMCC(t-1) + SES(t-1) , avg_60d(IMCC + SES) ) + DRC
```

Where:
- mc = multiplication factor (floor of 1.5, plus backtest penalty 0 to 0.5)
- IMCC = internally modelled capital calculation (modellable RFs)
- SES = stressed expected shortfall (non-modellable RFs)
- DRC = default risk charge (separate, not covered here)

### Plain English
Take the larger of yesterday's IMCC+SES or the 60-day average, multiply by a regulatory factor (at least 1.5, higher if you fail backtesting), and add the default risk charge on top.

---

## 1. Expected Shortfall (ES) — The Base Measure

### Regulatory formula (§215(b)(2))
```
ES = ES at 97.5th percentile, one-tail confidence level
```

### Simplified
```
ES = average of all losses beyond the 97.5th percentile

With 250 scenarios:
  Sort P&Ls from worst to best
  Worst 2.5% ≈ worst 6 scenarios
  ES = average of those 6 worst losses
```

### Plain English
VaR says: "what's the boundary of the worst 2.5% of days?"
ES says: "given we're in the worst 2.5%, what's the average loss across all of them?"

ES captures the shape of the tail. VaR only finds the edge.

---

## 2. Liquidity Horizon Adjustment — The Cascading Formula

### Regulatory formula (§215(b)(3))
```
ES = √[ (ES_T(P))² + Σ_{j≥2} ( ES_T(P,j) × √((LH_j - LH_{j-1}) / T) )² ]
```

Where:
- T = 10 days (base liquidity horizon)
- ES_T(P) = ES at 10 days using ALL risk factors
- ES_T(P,j) = ES at 10 days using only RFs with liquidity horizon ≥ LH_j
- LH_j = liquidity horizon for category j (10, 20, 40, 60, 120 days)

### Simplified — step by step
```
Step 1: Compute ES_10d using ALL risk factors                     → call this A

Step 2: Compute ES_10d using only RFs with LH ≥ 20 days          → call this B
        Scale: B_scaled = B × √((20-10)/10) = B × 1.0

Step 3: Compute ES_10d using only RFs with LH ≥ 40 days          → call this C
        Scale: C_scaled = C × √((40-20)/10) = C × √2

Step 4: Compute ES_10d using only RFs with LH ≥ 60 days          → call this D
        Scale: D_scaled = D × √((60-40)/10) = D × 2.0

Step 5: Compute ES_10d using only RFs with LH ≥ 120 days         → call this E
        Scale: E_scaled = E × √((120-60)/10) = E × √6

Final:  ES_LH_adjusted = √( A² + B_scaled² + C_scaled² + D_scaled² + E_scaled² )
```

### Plain English
Start with a 10-day ES using everything. Then ask: "what additional risk comes from the fact that some positions take 20 days to exit? 40 days? 60? 120?" Each step adds the incremental risk from less liquid factors, scaled by how much longer their horizon is.

The result is a single ES number that reflects the actual illiquidity of each risk factor — not a one-size-fits-all 10-day assumption.

**Key insight for quants:** You're computing 5 nested ES values, each using a progressively smaller subset of risk factors (those with longer horizons). The scaling factors (√((LH_j - LH_{j-1})/T)) translate 10-day ES into the appropriate horizon-specific increment.

**Comparison to VaR:** Under Basel 2.5, you compute one VaR and optionally scale by √(10/1). Under FRTB, you compute 5 ES values and combine them in a root-sum-of-squares.

---

## 3. Stress Calibration — Direct vs. Indirect Approach

### 3a. Direct Approach (§215(b)(6)(i))

### Regulatory formula
```
ES_stressed = ES computed using full set of risk factors
              with data from the identified 12-month stress period
```

### Plain English
Simple in concept: just compute ES using the stress period data directly. No ratio, no scaling. The challenge is that many risk factors don't have data going back to the stress period (often 2007-2009).

---

### 3b. Indirect Approach (§215(b)(6)(ii))

### Regulatory formula
```
ES = ES_{F,C} × ( ES_{R,S} / ES_{R,C} )
```

Where:
- ES_{F,C} = ES using Full set of risk factors, Current period (most recent 12 months)
- ES_{R,S} = ES using Reduced set of risk factors, Stress period
- ES_{R,C} = ES using Reduced set of risk factors, Current period

### Simplified
```
ES_stressed = ES(full, current) × Stress_Ratio

Where:
  Stress_Ratio = ES(reduced, stress) / ES(reduced, current)
```

### Plain English
Take your current ES using all risk factors. Then scale it up by asking: "how much worse did a reduced set of factors get during the stress period compared to now?" If the reduced set was 1.5x worse during the crisis, scale the full ES by 1.5.

The reduced set must:
- Have data going back to at least 2007
- Explain at least 75% of the variation in the full ES over the past 60 business days
- Be updated whenever the stress period is updated

**Key insight for quants:** The indirect approach is a proportional scaling. It assumes the full risk factor set would have experienced the same proportional stress as the reduced set. This is an approximation — but it's the only practical option when many risk factors don't have 15+ years of history.

**Validation requirement (75% R²):** On date t, the bank must demonstrate:

```
R² = 1 - [ Σ(ES_{F,C,h} - ES_{R,C,h})² ] / [ Σ(ES_{F,C,h} - Mean(ES_{F,C}))² ] ≥ 0.75
```

Over h = t-1 to t-60 business days. If R² drops below 75%, the reduced set must be updated.

---

## 4. IMCC — The Diversification-Constrained Aggregation

### Regulatory formula (§215(c)(4))
```
IMCC = ρ × IMCC(C) + (1 - ρ) × Σ_i IMCC(C_i)
```

Where:
- ρ = 0.5 (regulatory weight)
- IMCC(C) = ES using all risk classes together (unconstrained — full diversification)
- IMCC(C_i) = ES for risk class i alone (constrained — no cross-class diversification)
- i ∈ {interest rate, credit spread, equity, commodity, FX}

### Simplified
```
IMCC = 0.5 × ES(all classes together) + 0.5 × [ES(rates) + ES(credit) + ES(equity) + ES(commodity) + ES(FX)]
```

### Plain English
Your capital charge is a 50/50 blend of:
- The diversified view (all risk classes together — correlations allowed)
- The undiversified view (each risk class computed separately and summed)

You only get half credit for cross-class diversification. Within each class, you keep full empirical correlations.

**Key insight for quants:** The 50/50 blend is a regulatory compromise. Cross-asset correlations tend to spike toward 1 during crises (when diversification is most needed). Rather than trying to model stressed correlations, the regulator caps the benefit at 50%.

**Comparison to VaR:** Under Basel 2.5, GVAR captures whatever cross-asset correlations exist in your recent data — no constraint. FRTB is fundamentally more conservative on cross-class diversification.

---

## 5. SES — Stressed Expected Shortfall for Non-Modellable Risk Factors

### Regulatory formula (§215(d)(2))
```
SES = √[ (Σ_k SES_{NM,k})² + (1 - ρ_b²) × Σ_k (SES_{NM,k})² ] + Σ_j SES_{NM,j}
```

Where:
- k indexes Type A non-modellable risk factors (K total)
- j indexes Type B non-modellable risk factors (J total)
- ρ_b = 0.6 (correlation between Type A factors)
- SES_{NM,k} = standalone stress scenario capital for Type A RF k
- SES_{NM,j} = standalone stress scenario capital for Type B RF j

### Simplified — breaking it apart
```
SES = SES_TypeA + SES_TypeB

SES_TypeA = √[ (Σ individual charges)² + (1 - 0.36) × Σ individual² ]
          = √[ (sum)² + 0.64 × Σ individual² ]

SES_TypeB = Σ individual charges    (pure addition, no diversification)
```

### Plain English
Type A non-modellable risk factors get partial diversification. The correlation parameter ρ=0.6 allows some netting between them — but far less than what you'd get inside the ES model.

Type B non-modellable risk factors get zero diversification. Each one's stress charge is simply added to the total, dollar for dollar. If you have 100 Type B risk factors each with a $1M stress charge, SES_TypeB = $100M. No offset, no netting.

**Key insight for quants:** The SES formula for Type A is structurally similar to a correlation-based aggregation, but with a very conservative assumption (ρ=0.6 is much lower than most empirical within-class correlations). Type B is the mathematical equivalent of assuming perfect positive correlation — the most conservative assumption possible.

**Comparison to IMCC:** A risk factor inside IMCC benefits from empirical correlations with all other modellable risk factors and the 50/50 diversification blend. The same risk factor, if reclassified as Type B non-modellable, gets zero correlation benefit. The capital cost can be 2-3x higher purely from the aggregation treatment.

---

## Computation Requirements for Each Stress Scenario (SES)

For each non-modellable risk factor, the stress scenario must:

```
- Be calibrated to be at least as conservative as the ES measure
- Use the same 12-month stress period as other NMRFs in the same risk class
- Use a liquidity horizon of max(assigned LH, 20 days) — floor of 20 days
- Capture non-linearities and basis risks
- If unable to determine a scenario → use maximum possible loss
```

---

## Summary: The Complete Calculation Flow

```
Step 1: Identify all risk factors (§214a)
Step 2: Classify each RF via RFET (§214b) → Modellable / Type A / Type B

Step 3: For modellable RFs:
   3a. Compute liquidity-horizon-adjusted ES (5 nested ES values, cascading formula)
   3b. Calibrate to stress period (direct or indirect approach)
   3c. Aggregate across risk classes with 50% diversification cap → IMCC

Step 4: For non-modellable RFs:
   4a. Compute standalone stress scenario per RF
   4b. Aggregate Type A with ρ=0.6 correlation
   4c. Sum Type B with zero diversification → SES

Step 5: Total Capital = mc × max(IMCC+SES, avg_60d(IMCC+SES)) + DRC
```

---

## What Risk Factor Quality Affects at Each Step

| Step | What RF quality impacts | How |
|---|---|---|
| RFET classification | Whether RF is modellable or not | Bad data → fewer real price observations → fails RFET → more NMRFs → higher SES |
| ES base calculation | Accuracy of the 97.5% tail average | Bad tail data → ES over/understates → capital too high or regulatory breach |
| Liquidity horizons | Which horizon each RF gets | Missing or misclassified RFs → wrong horizon assignment → ES miscalculated |
| Stress calibration | Quality of the stress-period scaling | Reduced set doesn't represent full set → R² < 75% → must update → operational burden |
| IMCC aggregation | Cross-class diversification benefit | Missing RFs in one class → diversification benefit is wrong |
| SES charges | Penalty size per NMRF | Can't determine stress scenario → maximum possible loss assumption |

---

*End of reference document.*
