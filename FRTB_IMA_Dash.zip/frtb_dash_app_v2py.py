"""
FRTB IMA Risk Factor Programme — Interactive C-Suite Dashboard (Light Theme)
Run:  pip install dash dash-ag-grid dash-bootstrap-components plotly
      python frtb_dash_app.py
Opens at http://127.0.0.1:8050
"""

import dash
from dash import html, dcc, callback, Input, Output, State, ctx, no_update, ALL
import dash_ag_grid as dag
import dash_bootstrap_components as dbc
import plotly.graph_objects as go

# ══════════════════════════════════════════════════════════════════════
# Design Tokens — LIGHT / WHITE THEME
# ══════════════════════════════════════════════════════════════════════
BG       = "#ffffff"
PANEL    = "#f5f6f8"
PANEL_HI = "#eceef2"
BORDER   = "#dce0e8"
AMBER    = "#b87300"
CYAN     = "#087f92"
GREEN    = "#0a7d48"
RED      = "#b82d3a"
PURPLE   = "#5e42b8"
TEXT     = "#1c2030"
MUTED    = "#6d7a8a"
DIM      = "#e2e5ea"
MONO     = "'Courier New', monospace"
SANS     = "'Helvetica Neue', Arial, sans-serif"

AMBER_BG  = "rgba(184,115,0,0.08)"
GREEN_BG  = "rgba(10,125,72,0.08)"
RED_BG    = "rgba(184,45,58,0.08)"
CYAN_BG   = "rgba(8,127,146,0.08)"

# ══════════════════════════════════════════════════════════════════════
# Data
# ══════════════════════════════════════════════════════════════════════
WORKSTREAMS = [
    dict(id="eligibility", icon="◈", title="Risk Factor Eligibility",  sub="Market Object → RF Mapping & Classification", badge="IN PROGRESS", bc=AMBER,  p=68, kpi="847 objects assessed",      click=True),
    dict(id="dq",          icon="◎", title="Data Quality Framework",   sub="DQ Rules, Completeness & Outlier Detection",  badge="ACTIVE",      bc=GREEN,  p=82, kpi="2,400+ RF time series",     click=False),
    dict(id="carry",       icon="⟳", title="Carry Stripping",          sub="Theta Adjustment — Scenarios A / B / C",      badge="ACTIVE",      bc=GREEN,  p=75, kpi="3 methodologies deployed",  click=False),
    dict(id="nmrf_ws",     icon="◐", title="NMRF Assessment",          sub="Modellability Classification & Proxy Rules",   badge="IN PROGRESS", bc=AMBER,  p=45, kpi="583 RFs assessed",          click=False),
    dict(id="pla",         icon="⊡", title="PLA Testing",              sub="HPL vs RTPL — Desk-Level Attribution",        badge="PLANNED",     bc=MUTED,  p=20, kpi="Framework design phase",    click=False),
    dict(id="es",          icon="∑", title="ES / IMCC Computation",    sub="Capital Engine & Aggregation",                badge="PLANNED",     bc=MUTED,  p=10, kpi="Scoping underway",          click=False),
]

TOTAL = dict(total=847, mapped=583, needNew=142, oos=122)

ACS = [
    dict(id="ir",     name="IR Rate",     total=312, mapped=248, needNew=48, oos=16, mod=198, nmrf=50),
    dict(id="ir_vol", name="IR Vol",      total=186, mapped=112, needNew=52, oos=22, mod=78,  nmrf=34),
    dict(id="fx",     name="FX Spot/Fwd", total=124, mapped=118, needNew=4,  oos=2,  mod=112, nmrf=6),
    dict(id="fx_vol", name="FX Vol",      total=98,  mapped=62,  needNew=28, oos=8,  mod=44,  nmrf=18),
    dict(id="eq",     name="Equity",      total=72,  mapped=28,  needNew=8,  oos=36, mod=22,  nmrf=6),
    dict(id="cmd",    name="Commodity",   total=55,  mapped=15,  needNew=2,  oos=38, mod=12,  nmrf=3),
]

IR_DATA = [
    dict(rf="USD.OIS.1Y",     ccy="USD", bench="OIS",    tenor="1Y",  mod="Modellable", proxy="—",              obs=1260),
    dict(rf="USD.OIS.5Y",     ccy="USD", bench="OIS",    tenor="5Y",  mod="Modellable", proxy="—",              obs=1260),
    dict(rf="USD.OIS.10Y",    ccy="USD", bench="OIS",    tenor="10Y", mod="Modellable", proxy="—",              obs=1260),
    dict(rf="USD.OIS.30Y",    ccy="USD", bench="OIS",    tenor="30Y", mod="Modellable", proxy="—",              obs=856),
    dict(rf="EUR.OIS.2Y",     ccy="EUR", bench="OIS",    tenor="2Y",  mod="Modellable", proxy="—",              obs=1260),
    dict(rf="EUR.OIS.10Y",    ccy="EUR", bench="OIS",    tenor="10Y", mod="Modellable", proxy="—",              obs=1260),
    dict(rf="GBP.SONIA.20Y",  ccy="GBP", bench="SONIA",  tenor="20Y", mod="Modellable", proxy="—",              obs=1021),
    dict(rf="GBP.SONIA.30Y",  ccy="GBP", bench="SONIA",  tenor="30Y", mod="NMRF",       proxy="GBP.SONIA.20Y", obs=312),
    dict(rf="JPY.OIS.10Y",    ccy="JPY", bench="OIS",    tenor="10Y", mod="Modellable", proxy="—",              obs=1260),
    dict(rf="JPY.OIS.20Y",    ccy="JPY", bench="OIS",    tenor="20Y", mod="NMRF",       proxy="JPY.OIS.10Y",   obs=198),
    dict(rf="CHF.OIS.30Y",    ccy="CHF", bench="OIS",    tenor="30Y", mod="NEED NEW RF",proxy="—",              obs=0),
    dict(rf="SEK.STIBOR.10Y", ccy="SEK", bench="STIBOR", tenor="10Y", mod="NEED NEW RF",proxy="—",              obs=0),
]

FX_DATA = [
    dict(rf="EURUSD.SPOT",   pair="EUR/USD", type="Spot",       mod="Modellable", proxy="—",             obs=1260),
    dict(rf="GBPUSD.SPOT",   pair="GBP/USD", type="Spot",       mod="Modellable", proxy="—",             obs=1260),
    dict(rf="USDJPY.SPOT",   pair="USD/JPY", type="Spot",       mod="Modellable", proxy="—",             obs=1260),
    dict(rf="USDCHF.SPOT",   pair="USD/CHF", type="Spot",       mod="Modellable", proxy="—",             obs=1260),
    dict(rf="USDBRL.SPOT",   pair="USD/BRL", type="Spot",       mod="NMRF",       proxy="USDMXN.SPOT",  obs=287),
    dict(rf="EURUSD.1M.25D", pair="EUR/USD", type="Vol 1M 25Δ", mod="Modellable", proxy="—",             obs=987),
    dict(rf="EURUSD.3M.ATM", pair="EUR/USD", type="Vol 3M ATM", mod="Modellable", proxy="—",             obs=1260),
    dict(rf="USDJPY.1Y.10D", pair="USD/JPY", type="Vol 1Y 10Δ", mod="NMRF",       proxy="USDJPY.1Y.25D",obs=156),
    dict(rf="USDZAR.6M.ATM", pair="USD/ZAR", type="Vol 6M ATM", mod="NEED NEW RF",proxy="—",             obs=0),
]

# ══════════════════════════════════════════════════════════════════════
# Helpers
# ══════════════════════════════════════════════════════════════════════
pct = lambda n, d: round(n / d * 100) if d else 0

def tag(label, color):
    return html.Span(label, style=dict(
        fontSize=9, fontFamily=MONO, letterSpacing="0.1em", color=color,
        border=f"1px solid {color}", borderRadius=2, padding="2px 6px",
        whiteSpace="nowrap", display="inline-block",
    ))

def kpi_card(label, value, color=AMBER, note=""):
    return html.Div([
        html.Div(str(value), style=dict(fontSize=28, fontWeight=700, color=color, fontFamily=MONO, lineHeight="1")),
        html.Div(label, style=dict(fontSize=10, color=MUTED, marginTop=6, textTransform="uppercase", letterSpacing="0.08em")),
        html.Div(note, style=dict(fontSize=10, color=MUTED, marginTop=3)) if note else None,
    ], style=dict(textAlign="center", padding="18px 10px", background=PANEL, border=f"1px solid {BORDER}", borderRadius=6))

def progress_bar(value, color=GREEN, height=4):
    return html.Div(
        html.Div(style=dict(background=color, width=f"{value}%", height="100%", borderRadius=3)),
        style=dict(background=DIM, borderRadius=3, height=height, width="100%"),
    )

def callout(text, color=AMBER):
    bg = AMBER_BG if color == AMBER else RED_BG if color == RED else GREEN_BG
    return html.Div(text, style=dict(
        padding=12, background=bg, borderRadius=4, fontSize=11, color=color,
        border=f"1px solid {color}22", marginTop=14,
    ))

# ══════════════════════════════════════════════════════════════════════
# Breadcrumb
# ══════════════════════════════════════════════════════════════════════
PATHS = {
    "overview":    [("Programme Overview", "overview")],
    "eligibility": [("Programme Overview", "overview"), ("RF Eligibility", "eligibility")],
    "mapping":     [("Programme Overview", "overview"), ("RF Eligibility", "eligibility"), ("Mapping Coverage", "mapping")],
    "ir":          [("Programme Overview", "overview"), ("RF Eligibility", "eligibility"), ("IR Rate Drill", "ir")],
    "fx":          [("Programme Overview", "overview"), ("RF Eligibility", "eligibility"), ("FX Drill", "fx")],
    "nmrf":        [("Programme Overview", "overview"), ("RF Eligibility", "eligibility"), ("NMRF Landscape", "nmrf")],
}

def breadcrumb(screen):
    crumbs = PATHS.get(screen, PATHS["overview"])
    items = []
    for i, (label, sid) in enumerate(crumbs):
        if i > 0:
            items.append(html.Span(" › ", style=dict(color=MUTED, fontSize=13, margin="0 4px")))
        is_last = i == len(crumbs) - 1
        items.append(html.Span(
            label,
            id=dict(type="crumb", index=sid),
            n_clicks=0,
            style=dict(
                fontSize=12, color=TEXT if is_last else MUTED,
                cursor="default" if is_last else "pointer",
                fontFamily=SANS,
            ),
        ))
    items.append(html.Span(
        "FRTB IMA · RF PROGRAMME · 2024",
        style=dict(marginLeft="auto", fontSize=10, color=DIM, fontFamily=MONO, letterSpacing="0.08em"),
    ))
    return html.Div(items, style=dict(
        display="flex", alignItems="center", gap=4,
        marginBottom=28, paddingBottom=16, borderBottom=f"1px solid {BORDER}",
    ))

# ══════════════════════════════════════════════════════════════════════
# Screens
# ══════════════════════════════════════════════════════════════════════

def screen_overview():
    kpis = html.Div([
        kpi_card("Market Objects", 847, TEXT),
        kpi_card("Risk Factors Built", 583, GREEN, "↑ 69% coverage"),
        kpi_card("RF Build Pipeline", 142, AMBER, "gap identified"),
        kpi_card("Modellable RFs", 466, CYAN, "80% of mapped"),
    ], style=dict(display="grid", gridTemplateColumns="repeat(4,1fr)", gap=14, marginBottom=24))

    cards = []
    for ws in WORKSTREAMS:
        opacity = 0.5 if ws["badge"] == "PLANNED" else 1
        card_children = [
            html.Div([
                html.Span(ws["icon"], style=dict(fontSize=18, color=ws["bc"])),
                tag(ws["badge"], ws["bc"]),
            ], style=dict(display="flex", justifyContent="space-between", alignItems="flex-start", marginBottom=10)),
            html.Div(ws["title"], style=dict(fontSize=14, fontWeight=600, marginBottom=4, color=TEXT)),
            html.Div(ws["sub"], style=dict(fontSize=11, color=MUTED, marginBottom=14, lineHeight="1.5")),
            html.Div([
                html.Span(ws["kpi"], style=dict(fontSize=11, color=MUTED, fontFamily=MONO)),
                html.Span(f"{ws['p']}%", style=dict(fontSize=11, color=ws["bc"], fontFamily=MONO)),
            ], style=dict(display="flex", justifyContent="space-between")),
            progress_bar(ws["p"], ws["bc"], 3),
        ]
        if ws["click"]:
            card_children.append(html.Div("CLICK TO EXPLORE →", style=dict(
                marginTop=10, fontSize=10, color=AMBER, textAlign="right", letterSpacing="0.05em",
            )))
        cards.append(html.Div(
            card_children,
            id=dict(type="ws-card", index=ws["id"]),
            n_clicks=0,
            style=dict(
                background=PANEL, border=f"1px solid {BORDER}", borderRadius=6,
                padding=20, cursor="pointer" if ws["click"] else "default", opacity=opacity,
                transition="all 0.15s ease",
            ),
        ))

    return html.Div([
        html.H1([
            "FRTB IMA ", html.Span("Risk Factor Programme", style=dict(color=AMBER)),
        ], style=dict(fontSize=24, fontWeight=300, margin="0 0 6px", letterSpacing="-0.02em", color=TEXT)),
        html.P("Internal Models Approach — Work Stream Overview · Click the highlighted tile to explore Risk Factor Eligibility",
               style=dict(color=MUTED, fontSize=12, margin="0 0 22px", fontFamily=SANS)),
        kpis,
        html.Div(cards, style=dict(display="grid", gridTemplateColumns="repeat(3,1fr)", gap=14)),
    ])


def screen_eligibility():
    kpis = html.Div([
        kpi_card("Universe", TOTAL["total"], TEXT),
        kpi_card("Mapped to RF", TOTAL["mapped"], GREEN, f"{pct(TOTAL['mapped'], TOTAL['total'])}% coverage"),
        kpi_card("RF Build Needed", TOTAL["needNew"], AMBER, "gap = opportunity"),
        kpi_card("Out of Scope", TOTAL["oos"], MUTED),
    ], style=dict(display="grid", gridTemplateColumns="repeat(4,1fr)", gap=14, marginBottom=24))

    tiles_data = [
        ("mapping", "▦", "Mapping Coverage",    "Asset-class breakdown of what is mapped, what requires new RF construction, and what is out of scope.", AMBER),
        ("ir",      "〜", "IR Rate — Deep Dive", "Curve-level IR rate risk factors by currency and benchmark: tenors, modellability status, and proxy assignments.", CYAN),
        ("fx",      "⇌",  "FX — Deep Dive",      "FX spot and vol surface risk factors by pair: mapping coverage, NMRF classification, and proxy chains.", PURPLE),
        ("nmrf",    "◐", "NMRF Landscape",      "Modellable vs non-modellable breakdown by asset class. Capital add-on implications and optimization opportunities.", RED),
    ]
    tiles = []
    for sid, icon, label, desc, color in tiles_data:
        tiles.append(html.Div([
            html.Div(icon, style=dict(fontSize=20, color=color, marginBottom=10)),
            html.Div(label, style=dict(fontSize=14, fontWeight=600, marginBottom=6, color=TEXT)),
            html.Div(desc, style=dict(fontSize=11, color=MUTED, lineHeight="1.5", marginBottom=14)),
            html.Div("EXPLORE →", style=dict(fontSize=10, color=color, letterSpacing="0.05em")),
        ], id=dict(type="tile", index=sid), n_clicks=0,
           style=dict(background=PANEL, border=f"1px solid {BORDER}", borderRadius=6,
                      padding=22, cursor="pointer", transition="all 0.15s ease")))

    return html.Div([
        html.H2([
            "Risk Factor ", html.Span("Eligibility Framework", style=dict(color=AMBER)),
        ], style=dict(fontSize=20, fontWeight=300, margin="0 0 6px", color=TEXT)),
        html.P("Not every market object maps to a risk factor. The framework classifies coverage, surfaces gaps, and tracks what we still need to build.",
               style=dict(color=MUTED, fontSize=12, margin="0 0 22px", fontFamily=SANS)),
        kpis,
        html.Div(tiles, style=dict(display="grid", gridTemplateColumns="repeat(2,1fr)", gap=14)),
    ])


def screen_mapping():
    fig = go.Figure()
    fig.add_trace(go.Bar(x=[TOTAL["mapped"]], y=["Coverage"], orientation="h", name="Mapped", marker_color=GREEN, opacity=0.85))
    fig.add_trace(go.Bar(x=[TOTAL["needNew"]], y=["Coverage"], orientation="h", name="Need RF", marker_color=AMBER, opacity=0.85))
    fig.add_trace(go.Bar(x=[TOTAL["oos"]], y=["Coverage"], orientation="h", name="Out of Scope", marker_color=DIM, opacity=0.85))
    fig.update_layout(barmode="stack", height=60, margin=dict(l=0, r=0, t=0, b=0),
                      paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
                      showlegend=True, legend=dict(orientation="h", font=dict(color=MUTED, size=10), x=0, y=-1.5),
                      yaxis=dict(visible=False), xaxis=dict(visible=False))

    col_defs = [
        dict(field="name",    headerName="Asset Class", flex=2, cellStyle={"fontFamily": MONO}),
        dict(field="total",   headerName="Total",       flex=1, type="numericColumn"),
        dict(field="mapped",  headerName="Mapped",      flex=1, type="numericColumn",
             cellStyle={"color": GREEN, "fontFamily": MONO}),
        dict(field="pct",     headerName="Coverage %",   flex=1, type="numericColumn",
             cellStyle={"fontFamily": MONO},
             valueFormatter={"function": "params.value + '%'"}),
        dict(field="needNew", headerName="Need RF",     flex=1, type="numericColumn",
             cellStyle={"function": f"params.value > 0 ? {{'color': '{AMBER}', 'fontFamily': '{MONO}'}} : {{'color': '{MUTED}', 'fontFamily': '{MONO}'}}"}),
        dict(field="oos",     headerName="OOS",         flex=1, type="numericColumn",
             cellStyle={"color": MUTED, "fontFamily": MONO}),
        dict(field="drill",   headerName="",            flex=1,
             cellStyle={"function": f"params.value !== '—' ? {{'color': '{AMBER}', 'cursor': 'pointer', 'fontFamily': '{MONO}'}} : {{}}"}),
    ]
    rows = []
    for ac in ACS:
        drill = "→ Drill" if ac["id"] in ("ir", "fx") else "—"
        rows.append(dict(name=ac["name"], total=ac["total"], mapped=ac["mapped"],
                         pct=pct(ac["mapped"], ac["total"]),
                         needNew=ac["needNew"], oos=ac["oos"], drill=drill, id=ac["id"]))

    grid = dag.AgGrid(
        id="mapping-grid",
        rowData=rows,
        columnDefs=col_defs,
        defaultColDef=dict(resizable=False, sortable=True),
        dashGridOptions=dict(headerHeight=32, rowHeight=38, domLayout="autoHeight", rowSelection="single"),
        style=dict(height=None, width="100%"),
        className="ag-theme-alpine",
    )

    return html.Div([
        html.H2([
            "Market Object → Risk Factor ", html.Span("Mapping Coverage", style=dict(color=AMBER)),
        ], style=dict(fontSize=20, fontWeight=300, margin="0 0 6px", color=TEXT)),
        html.P("847 market objects assessed across all asset classes. Coverage is non-uniform — gaps directly drive the RF build pipeline.",
               style=dict(color=MUTED, fontSize=12, margin="0 0 22px", fontFamily=SANS)),
        html.Div([
            html.Div("Overall Universe Coverage", style=dict(fontSize=10, color=MUTED, textTransform="uppercase",
                                                              letterSpacing="0.1em", marginBottom=10)),
            dcc.Graph(figure=fig, config=dict(displayModeBar=False)),
        ], style=dict(background=PANEL, border=f"1px solid {BORDER}", borderRadius=6, padding=20, marginBottom=16)),
        html.Div([
            html.Div("By Asset Class — click IR Rate or FX row to drill down", style=dict(
                fontSize=10, color=MUTED, textTransform="uppercase", letterSpacing="0.1em", marginBottom=14)),
            grid,
            callout("⚠ 142 market objects require new RF construction — concentrated in IR Vol (52) and FX Vol (28) where surface coverage remains incomplete.", AMBER),
        ], style=dict(background=PANEL, border=f"1px solid {BORDER}", borderRadius=6, padding=20)),
    ])


def screen_drill(asset):
    is_ir = asset == "ir"
    data = IR_DATA if is_ir else FX_DATA
    accent = CYAN if is_ir else PURPLE

    status_style_fn = f"params.value === 'Modellable' ? {{'color':'{GREEN}','fontWeight':600}} : params.value === 'NMRF' ? {{'color':'{RED}','fontWeight':600}} : {{'color':'{AMBER}','fontWeight':600}}"

    if is_ir:
        col_defs = [
            dict(field="rf",    headerName="RF Identifier", flex=3, cellStyle={"fontFamily": MONO, "color": accent}),
            dict(field="ccy",   headerName="CCY",           flex=1, cellStyle={"fontFamily": MONO, "color": MUTED}),
            dict(field="bench", headerName="Benchmark",     flex=1.5, cellStyle={"fontFamily": MONO, "color": MUTED}),
            dict(field="tenor", headerName="Tenor",         flex=1, cellStyle={"fontFamily": MONO, "color": MUTED}),
            dict(field="obs",   headerName="Obs (days)",    flex=1.5, type="numericColumn", cellStyle={"fontFamily": MONO}),
            dict(field="mod",   headerName="Status",        flex=1.5, cellStyle={"function": status_style_fn}),
            dict(field="proxy", headerName="Proxy",         flex=2, cellStyle={"fontFamily": MONO, "color": AMBER}),
        ]
    else:
        col_defs = [
            dict(field="rf",    headerName="RF Identifier", flex=3, cellStyle={"fontFamily": MONO, "color": accent}),
            dict(field="pair",  headerName="Pair",          flex=1.2, cellStyle={"fontFamily": MONO, "color": MUTED}),
            dict(field="type",  headerName="Type",          flex=1.5, cellStyle={"fontFamily": MONO, "color": MUTED}),
            dict(field="obs",   headerName="Obs (days)",    flex=1.5, type="numericColumn", cellStyle={"fontFamily": MONO}),
            dict(field="mod",   headerName="Status",        flex=1.5, cellStyle={"function": status_style_fn}),
            dict(field="proxy", headerName="Proxy",         flex=2, cellStyle={"fontFamily": MONO, "color": AMBER}),
        ]

    grid = dag.AgGrid(
        id="drill-grid",
        rowData=data,
        columnDefs=col_defs,
        defaultColDef=dict(resizable=False, sortable=True),
        dashGridOptions=dict(headerHeight=32, rowHeight=38, domLayout="autoHeight", rowSelection="single", animateRows=True),
        style=dict(height=None, width="100%"),
        className="ag-theme-alpine",
    )

    title_text = "IR Rate" if is_ir else "FX"
    desc = ("Interest rate curves by currency and benchmark. Modellability driven by observation count against 500-day threshold. Click a row for details below."
            if is_ir else
            "FX spot and vol surface risk factors by pair. Spot pairs are largely modellable; vol surface coverage has meaningful gaps. Click a row for details below.")

    return html.Div([
        html.H2([
            f"{title_text} ", html.Span("Risk Factor Drill-Down", style=dict(color=accent)),
        ], style=dict(fontSize=20, fontWeight=300, margin="0 0 6px", color=TEXT)),
        html.P(desc, style=dict(color=MUTED, fontSize=12, margin="0 0 22px", fontFamily=SANS)),
        html.Div([grid], style=dict(background=PANEL, border=f"1px solid {BORDER}", borderRadius=6, padding=20)),
        html.Div(id="rf-detail-panel", style=dict(marginTop=16)),
    ])


def screen_nmrf():
    total_mod  = sum(a["mod"]  for a in ACS)
    total_nmrf = sum(a["nmrf"] for a in ACS)

    kpis = html.Div([
        kpi_card("Modellable RFs", total_mod, GREEN, f"{pct(total_mod, total_mod + total_nmrf)}% of mapped RFs"),
        kpi_card("NMRF", total_nmrf, RED, "Attract capital add-on"),
        kpi_card("Proxy-Assigned", 67, AMBER, "Partially mitigated"),
    ], style=dict(display="grid", gridTemplateColumns="repeat(3,1fr)", gap=14, marginBottom=22))

    fig = go.Figure()
    names = [a["name"] for a in reversed(ACS)]
    mods  = [a["mod"]  for a in reversed(ACS)]
    nmrfs = [a["nmrf"] for a in reversed(ACS)]
    fig.add_trace(go.Bar(y=names, x=mods,  orientation="h", name="Modellable", marker_color=GREEN, opacity=0.8))
    fig.add_trace(go.Bar(y=names, x=nmrfs, orientation="h", name="NMRF",       marker_color=RED,   opacity=0.8))
    fig.update_layout(
        barmode="stack", height=280,
        margin=dict(l=0, r=20, t=10, b=10),
        paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
        legend=dict(orientation="h", font=dict(color=MUTED, size=10), x=0, y=-0.15),
        xaxis=dict(showgrid=False, zeroline=False, color=MUTED, tickfont=dict(size=10)),
        yaxis=dict(showgrid=False, color=TEXT, tickfont=dict(size=11, family=SANS)),
    )
    for ac in ACS:
        tot = ac["mod"] + ac["nmrf"]
        mp = pct(ac["mod"], tot)
        fig.add_annotation(
            x=tot + 5, y=ac["name"],
            text=f"{mp}%",
            showarrow=False,
            font=dict(size=10, color=GREEN if mp >= 75 else AMBER, family=MONO),
            xanchor="left",
        )

    return html.Div([
        html.H2([
            html.Span("NMRF", style=dict(color=RED)), " Landscape — Modellability Map",
        ], style=dict(fontSize=20, fontWeight=300, margin="0 0 6px", color=TEXT)),
        html.P("Current modellability state across all assessed risk factors. NMRFs attract regulatory capital add-ons — reducing NMRF count is a key IMA optimization lever.",
               style=dict(color=MUTED, fontSize=12, margin="0 0 22px", fontFamily=SANS)),
        kpis,
        html.Div([
            html.Div("Modellability Split by Asset Class", style=dict(
                fontSize=10, color=MUTED, textTransform="uppercase", letterSpacing="0.1em", marginBottom=8)),
            dcc.Graph(figure=fig, config=dict(displayModeBar=False)),
            callout("⚑ IR Vol (70% modellable) and FX Vol (71% modellable) carry the highest NMRF concentration. "
                    "Expanding RF surface coverage here is the primary capital optimization opportunity.", RED),
        ], style=dict(background=PANEL, border=f"1px solid {BORDER}", borderRadius=6, padding=20)),
    ])


# ══════════════════════════════════════════════════════════════════════
# App
# ══════════════════════════════════════════════════════════════════════
app = dash.Dash(__name__, external_stylesheets=[dbc.themes.FLATLY])
app.title = "FRTB IMA · Risk Factor Programme"

app.layout = html.Div([
    dcc.Store(id="nav-store", data="overview"),
    html.Div(id="breadcrumb-container"),
    html.Div(id="screen-container"),
], style=dict(
    background=BG, minHeight="100vh", color=TEXT, fontFamily=SANS,
    padding="24px 32px", boxSizing="border-box",
    backgroundImage="radial-gradient(rgba(0,0,0,0.03) 1px, transparent 1px)",
    backgroundSize="22px 22px",
))

# ══════════════════════════════════════════════════════════════════════
# Callbacks
# ══════════════════════════════════════════════════════════════════════

@callback(
    Output("nav-store", "data"),
    [
        Input({"type": "ws-card", "index": ALL}, "n_clicks"),
        Input({"type": "tile",    "index": ALL}, "n_clicks"),
        Input({"type": "crumb",   "index": ALL}, "n_clicks"),
    ],
    State("nav-store", "data"),
    prevent_initial_call=True,
)
def navigate(_ws, _tiles, _crumbs, current):
    triggered = ctx.triggered_id
    if not triggered:
        return no_update
    idx = triggered["index"]
    kind = triggered["type"]
    if kind == "ws-card":
        ws = next((w for w in WORKSTREAMS if w["id"] == idx), None)
        if ws and ws["click"]:
            return "eligibility"
    elif kind == "tile":
        return idx
    elif kind == "crumb":
        return idx
    return no_update


@callback(
    Output("nav-store", "data", allow_duplicate=True),
    Input("mapping-grid", "selectedRows"),
    prevent_initial_call=True,
)
def drill_from_mapping(selected):
    if not selected:
        return no_update
    row = selected[0]
    if row.get("id") in ("ir", "fx"):
        return row["id"]
    return no_update


@callback(
    [Output("breadcrumb-container", "children"),
     Output("screen-container", "children")],
    Input("nav-store", "data"),
)
def render(screen):
    bc = breadcrumb(screen)
    screens = {
        "overview": screen_overview,
        "eligibility": screen_eligibility,
        "mapping": screen_mapping,
        "ir": lambda: screen_drill("ir"),
        "fx": lambda: screen_drill("fx"),
        "nmrf": screen_nmrf,
    }
    content = screens.get(screen, screen_overview)()
    return bc, content


@callback(
    Output("rf-detail-panel", "children"),
    Input("drill-grid", "selectedRows"),
    State("nav-store", "data"),
    prevent_initial_call=True,
)
def show_rf_detail(selected, screen):
    if not selected:
        return None
    rf = selected[0]
    is_ir = screen == "ir"
    accent = CYAN if is_ir else PURPLE

    meta = [
        ("Asset Class", "IR Rate" if is_ir else "FX"),
        ("Benchmark" if is_ir else "Currency Pair", rf.get("bench", rf.get("pair", "—"))),
        ("Tenor" if is_ir else "Instrument", rf.get("tenor", rf.get("type", "—"))),
    ]
    if is_ir:
        meta.append(("Currency", rf.get("ccy", "—")))
    meta += [
        ("Observations", rf.get("obs", "N/A")),
        ("Data Sufficiency", "Sufficient" if rf.get("obs", 0) >= 500 else ("Marginal" if rf.get("obs", 0) > 0 else "Not assessed")),
    ]

    meta_rows = [
        html.Div([
            html.Span(k, style=dict(fontSize=11, color=MUTED)),
            html.Span(str(v), style=dict(fontSize=11, fontFamily=MONO, color=TEXT)),
        ], style=dict(display="flex", justifyContent="space-between", padding="6px 0",
                      borderBottom=f"1px solid {BORDER}"))
        for k, v in meta
    ]

    mod = rf.get("mod", "—")
    if mod == "NEED NEW RF":
        status_block = html.Div("⚠ RF not yet built. Queued in RF construction pipeline.",
                                style=dict(padding=10, background=AMBER_BG, borderRadius=4, fontSize=11, color=AMBER))
    elif mod == "Modellable":
        status_block = html.Div([
            html.Div("✓ Modellable", style=dict(fontSize=12, color=GREEN, fontWeight=600, marginBottom=4)),
            html.Div(f"{rf.get('obs', 0)} obs — above 500-day threshold", style=dict(fontSize=10, color=MUTED)),
        ], style=dict(padding=10, background=GREEN_BG, borderRadius=4))
    else:
        status_block = html.Div([
            html.Div("✗ NMRF", style=dict(fontSize=12, color=RED, fontWeight=600, marginBottom=4)),
            html.Div(f"{rf.get('obs', 0)} obs — below 500-day threshold", style=dict(fontSize=10, color=MUTED)),
        ], style=dict(padding=10, background=RED_BG, borderRadius=4))

    proxy_block = None
    proxy_val = rf.get("proxy", "—")
    if proxy_val and proxy_val != "—":
        proxy_block = html.Div([
            html.Div("Proxy Assignment", style=dict(fontSize=10, color=MUTED, textTransform="uppercase",
                                                     letterSpacing="0.08em", marginBottom=8)),
            html.Div([
                html.Div("Proxied to", style=dict(fontSize=10, color=MUTED, marginBottom=4)),
                html.Div(proxy_val, style=dict(fontFamily=MONO, fontSize=12, color=AMBER)),
                html.Div("NMRF stress applied. Contributes to add-on capital charge under IMA.",
                         style=dict(fontSize=10, color=MUTED, marginTop=6)),
            ], style=dict(padding=10, background=BG, border=f"1px solid {BORDER}", borderRadius=4)),
        ], style=dict(marginTop=14))

    return html.Div([
        html.Div([
            html.Div("RF Detail", style=dict(fontSize=10, color=MUTED, textTransform="uppercase",
                                              letterSpacing="0.1em", marginBottom=14)),
            html.Div(rf["rf"], style=dict(fontFamily=MONO, fontSize=14, color=accent,
                                           marginBottom=16, wordBreak="break-all", lineHeight="1.5")),
            html.Div("Metadata", style=dict(fontSize=10, color=MUTED, textTransform="uppercase",
                                             letterSpacing="0.08em", marginBottom=8)),
            html.Div(meta_rows),
            html.Div("Modellability", style=dict(fontSize=10, color=MUTED, textTransform="uppercase",
                                                  letterSpacing="0.08em", marginTop=14, marginBottom=8)),
            status_block,
            proxy_block,
        ], style=dict(background=PANEL, border=f"1px solid {BORDER}", borderRadius=6, padding=20)),
    ], style=dict(maxWidth=480))


# ══════════════════════════════════════════════════════════════════════
# Custom CSS — Light AG Grid
# ══════════════════════════════════════════════════════════════════════
app.index_string = """<!DOCTYPE html>
<html>
<head>
    {%metas%}
    <title>{%title%}</title>
    {%favicon%}
    {%css%}
    <style>
        body { margin: 0; background: #ffffff; color: #1c2030; }
        .ag-theme-alpine {
            --ag-background-color: #f5f6f8;
            --ag-header-background-color: #f5f6f8;
            --ag-odd-row-background-color: #ffffff;
            --ag-row-hover-color: #eceef2;
            --ag-selected-row-background-color: rgba(8,127,146,0.08);
            --ag-border-color: #dce0e8;
            --ag-header-foreground-color: #6d7a8a;
            --ag-foreground-color: #1c2030;
            --ag-font-family: 'Helvetica Neue', Arial, sans-serif;
            --ag-font-size: 12px;
            --ag-row-border-color: #dce0e8;
        }
        .ag-theme-alpine .ag-header-cell-label {
            text-transform: uppercase;
            font-size: 10px;
            letter-spacing: 0.08em;
        }
    </style>
</head>
<body>
    {%app_entry%}
    <footer>
        {%config%}
        {%scripts%}
        {%renderer%}
    </footer>
</body>
</html>"""


if __name__ == "__main__":
    app.run(debug=True, port=8050)
