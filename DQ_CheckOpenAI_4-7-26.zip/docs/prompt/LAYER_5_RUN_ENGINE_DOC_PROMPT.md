# Prompt: Layer 5 Run Engine / Orchestrator Documentation

```text
You are a Principal Python Architect documenting a production-minded layered system.

Task:
Create a deep technical Markdown doc for Layer 5: Run Engine / Orchestrator.
Write to: docs/5_RunEngine_Layer.MD

Project context:
- Layered architecture for "Advanced DQ Checks on RF"
- 50k+ financial risk-factor time series
- business_date snapshot model
- config-driven behavior (YAML)
- auditable outputs

Required doc structure (follow exactly):
1) Purpose
2) Architecture
3) Main Design Decisions
4) Module And Function Reference
5) Data Contracts / Schemas
6) Configuration Surface
7) Processing Flow
8) Inputs and Outputs
9) Error Handling and Guardrails
10) Performance and Scale Notes
11) Testing and Verification
12) Example Commands
13) How This Layer Is Modular

Output quality requirements:
- Concise but deep and implementation-grounded
- Use concrete file references from this codebase
- Use bullet points and code blocks where useful
- No generic filler; tie every section to actual code
- If code is missing for a requested section, state "Not implemented yet" and suggest exact next steps

Now generate docs/5_RunEngine_Layer.MD for:
- Layer: 5 - Run Engine / Orchestrator
- Focus modules:
  - src/engine/run_engine.py
  - src/pipeline/run_demo.py
  - src/pipeline/run_demo_layer5_runEngine.py
  - src/data_access/parquet_repository.py
  - src/universe/builder.py
  - src/dq_checks/registry.py
  - src/normalization/normalizer.py
  - src/triage/false_alarm.py
- Related CLI/demo entrypoint(s):
  - dq-demo
  - src/pipeline/run_demo.py
  - dq-demo-layer5-runengine
  - src/pipeline/run_demo_layer5_runEngine.py
- Related tests/notebooks:
  - tests/test_normalization.py
  - tests/test_business_date_repository.py
  - tests/layer5_runEngine_demo.ipynb
```

