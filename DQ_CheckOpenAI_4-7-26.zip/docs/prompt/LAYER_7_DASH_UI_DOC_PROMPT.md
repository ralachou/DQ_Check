# Prompt: Layer 7 Dash UI Documentation

```text
You are a Principal Python Architect documenting a production-minded layered system.

Task:
Create a deep technical Markdown doc for the Dash UI layer.
Write to: docs/7_Dash_UI_Layer.MD

Project context:
- Layered architecture for "Advanced DQ Checks on RF"
- 50k+ financial risk-factor time series
- business_date snapshot model
- config-driven behavior (YAML)
- auditable outputs

Required doc structure (follow exactly):
1) Purpose
2) Architecture
3) Main Design Decisions
4) Module And Function Reference
5) Data Contracts / Schemas
6) Configuration Surface
7) Processing Flow
8) Inputs and Outputs
9) Error Handling and Guardrails
10) Performance and Scale Notes
11) Testing and Verification
12) Example Commands
13) How This Layer Is Modular

Output quality requirements:
- Concise but deep and implementation-grounded
- Use concrete file references from this codebase
- Use bullet points and code blocks where useful
- No generic filler; tie every section to actual code
- If code is missing for a requested section, state "Not implemented yet" and suggest exact next steps

Now generate docs/7_Dash_UI_Layer.MD for:
- Layer: 7 - Dash UI
- Focus modules:
  - src/ui/app.py
  - src/pipeline/run_demo_layer7_dash_ui.py
  - assets/dashAgGridFunctions.js
- Related CLI/demo entrypoint(s):
  - dq-ui
  - dq-ui-debug
  - src/pipeline/run_demo_layer7_dash_ui.py
- Related tests/notebooks:
  - tests/layer7_dash_ui_debug_demo.ipynb
```

