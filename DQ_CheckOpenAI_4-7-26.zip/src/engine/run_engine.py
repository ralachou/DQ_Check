from __future__ import annotations

import json
import time
from dataclasses import dataclass
from typing import Any

import pandas as pd

from common.schemas import config_hash, load_yaml
from common.taxonomy import (
    TAXONOMY_COLUMNS,
    TAXONOMY_PEER_KEYS,
    apply_peer_grouping,
    normalize_taxonomy_frame,
    resolve_peer_group_config,
)
from data_access.base import TimeSeriesRepository
from dq_checks.feature_builder import FeatureBuilder
from dq_checks.registry import ModelRegistry, ModelSpec
from normalization.normalizer import normalize_results
from triage.false_alarm import FalseAlarmReducer
from universe.builder import UniverseBuilder
from universe.definitions import UniverseDefinition


@dataclass
class RunRequest:
    run_id: str
    universe_name: str
    start_date: str
    end_date: str
    business_date: str | None = None
    config_path: str = "configs/model_catalog.yaml"
    incremental: bool = True
    with_supervised_triage: bool = False
    triage_label_col: str | None = None
    preserve_check_flags: bool = True
    analysis_field: str = "value"


class RunEngine:
    def __init__(self, repository: TimeSeriesRepository, artifact_root: str = "data/artifacts/normalization") -> None:
        self.repository = repository
        self.registry = ModelRegistry()
        self.feature_builder = FeatureBuilder()
        self.artifact_root = artifact_root

    def _build_universe(self, catalog: dict[str, Any], universe_name: str) -> pd.DataFrame:
        universe_cfg = catalog.get("universes", {}).get(universe_name)
        if not universe_cfg:
            raise ValueError(f"Universe '{universe_name}' not found in catalog.")
        definition = UniverseDefinition(
            name=universe_name,
            description=str(universe_cfg.get("description", "")),
            filter_rules=universe_cfg.get("filters", {}),
        )
        return UniverseBuilder(self.repository).build(definition)

    def _check_profiles(self, specs: list[ModelSpec], catalog: dict[str, Any]) -> dict[str, dict[str, Any]]:
        profiles = catalog.get("normalization", {}).get("profiles", {})
        defaults = catalog.get("normalization", {}).get("defaults", {})
        global_severity = catalog.get("globals", {}).get("default_severity_thresholds", {})
        out: dict[str, dict[str, Any]] = {}
        for spec in specs:
            profile_cfg = profiles.get(spec.normalization_profile, {})
            strategy = profile_cfg.get("strategy", defaults.get("strategy", "ecdf"))
            out[spec.id] = {
                "normalization_strategy": strategy,
                "normalization_params": profile_cfg,
                "backend": spec.backend,
                "severity_mode": "fixed",
                "severity_thresholds": global_severity.get("quantile", {}),
                "fixed_thresholds": global_severity.get("fixed", {}),
                "model_version": spec.version_tag,
            }
        return out

    @staticmethod
    def _apply_analysis_field(series: pd.DataFrame, requested_field: str) -> tuple[pd.DataFrame, str]:
        field = str(requested_field or "value").strip()
        if field and field in series.columns:
            selected = field
        elif field == "shift" and "value" in series.columns:
            selected = "value"
            print("Warning: analysis field 'shift' not found. Falling back to 'value'.")
        elif "value" in series.columns:
            selected = "value"
            print(f"Warning: analysis field '{field}' not found. Falling back to 'value'.")
        else:
            raise ValueError(
                f"Requested analysis field '{field}' not found, and fallback 'value' is unavailable. "
                f"Available columns: {list(series.columns)}"
            )

        out = series.copy()
        out["value"] = pd.to_numeric(out[selected], errors="coerce")
        out = out.dropna(subset=["value", "date"]).reset_index(drop=True)
        if out.empty and selected != "value" and "value" in series.columns:
            print(
                f"Warning: analysis field '{selected}' produced no numeric rows. "
                "Falling back to 'value'."
            )
            selected = "value"
            out = series.copy()
            out["value"] = pd.to_numeric(out[selected], errors="coerce")
            out = out.dropna(subset=["value", "date"]).reset_index(drop=True)
        if out.empty:
            raise ValueError(f"No numeric rows available after applying analysis field '{selected}'.")
        return out, selected

    def _execute_per_series(
        self,
        check,
        data: pd.DataFrame,
        check_id: str,
        backend: str,
        family: str,
        series_semantics: str = "level",
    ) -> pd.DataFrame:
        parts = []
        for rf_id, series_df in data.groupby("risk_factor_id", sort=False):
            sdf = series_df.sort_values("date").reset_index(drop=True)
            context = {"risk_factor_id": rf_id, "series_semantics": series_semantics}
            state = check.fit(sdf, context)
            scored = check.score(sdf, context, state)
            scored["check_id"] = check_id
            scored["model_id"] = check_id
            scored["backend"] = backend
            scored["family"] = family
            parts.append(scored)
        return pd.concat(parts, ignore_index=True) if parts else pd.DataFrame()

    def _execute_per_peer_group(
        self,
        check,
        data: pd.DataFrame,
        membership: pd.DataFrame,
        peer_group_keys: list[str],
        check_id: str,
        backend: str,
        family: str,
        series_semantics: str = "level",
    ) -> pd.DataFrame:
        peer_keys = [c for c in peer_group_keys if c in membership.columns]
        if not peer_keys:
            peer_keys = [c for c in TAXONOMY_PEER_KEYS if c in membership.columns]
        m = membership[["risk_factor_id"] + peer_keys]
        merged = data.merge(m, on="risk_factor_id", how="left")
        parts = []
        group_keys = peer_keys
        for _, grp in merged.groupby(group_keys, dropna=False, sort=False):
            if grp["risk_factor_id"].nunique() < 3:
                for rf_id, sdf in grp.groupby("risk_factor_id", sort=False):
                    feat = self.feature_builder.build_features(sdf)
                    ctx = {"risk_factor_id": rf_id, "series_semantics": series_semantics}
                    state = check.fit(feat, ctx)
                    scored = check.score(feat, ctx, state)
                    scored["check_id"] = check_id
                    scored["model_id"] = check_id
                    scored["backend"] = backend
                    scored["family"] = family
                    parts.append(scored)
                continue
            feat_grp = self.feature_builder.build_batch(grp[["risk_factor_id", "date", "value"]], max_workers=4)
            ctx = {"peer_group": True, "series_semantics": series_semantics}
            state = check.fit(feat_grp, ctx)
            scored = check.score(feat_grp, ctx, state)
            scored["check_id"] = check_id
            scored["model_id"] = check_id
            scored["backend"] = backend
            scored["family"] = family
            parts.append(scored)
        return pd.concat(parts, ignore_index=True) if parts else pd.DataFrame()

    def _execute_global(
        self,
        check,
        data: pd.DataFrame,
        check_id: str,
        backend: str,
        family: str,
        series_semantics: str = "level",
    ) -> pd.DataFrame:
        feat = self.feature_builder.build_batch(data[["risk_factor_id", "date", "value"]], max_workers=4)
        ctx = {"global": True, "series_semantics": series_semantics}
        state = check.fit(feat, ctx)
        scored = check.score(feat, ctx, state)
        scored["check_id"] = check_id
        scored["model_id"] = check_id
        scored["backend"] = backend
        scored["family"] = family
        return scored

    @staticmethod
    def _preserve_raw_alert_flags(raw_results: pd.DataFrame, normalized: pd.DataFrame) -> pd.DataFrame:
        """Carry forward raw detector flag/severity into normalized frame."""
        if raw_results.empty or normalized.empty:
            return normalized
        keys = ["risk_factor_id", "date", "check_id"]
        if not set(keys).issubset(raw_results.columns) or not set(keys).issubset(normalized.columns):
            return normalized
        raw_flags = (
            raw_results[keys + [c for c in ["flag", "severity"] if c in raw_results.columns]]
            .drop_duplicates(subset=keys, keep="last")
            .rename(columns={"flag": "flag_raw", "severity": "severity_raw"})
        )
        out = normalized.merge(raw_flags, on=keys, how="left")
        if "flag" in out.columns:
            out["flag_normalized"] = out["flag"]
        if "severity" in out.columns:
            out["severity_normalized"] = out["severity"]
        if "flag_raw" in out.columns:
            out["flag"] = out["flag_raw"].fillna(out.get("flag", False)).astype(bool)
        if "severity_raw" in out.columns:
            out["severity"] = out["severity_raw"].fillna(out.get("severity", "Low")).astype(str)
        return out

    def run(self, request: RunRequest) -> dict[str, Any]:
        t0 = time.perf_counter()
        catalog = load_yaml(request.config_path)
        cfg_hash = config_hash(catalog)

        start_ts = pd.to_datetime(request.start_date)
        end_ts = pd.to_datetime(request.end_date)
        business_ts = pd.to_datetime(request.business_date or request.end_date).normalize()
        if request.incremental:
            prior = self.repository.get_series(None, request.start_date, request.end_date, business_date=business_ts)
            if not prior.empty:
                start_ts = min(start_ts, pd.to_datetime(prior["date"]).min())

        t_universe = time.perf_counter()
        membership = self._build_universe(catalog, request.universe_name)
        if membership.empty:
            raise ValueError(f"No risk factors found for universe '{request.universe_name}'.")
        membership = normalize_taxonomy_frame(membership, require_risk_factor_id=True)
        peer_cfg = resolve_peer_group_config(catalog, request.universe_name, membership=membership)
        membership, peer_group_keys = apply_peer_grouping(
            membership,
            peer_keys=peer_cfg.get("keys", TAXONOMY_PEER_KEYS),
            peer_rules=peer_cfg.get("rules", []),
        )
        risk_factor_ids = membership["risk_factor_id"].astype(str).tolist()
        membership = membership.copy()
        membership["business_date"] = business_ts
        self.repository.write_results(membership, "universe_membership", partition_cols=["business_date", "universe_name"])
        t_universe = time.perf_counter() - t_universe

        t_load = time.perf_counter()
        series = self.repository.get_series(risk_factor_ids, start_ts, end_ts, business_date=business_ts)
        if series.empty:
            raise ValueError("No time-series data returned for selected universe/date range.")
        series, resolved_analysis_field = self._apply_analysis_field(series, request.analysis_field)
        series_semantics = "shift" if str(resolved_analysis_field).strip().lower() == "shift" else "level"
        t_load = time.perf_counter() - t_load

        t_checks = time.perf_counter()
        specs = [s for s in self.registry.load_universe_specs(catalog, request.universe_name) if s.enabled]
        checks = {}
        for spec in specs:
            checks[spec.id] = self.registry.build_from_spec(spec, checks)
        raw_parts = []
        for spec in specs:
            check = checks[spec.id]
            if spec.fit_policy == "global":
                out = self._execute_global(
                    check, series, spec.id, spec.backend, spec.family, series_semantics=series_semantics
                )
            elif spec.fit_policy == "per_peer_group":
                out = self._execute_per_peer_group(
                    check,
                    series,
                    membership,
                    peer_group_keys,
                    spec.id,
                    spec.backend,
                    spec.family,
                    series_semantics=series_semantics,
                )
            else:
                out = self._execute_per_series(
                    check, series, spec.id, spec.backend, spec.family, series_semantics=series_semantics
                )
            out["run_id"] = request.run_id
            out["universe_name"] = request.universe_name
            out["business_date"] = business_ts
            raw_parts.append(out)
        raw_results = pd.concat(raw_parts, ignore_index=True) if raw_parts else pd.DataFrame()
        raw_flag_count = int(raw_results["flag"].fillna(False).astype(bool).sum()) if "flag" in raw_results.columns else 0
        t_checks = time.perf_counter() - t_checks

        t_norm = time.perf_counter()
        profiles = self._check_profiles(specs, catalog)
        normalized = normalize_results(
            results_df=raw_results,
            check_profiles=profiles,
            run_id=request.run_id,
            config_hash=cfg_hash,
            business_date=str(business_ts.date()),
            artifact_root=self.artifact_root,
        )
        if bool(request.preserve_check_flags):
            normalized = self._preserve_raw_alert_flags(raw_results=raw_results, normalized=normalized)
        normalized_flag_count = int(normalized["flag"].fillna(False).astype(bool).sum()) if "flag" in normalized.columns else 0
        t_norm = time.perf_counter() - t_norm

        t_triage = time.perf_counter()
        triage_cfg = catalog.get("triage", {}) if isinstance(catalog, dict) else {}
        supervised_cfg = triage_cfg.get("supervised", {}) if isinstance(triage_cfg, dict) else {}
        target_cfg = supervised_cfg.get("target", {}) if isinstance(supervised_cfg, dict) else {}
        target_label = str(request.triage_label_col or target_cfg.get("label_col", "is_false_alarm"))
        legacy_candidates = triage_cfg.get("supervised_candidates", ["xgboost", "lightgbm", "random_forest", "logistic_regression"])
        cfg_candidates = supervised_cfg.get("candidates", legacy_candidates)
        selected_candidates = list(cfg_candidates)
        cfg_calibration = (supervised_cfg.get("calibration", {}) or {}).get("method")
        calibration_method = str(cfg_calibration).strip().lower() if cfg_calibration is not None else ""
        if calibration_method in {"", "none"}:
            calibration_method = None

        event_calendar = pd.DataFrame(triage_cfg.get("event_calendar", []))
        triager = FalseAlarmReducer(
            regime_windows=catalog.get("globals", {}).get("regime_windows", []),
            peer_keys=peer_group_keys,
            event_calendar=event_calendar,
            event_window_days=int(triage_cfg.get("event_window_days", 1)),
            min_peer_group_size=int(triage_cfg.get("min_peer_group_size", 5)),
            peer_confirm_ratio=float(triage_cfg.get("peer_confirm_ratio", 0.60)),
            stress_threshold_multiplier=float(triage_cfg.get("stress_threshold_multiplier", 1.5)),
            supervised_candidates=selected_candidates,
            calibration_method=calibration_method,
            supervised_config=supervised_cfg,
        )
        membership_cols = ["risk_factor_id"] + [
            c for c in list(TAXONOMY_COLUMNS) + list(peer_group_keys) if c in membership.columns
        ]
        triaged, triage_audit = triager.run(
            alerts_df=normalized.merge(membership[membership_cols], on="risk_factor_id", how="left"),
            raw_df=series,
            membership=membership[membership_cols],
            with_supervised=bool(request.with_supervised_triage),
            label_col=target_label,
        )
        t_triage = time.perf_counter() - t_triage

        result_cols = [
            "run_id",
            "universe_name",
            "business_date",
            "risk_factor_id",
            "date",
            "check_id",
            "model_id",
            "backend",
            "family",
            "raw_score",
            "norm_score",
            "threshold",
            "flag",
            "severity",
            "severity_score_100",
            "reason_code",
            "explain",
            "artifacts_json",
            "peer_confirmed",
            "peer_confidence",
            "regime_tag",
            "confidence_estimate",
            "recommended_action",
            "decision_policy_reason",
            "false_alarm_probability",
            "p_bad_data",
            "is_false_alarm_pred",
            "event_proximate",
            "peer_flag_ratio",
            "peer_corr_60d",
            "triage_artifacts_json",
        ]
        triaged = triaged.reindex(columns=result_cols)
        triaged = triaged.sort_values(["business_date", "risk_factor_id", "date", "check_id"]).reset_index(drop=True)
        triaged_flag_count = int(triaged["flag"].fillna(False).astype(bool).sum()) if "flag" in triaged.columns else 0

        self.repository.write_results(
            triaged,
            table_name="dq_results",
            partition_cols=["business_date", "universe_name", "check_id"],
        )

        triage_model_df = pd.DataFrame([triage_audit.get("triage_model", {})])
        if not triage_model_df.empty:
            triage_model_df["run_id"] = request.run_id
            triage_model_df["universe_name"] = request.universe_name
            triage_model_df["business_date"] = business_ts
            self.repository.write_results(
                triage_model_df,
                table_name="triage_model",
                partition_cols=["business_date", "universe_name"],
            )

        fi_global_df = pd.DataFrame(triage_audit.get("feature_importance_global", []))
        if not fi_global_df.empty:
            fi_global_df["run_id"] = request.run_id
            fi_global_df["universe_name"] = request.universe_name
            fi_global_df["business_date"] = business_ts
            self.repository.write_results(
                fi_global_df,
                table_name="feature_importance_global",
                partition_cols=["business_date", "universe_name"],
            )

        fi_local_df = pd.DataFrame(triage_audit.get("feature_importance_local", []))
        if not fi_local_df.empty:
            fi_local_df["run_id"] = request.run_id
            fi_local_df["universe_name"] = request.universe_name
            fi_local_df["business_date"] = business_ts
            self.repository.write_results(
                fi_local_df,
                table_name="feature_importance_local",
                partition_cols=["business_date", "universe_name"],
            )

        fi_summary_df = pd.DataFrame([triage_audit.get("feature_importance_summary", {})])
        if not fi_summary_df.empty:
            fi_summary_df["run_id"] = request.run_id
            fi_summary_df["universe_name"] = request.universe_name
            fi_summary_df["business_date"] = business_ts
            self.repository.write_results(
                fi_summary_df,
                table_name="feature_importance_summary",
                partition_cols=["business_date", "universe_name"],
            )

        audit_log = pd.DataFrame(
            [
                {
                    "run_id": request.run_id,
                    "universe_name": request.universe_name,
                    "business_date": str(business_ts.date()),
                    "start_date": str(start_ts.date()),
                    "end_date": str(end_ts.date()),
                    "config_hash": cfg_hash,
                    "row_count_series": int(len(series)),
                    "row_count_results": int(len(triaged)),
                    "stage_universe_sec": t_universe,
                    "stage_load_sec": t_load,
                    "stage_checks_sec": t_checks,
                    "stage_normalization_sec": t_norm,
                    "stage_triage_sec": t_triage,
                    "peer_group_keys": json.dumps(peer_group_keys),
                    "peer_group_source": str(peer_cfg.get("source", "default")),
                    "preserve_check_flags": bool(request.preserve_check_flags),
                    "analysis_field_requested": str(request.analysis_field),
                    "analysis_field_used": str(resolved_analysis_field),
                    "raw_flag_count": raw_flag_count,
                    "normalized_flag_count": normalized_flag_count,
                    "triaged_flag_count": triaged_flag_count,
                    "elapsed_sec": time.perf_counter() - t0,
                    "triage_audit": json.dumps(triage_audit, default=str),
                }
            ]
        )
        self.repository.write_results(audit_log, "audit_log", partition_cols=["business_date", "universe_name"])
        return {"results": triaged, "audit_log": audit_log}
