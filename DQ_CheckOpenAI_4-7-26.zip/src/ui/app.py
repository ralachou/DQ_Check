from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

import dash
import dash_ag_grid as dag
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from dash import Dash, Input, Output, State, dcc, html

from common.taxonomy import DEFAULT_NULL_TOKEN, normalize_taxonomy_frame
from dq_checks.taxonomy import canonicalize_family

PROJECT_ROOT = Path(__file__).resolve().parents[2]


def _normalize_business_dates(business_date: str | list[str] | tuple[str, ...] | None) -> list[str]:
    if business_date is None:
        return []
    if isinstance(business_date, (list, tuple)):
        vals = business_date
    else:
        vals = [business_date]
    out: list[str] = []
    for v in vals:
        if v is None:
            continue
        text = str(v).strip()
        if not text:
            continue
        out.append(str(pd.to_datetime(text).normalize().date()))
    return sorted(set(out))


def _read_parquet_dir(path: str | Path, business_date: str | list[str] | tuple[str, ...] | None = None) -> pd.DataFrame:
    root = Path(path)
    if not root.exists():
        return pd.DataFrame()
    business_dates = _normalize_business_dates(business_date)
    if root.is_file():
        try:
            part = pd.read_parquet(root)
        except Exception:
            return pd.DataFrame()
        if business_dates and "business_date" in part.columns:
            keep = set(business_dates)
            part = part[pd.to_datetime(part["business_date"], errors="coerce").dt.strftime("%Y-%m-%d").isin(keep)]
        return part
    filters = None
    if business_dates:
        if len(business_dates) == 1:
            filters = [("business_date", "==", business_dates[0])]
        else:
            filters = [("business_date", "in", business_dates)]
    # Preferred path: read as a partitioned dataset so partition keys
    # (e.g., run_id/universe_name/check_id) are materialized as columns.
    try:
        if filters is None:
            df = pd.read_parquet(root)
        else:
            df = pd.read_parquet(root, filters=filters)
        if not df.empty:
            return df
    except Exception:
        pass

    files: list[Path] = []
    if business_dates:
        for bd in business_dates:
            part_root = root / f"business_date={bd}"
            if part_root.exists():
                files.extend(part_root.rglob("*.parquet"))
        if not files:
            files = list(root.rglob("*.parquet"))
    else:
        files = list(root.rglob("*.parquet"))
    if not files:
        return pd.DataFrame()

    parts = []
    for f in files:
        part = pd.read_parquet(f)
        # Fallback path: recover hive-style partition columns from the path.
        rel_parts = f.relative_to(root).parts[:-1]
        for segment in rel_parts:
            if "=" in segment:
                key, value = segment.split("=", 1)
                if key and key not in part.columns:
                    part[key] = value
        if business_dates and "business_date" in part.columns:
            keep = set(business_dates)
            part = part[pd.to_datetime(part["business_date"], errors="coerce").dt.strftime("%Y-%m-%d").isin(keep)]
        parts.append(part)
    if not parts:
        return pd.DataFrame()
    return pd.concat(parts, ignore_index=True)


def load_data(
    results_path: str,
    raw_path: str,
    membership_path: str,
    business_date: str | list[str] | tuple[str, ...] | None = None,
) -> dict[str, pd.DataFrame]:
    business_dates = _normalize_business_dates(business_date)
    dq_results = _read_parquet_dir(results_path, business_dates)
    timeseries_raw = _read_parquet_dir(raw_path, business_dates)
    membership = _read_parquet_dir(membership_path, business_dates)
    for df in [dq_results, timeseries_raw, membership]:
        if "date" in df.columns:
            df["date"] = pd.to_datetime(df["date"])
        if "business_date" in df.columns:
            df["business_date"] = pd.to_datetime(df["business_date"]).dt.normalize()
            if business_dates:
                keep_ts = {pd.to_datetime(v).normalize() for v in business_dates}
                df.drop(df.index[~df["business_date"].isin(keep_ts)], inplace=True)
    return {"dq_results": dq_results, "timeseries_raw": timeseries_raw, "membership": membership}


def _scan_parquet_path(path: str | Path, business_dates: list[str]) -> dict[str, Any]:
    root = Path(path)
    info: dict[str, Any] = {
        "path": str(root),
        "exists": root.exists(),
    }
    if not root.exists():
        return info
    info["kind"] = "file" if root.is_file() else "directory"
    if root.is_file():
        try:
            info["size_bytes"] = int(root.stat().st_size)
        except Exception:
            info["size_bytes"] = None
        return info

    try:
        all_files = list(root.rglob("*.parquet"))
        info["parquet_files_total"] = len(all_files)
    except Exception:
        info["parquet_files_total"] = None
    if business_dates:
        scoped = 0
        found_partitions: list[str] = []
        for bd in business_dates:
            part_root = root / f"business_date={bd}"
            if part_root.exists():
                found_partitions.append(str(part_root))
                try:
                    scoped += len(list(part_root.rglob("*.parquet")))
                except Exception:
                    pass
        info["business_date_partitions_found"] = found_partitions
        info["parquet_files_in_business_date_partitions"] = scoped
    return info


def _frame_snapshot(df: pd.DataFrame) -> dict[str, Any]:
    out: dict[str, Any] = {
        "rows": int(df.shape[0]),
        "cols": int(df.shape[1]),
        "columns": [str(c) for c in df.columns[:20].tolist()],
    }
    if "business_date" in df.columns and not df.empty:
        b = pd.to_datetime(df["business_date"].astype(str), errors="coerce").dropna()
        if not b.empty:
            out["business_date_min"] = str(b.min().date())
            out["business_date_max"] = str(b.max().date())
            out["business_date_unique_sample"] = sorted(b.dt.strftime("%Y-%m-%d").unique().tolist())[:10]
    if "date" in df.columns and not df.empty:
        d = pd.to_datetime(df["date"].astype(str), errors="coerce").dropna()
        if not d.empty:
            out["date_min"] = str(d.min().date())
            out["date_max"] = str(d.max().date())
    return out


def load_data_with_debug(
    results_path: str,
    raw_path: str,
    membership_path: str,
    business_date: str | list[str] | tuple[str, ...] | None = None,
) -> tuple[dict[str, pd.DataFrame], dict[str, Any]]:
    business_dates = _normalize_business_dates(business_date)
    report: dict[str, Any] = {
        "business_dates_requested": business_dates,
        "sources": {},
        "final": {},
        "hints": [],
    }
    sources = {
        "dq_results": results_path,
        "timeseries_raw": raw_path,
        "membership": membership_path,
    }
    for name, src in sources.items():
        src_info = _scan_parquet_path(src, business_dates)
        unfiltered = _read_parquet_dir(src, None)
        filtered = _read_parquet_dir(src, business_dates)
        src_info["unfiltered_snapshot"] = _frame_snapshot(unfiltered)
        src_info["filtered_snapshot"] = _frame_snapshot(filtered)
        if business_dates and unfiltered.shape[0] > 0 and filtered.shape[0] == 0:
            if "business_date" not in unfiltered.columns:
                report["hints"].append(f"{name}: no business_date column; filtering by --business-date cannot be applied.")
            else:
                report["hints"].append(f"{name}: rows exist unfiltered but zero after business_date filter; verify requested date exists.")
        report["sources"][name] = src_info

    data = load_data(results_path, raw_path, membership_path, business_date=business_dates)
    for name, df in data.items():
        report["final"][name] = _frame_snapshot(df)
    if data["dq_results"].empty:
        report["hints"].append("dq_results is empty after load; most UI tabs will be empty.")
    if data["membership"].empty:
        report["hints"].append("membership is empty after load; hierarchy/tree tabs will be empty.")
    return data, report


def _empty_fig(title: str) -> go.Figure:
    fig = go.Figure()
    fig.update_layout(title=title, template="plotly_white", xaxis={"visible": False}, yaxis={"visible": False})
    return fig


def create_app(data: dict[str, pd.DataFrame]) -> Dash:
    dq_results = normalize_taxonomy_frame(data["dq_results"], require_risk_factor_id=False)
    timeseries_raw = data["timeseries_raw"]
    membership = normalize_taxonomy_frame(data["membership"], require_risk_factor_id=False)
    if "family" in dq_results.columns:
        dq_results = dq_results.copy()
        dq_results["family"] = dq_results["family"].astype(str).map(lambda x: canonicalize_family(x))
    asset_classes = sorted(membership.get("asset_class", pd.Series(dtype=str)).dropna().unique().tolist())
    universes = sorted(dq_results.get("universe_name", pd.Series(dtype=str)).dropna().unique().tolist())
    families = sorted(dq_results.get("family", pd.Series(dtype=str)).dropna().unique().tolist())
    checks = sorted(dq_results.get("check_id", pd.Series(dtype=str)).dropna().unique().tolist())
    severities = ["Low", "Med", "High", "Critical"]

    app = Dash(__name__)
    app.layout = html.Div(
        [
            html.H2("Advanced DQ Checks on RF"),
            dcc.Store(id="store-state", data={"selected_risk_factor_id": None}),
            html.Div(
                [
                    dcc.Dropdown(id="filter-asset-class", options=[{"label": x, "value": x} for x in asset_classes], multi=True, placeholder="Asset class"),
                    dcc.Dropdown(id="filter-universe", options=[{"label": x, "value": x} for x in universes], multi=True, placeholder="Universe"),
                    dcc.Dropdown(id="filter-family", options=[{"label": x, "value": x} for x in families], multi=True, placeholder="Model family"),
                    dcc.Dropdown(id="filter-check-id", options=[{"label": x, "value": x} for x in checks], multi=True, placeholder="Check/model ID"),
                    dcc.Dropdown(id="filter-severity", options=[{"label": x, "value": x} for x in severities], multi=True, placeholder="Severity"),
                    dcc.DatePickerRange(id="filter-date-range"),
                ],
                style={"display": "grid", "gridTemplateColumns": "repeat(6, minmax(160px, 1fr))", "gap": "8px", "marginBottom": "12px"},
            ),
            dcc.Tabs(
                id="tabs-main",
                value="tab-summary",
                children=[
                    dcc.Tab(
                        label="Summary",
                        value="tab-summary",
                        children=[
                            html.Div(id="summary-kpis", style={"display": "grid", "gridTemplateColumns": "repeat(4, 1fr)", "gap": "8px", "margin": "8px 0"}),
                            dcc.Graph(id="summary-alerts-over-time"),
                            dcc.Graph(id="summary-breakdown"),
                            dcc.Graph(id="summary-heatmap"),
                        ],
                    ),
                    dcc.Tab(
                        label="Hierarchy Drilldown",
                        value="tab-drilldown",
                        children=[
                            dag.AgGrid(
                                id="drilldown-tree",
                                columnDefs=[
                                    {"field": "hierarchy", "headerName": "Hierarchy"},
                                    {"field": "risk_factor_id"},
                                    {"field": "rf_level1"},
                                    {"field": "rf_level2"},
                                    {"field": "rf_level3"},
                                    {"field": "rf_level4"},
                                    {"field": "rf_level5"},
                                ],
                                rowData=[],
                                defaultColDef={"flex": 1, "sortable": True, "filter": True, "resizable": True},
                                dashGridOptions={
                                    "treeData": True,
                                    "animateRows": True,
                                    "getDataPath": {"function": "getDataPath(params.data)"},
                                    "autoGroupColumnDef": {"headerName": "Hierarchy", "minWidth": 280},
                                    "rowSelection": "single",
                                },
                                style={"height": 360},
                            ),
                            dcc.Graph(id="drilldown-series"),
                            dag.AgGrid(
                                id="drilldown-issues",
                                columnDefs=[
                                    {"field": "date"},
                                    {"field": "check_id"},
                                    {"field": "raw_score"},
                                    {"field": "norm_score"},
                                    {"field": "severity"},
                                    {"field": "reason_code"},
                                ],
                                rowData=[],
                                defaultColDef={"flex": 1, "sortable": True, "filter": True, "resizable": True},
                                style={"height": 280},
                            ),
                            dcc.Graph(id="drilldown-model-overlay"),
                        ],
                    ),
                    dcc.Tab(
                        label="Model Comparison",
                        value="tab-model-compare",
                        children=[
                            html.Div(
                                [
                                    dcc.Dropdown(id="compare-models", multi=True, placeholder="Select checks/models"),
                                    dcc.DatePickerRange(id="compare-date-range"),
                                ],
                                style={"display": "grid", "gridTemplateColumns": "2fr 1fr", "gap": "8px", "margin": "8px 0"},
                            ),
                            dag.AgGrid(
                                id="compare-ranked",
                                columnDefs=[
                                    {"field": "risk_factor_id"},
                                    {"field": "check_id"},
                                    {"field": "max_norm_score"},
                                    {"field": "max_severity"},
                                    {"field": "alerts"},
                                ],
                                rowData=[],
                                defaultColDef={"flex": 1, "sortable": True, "filter": True, "resizable": True},
                                style={"height": 320},
                            ),
                            dcc.Graph(id="compare-overlap"),
                            dcc.Graph(id="compare-severity-dist"),
                        ],
                    ),
                ],
            ),
        ],
        style={"padding": "12px"},
    )

    app.clientside_callback(
        """
        function(rows, state) {
            if (!rows || rows.length === 0) { return window.dash_clientside.no_update; }
            const cur = state || {};
            cur.selected_risk_factor_id = rows[0].risk_factor_id;
            return cur;
        }
        """,
        Output("store-state", "data", allow_duplicate=True),
        Input("drilldown-tree", "selectedRows"),
        State("store-state", "data"),
        prevent_initial_call=True,
    )

    @app.callback(
        Output("store-state", "data", allow_duplicate=True),
        Input("filter-asset-class", "value"),
        Input("filter-universe", "value"),
        Input("filter-family", "value"),
        Input("filter-check-id", "value"),
        Input("filter-severity", "value"),
        Input("filter-date-range", "start_date"),
        Input("filter-date-range", "end_date"),
        State("store-state", "data"),
        prevent_initial_call=True,
    )
    def sync_filter_state(
        asset_class_v: list[str] | None,
        universe_v: list[str] | None,
        family_v: list[str] | None,
        check_id_v: list[str] | None,
        severity_v: list[str] | None,
        start_date: str | None,
        end_date: str | None,
        state: dict[str, Any] | None,
    ) -> dict[str, Any]:
        cur = dict(state or {})
        cur["filters"] = {
            "asset_class": asset_class_v or [],
            "universe": universe_v or [],
            "family": family_v or [],
            "check_id": check_id_v or [],
            "severity": severity_v or [],
            "start_date": start_date,
            "end_date": end_date,
        }
        return cur

    @app.callback(
        Output("summary-kpis", "children"),
        Output("summary-alerts-over-time", "figure"),
        Output("summary-breakdown", "figure"),
        Output("summary-heatmap", "figure"),
        Output("drilldown-tree", "rowData"),
        Input("store-state", "data"),
    )
    def refresh_summary(state: dict[str, Any] | None):
        filters = (state or {}).get("filters", {})
        asset_class_v = filters.get("asset_class") or []
        universe_v = filters.get("universe") or []
        family_v = filters.get("family") or []
        check_id_v = filters.get("check_id") or []
        severity_v = filters.get("severity") or []
        start_date = filters.get("start_date")
        end_date = filters.get("end_date")
        res = dq_results.copy()
        mem = membership.copy()
        if len(asset_class_v) > 0 and "asset_class" in mem.columns:
            mem = mem[mem["asset_class"].isin(asset_class_v)]
            res = res[res["risk_factor_id"].isin(mem["risk_factor_id"])]
        if len(universe_v) > 0 and "universe_name" in res.columns:
            res = res[res["universe_name"].isin(universe_v)]
        if len(family_v) > 0 and "family" in res.columns:
            res = res[res["family"].isin(family_v)]
        if len(check_id_v) > 0 and "check_id" in res.columns:
            res = res[res["check_id"].isin(check_id_v)]
        if len(severity_v) > 0 and "severity" in res.columns:
            res = res[res["severity"].isin(severity_v)]
        if start_date:
            res = res[res["date"] >= pd.to_datetime(start_date)]
        if end_date:
            res = res[res["date"] <= pd.to_datetime(end_date)]

        total_series = int(mem["risk_factor_id"].nunique()) if not mem.empty else 0
        total_alerts = int(res["flag"].sum()) if "flag" in res.columns else 0
        critical_alerts = int(((res["severity"] == "Critical") & (res["flag"])).sum()) if "severity" in res.columns else 0
        checks_covered = int(res["check_id"].nunique()) if "check_id" in res.columns else 0
        kpis = [
            html.Div([html.B("Total Series"), html.Div(f"{total_series:,}")], style={"border": "1px solid #ddd", "padding": "8px"}),
            html.Div([html.B("Alerts"), html.Div(f"{total_alerts:,}")], style={"border": "1px solid #ddd", "padding": "8px"}),
            html.Div([html.B("Critical"), html.Div(f"{critical_alerts:,}")], style={"border": "1px solid #ddd", "padding": "8px"}),
            html.Div([html.B("Checks"), html.Div(f"{checks_covered:,}")], style={"border": "1px solid #ddd", "padding": "8px"}),
        ]

        if res.empty:
            return kpis, _empty_fig("Alerts Over Time"), _empty_fig("Breakdown"), _empty_fig("Asset Class x Currency"), []

        alerts_ts = res[res["flag"]].groupby("date", as_index=False).size().rename(columns={"size": "alerts"})
        fig_alerts = px.line(alerts_ts, x="date", y="alerts", title="Alerts Over Time")

        if "asset_class" not in res.columns and not mem.empty:
            res = res.merge(
                mem[["risk_factor_id", "asset_class", "ccy", "rf_level1", "rf_level2", "rf_level3", "rf_level4", "rf_level5"]],
                on="risk_factor_id",
                how="left",
            )

        breakdown = (
            res[res["flag"]]
            .groupby(["asset_class", "family"], as_index=False)
            .size()
            .rename(columns={"size": "alerts"})
        )
        fig_breakdown = px.bar(breakdown, x="asset_class", y="alerts", color="family", barmode="group", title="Alert Breakdown")

        heat = (
            res[res["flag"]]
            .groupby(["asset_class", "ccy"], as_index=False)
            .size()
            .rename(columns={"size": "alerts"})
        )
        fig_heat = px.density_heatmap(heat, x="asset_class", y="ccy", z="alerts", title="Alerts Heatmap (Asset Class x Currency)")

        tree_src = mem.copy()
        if not tree_src.empty:
            tree_src["hierarchy"] = tree_src.apply(
                lambda r: [str(r.get("asset_class", DEFAULT_NULL_TOKEN)), str(r.get("ccy", DEFAULT_NULL_TOKEN)), str(r.get("rf_level1", DEFAULT_NULL_TOKEN)), str(r.get("rf_level2", DEFAULT_NULL_TOKEN)), str(r.get("rf_level3", DEFAULT_NULL_TOKEN)), str(r.get("rf_level4", DEFAULT_NULL_TOKEN)), str(r.get("rf_level5", DEFAULT_NULL_TOKEN)), str(r.get("risk_factor_id"))],
                axis=1,
            )
        return kpis, fig_alerts, fig_breakdown, fig_heat, tree_src.to_dict("records")

    @app.callback(
        Output("drilldown-series", "figure"),
        Output("drilldown-issues", "rowData"),
        Output("drilldown-model-overlay", "figure"),
        Input("store-state", "data"),
    )
    def refresh_drilldown(state: dict[str, Any]):
        rf_id = (state or {}).get("selected_risk_factor_id")
        if not rf_id:
            return _empty_fig("Select a risk factor from the tree"), [], _empty_fig("Model overlay")
        ts = timeseries_raw[timeseries_raw["risk_factor_id"] == rf_id].sort_values("date")
        issues = dq_results[(dq_results["risk_factor_id"] == rf_id) & (dq_results["flag"])].sort_values("date")
        if ts.empty:
            return _empty_fig(f"No time series for {rf_id}"), issues.to_dict("records"), _empty_fig("Model overlay")
        fig_ts = go.Figure()
        fig_ts.add_trace(go.Scatter(x=ts["date"], y=ts["value"], mode="lines", name="value"))
        if not issues.empty:
            ts_join = ts.merge(issues[["date", "check_id", "severity", "norm_score"]], on="date", how="inner")
            fig_ts.add_trace(
                go.Scatter(
                    x=ts_join["date"],
                    y=ts_join["value"],
                    mode="markers",
                    marker={"size": 7, "color": ts_join["norm_score"], "colorscale": "Reds", "showscale": True},
                    text=ts_join["check_id"].astype(str) + " | " + ts_join["severity"].astype(str),
                    name="flags",
                )
            )
        fig_ts.update_layout(template="plotly_white", title=f"Time Series with Flags: {rf_id}")

        overlay = dq_results[dq_results["risk_factor_id"] == rf_id].copy()
        if overlay.empty:
            return fig_ts, issues.to_dict("records"), _empty_fig("Model overlay")
        fig_overlay = px.scatter(
            overlay,
            x="date",
            y="norm_score",
            color="check_id",
            symbol="severity",
            title=f"Model Comparison Overlay: {rf_id}",
        )
        return fig_ts, issues.to_dict("records"), fig_overlay

    @app.callback(
        Output("compare-models", "options"),
        Output("compare-ranked", "rowData"),
        Output("compare-overlap", "figure"),
        Output("compare-severity-dist", "figure"),
        Input("compare-models", "value"),
        Input("compare-date-range", "start_date"),
        Input("compare-date-range", "end_date"),
    )
    def refresh_model_compare(selected_models: list[str] | None, start_date: str | None, end_date: str | None):
        res = dq_results.copy()
        if start_date:
            res = res[res["date"] >= pd.to_datetime(start_date)]
        if end_date:
            res = res[res["date"] <= pd.to_datetime(end_date)]
        model_options = [{"label": m, "value": m} for m in sorted(res.get("check_id", pd.Series(dtype=str)).dropna().unique().tolist())]
        if selected_models:
            res = res[res["check_id"].isin(selected_models)]
        flagged = res[res["flag"]] if "flag" in res.columns else pd.DataFrame()
        if flagged.empty:
            return model_options, [], _empty_fig("Overlap"), _empty_fig("Severity Distribution")

        ranked = (
            flagged.groupby(["risk_factor_id", "check_id"], as_index=False)
            .agg(max_norm_score=("norm_score", "max"), max_severity=("severity", "max"), alerts=("date", "count"))
            .sort_values("max_norm_score", ascending=False)
            .head(500)
        )

        overlap = (
            flagged.groupby(["date", "check_id"], as_index=False)["risk_factor_id"]
            .nunique()
            .rename(columns={"risk_factor_id": "flagged_series"})
        )
        fig_overlap = px.line(overlap, x="date", y="flagged_series", color="check_id", title="Model Overlap Through Time")

        sev = (
            flagged.groupby(["check_id", "severity"], as_index=False)
            .size()
            .rename(columns={"size": "count"})
        )
        fig_sev = px.bar(sev, x="check_id", y="count", color="severity", title="Severity Distribution by Model")

        return model_options, ranked.to_dict("records"), fig_overlap, fig_sev

    return app


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run Dash UI for Advanced DQ Checks on RF.")
    parser.add_argument("--results-path", default=str(PROJECT_ROOT / "data" / "processed" / "dq_results"))
    parser.add_argument("--raw-path", default=str(PROJECT_ROOT / "data" / "raw" / "timeseries_raw"))
    parser.add_argument("--membership-path", default=str(PROJECT_ROOT / "data" / "processed" / "universe_membership"))
    parser.add_argument("--business-date", default="", help="Optional business_date filter (YYYY-MM-DD) applied at load time.")
    parser.add_argument("--debug-load", action="store_true", help="Print detailed loader diagnostics before launching UI.")
    parser.add_argument("--debug-load-only", action="store_true", help="Print loader diagnostics and exit.")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8050)
    parser.add_argument("--debug", action="store_true")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    if args.debug_load or args.debug_load_only:
        data, report = load_data_with_debug(
            args.results_path,
            args.raw_path,
            args.membership_path,
            business_date=args.business_date or None,
        )
        print(json.dumps(report, indent=2))
        if args.debug_load_only:
            return
    else:
        data = load_data(
            args.results_path,
            args.raw_path,
            args.membership_path,
            business_date=args.business_date or None,
        )
    app = create_app(data)
    app.run(host=args.host, port=args.port, debug=args.debug)


if __name__ == "__main__":
    main()
