from __future__ import annotations

import argparse
import json
import re
import sqlite3
from datetime import datetime
from pathlib import Path
from typing import Any

import pandas as pd

from common.driver_name_parser import parse_driver_names
from common.taxonomy import DEFAULT_NULL_TOKEN, normalize_taxonomy_frame

PROJECT_ROOT = Path(__file__).resolve().parents[2]

COLUMN_CANDIDATES: dict[str, list[str]] = {
    "business_date": ["runDate", "businessDate", "business_date"],
    "risk_factor_id": ["driverName", "risk_factor_id"],
    "date": ["closeDate", "date"],
    "shift": ["shift", "shifts"],
    "pre_close_value": ["preCloseValue", "prevCloseValue", "pre_close_value"],
    "close_value": ["closeValue", "close_value", "value"],
    "holding_period": ["holdingPeriod", "holding_period"],
}
REQUIRED_CANONICAL_COLUMNS = ["business_date", "risk_factor_id", "date", "close_value"]
DRIVER_MAP_REQUIRED = [
    "risk_factor_id",
    "asset_class",
    "ccy",
    "rf_level1",
    "rf_level2",
    "rf_level3",
    "rf_level4",
    "rf_level5",
]


def _safe_table_name(table_name: str) -> str:
    if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", table_name):
        raise ValueError(f"Unsafe table name '{table_name}'. Use letters, numbers, and underscores only.")
    return table_name


def _normalize_colname(value: str) -> str:
    return str(value).strip().lower()


def _find_first_column(df: pd.DataFrame, candidates: list[str]) -> str | None:
    lower_map = {_normalize_colname(c): str(c) for c in df.columns}
    for c in candidates:
        key = _normalize_colname(c)
        if key in lower_map:
            return lower_map[key]
    return None


def _resolve_source_columns(df: pd.DataFrame) -> dict[str, str | None]:
    lower_map = {_normalize_colname(c): str(c) for c in df.columns}
    out: dict[str, str | None] = {}
    for canonical, candidates in COLUMN_CANDIDATES.items():
        source_col = None
        for candidate in candidates:
            key = _normalize_colname(candidate)
            if key in lower_map:
                source_col = lower_map[key]
                break
        out[canonical] = source_col
    return out


def _load_driver_map_file(path: str | Path) -> pd.DataFrame:
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"Driver mapping file not found: {p}")
    suffix = p.suffix.lower()
    if suffix == ".parquet":
        return pd.read_parquet(p)
    if suffix in {".xlsx", ".xls"}:
        return pd.read_excel(p)
    if suffix == ".csv":
        return pd.read_csv(p)
    raise ValueError(f"Unsupported driver mapping format '{suffix}'. Use parquet/excel/csv.")


def _normalize_driver_map_columns(df: pd.DataFrame) -> pd.DataFrame:
    colmap = {
        "risk_factor_id": ["risk_factor_id", "driverName", "driver_name"],
        "asset_class": ["asset_class", "assetClass", "rf_level1"],
        "ccy": ["ccy", "currency", "rf_level2"],
        "rf_level1": ["rf_level1", "assetClass", "asset_class"],
        "rf_level2": ["rf_level2", "ccy", "currency"],
        "rf_level3": ["rf_level3"],
        "rf_level4": ["rf_level4"],
        "rf_level5": ["rf_level5"],
    }
    out = pd.DataFrame()
    for target, candidates in colmap.items():
        src = _find_first_column(df, candidates)
        out[target] = df[src] if src else pd.NA

    missing = [c for c in DRIVER_MAP_REQUIRED if c in {"risk_factor_id", "rf_level3"} and out[c].isna().all()]
    if missing:
        raise ValueError(
            "Driver mapping is missing required columns/values for "
            f"{missing}. Required columns: {DRIVER_MAP_REQUIRED}"
        )

    for col in DRIVER_MAP_REQUIRED:
        out[col] = out[col].astype("string").fillna(DEFAULT_NULL_TOKEN).str.strip()
    out = normalize_taxonomy_frame(out, require_risk_factor_id=True)
    out = out[out["risk_factor_id"].astype(str).str.len() > 0].copy()
    out = out.drop_duplicates(subset=["risk_factor_id"]).reset_index(drop=True)
    return out[DRIVER_MAP_REQUIRED]


def _build_driver_map(
    driver_names: set[str],
    driver_map_path: str,
) -> tuple[pd.DataFrame, str]:
    if str(driver_map_path).strip():
        raw_map = _load_driver_map_file(driver_map_path)
        normalized = _normalize_driver_map_columns(raw_map)
        source = f"external_file:{Path(driver_map_path).name}"
        return normalized, source

    # Fallback only when no external map is provided.
    parsed = parse_driver_names(sorted(driver_names), rules_path=None).rename(columns={"assetClass": "asset_class"})
    parsed["asset_class"] = parsed["asset_class"].fillna(parsed["rf_level1"])
    parsed = parsed[DRIVER_MAP_REQUIRED].copy()
    return parsed, "fallback_internal_parser"


def _canonicalize_chunk(
    chunk: pd.DataFrame,
    source_cols: dict[str, str | None],
    allow_missing_shift: bool,
) -> pd.DataFrame:
    missing_required = [c for c in REQUIRED_CANONICAL_COLUMNS if source_cols.get(c) is None]
    if missing_required:
        raise ValueError(
            "Source query result is missing required columns "
            f"{missing_required}. Returned columns: {list(chunk.columns)}"
        )
    if source_cols.get("shift") is None and not allow_missing_shift:
        raise ValueError(
            "Source query result does not include 'shift'. "
            "Use --allow-missing-shift only if you intentionally want value-only analysis."
        )

    out = pd.DataFrame()
    out["business_date"] = chunk[source_cols["business_date"]]  # type: ignore[index]
    out["risk_factor_id"] = chunk[source_cols["risk_factor_id"]]  # type: ignore[index]
    out["date"] = chunk[source_cols["date"]]  # type: ignore[index]
    out["close_value"] = chunk[source_cols["close_value"]]  # type: ignore[index]
    out["value"] = out["close_value"]
    out["shift"] = chunk[source_cols["shift"]] if source_cols["shift"] else pd.NA
    out["pre_close_value"] = chunk[source_cols["pre_close_value"]] if source_cols["pre_close_value"] else pd.NA
    out["holding_period"] = chunk[source_cols["holding_period"]] if source_cols["holding_period"] else pd.NA

    out["business_date"] = pd.to_datetime(out["business_date"], errors="coerce").dt.normalize()
    out["risk_factor_id"] = out["risk_factor_id"].astype("string").str.strip()
    out["date"] = pd.to_datetime(out["date"], errors="coerce")
    out["close_value"] = pd.to_numeric(out["close_value"], errors="coerce")
    out["value"] = pd.to_numeric(out["value"], errors="coerce")
    out["shift"] = pd.to_numeric(out["shift"], errors="coerce")
    out["pre_close_value"] = pd.to_numeric(out["pre_close_value"], errors="coerce")
    out["holding_period"] = out["holding_period"].astype("string")

    out = out.dropna(subset=["business_date", "risk_factor_id", "date"]).copy()
    out = out[out["risk_factor_id"].str.len() > 0]
    return out.reset_index(drop=True)


def _write_partitioned_timeseries(chunk: pd.DataFrame, output_root: Path, chunk_index: int) -> dict[str, int]:
    chunk = chunk.copy()
    chunk["business_date"] = pd.to_datetime(chunk["business_date"]).dt.strftime("%Y-%m-%d")
    summary: dict[str, int] = {}
    for part_index, (biz_date, part) in enumerate(chunk.groupby("business_date", sort=False), start=1):
        part_root = output_root / f"business_date={biz_date}"
        part_root.mkdir(parents=True, exist_ok=True)
        file_path = part_root / f"part-{chunk_index:06d}-{part_index:03d}.parquet"
        payload = part.drop(columns=["business_date"], errors="ignore")
        payload.to_parquet(file_path, index=False)
        summary[biz_date] = summary.get(biz_date, 0) + len(payload)
    return summary


def _write_excel_preview(
    sample_df: pd.DataFrame,
    metadata_df: pd.DataFrame,
    driver_map_df: pd.DataFrame,
    output_root: Path,
) -> dict[str, str]:
    output_root.mkdir(parents=True, exist_ok=True)
    out: dict[str, str] = {}

    ts_path = output_root / "timeseries_raw_preview.xlsx"
    sample_df.to_excel(ts_path, index=False)
    out["timeseries_raw_preview"] = str(ts_path)

    meta_path = output_root / "risk_factors.xlsx"
    metadata_df.to_excel(meta_path, index=False)
    out["risk_factors"] = str(meta_path)

    mapping_path = output_root / "driver_name_mapping.xlsx"
    driver_map_df.to_excel(mapping_path, index=False)
    out["driver_name_mapping"] = str(mapping_path)
    return out


def _build_default_query(table_name: str, args: argparse.Namespace) -> tuple[str, dict[str, Any]]:
    conditions: list[str] = []
    params: dict[str, Any] = {}

    if args.run_date_from:
        conditions.append("runDate >= :run_date_from")
        params["run_date_from"] = str(pd.to_datetime(args.run_date_from).date())
    if args.run_date_to:
        conditions.append("runDate <= :run_date_to")
        params["run_date_to"] = str(pd.to_datetime(args.run_date_to).date())
    if args.close_date_from:
        conditions.append("closeDate >= :close_date_from")
        params["close_date_from"] = str(pd.to_datetime(args.close_date_from).date())
    if args.close_date_to:
        conditions.append("closeDate <= :close_date_to")
        params["close_date_to"] = str(pd.to_datetime(args.close_date_to).date())
    if args.extra_where:
        conditions.append(f"({args.extra_where})")

    where_sql = f"WHERE {' AND '.join(conditions)}" if conditions else ""
    query = f"""
SELECT runDate, driverName, closeDate, shift, preCloseValue, closeValue, holdingPeriod
FROM {table_name}
{where_sql}
"""
    return query.strip(), params


def _open_sql_connection(
    sqlite_path: Path,
    connection_url: str,
) -> tuple[Any, str, callable]:
    url = str(connection_url or "").strip()
    if url:
        try:
            import sqlalchemy as sa
        except ImportError as exc:  # pragma: no cover
            raise RuntimeError(
                "connection-url requires SQLAlchemy. Install with: pip install sqlalchemy"
            ) from exc
        engine = sa.create_engine(url)
        backend = f"sqlalchemy:{url.split('://', 1)[0]}"
        return engine, backend, engine.dispose

    if not sqlite_path.exists():
        raise FileNotFoundError(f"SQLite database not found: {sqlite_path}")
    conn = sqlite3.connect(sqlite_path)
    return conn, "sqlite", conn.close


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Extract marketData rows via SQL, map to framework schema, and save partitioned parquet."
    )
    parser.add_argument("--sqlite-path", default=str(PROJECT_ROOT / "data" / "incoming" / "market_data.db"))
    parser.add_argument(
        "--connection-url",
        default="",
        help="Optional SQLAlchemy URL. If set, this is used instead of --sqlite-path.",
    )
    parser.add_argument("--table-name", default="marketData")
    parser.add_argument(
        "--sql-query",
        default="",
        help="Optional custom SQL query. If empty, a default query is built from table/date filters.",
    )
    parser.add_argument("--run-date-from", default="2026-02-27")
    parser.add_argument("--run-date-to", default="2026-02-27")
    parser.add_argument("--close-date-from", default="2025-01-01")
    parser.add_argument("--close-date-to", default="2026-02-27")
    parser.add_argument("--extra-where", default="", help="Extra SQL predicate appended to WHERE.")
    parser.add_argument("--chunksize", type=int, default=250_000)
    parser.add_argument("--raw-path", default=str(PROJECT_ROOT / "data" / "raw_sql"))
    parser.add_argument(
        "--driver-map-path",
        default="", # data\incoming\my_driver_map.parquet
        help=(
            "Path to prebuilt mapping file (parquet/excel/csv) with columns: "
            "risk_factor_id, asset_class, ccy, rf_level1..rf_level5."
        ),
    )
    parser.add_argument(
        "--output-format",
        default="both",
        choices=["parquet", "excel", "both"],
        help="Parquet writes full data. Excel writes a preview + metadata.",
    )
    parser.add_argument(
        "--excel-max-rows",
        type=int,
        default=100_000,
        help="Maximum number of rows captured in Excel preview.",
    )
    parser.add_argument(
        "--allow-missing-shift",
        action=argparse.BooleanOptionalAction,
        default=False,
        help="Allow ingestion when source does not include shift column.",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    sqlite_path = Path(args.sqlite_path)

    table_name = _safe_table_name(str(args.table_name))
    query, params = (_build_default_query(table_name, args) if not args.sql_query else (str(args.sql_query), {}))
    raw_path = Path(args.raw_path)
    timeseries_root = raw_path / "timeseries_raw"
    risk_factors_root = raw_path / "risk_factors"
    driver_map_root = raw_path / "driver_name_mapping"
    timeseries_root.mkdir(parents=True, exist_ok=True)
    risk_factors_root.mkdir(parents=True, exist_ok=True)
    driver_map_root.mkdir(parents=True, exist_ok=True)

    excel_enabled = args.output_format in {"excel", "both"}
    parquet_enabled = args.output_format in {"parquet", "both"}
    if not parquet_enabled:
        print("Warning: parquet output disabled. Framework layers require parquet outputs to run.")

    total_rows = 0
    chunk_count = 0
    business_date_rows: dict[str, int] = {}
    min_date: pd.Timestamp | None = None
    max_date: pd.Timestamp | None = None
    min_business_date: pd.Timestamp | None = None
    max_business_date: pd.Timestamp | None = None
    driver_names: set[str] = set()
    excel_preview_parts: list[pd.DataFrame] = []
    excel_remaining = max(int(args.excel_max_rows), 0)
    source_mapping: dict[str, str | None] | None = None

    con, connection_backend, close_connection = _open_sql_connection(sqlite_path, str(args.connection_url))
    try:
        reader = pd.read_sql_query(query, con, params=params, chunksize=max(int(args.chunksize), 1))
        for raw_chunk in reader:
            if raw_chunk.empty:
                continue
            if source_mapping is None:
                source_mapping = _resolve_source_columns(raw_chunk)
            chunk = _canonicalize_chunk(raw_chunk, source_mapping, allow_missing_shift=bool(args.allow_missing_shift))
            if chunk.empty:
                continue

            chunk_count += 1
            total_rows += len(chunk)
            driver_names.update(chunk["risk_factor_id"].astype(str).tolist())

            c_min_date = chunk["date"].min()
            c_max_date = chunk["date"].max()
            c_min_biz = chunk["business_date"].min()
            c_max_biz = chunk["business_date"].max()
            min_date = c_min_date if min_date is None else min(min_date, c_min_date)
            max_date = c_max_date if max_date is None else max(max_date, c_max_date)
            min_business_date = c_min_biz if min_business_date is None else min(min_business_date, c_min_biz)
            max_business_date = c_max_biz if max_business_date is None else max(max_business_date, c_max_biz)

            if parquet_enabled:
                part_summary = _write_partitioned_timeseries(chunk, timeseries_root, chunk_count)
                for key, val in part_summary.items():
                    business_date_rows[key] = business_date_rows.get(key, 0) + int(val)

            if excel_enabled and excel_remaining > 0:
                take_n = min(excel_remaining, len(chunk))
                excel_preview_parts.append(chunk.head(take_n).copy())
                excel_remaining -= take_n
    finally:
        close_connection()

    if total_rows == 0:
        raise ValueError("SQL query returned zero rows after canonical mapping.")

    driver_map, driver_map_source = _build_driver_map(
        driver_names=driver_names,
        driver_map_path=str(args.driver_map_path),
    )
    missing_ids = sorted(driver_names.difference(set(driver_map["risk_factor_id"].astype(str).tolist())))
    if missing_ids:
        missing_preview = missing_ids[:10]
        raise ValueError(
            "Driver mapping does not cover all risk_factor_id values from SQL extract. "
            f"Missing count={len(missing_ids)}, sample={missing_preview}"
        )
    driver_map_path = driver_map_root / "part-000.parquet"
    driver_map.to_parquet(driver_map_path, index=False)

    risk_factors = driver_map.copy()
    risk_factors["tenor_bucket"] = risk_factors["rf_level5"].astype(str)
    risk_factors["vendor"] = "UNKNOWN"
    risk_factors["rating"] = "NA"
    risk_factors_cols = [
        "risk_factor_id",
        "rf_level1",
        "rf_level2",
        "rf_level3",
        "rf_level4",
        "rf_level5",
        "tenor_bucket",
        "vendor",
        "rating",
        "asset_class",
        "ccy",
    ]
    for col in risk_factors_cols:
        if col not in risk_factors.columns:
            risk_factors[col] = DEFAULT_NULL_TOKEN
    risk_factors = risk_factors[risk_factors_cols].drop_duplicates(subset=["risk_factor_id"]).reset_index(drop=True)
    risk_factors_path = risk_factors_root / "part-000.parquet"
    risk_factors.to_parquet(risk_factors_path, index=False)

    excel_outputs: dict[str, str] = {}
    if excel_enabled:
        excel_preview = pd.concat(excel_preview_parts, ignore_index=True) if excel_preview_parts else pd.DataFrame()
        excel_root = raw_path / "excel_exports"
        excel_outputs = _write_excel_preview(excel_preview, risk_factors, driver_map, excel_root)

    summary = {
        "job": "sql_marketdata_ingest",
        "run_ts": datetime.now().isoformat(),
        "connection_backend": connection_backend,
        "sqlite_path": str(sqlite_path.resolve()) if not str(args.connection_url).strip() else "",
        "query": query,
        "query_params": params,
        "source_mapping": source_mapping or {},
        "driver_map_source": driver_map_source,
        "driver_map_path_input": str(args.driver_map_path) if str(args.driver_map_path).strip() else "",
        "rows": {
            "timeseries_rows": int(total_rows),
            "unique_risk_factors": int(len(driver_names)),
            "chunk_count": int(chunk_count),
            "business_date_partitions": int(len(business_date_rows)),
        },
        "date_bounds": {
            "business_date_min": str(min_business_date.date()) if min_business_date is not None else "",
            "business_date_max": str(max_business_date.date()) if max_business_date is not None else "",
            "close_date_min": str(min_date.date()) if min_date is not None else "",
            "close_date_max": str(max_date.date()) if max_date is not None else "",
        },
        "outputs": {
            "timeseries_root": str(timeseries_root.resolve()),
            "risk_factors_file": str(risk_factors_path.resolve()),
            "driver_name_mapping_file": str(driver_map_path.resolve()),
            "excel_exports": excel_outputs,
        },
        "analysis_note": "Layer 3 and Layer 6 can run with --analysis-field shift on this dataset.",
    }
    summary_path = raw_path / "sql_ingest_summary.json"
    summary_path.write_text(json.dumps(summary, indent=2), encoding="utf-8")

    print("=== SQL MarketData Ingest Summary ===")
    print(f"Rows extracted: {total_rows:,}")
    print(f"Unique risk factors: {len(driver_names):,}")
    print(f"Business-date partitions: {len(business_date_rows):,}")
    print(f"Timeseries root: {timeseries_root}")
    print(f"Risk factors file: {risk_factors_path}")
    print(f"Driver-name mapping file: {driver_map_path}")
    print(f"Driver-map source: {driver_map_source}")
    if excel_outputs:
        print(f"Excel exports: {excel_outputs}")
    print(f"Summary file: {summary_path}")
    print("Next step Layer 3 example:")
    print(
        "python -m pipeline.run_demo_layer3_dqChecks "
        f"--raw-path \"{raw_path}\" "
        f"--analysis-field shift "
        "--generate-demo-data false"
    )


if __name__ == "__main__":
    main()
