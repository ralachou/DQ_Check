from __future__ import annotations

import argparse
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

PROJECT_ROOT = Path(__file__).resolve().parents[2]


@dataclass(frozen=True)
class ShiftProfile:
    key: str
    mean: float
    std: float
    min_v: float
    max_v: float


@dataclass(frozen=True)
class SubsetSpec:
    key: str
    count: int
    asset_class: str
    ccy: str
    rf_level1: str
    rf_level2: str
    id_prefix: str
    shift_profile_key: str


SHIFT_PROFILES: dict[str, ShiftProfile] = {
    # Note: RMBS average in user notes appears as -9.11283e05; using -9.11283e-05.
    "CP_RATE_USD_RMBSLTCMO": ShiftProfile(
        key="CP_RATE_USD_RMBSLTCMO",
        mean=-9.11283e-05,
        std=0.004327,
        min_v=-0.043,
        max_v=0.0485,
    ),
    "CP_RATE_USD_CMBS": ShiftProfile(
        key="CP_RATE_USD_CMBS",
        mean=8.2771156e-06,
        std=0.0052848,
        min_v=-0.01815,
        max_v=0.06489,
    ),
    "CP_RATE_USD_CORP": ShiftProfile(
        key="CP_RATE_USD_CORP",
        mean=-0.000482,
        std=0.0072,
        min_v=-0.045,
        max_v=0.147,
    ),
    "CP_RATE_USD_CDS": ShiftProfile(
        key="CP_RATE_USD_CDS",
        mean=-3.3771482e-05,
        std=0.0022,
        min_v=-0.037107,
        max_v=0.03256,
    ),
    "IR_RATE_BASISFXSOFR": ShiftProfile(
        key="IR_RATE_BASISFXSOFR",
        mean=-0.0026605,
        std=0.026196,
        min_v=-1.33037107,
        max_v=1.05907,
    ),
    "EQ_VOL_CURV_M06_M09": ShiftProfile(
        key="EQ_VOL_CURV_M06_M09",
        mean=0.00195,
        std=0.3093,
        min_v=-30.26,
        max_v=30.35,
    ),
}


SUBSET_SPECS: list[SubsetSpec] = [
    SubsetSpec(
        key="CP_RATE_USD_RMBSLTCMO",
        count=9,
        asset_class="CP_RATE",
        ccy="USD",
        rf_level1="RMBS",
        rf_level2="CMO",
        id_prefix="CP_RATE_VAR_USD_RMBSLTCMO",
        shift_profile_key="CP_RATE_USD_RMBSLTCMO",
    ),
    SubsetSpec(
        key="CP_RATE_USD_CMBS",
        count=21,
        asset_class="CP_RATE",
        ccy="USD",
        rf_level1="CMBS",
        rf_level2="CMBS_GENERIC",
        id_prefix="CP_RATE_VAR_USD_CMBS",
        shift_profile_key="CP_RATE_USD_CMBS",
    ),
    SubsetSpec(
        key="CP_RATE_USD_CORP",
        count=117,
        asset_class="CP_RATE",
        ccy="USD",
        rf_level1="CORP",
        rf_level2="CORP_SPREAD",
        id_prefix="CP_RATE_VAR_USD_CORP",
        shift_profile_key="CP_RATE_USD_CORP",
    ),
    SubsetSpec(
        key="CP_RATE_USD_CDS_REGIONAL",
        count=127,
        asset_class="CP_RATE",
        ccy="USD",
        rf_level1="CDS Regional",
        rf_level2="CDS",
        id_prefix="CP_RATE_VAR_CDS_REGIONAL",
        shift_profile_key="CP_RATE_USD_CDS",
    ),
    SubsetSpec(
        key="CP_RATE_USD_CDS_RATING",
        count=127,
        asset_class="CP_RATE",
        ccy="USD",
        rf_level1="CDS Rating",
        rf_level2="CDS",
        id_prefix="CP_RATE_VAR_CDS_RATING",
        shift_profile_key="CP_RATE_USD_CDS",
    ),
    SubsetSpec(
        key="IR_RATE_BASISFXSOFR",
        count=373,
        asset_class="IR_RATE",
        ccy="USD",
        rf_level1="BASISFXSOFR",
        rf_level2="SOFR",
        id_prefix="IR_RATE_USD_BASISFX_SOFR",
        shift_profile_key="IR_RATE_BASISFXSOFR",
    ),
    SubsetSpec(
        key="EQ_VOL_CURV_M06_M09",
        count=156,
        asset_class="EQ_VOL",
        ccy="USD",
        rf_level1="EQ_VOL",
        rf_level2="CURV",
        id_prefix="EQ_VOL_USD_CURV_M06_M09",
        shift_profile_key="EQ_VOL_CURV_M06_M09",
    ),
]


def _business_days(start_date: str, end_date: str) -> pd.DatetimeIndex:
    start_ts = pd.to_datetime(start_date)
    end_ts = pd.to_datetime(end_date)
    if end_ts < start_ts:
        raise ValueError("end_date must be >= start_date")
    return pd.bdate_range(start=start_ts, end=end_ts)


def _trunc_normal(
    rng: np.random.Generator,
    n: int,
    mean: float,
    std: float,
    min_v: float,
    max_v: float,
) -> np.ndarray:
    if n <= 0:
        return np.array([], dtype=float)
    if std <= 0:
        out = np.full(n, fill_value=mean, dtype=float)
    else:
        out = rng.normal(loc=mean, scale=std, size=n)
    out = np.clip(out, min_v, max_v)
    if n >= 2:
        out[0] = min_v
        out[1] = max_v
        rng.shuffle(out)
    return out


def _start_value_for_asset(asset_class: str, rng: np.random.Generator) -> float:
    if asset_class == "CP_RATE":
        return float(rng.uniform(0.005, 0.08))
    if asset_class == "IR_RATE":
        return float(rng.uniform(0.5, 5.0))
    if asset_class == "EQ_VOL":
        return float(rng.uniform(10.0, 40.0))
    return float(rng.uniform(1.0, 10.0))


def _rf_level3(spec: SubsetSpec, idx: int) -> str:
    if "CDS_" in spec.key:
        return f"CDX_{idx % 12:02d}"
    if spec.asset_class == "IR_RATE":
        return "BASISFX"
    if spec.asset_class == "EQ_VOL":
        return "EQ_CURVE"
    return "GENERIC"


def _rf_level4(spec: SubsetSpec, idx: int) -> str:
    if spec.key == "CP_RATE_USD_RMBSLTCMO":
        return "LTCMO"
    if spec.key == "EQ_VOL_CURV_M06_M09":
        return "M06_M09"
    if spec.asset_class == "IR_RATE":
        return "SPREAD"
    if "CMBS" in spec.key:
        return "CASH"
    if "CORP" in spec.key:
        return ["AAA", "AA", "A", "BBB", "BB"][idx % 5]
    return "NA"


def _rf_level5(spec: SubsetSpec, idx: int) -> str:
    if spec.asset_class == "EQ_VOL":
        return "M06_M09"
    buckets = ["Y01", "Y02", "Y03", "Y05", "Y07", "Y10"]
    return buckets[idx % len(buckets)]


def build_risk_factors() -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    for spec in SUBSET_SPECS:
        for i in range(1, spec.count + 1):
            rf_id = f"{spec.id_prefix}_{i:03d}"
            rows.append(
                {
                    "risk_factor_id": rf_id,
                    "asset_class": spec.asset_class,
                    "ccy": spec.ccy,
                    "rf_level1": spec.rf_level1,
                    "rf_level2": spec.rf_level2,
                    "rf_level3": _rf_level3(spec, i),
                    "rf_level4": _rf_level4(spec, i),
                    "rf_level5": _rf_level5(spec, i),
                    "subset_key": spec.key,
                    "shift_profile_key": spec.shift_profile_key,
                }
            )
    out = pd.DataFrame(rows).drop_duplicates(subset=["risk_factor_id"]).reset_index(drop=True)
    return out


def build_timeseries(
    risk_factors: pd.DataFrame,
    start_date: str,
    end_date: str,
    business_date: str,
    seed: int,
) -> pd.DataFrame:
    dates = _business_days(start_date, end_date)
    biz_ts = pd.to_datetime(business_date).normalize()
    rng = np.random.default_rng(seed)

    rows: list[pd.DataFrame] = []
    for driver_idx, rf in enumerate(risk_factors.itertuples(index=False), start=1):
        profile = SHIFT_PROFILES[str(rf.shift_profile_key if hasattr(rf, "shift_profile_key") else "")]
        local_mean = float(profile.mean + rng.normal(0.0, max(profile.std * 0.05, 1.0e-8)))
        local_std = float(max(profile.std * rng.uniform(0.85, 1.15), profile.std * 0.25))
        shift = _trunc_normal(
            rng=rng,
            n=len(dates),
            mean=local_mean,
            std=local_std,
            min_v=profile.min_v,
            max_v=profile.max_v,
        )
        value = np.empty(len(dates), dtype=float)
        value[0] = _start_value_for_asset(str(rf.asset_class), rng)
        for j in range(1, len(dates)):
            value[j] = value[j - 1] + shift[j]
        prev_close = np.empty(len(dates), dtype=float)
        prev_close[0] = value[0] - shift[0]
        prev_close[1:] = value[:-1]

        rows.append(
            pd.DataFrame(
                {
                    "business_date": biz_ts,
                    "risk_factor_id": str(rf.risk_factor_id),
                    "date": dates,
                    "value": value,
                    "prev_close_value": prev_close,
                    "shift": shift,
                    "driver_id": int(driver_idx),
                }
            )
        )
    out = pd.concat(rows, ignore_index=True) if rows else pd.DataFrame()
    return out.sort_values(["risk_factor_id", "date"]).reset_index(drop=True)


def _shift_summary(
    risk_factors: pd.DataFrame,
    timeseries: pd.DataFrame,
) -> pd.DataFrame:
    joined = timeseries.merge(
        risk_factors[["risk_factor_id", "subset_key", "asset_class", "rf_level1", "rf_level2"]],
        on="risk_factor_id",
        how="left",
    )
    out = (
        joined.groupby("subset_key", as_index=False)
        .agg(
            risk_factor_count=("risk_factor_id", "nunique"),
            rows=("risk_factor_id", "count"),
            shift_min=("shift", "min"),
            shift_max=("shift", "max"),
            shift_mean=("shift", "mean"),
            shift_median=("shift", "median"),
            shift_std=("shift", "std"),
        )
        .sort_values("subset_key")
        .reset_index(drop=True)
    )
    return out


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Generate synthetic MARS_SUBSET raw data files.")
    parser.add_argument("--raw-path", default=str(PROJECT_ROOT / "data" / "raw"))
    parser.add_argument("--start-date", default="2019-01-02")
    parser.add_argument("--end-date", default="2020-12-31")
    parser.add_argument("--business-date", default="2026-02-27")
    parser.add_argument("--seed", type=int, default=20260227)
    parser.add_argument(
        "--risk-factors-file",
        default="risk_factors_CORP-CDS-CMO-BASISFX-EQVOL.parquet",
        help="File name under raw/risk_factors.",
    )
    parser.add_argument(
        "--timeseries-file",
        default="CORP-CDS-CMO-BASISFX-EQVOL.parquet",
        help="File name under raw/timeseries_raw.",
    )
    parser.add_argument(
        "--output-format",
        default="both",
        choices=["parquet", "excel", "both"],
        help="Output format for generated raw tables.",
    )
    parser.add_argument(
        "--overwrite",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="Overwrite output files if they already exist.",
    )
    parser.add_argument(
        "--clean-target",
        action=argparse.BooleanOptionalAction,
        default=False,
        help="Delete existing parquet files under raw/risk_factors and raw/timeseries_raw before writing.",
    )
    return parser.parse_args()


def _replace_suffix(path: Path, new_suffix: str) -> Path:
    suffix = new_suffix if new_suffix.startswith(".") else f".{new_suffix}"
    return path.with_suffix(suffix)


def _write_table(df: pd.DataFrame, base_path: Path, output_format: str) -> list[Path]:
    written: list[Path] = []
    if output_format in {"parquet", "both"}:
        p = _replace_suffix(base_path, ".parquet")
        df.to_parquet(p, index=False)
        written.append(p)
    if output_format in {"excel", "both"}:
        p = _replace_suffix(base_path, ".xlsx")
        try:
            df.to_excel(p, index=False)
        except ImportError as exc:
            raise RuntimeError("Excel output requires openpyxl. Install with: pip install openpyxl") from exc
        written.append(p)
    return written


def main() -> None:
    args = parse_args()
    raw_root = Path(args.raw_path)
    business_date_str = str(pd.to_datetime(args.business_date).date())
    rf_root = raw_root / "risk_factors"
    ts_root = raw_root / "timeseries_raw"
    rf_root.mkdir(parents=True, exist_ok=True)
    ts_root.mkdir(parents=True, exist_ok=True)

    if bool(args.clean_target):
        for p in rf_root.rglob("*.parquet"):
            p.unlink(missing_ok=True)
        for p in ts_root.rglob("*.parquet"):
            p.unlink(missing_ok=True)

    rf_base_path = rf_root / Path(args.risk_factors_file).name
    ts_partition_root = ts_root / f"business_date={business_date_str}"
    ts_partition_root.mkdir(parents=True, exist_ok=True)
    ts_base_path = ts_partition_root / Path(args.timeseries_file).name
    candidate_paths = [_replace_suffix(rf_base_path, ".parquet"), _replace_suffix(rf_base_path, ".xlsx"), _replace_suffix(ts_base_path, ".parquet"), _replace_suffix(ts_base_path, ".xlsx")]
    if any(p.exists() for p in candidate_paths) and not bool(args.overwrite):
        raise FileExistsError("Output file already exists; use --overwrite to replace.")

    risk_factors = build_risk_factors()
    timeseries = build_timeseries(
        risk_factors=risk_factors,
        start_date=args.start_date,
        end_date=args.end_date,
        business_date=args.business_date,
        seed=int(args.seed),
    )

    risk_factors_out = risk_factors[
        ["risk_factor_id", "asset_class", "ccy", "rf_level1", "rf_level2", "rf_level3", "rf_level4", "rf_level5"]
    ].copy()
    timeseries_out = timeseries[
        ["business_date", "risk_factor_id", "date", "value", "prev_close_value", "shift", "driver_id"]
    ].copy()

    rf_written = _write_table(risk_factors_out, rf_base_path, args.output_format)
    ts_written = _write_table(timeseries_out, ts_base_path, args.output_format)

    summary = _shift_summary(risk_factors, timeseries_out)
    cp_rate_total = int(risk_factors_out[risk_factors_out["asset_class"] == "CP_RATE"]["risk_factor_id"].nunique())
    summary_payload = {
        "inputs": {
            "raw_path": str(raw_root),
            "risk_factors_files": [str(p) for p in rf_written],
            "timeseries_files": [str(p) for p in ts_written],
            "output_format": args.output_format,
            "start_date": str(pd.to_datetime(args.start_date).date()),
            "end_date": str(pd.to_datetime(args.end_date).date()),
            "business_date": business_date_str,
            "seed": int(args.seed),
        },
        "counts": {
            "risk_factor_total": int(risk_factors_out["risk_factor_id"].nunique()),
            "cp_rate_total": cp_rate_total,
            "ir_rate_basisfxsofr_total": int(
                risk_factors_out[
                    (risk_factors_out["asset_class"] == "IR_RATE")
                    & (risk_factors_out["rf_level1"] == "BASISFXSOFR")
                ]["risk_factor_id"].nunique()
            ),
            "eq_vol_curv_m06_m09_total": int(
                risk_factors_out[
                    (risk_factors_out["asset_class"] == "EQ_VOL")
                    & (risk_factors_out["rf_level2"] == "CURV")
                    & (risk_factors_out["risk_factor_id"].str.contains("M06_M09", na=False))
                ]["risk_factor_id"].nunique()
            ),
            "timeseries_rows": int(len(timeseries_out)),
        },
        "shift_summary_by_subset": summary.round(8).to_dict("records"),
    }
    summary_path = raw_root / "mars_subset_generation_summary.json"
    summary_path.write_text(json.dumps(summary_payload, indent=2), encoding="utf-8")

    print("=== MARS_SUBSET Synthetic Data Generated ===")
    print("Risk factors files:")
    for p in rf_written:
        print(f"  - {p}")
    print("Timeseries files:")
    for p in ts_written:
        print(f"  - {p}")
    print(f"Risk factors:      {risk_factors_out['risk_factor_id'].nunique():,}")
    print(f"Timeseries rows:   {len(timeseries_out):,}")
    print(f"Business date:     {pd.to_datetime(args.business_date).date()}")
    print(f"Summary JSON:      {summary_path}")
    print("")
    print("Subset counts:")
    for row in summary_payload["shift_summary_by_subset"]:
        print(f"  - {row['subset_key']}: rf={row['risk_factor_count']}, rows={row['rows']}")


if __name__ == "__main__":
    main()
