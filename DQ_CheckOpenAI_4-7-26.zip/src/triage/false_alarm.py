
from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any

import numpy as np
import pandas as pd
from sklearn.calibration import CalibratedClassifierCV
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, average_precision_score, confusion_matrix, precision_score, recall_score, roc_auc_score
from sklearn.model_selection import train_test_split

from common.taxonomy import TAXONOMY_COLUMNS, TAXONOMY_PEER_KEYS, normalize_taxonomy_frame
from dq_checks.taxonomy import (
    ENSEMBLE,
    ML_FORECAST_BASED,
    ML_UNSUPERVISED,
    PEER_CROSS_GROUP,
    RULE_BASED,
    STATISTICAL_BASIC,
    STATISTICAL_ROBUST,
    canonicalize_family,
)

try:
    from xgboost import XGBClassifier
    XGBOOST_AVAILABLE = True
except Exception:
    XGBOOST_AVAILABLE = False

try:
    from lightgbm import LGBMClassifier
    LIGHTGBM_AVAILABLE = True
except Exception:
    LIGHTGBM_AVAILABLE = False

PEER_KEYS_DEFAULT = list(TAXONOMY_PEER_KEYS)
STRESS_TAGS_DEFAULT = {"high_vol", "stress"}
FAMILY_TOKENS = [STATISTICAL_BASIC, STATISTICAL_ROBUST, RULE_BASED, ML_UNSUPERVISED, ML_FORECAST_BASED, PEER_CROSS_GROUP, ENSEMBLE]


def _severity_to_rank(s: pd.Series) -> pd.Series:
    return s.map({"Low": 0, "Med": 1, "High": 2, "Critical": 3}).fillna(0).astype(int)


def _rank_to_severity(rank: pd.Series) -> pd.Series:
    return rank.clip(0, 3).map({0: "Low", 1: "Med", 2: "High", 3: "Critical"}).fillna("Low")


def _to_binary(s: pd.Series) -> pd.Series:
    return (pd.to_numeric(s, errors="coerce").fillna(0.0) >= 0.5).astype(int)


def _norm_token(x: str) -> str:
    t = str(x or "").strip().upper()
    alias = {
        "STAT": "STAT",
        "STATISTICAL_BASIC": STATISTICAL_BASIC,
        "STATISTICAL_ROBUST": STATISTICAL_ROBUST,
        "RULE_BASED": RULE_BASED,
        "ML_UNSUPERVISED": ML_UNSUPERVISED,
        "ML_FORECAST_BASED": ML_FORECAST_BASED,
        "PEER_CROSS_GROUP": PEER_CROSS_GROUP,
        "PEER": "PEER",
        "FORECAST": "FORECAST",
        "ENSEMBLE": ENSEMBLE,
        "RF_LEVEL": "RF_LEVEL",
        "RF_LABEL": "RF_LEVEL",
        "RF_LABELS": "RF_LEVEL",
        "REGIME": "REGIME_SHIFT",
        "REGIME_SHIFT": "REGIME_SHIFT",
        "REGIME_SHIFTS": "REGIME_SHIFT",
        "MARKETEVENT": "MARKETEVENT",
        "MARKET_EVENT": "MARKETEVENT",
        "MARKEEVENT": "MARKETEVENT",
        "CROSS_ASSET": "CROSS_ASSET",
    }
    return alias.get(t, t)


@dataclass
class TriageModelInfo:
    enabled: bool
    model_name: str
    auc: float | None
    accuracy: float | None = None
    precision: float | None = None
    recall: float | None = None
    confusion_matrix: list[list[int]] = field(default_factory=list)
    features: list[str] = field(default_factory=list)
    candidates_tried: list[str] = field(default_factory=list)
    details: dict[str, Any] = field(default_factory=dict)


class FalseAlarmReducer:
    def __init__(
        self,
        regime_windows: list[dict[str, Any]] | None = None,
        peer_keys: list[str] | None = None,
        event_calendar: pd.DataFrame | None = None,
        event_window_days: int = 1,
        min_peer_group_size: int = 5,
        peer_confirm_ratio: float = 0.60,
        stress_tags: set[str] | None = None,
        stress_threshold_multiplier: float = 1.5,
        supervised_candidates: list[str] | None = None,
        calibration_method: str | None = "sigmoid",
        supervised_config: dict[str, Any] | None = None,
    ) -> None:
        self.regime_windows = regime_windows or []
        self.peer_keys = peer_keys or PEER_KEYS_DEFAULT
        self.event_calendar = event_calendar.copy() if event_calendar is not None else pd.DataFrame()
        self.event_window_days = int(event_window_days)
        self.min_peer_group_size = int(min_peer_group_size)
        self.peer_confirm_ratio = float(peer_confirm_ratio)
        self.stress_tags = stress_tags or STRESS_TAGS_DEFAULT
        self.stress_threshold_multiplier = float(stress_threshold_multiplier)
        self.supervised_config = supervised_config or {}
        cfg_candidates = self.supervised_config.get("candidates", [])
        cli_candidates = list(supervised_candidates or [])
        if cli_candidates:
            self.supervised_candidates = cli_candidates
        elif cfg_candidates:
            self.supervised_candidates = list(cfg_candidates)
        else:
            self.supervised_candidates = ["xgboost", "lightgbm", "random_forest", "logistic_regression"]
        cfg_calib = (self.supervised_config.get("calibration", {}) or {}).get("method")
        cal = calibration_method if calibration_method not in {None, "", "none"} else cfg_calib
        cal = str(cal).strip().lower() if cal is not None else ""
        self.calibration_method = cal if cal in {"sigmoid", "isotonic"} else None
        target_cfg = self.supervised_config.get("target", {}) or {}
        self.target_label_col = str(target_cfg.get("label_col", "is_false_alarm"))
        self.training_mode = str(self.supervised_config.get("training_mode", "ablation")).lower()
        self.feature_families = [_norm_token(x) for x in (self.supervised_config.get("feature_families", FAMILY_TOKENS + ["RF_LEVEL", "REGIME_SHIFT", "MARKETEVENT"]) or [])]
        self.ablation_sequence = self.supervised_config.get("ablation_sequence", []) or []
        self._last_monitoring_artifacts: dict[str, Any] = {}

    def tag_regime(self, dates: pd.Series, as_of_date: pd.Timestamp | None = None) -> pd.Series:
        as_of_date = as_of_date or pd.Timestamp.today().normalize()
        tags = pd.Series("normal", index=dates.index, dtype="object")
        d = pd.to_datetime(dates)
        for rw in self.regime_windows:
            tag = rw.get("regime_tag", "regime")
            if "relative_window_days" in rw:
                days = int(rw["relative_window_days"])
                start = as_of_date - pd.Timedelta(days=days)
                end = as_of_date
            else:
                start = pd.to_datetime(rw.get("start_date"))
                end = pd.to_datetime(rw.get("end_date"))
            tags.loc[(d >= start) & (d <= end)] = tag
        return tags

    def _event_proximate(self, dates: pd.Series) -> pd.Series:
        if self.event_calendar.empty:
            return pd.Series(False, index=dates.index, dtype=bool)
        ec = self.event_calendar.copy()
        col = "event_date" if "event_date" in ec.columns else ("date" if "date" in ec.columns else None)
        if col is None:
            return pd.Series(False, index=dates.index, dtype=bool)
        ev = pd.to_datetime(ec[col]).dropna().dt.normalize().unique()
        d = pd.to_datetime(dates).dt.normalize()
        out = pd.Series(False, index=dates.index, dtype=bool)
        for e in ev:
            out = out | ((d >= e - pd.Timedelta(days=self.event_window_days)) & (d <= e + pd.Timedelta(days=self.event_window_days)))
        return out

    def _peer_move_frame(self, raw_df: pd.DataFrame, membership: pd.DataFrame) -> pd.DataFrame:
        raw = raw_df[["risk_factor_id", "date", "value"]].copy()
        raw["date"] = pd.to_datetime(raw["date"])
        raw = raw.sort_values(["risk_factor_id", "date"]).drop_duplicates(["risk_factor_id", "date"], keep="last")
        m = membership[["risk_factor_id"] + self.peer_keys].drop_duplicates(["risk_factor_id"], keep="last")
        base = raw.merge(m, on="risk_factor_id", how="left")
        base["series_move"] = base.groupby("risk_factor_id")["value"].diff()
        gk = self.peer_keys + ["date"]
        peer = base.groupby(gk, as_index=False).agg(peer_median_move=("series_move", "median"), peer_q25=("series_move", lambda x: x.quantile(0.25)), peer_q75=("series_move", lambda x: x.quantile(0.75)), peer_median_value=("value", "median"), peer_group_size=("risk_factor_id", "nunique"))
        peer["peer_iqr_move"] = peer["peer_q75"] - peer["peer_q25"]
        out = base.merge(peer[gk + ["peer_median_move", "peer_iqr_move", "peer_median_value", "peer_group_size"]], on=gk, how="left")
        return out

    def peer_consistency(self, alerts_df: pd.DataFrame, raw_df: pd.DataFrame, membership: pd.DataFrame) -> pd.DataFrame:
        if alerts_df.empty:
            return alerts_df.copy()
        peer = self._peer_move_frame(raw_df, membership)
        out = alerts_df.merge(peer[["risk_factor_id", "date", "series_move", "peer_median_move", "peer_iqr_move", "peer_group_size"]], on=["risk_factor_id", "date"], how="left")
        gk = [k for k in self.peer_keys if k in out.columns] + ["date"]
        if gk and "flag" in out.columns:
            grp = out.groupby(gk, as_index=False).agg(peer_flagged_count=("flag", "sum"), peer_rows=("risk_factor_id", "nunique"))
            grp["peer_flag_ratio"] = grp["peer_flagged_count"] / (grp["peer_rows"] + 1.0e-9)
            out = out.merge(grp[gk + ["peer_flag_ratio"]], on=gk, how="left")
        else:
            out["peer_flag_ratio"] = 0.0
        align = np.sign(out["series_move"].fillna(0.0)) == np.sign(out["peer_median_move"].fillna(0.0))
        spread = out["peer_iqr_move"].abs().fillna(0.0)
        support = out["peer_median_move"].abs().fillna(0.0) / (spread + 1.0e-9)
        size = pd.to_numeric(out["peer_group_size"], errors="coerce").fillna(1.0)
        out["peer_confidence"] = np.clip(support * np.clip(size / max(1.0, float(self.min_peer_group_size)), 0.2, 1.0), 0.0, 1.0)
        ratio_ok = pd.to_numeric(out["peer_flag_ratio"], errors="coerce").fillna(0.0) >= self.peer_confirm_ratio
        out["peer_confirmed"] = (ratio_ok | (out["peer_confidence"] >= 0.5)) & align
        return out

    def _apply_event_and_regime_adjustments(self, df: pd.DataFrame) -> pd.DataFrame:
        out = df.copy()
        out["event_proximate"] = self._event_proximate(out["date"])
        rank = _severity_to_rank(out["severity"])
        integrity = out["reason_code"].str.contains("MISSING|STALE|INTEGRITY|GAP", case=False, na=False)
        rank = np.where(out["event_proximate"] & ~integrity, np.maximum(rank - 1, 0), rank)
        rank = np.where(out["regime_tag"].isin(self.stress_tags) & ~integrity, np.maximum(rank - 1, 0), rank)
        out["severity"] = _rank_to_severity(pd.Series(rank, index=out.index))
        return out

    def triage_heuristic(self, df: pd.DataFrame) -> pd.DataFrame:
        out = self._apply_event_and_regime_adjustments(df)
        if "severity_score_100" not in out.columns:
            out["severity_score_100"] = (pd.to_numeric(out.get("norm_score"), errors="coerce").fillna(0.0) * 100.0).clip(0, 100)
        out["confidence_estimate"] = 0.60
        out["recommended_action"] = "NEEDS_REVIEW"
        integrity = out["reason_code"].str.contains("MISSING|STALE|INTEGRITY|GAP", case=False, na=False)
        out.loc[out["peer_confirmed"] & out["regime_tag"].isin(self.stress_tags), ["recommended_action", "confidence_estimate"]] = ["ACCEPT_MOVE", 0.85]
        out.loc[(~out["peer_confirmed"]) & integrity, ["recommended_action", "confidence_estimate"]] = ["CONFIRM_BAD_DATA", 0.90]
        return out

    def _feature_table(self, df: pd.DataFrame, label_col: str) -> tuple[pd.DataFrame, dict[str, list[str]]]:
        t = df.reset_index().rename(columns={"index": "_row_id"}).copy()
        t["family"] = t["family"].astype(str).map(lambda x: canonicalize_family(x))
        t["date"] = pd.to_datetime(t["date"], errors="coerce")
        t["peer_confirmed"] = t.get("peer_confirmed", False).astype(int)
        t["severity_num"] = _severity_to_rank(t.get("severity", pd.Series("Low", index=t.index)))
        t["event_proximate"] = t.get("event_proximate", False).astype(int)
        t["is_macro_event_day"] = t["event_proximate"]
        if "severity_score_100" not in t.columns:
            t["severity_score_100"] = (pd.to_numeric(t.get("norm_score"), errors="coerce").fillna(0.0) * 100.0).clip(0, 100)
        t = t.sort_values(["risk_factor_id", "check_id", "date"]).reset_index(drop=True)
        prev = t.groupby(["risk_factor_id", "check_id"])["regime_tag"].shift(1)
        t["regime_shift_flag"] = (t["regime_tag"].astype(str) != prev.astype(str)).fillna(False).astype(int)
        t = normalize_taxonomy_frame(t, require_risk_factor_id=False)

        fam = t.groupby(["risk_factor_id", "date", "family"], as_index=False).agg(fam_norm=("norm_score", "max"), fam_sev=("severity_score_100", "max"), fam_flag=("flag", "max"))
        base = t[["risk_factor_id", "date"]].drop_duplicates().copy()
        groups: dict[str, list[str]] = {
            "DETECTOR_BASE": ["raw_score", "norm_score", "severity_num", "severity_score_100", "peer_confidence", "peer_confirmed", "peer_flag_ratio"],
            "REGIME_SHIFT": ["regime_shift_flag"],
            "MARKETEVENT": ["event_proximate", "is_macro_event_day"],
        }
        for f in FAMILY_TOKENS:
            p = fam[fam["family"] == f][["risk_factor_id", "date", "fam_norm", "fam_sev", "fam_flag"]].rename(columns={"fam_norm": f"fam_norm_{f}", "fam_sev": f"fam_sev100_{f}", "fam_flag": f"fam_flag_{f}"})
            cols = [f"fam_norm_{f}", f"fam_sev100_{f}", f"fam_flag_{f}"]
            groups[f] = cols
            base = base.merge(p, on=["risk_factor_id", "date"], how="left")
        t = t.merge(base, on=["risk_factor_id", "date"], how="left")
        for f in FAMILY_TOKENS:
            for c in groups[f]:
                t[c] = pd.to_numeric(t.get(c), errors="coerce").fillna(0.0)

        ca = t.groupby(["date", "asset_class"], as_index=False).agg(cross_asset_flag_rate=("flag", "mean"))
        d = t.groupby("date", as_index=False).agg(cross_market_flag_rate=("flag", "mean"))
        t = t.merge(ca, on=["date", "asset_class"], how="left").merge(d, on="date", how="left")
        groups["CROSS_ASSET"] = ["cross_asset_flag_rate", "cross_market_flag_rate"]

        d_reason = pd.get_dummies(t.get("reason_code", "UNK").fillna("UNK"), prefix="reason")
        t = pd.concat([t, d_reason], axis=1)
        groups["REASONCODE"] = list(d_reason.columns)

        rf_cols = []
        for c in TAXONOMY_COLUMNS:
            dd = pd.get_dummies(t[c].fillna("UNK"), prefix=c)
            t = pd.concat([t, dd], axis=1)
            rf_cols.extend(list(dd.columns))
        groups["RF_LEVEL"] = rf_cols

        if label_col not in t.columns:
            if label_col == "p_bad_data" and "is_false_alarm" in t.columns:
                t[label_col] = 1 - _to_binary(t["is_false_alarm"])
            elif label_col == "is_false_alarm" and "p_bad_data" in t.columns:
                t[label_col] = 1 - _to_binary(t["p_bad_data"])
            else:
                t[label_col] = np.nan
        t[label_col] = _to_binary(t[label_col]) if label_col in {"is_false_alarm", "p_bad_data"} else pd.to_numeric(t[label_col], errors="coerce")
        return t, groups

    def _select_cols(self, groups: dict[str, list[str]], tokens: list[str]) -> list[str]:
        cols = []
        for tok in [_norm_token(x) for x in (tokens or [])]:
            if tok == "STAT":
                cols += groups.get(STATISTICAL_BASIC, []) + groups.get(STATISTICAL_ROBUST, [])
            elif tok == "PEER":
                cols += groups.get(PEER_CROSS_GROUP, [])
            elif tok == "FORECAST":
                cols += groups.get(ML_FORECAST_BASED, [])
            else:
                cols += groups.get(tok, [])
        cols += groups.get("DETECTOR_BASE", [])
        return list(dict.fromkeys([c for c in cols if c]))

    def _split(self, x: pd.DataFrame, y: pd.Series, t: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame, pd.Series, pd.Series]:
        cfg = (((self.supervised_config.get("evaluation", {}) or {}).get("split", {}) or {}))
        if str(cfg.get("method", "grouped_time")).lower() == "grouped_time":
            dt = pd.to_datetime(t["date"], errors="coerce")
            tm = cfg.get("time", {}) or {}
            test_days = int(tm.get("test_days", 60))
            train_days = int(tm.get("train_lookback_days", 520))
            mx = dt.max()
            if pd.notna(mx):
                test_start = mx - pd.Timedelta(days=max(test_days - 1, 1))
                train_start = test_start - pd.Timedelta(days=max(train_days, 1))
                m_tr = (dt >= train_start) & (dt < test_start)
                m_te = dt >= test_start
                if int(m_tr.sum()) > 100 and int(m_te.sum()) > 30 and y.loc[m_tr].nunique() > 1 and y.loc[m_te].nunique() > 1:
                    return x.loc[m_tr], x.loc[m_te], y.loc[m_tr], y.loc[m_te]
        return train_test_split(x, y, test_size=0.25, random_state=42, stratify=y)

    def _fit_candidate(self, name: str):
        n = name.lower()
        hp = ((self.supervised_config.get("hyperparams", {}) or {}).get(n, {}) or {})
        if n == "xgboost":
            if not XGBOOST_AVAILABLE:
                raise RuntimeError("xgboost_not_available")
            d = {"objective": "binary:logistic", "eval_metric": "logloss", "max_depth": 4, "n_estimators": 600, "learning_rate": 0.03, "subsample": 0.8, "colsample_bytree": 0.8, "reg_lambda": 1.0, "random_state": 42}
            d.update(hp)
            return XGBClassifier(**d)
        if n == "lightgbm":
            if not LIGHTGBM_AVAILABLE:
                raise RuntimeError("lightgbm_not_available")
            d = {"num_leaves": 31, "n_estimators": 800, "learning_rate": 0.03, "random_state": 42}
            d.update(hp)
            return LGBMClassifier(**d)
        if n == "random_forest":
            d = {"n_estimators": 500, "max_depth": 18, "min_samples_leaf": 5, "random_state": 42}
            d.update(hp)
            return RandomForestClassifier(**d)
        if n == "logistic_regression":
            d = {"C": 1.0, "penalty": "l2", "max_iter": 200, "random_state": 42}
            d.update(hp)
            return LogisticRegression(**d)
        raise RuntimeError(f"unsupported_candidate:{name}")

    def _primary(self, y: pd.Series, p: np.ndarray) -> float:
        m = str(((self.supervised_config.get("evaluation", {}) or {}).get("primary_metric", "pr_auc"))).lower()
        return float(roc_auc_score(y, p)) if m == "roc_auc" else float(average_precision_score(y, p))

    @staticmethod
    def _predict_proba(model: Any, x: pd.DataFrame) -> np.ndarray:
        if hasattr(model, "predict_proba"):
            return np.asarray(model.predict_proba(x)[:, 1], dtype=float)
        if hasattr(model, "decision_function"):
            return 1.0 / (1.0 + np.exp(-np.asarray(model.decision_function(x), dtype=float)))
        pred = np.asarray(model.predict(x), dtype=float)
        return np.clip(pred, 0.0, 1.0)

    def _maybe_calibrate(
        self,
        model: Any,
        x_train: pd.DataFrame,
        y_train: pd.Series,
    ) -> tuple[Any, dict[str, Any]]:
        details: dict[str, Any] = {"calibration_method": self.calibration_method or "none", "calibration_applied": False}
        if self.calibration_method is None:
            return model, details

        method = self.calibration_method
        if method == "isotonic":
            min_iso = int(((self.supervised_config.get("calibration", {}) or {}).get("min_samples_for_isotonic", 20000)))
            if len(x_train) < min_iso:
                method = "sigmoid"

        try:
            calibrated = CalibratedClassifierCV(model, method=method, cv=3)
            calibrated.fit(x_train, y_train)
            details = {"calibration_method": method, "calibration_applied": True}
            return calibrated, details
        except Exception as exc:
            details["calibration_error"] = str(exc)
            return model, details

    def _token_cols(self, groups: dict[str, list[str]], token: str) -> list[str]:
        tok = _norm_token(token)
        if tok == "STAT":
            return groups.get(STATISTICAL_BASIC, []) + groups.get(STATISTICAL_ROBUST, [])
        if tok == "PEER":
            return groups.get(PEER_CROSS_GROUP, [])
        if tok == "FORECAST":
            return groups.get(ML_FORECAST_BASED, [])
        return groups.get(tok, [])

    @staticmethod
    def _normalize_feature_column(col_name: str, values: pd.Series) -> pd.Series:
        x = pd.to_numeric(values, errors="coerce").fillna(0.0)
        name = str(col_name).lower()
        if "sev100" in name or "severity_score_100" in name:
            return (x / 100.0).clip(0.0, 1.0)
        if "severity_num" in name:
            return (x / 3.0).clip(0.0, 1.0)
        return x.clip(0.0, 1.0)

    def _family_prob_from_weights(
        self,
        frame: pd.DataFrame,
        groups: dict[str, list[str]],
        family_weights: dict[str, Any],
    ) -> np.ndarray | None:
        if frame.empty:
            return None
        num = np.zeros(len(frame), dtype=float)
        den = 0.0
        for raw_key, raw_w in (family_weights or {}).items():
            w = float(raw_w)
            if w <= 0.0:
                continue
            cols = self._token_cols(groups, str(raw_key))
            cols = [c for c in cols if c in frame.columns]
            if not cols:
                continue
            normalized = [self._normalize_feature_column(c, frame[c]) for c in cols]
            fam_proxy = pd.concat(normalized, axis=1).max(axis=1).to_numpy(dtype=float)
            num += w * fam_proxy
            den += w
        if den <= 0.0:
            return None
        return np.clip(num / den, 0.0, 1.0)

    @staticmethod
    def _unwrap_estimator(model: Any) -> Any:
        if hasattr(model, "calibrated_classifiers_"):
            c = getattr(model, "calibrated_classifiers_", [])
            if c:
                est = getattr(c[0], "estimator", None)
                if est is not None:
                    return est
        return model

    def _global_importance_from_model(
        self,
        model: Any,
        feature_names: list[str],
        method: str,
        source_model: str,
    ) -> pd.DataFrame:
        est = self._unwrap_estimator(model)
        rows: list[dict[str, Any]] = []
        meth = str(method or "xgb_gain").lower()

        if meth in {"xgb_gain", "gain"} and hasattr(est, "get_booster"):
            try:
                booster = est.get_booster()
                gains = booster.get_score(importance_type="gain")
                vals = {f: float(gains.get(f, gains.get(f"f{idx}", 0.0))) for idx, f in enumerate(feature_names)}
                rows = [{"feature": k, "importance": v, "source_model": source_model, "importance_method": "xgb_gain"} for k, v in vals.items()]
            except Exception:
                rows = []

        if not rows and hasattr(est, "feature_importances_"):
            vals = np.asarray(getattr(est, "feature_importances_"), dtype=float)
            if len(vals) == len(feature_names):
                rows = [{"feature": f, "importance": float(v), "source_model": source_model, "importance_method": "feature_importances_"} for f, v in zip(feature_names, vals)]

        if not rows and hasattr(est, "coef_"):
            coef = np.asarray(getattr(est, "coef_"))
            vals = np.abs(coef[0] if coef.ndim > 1 else coef).astype(float)
            if len(vals) == len(feature_names):
                rows = [{"feature": f, "importance": float(v), "source_model": source_model, "importance_method": "abs_coef"} for f, v in zip(feature_names, vals)]

        out = pd.DataFrame(rows)
        if out.empty:
            return out
        out["importance"] = pd.to_numeric(out["importance"], errors="coerce").fillna(0.0)
        out = out.groupby(["feature", "source_model", "importance_method"], as_index=False)["importance"].sum()
        return out

    @staticmethod
    def _normalize_importance(df: pd.DataFrame) -> pd.DataFrame:
        out = df.copy()
        total = float(pd.to_numeric(out.get("importance"), errors="coerce").fillna(0.0).sum())
        out["importance_norm"] = (
            pd.to_numeric(out.get("importance"), errors="coerce").fillna(0.0) / (total + 1.0e-12)
            if total > 0.0
            else 0.0
        )
        out = out.sort_values("importance_norm", ascending=False).reset_index(drop=True)
        out["rank"] = np.arange(1, len(out) + 1, dtype=int)
        return out

    def _build_global_importance(self, best: dict[str, Any], feature_names: list[str]) -> pd.DataFrame:
        mon_cfg = ((self.supervised_config.get("monitoring", {}) or {}).get("feature_importance", {}) or {})
        method = str(mon_cfg.get("method", "xgb_gain"))
        if best.get("candidate") == "ensemble_weighted_prob" and best.get("members"):
            w = best.get("details", {}).get("ensemble_weights", {}) or {}
            parts = []
            for name, info in (best.get("members") or {}).items():
                imp = self._global_importance_from_model(info.get("pred"), feature_names, method=method, source_model=str(name))
                if imp.empty:
                    continue
                wt = float(w.get(name, 1.0))
                imp["importance"] = pd.to_numeric(imp["importance"], errors="coerce").fillna(0.0) * max(wt, 0.0)
                parts.append(imp)
            if not parts:
                return pd.DataFrame()
            merged = pd.concat(parts, ignore_index=True).groupby("feature", as_index=False)["importance"].sum()
            merged["source_model"] = "ensemble_weighted_prob"
            merged["importance_method"] = method
            return self._normalize_importance(merged)

        if "pred" not in best:
            return pd.DataFrame()
        base = self._global_importance_from_model(best["pred"], feature_names, method=method, source_model=str(best.get("candidate", "model")))
        if base.empty:
            return base
        return self._normalize_importance(base.groupby("feature", as_index=False)["importance"].sum().assign(source_model=str(best.get("candidate", "model")), importance_method=method))

    def _build_local_importance(
        self,
        x_all: pd.DataFrame,
        tr: pd.DataFrame,
        p_bad: np.ndarray,
        global_imp: pd.DataFrame,
        top_k: int,
        top_rows: int,
        method: str,
        model: Any | None,
    ) -> pd.DataFrame:
        if x_all.empty or len(p_bad) != len(x_all):
            return pd.DataFrame()
        work = tr[["_row_id", "risk_factor_id", "date", "check_id", "severity"]].copy()
        work["p_bad_data"] = np.asarray(p_bad, dtype=float)
        work = work.sort_values("p_bad_data", ascending=False).head(max(1, top_rows)).copy()
        if work.empty:
            return pd.DataFrame()

        x_sel = x_all.loc[work.index].copy()
        feat_names = list(x_sel.columns)
        out_rows: list[dict[str, Any]] = []
        local_method = "importance_proxy"
        used_shap = False

        if str(method).lower() == "shap" and model is not None:
            try:
                import shap  # type: ignore

                est = self._unwrap_estimator(model)
                explainer = shap.TreeExplainer(est)
                sv = explainer.shap_values(x_sel)
                if isinstance(sv, list):
                    sv = sv[-1]
                abs_sv = np.abs(np.asarray(sv, dtype=float))
                for i, (idx, row_meta) in enumerate(work.iterrows()):
                    vals = abs_sv[i]
                    order = np.argsort(-vals)[: max(1, top_k)]
                    for r, j in enumerate(order, start=1):
                        out_rows.append(
                            {
                                "row_id": int(row_meta["_row_id"]),
                                "risk_factor_id": str(row_meta["risk_factor_id"]),
                                "date": pd.to_datetime(row_meta["date"]).strftime("%Y-%m-%d"),
                                "check_id": str(row_meta.get("check_id", "")),
                                "severity": str(row_meta.get("severity", "")),
                                "p_bad_data": float(row_meta["p_bad_data"]),
                                "feature": feat_names[j],
                                "abs_contribution": float(vals[j]),
                                "local_rank": int(r),
                                "local_method": "shap",
                            }
                        )
                used_shap = True
                local_method = "shap"
            except Exception:
                used_shap = False

        if not used_shap:
            w = global_imp.set_index("feature")["importance_norm"].to_dict() if not global_imp.empty else {}
            arr = x_sel.to_numpy(dtype=float, copy=True)
            feat_w = np.array([float(w.get(f, 0.0)) for f in feat_names], dtype=float)
            contrib = np.abs(arr * feat_w)
            for i, (idx, row_meta) in enumerate(work.iterrows()):
                vals = contrib[i]
                order = np.argsort(-vals)[: max(1, top_k)]
                for r, j in enumerate(order, start=1):
                    out_rows.append(
                        {
                            "row_id": int(row_meta["_row_id"]),
                            "risk_factor_id": str(row_meta["risk_factor_id"]),
                            "date": pd.to_datetime(row_meta["date"]).strftime("%Y-%m-%d"),
                            "check_id": str(row_meta.get("check_id", "")),
                            "severity": str(row_meta.get("severity", "")),
                            "p_bad_data": float(row_meta["p_bad_data"]),
                            "feature": feat_names[j],
                            "abs_contribution": float(vals[j]),
                            "local_rank": int(r),
                            "local_method": local_method,
                        }
                    )
        return pd.DataFrame(out_rows)

    def _apply_policy(self, out: pd.DataFrame) -> pd.DataFrame:
        if "p_bad_data" not in out.columns:
            return out
        res = out.copy()
        p_hi = float((self.supervised_config.get("decision_policy", {}) or {}).get("p_bad_data_high", 0.70))
        sr = _severity_to_rank(res["severity"])
        high = sr >= 2
        mod_peer = (sr == 1) & res.get("peer_confirmed", False).astype(bool)
        pb = pd.to_numeric(res["p_bad_data"], errors="coerce").fillna(0.5)
        res["decision_policy_reason"] = "heuristic_default"
        res.loc[high & (pb >= p_hi), ["recommended_action", "decision_policy_reason"]] = ["CONFIRM_BAD_DATA", "high_severity_high_p_bad_data"]
        res.loc[high & (pb < p_hi), ["recommended_action", "decision_policy_reason"]] = ["ACCEPT_MOVE", "high_severity_low_p_bad_data"]
        res.loc[mod_peer, ["recommended_action", "decision_policy_reason"]] = ["MONITOR_NO_ACTION", "moderate_severity_peer_confirmed"]
        return res

    def triage_supervised(self, df: pd.DataFrame, label_col: str = "is_false_alarm") -> tuple[pd.DataFrame, TriageModelInfo]:
        out = df.copy().reset_index(drop=True)
        self._last_monitoring_artifacts = {}
        lbl = self.target_label_col or label_col
        t, groups = self._feature_table(out, lbl)
        if t.empty or lbl not in t.columns or t[lbl].isna().all():
            out["p_bad_data"] = np.nan
            out["false_alarm_probability"] = np.nan
            out["is_false_alarm_pred"] = np.nan
            return out, TriageModelInfo(enabled=False, model_name="", auc=None)

        tr = t.dropna(subset=[lbl]).copy()
        y = _to_binary(tr[lbl])
        if tr.empty or y.nunique() < 2:
            out["p_bad_data"] = np.nan
            out["false_alarm_probability"] = np.nan
            out["is_false_alarm_pred"] = np.nan
            return out, TriageModelInfo(enabled=False, model_name="", auc=None)

        exps = []
        if self.training_mode == "ablation" and self.ablation_sequence:
            for row in self.ablation_sequence:
                exps.append({"name": str(row.get("name", "ablation")), "tokens": [_norm_token(x) for x in (row.get("use", []) or [])]})
        else:
            exps.append({"name": "all_configured", "tokens": self.feature_families})

        best = None
        tried, ab_res = [], []
        if self.training_mode == "ensemble":
            ex = exps[0]
            cols = self._select_cols(groups, ex["tokens"])
            if cols:
                x_all = tr[cols].fillna(0.0)
                x_tr, x_te, y_tr, y_te = self._split(x_all, y, tr)
                members: dict[str, dict[str, Any]] = {}
                if y_tr.nunique() >= 2 and y_te.nunique() >= 2:
                    for candidate in self.supervised_candidates:
                        try:
                            tried.append(candidate)
                            model = self._fit_candidate(candidate)
                            model.fit(x_tr, y_tr)
                            pred, cal = self._maybe_calibrate(model, x_tr, y_tr)
                            p_te = self._predict_proba(pred, x_te)
                            p_all = self._predict_proba(pred, x_all)
                            candidate_score = self._primary(y_te, p_te)
                            ab_res.append(
                                {
                                    "experiment": ex["name"],
                                    "candidate": candidate,
                                    "primary_score": float(candidate_score),
                                    "features_count": int(len(cols)),
                                }
                            )
                            members[candidate] = {"pred": pred, "p_te": p_te, "p_all": p_all, "score": float(candidate_score), "cal": cal}
                        except Exception:
                            continue
                if members:
                    ens_cfg = (self.supervised_config.get("ensemble", {}) or {})
                    weights_cfg = ens_cfg.get("model_weights", {}) or {}
                    w_raw = {name: float(weights_cfg.get(name, 1.0)) for name in members}
                    w_sum = float(sum(max(v, 0.0) for v in w_raw.values()))
                    weights = {k: (max(v, 0.0) / w_sum if w_sum > 0.0 else 1.0 / len(w_raw)) for k, v in w_raw.items()}
                    p_te_ens = np.zeros_like(next(iter(members.values()))["p_te"], dtype=float)
                    p_all_ens = np.zeros_like(next(iter(members.values()))["p_all"], dtype=float)
                    for name, info in members.items():
                        p_te_ens += weights[name] * info["p_te"]
                        p_all_ens += weights[name] * info["p_all"]
                    fam_cfg = ens_cfg.get("family_weighting", {}) or {}
                    fam_applied = False
                    if bool(fam_cfg.get("enabled", False)):
                        fam_weights = fam_cfg.get("weights", {}) or {}
                        p_family_all = self._family_prob_from_weights(tr, groups, fam_weights)
                        p_family_te = self._family_prob_from_weights(tr.loc[x_te.index], groups, fam_weights)
                        if p_family_all is not None and p_family_te is not None:
                            p_all_ens = np.clip(0.5 * p_all_ens + 0.5 * p_family_all, 0.0, 1.0)
                            p_te_ens = np.clip(0.5 * p_te_ens + 0.5 * p_family_te, 0.0, 1.0)
                            fam_applied = True
                    ens_score = self._primary(y_te, p_te_ens)
                    best = {
                        "score": float(ens_score),
                        "candidate": "ensemble_weighted_prob",
                        "experiment": ex["name"],
                        "tokens": ex["tokens"],
                        "cols": cols,
                        "p_te": p_te_ens,
                        "p_all": p_all_ens,
                        "y_te": y_te,
                        "cal": {"calibration_method": self.calibration_method or "none", "calibration_applied": any(v["cal"].get("calibration_applied", False) for v in members.values())},
                        "details": {
                            "ensemble_members": list(members.keys()),
                            "ensemble_weights": weights,
                            "family_weighting_applied": fam_applied,
                            "family_weights": fam_cfg.get("weights", {}),
                        },
                        "members": members,
                        "x_all": x_all,
                    }
                    ab_res.append(
                        {
                            "experiment": ex["name"],
                            "candidate": "ensemble_weighted_prob",
                            "primary_score": float(ens_score),
                            "features_count": int(len(cols)),
                        }
                    )
        else:
            for ex in exps:
                cols = self._select_cols(groups, ex["tokens"])
                if not cols:
                    continue
                x_all = tr[cols].fillna(0.0)
                x_tr, x_te, y_tr, y_te = self._split(x_all, y, tr)
                if y_tr.nunique() < 2 or y_te.nunique() < 2:
                    continue
                for candidate in self.supervised_candidates:
                    try:
                        tried.append(candidate)
                        model = self._fit_candidate(candidate)
                        model.fit(x_tr, y_tr)
                        pred, cal = self._maybe_calibrate(model, x_tr, y_tr)
                        p_te = self._predict_proba(pred, x_te)
                        score = self._primary(y_te, p_te)
                        ab_res.append(
                            {
                                "experiment": ex["name"],
                                "candidate": candidate,
                                "primary_score": float(score),
                                "features_count": int(len(cols)),
                            }
                        )
                        if best is None or float(score) > float(best["score"]):
                            best = {
                                "score": float(score),
                                "candidate": candidate,
                                "experiment": ex["name"],
                                "tokens": ex["tokens"],
                                "cols": cols,
                                "pred": pred,
                                "x_all": x_all,
                                "y_te": y_te,
                                "p_te": p_te,
                                "cal": cal,
                                "details": {},
                            }
                    except Exception:
                        continue

        if best is None:
            out["p_bad_data"] = np.nan
            out["false_alarm_probability"] = np.nan
            out["is_false_alarm_pred"] = np.nan
            return out, TriageModelInfo(enabled=False, model_name="", auc=None, candidates_tried=tried, details={"ablation_results": ab_res})

        if "p_all" in best:
            p_all = np.asarray(best["p_all"], dtype=float)
        else:
            p_all = self._predict_proba(best["pred"], best["x_all"])
        p_false = p_all if lbl == "is_false_alarm" else 1.0 - p_all
        p_bad = 1.0 - p_false
        out["p_bad_data"] = np.nan
        out["false_alarm_probability"] = np.nan
        out["is_false_alarm_pred"] = np.nan
        out.loc[tr["_row_id"], "p_bad_data"] = p_bad
        out.loc[tr["_row_id"], "false_alarm_probability"] = p_false
        out.loc[tr["_row_id"], "is_false_alarm_pred"] = (p_false >= 0.5).astype(int)
        if "is_false_alarm" not in out.columns:
            out["is_false_alarm"] = out["is_false_alarm_pred"]

        mon_cfg = ((self.supervised_config.get("monitoring", {}) or {}).get("feature_importance", {}) or {})
        if bool(mon_cfg.get("enabled", False)):
            top_k = int(mon_cfg.get("top_k", 30))
            method = str(mon_cfg.get("method", "xgb_gain"))
            top_rows = int(mon_cfg.get("top_rows", 200))
            global_imp = self._build_global_importance(best, list(best["cols"])).head(max(1, top_k))
            model_for_local = best.get("pred")
            local_imp = self._build_local_importance(
                x_all=best["x_all"],
                tr=tr,
                p_bad=p_bad,
                global_imp=global_imp,
                top_k=max(1, top_k),
                top_rows=max(1, top_rows),
                method=method,
                model=model_for_local,
            )
            self._last_monitoring_artifacts = {
                "feature_importance_global": global_imp.to_dict("records") if not global_imp.empty else [],
                "feature_importance_local": local_imp.to_dict("records") if not local_imp.empty else [],
                "feature_importance_summary": {
                    "enabled": True,
                    "method_requested": method,
                    "top_k": int(top_k),
                    "top_rows": int(top_rows),
                    "global_rows": int(len(global_imp)),
                    "local_rows": int(len(local_imp)),
                    "local_method": str(local_imp["local_method"].iloc[0]) if not local_imp.empty else "none",
                },
            }
        else:
            self._last_monitoring_artifacts = {"feature_importance_summary": {"enabled": False}}

        yhat = (best["p_te"] >= 0.5).astype(int)
        info = TriageModelInfo(
            enabled=True,
            model_name=str(best["candidate"]),
            auc=float(roc_auc_score(best["y_te"], best["p_te"])),
            accuracy=float(accuracy_score(best["y_te"], yhat)),
            precision=float(precision_score(best["y_te"], yhat, zero_division=0)),
            recall=float(recall_score(best["y_te"], yhat, zero_division=0)),
            confusion_matrix=confusion_matrix(best["y_te"], yhat).astype(int).tolist(),
            features=list(best["cols"]),
            candidates_tried=list(dict.fromkeys(tried)),
            details={
                "target_label": lbl,
                "training_mode": self.training_mode,
                "selected_experiment": best["experiment"],
                "selected_tokens": best["tokens"],
                "ablation_results": ab_res,
                **best["cal"],
                **best.get("details", {}),
                "feature_importance_summary": self._last_monitoring_artifacts.get("feature_importance_summary", {}),
            },
        )
        return out, info

    def run(
        self,
        alerts_df: pd.DataFrame,
        raw_df: pd.DataFrame,
        membership: pd.DataFrame,
        with_supervised: bool = False,
        label_col: str = "is_false_alarm",
    ) -> tuple[pd.DataFrame, dict[str, Any]]:
        if alerts_df.empty:
            return alerts_df.copy(), {"triage_model": {"enabled": False}}
        alerts = normalize_taxonomy_frame(alerts_df, require_risk_factor_id=True)
        mem = normalize_taxonomy_frame(membership, require_risk_factor_id=True).drop_duplicates(subset=["risk_factor_id"])
        enriched = self.peer_consistency(alerts_df=alerts, raw_df=raw_df, membership=mem)
        enriched["regime_tag"] = self.tag_regime(enriched["date"])
        triaged = self.triage_heuristic(enriched)
        model_info = TriageModelInfo(enabled=False, model_name="", auc=None)
        if with_supervised:
            triaged, model_info = self.triage_supervised(triaged, label_col=label_col)
            triaged = self._apply_policy(triaged)

        triaged["triage_artifacts_json"] = json.dumps(
            {
                "peer_keys": self.peer_keys,
                "regime_windows_count": len(self.regime_windows),
                "supervised_enabled": model_info.enabled,
                "supervised_model": model_info.model_name,
                "target_label_col": self.target_label_col,
                "feature_families": self.feature_families,
                "training_mode": self.training_mode,
                "calibration_method": model_info.details.get("calibration_method", "none"),
                "calibration_applied": bool(model_info.details.get("calibration_applied", False)),
                "event_calendar_rows": int(len(self.event_calendar)),
                "min_peer_group_size": self.min_peer_group_size,
                "peer_confirm_ratio": self.peer_confirm_ratio,
                "stress_threshold_multiplier": self.stress_threshold_multiplier,
                "feature_importance_monitoring": self._last_monitoring_artifacts.get("feature_importance_summary", {}),
            }
        )
        return triaged, {
            "triage_model": model_info.__dict__,
            "feature_importance_global": self._last_monitoring_artifacts.get("feature_importance_global", []),
            "feature_importance_local": self._last_monitoring_artifacts.get("feature_importance_local", []),
            "feature_importance_summary": self._last_monitoring_artifacts.get("feature_importance_summary", {}),
        }
