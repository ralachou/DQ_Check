from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any

import pandas as pd

from common.schemas import ensure_timeseries_schema
from common.taxonomy import apply_taxonomy_filters
from data_access.base import TimeSeriesRepository


class ParquetTimeSeriesRepository(TimeSeriesRepository):
    """Parquet-backed repository with table directories under a base path."""

    def __init__(self, base_path: str | Path, write_base_path: str | Path | None = None) -> None:
        self.base_path = Path(base_path)
        self.write_base_path = Path(write_base_path) if write_base_path else self.base_path
        self.base_path.mkdir(parents=True, exist_ok=True)
        self.write_base_path.mkdir(parents=True, exist_ok=True)

    def _table_path(self, table_name: str) -> Path:
        return self.base_path / table_name

    def _write_table_path(self, table_name: str) -> Path:
        return self.write_base_path / table_name

    def _read_parquet_dir(self, table_name: str) -> pd.DataFrame:
        path = self._table_path(table_name)
        if not path.exists():
            return pd.DataFrame()
        parquet_files = list(path.rglob("*.parquet"))
        if not parquet_files:
            return pd.DataFrame()
        parts = []
        for file_path in parquet_files:
            part = pd.read_parquet(file_path)
            rel_parts = file_path.relative_to(path).parts[:-1]
            for segment in rel_parts:
                if "=" not in segment:
                    continue
                key, value = segment.split("=", 1)
                if key and key not in part.columns:
                    part[key] = value
            parts.append(part)
        return pd.concat(parts, ignore_index=True)

    @staticmethod
    def _partition_value(value: Any) -> str:
        if pd.isna(value):
            return "NA"
        if isinstance(value, (pd.Timestamp,)):
            return str(value.normalize().date())
        try:
            as_ts = pd.to_datetime(value, errors="raise")
            if pd.notna(as_ts):
                return str(as_ts.normalize().date())
        except Exception:
            pass
        return str(value)

    @staticmethod
    def _safe_token(value: str) -> str:
        return re.sub(r"[^A-Za-z0-9_.-]+", "_", value).strip("_") or "value"

    @staticmethod
    def _next_file_path(root: Path, stem: str) -> Path:
        candidate = root / f"{stem}.parquet"
        if not candidate.exists():
            return candidate
        idx = 1
        while True:
            candidate = root / f"{stem}_{idx}.parquet"
            if not candidate.exists():
                return candidate
            idx += 1

    @staticmethod
    def _serialize_nested_object_columns(df: pd.DataFrame) -> pd.DataFrame:
        """Serialize nested object values (dict/list/tuple/set) to JSON-safe strings.

        This avoids pyarrow struct inference issues (for example empty dict => struct<>).
        """
        out = df.copy()
        object_cols = [c for c in out.columns if out[c].dtype == "object"]
        if not object_cols:
            return out

        def _has_nested_values(series: pd.Series) -> bool:
            non_na = series.dropna()
            if non_na.empty:
                return False
            for value in non_na.head(1000):
                if isinstance(value, (dict, list, tuple, set)):
                    return True
            return False

        def _to_json_or_string(value: Any) -> Any:
            if pd.isna(value):
                return None
            if isinstance(value, (dict, list, tuple, set)):
                return json.dumps(value, default=str)
            return value

        for col in object_cols:
            if _has_nested_values(out[col]):
                out[col] = out[col].map(_to_json_or_string)
        return out

    def get_series(
        self,
        risk_factor_ids: list[str] | None,
        start_date: str | pd.Timestamp,
        end_date: str | pd.Timestamp,
        business_date: str | pd.Timestamp | None = None,
    ) -> pd.DataFrame:
        df = self._read_parquet_dir("timeseries_raw")
        if df.empty:
            return df
        default_business_date = business_date if business_date is not None else end_date
        df = ensure_timeseries_schema(df, default_business_date=default_business_date, keep_extra_columns=True)
        start_ts = pd.to_datetime(start_date)
        end_ts = pd.to_datetime(end_date)
        if business_date is not None:
            biz_ts = pd.to_datetime(business_date).normalize()
            df = df[df["business_date"] == biz_ts]
        mask = (df["date"] >= start_ts) & (df["date"] <= end_ts)
        if risk_factor_ids:
            mask &= df["risk_factor_id"].isin(risk_factor_ids)
        return df.loc[mask].sort_values(["business_date", "risk_factor_id", "date"]).reset_index(drop=True)

    def list_risk_factors(self, filters: dict[str, Any] | None = None) -> pd.DataFrame:
        df = self._read_parquet_dir("risk_factors")
        if df.empty:
            return df
        return apply_taxonomy_filters(df, filters)

    def write_results(
        self,
        df: pd.DataFrame,
        table_name: str,
        partition_cols: list[str] | None = None,
    ) -> None:
        if df.empty:
            return
        path = self._write_table_path(table_name)
        path.mkdir(parents=True, exist_ok=True)
        partition_cols = partition_cols or []
        data = df.copy()
        for col in partition_cols:
            if col not in data.columns:
                continue
            if pd.api.types.is_datetime64_any_dtype(data[col]):
                data[col] = pd.to_datetime(data[col]).dt.strftime("%Y-%m-%d")

        if partition_cols:
            grouped = data.groupby(partition_cols, dropna=False, sort=False)
            for keys, part in grouped:
                if not isinstance(keys, tuple):
                    keys = (keys,)
                part_path = path
                for col, key in zip(partition_cols, keys):
                    key_s = self._partition_value(key)
                    part_path = part_path / f"{col}={self._safe_token(key_s)}"
                part_path.mkdir(parents=True, exist_ok=True)
                stem = self._safe_token(table_name)
                out_file = self._next_file_path(part_path, stem)
                write_part = part.drop(columns=[c for c in partition_cols if c in part.columns])
                write_part = self._serialize_nested_object_columns(write_part)
                write_part.to_parquet(out_file, engine="pyarrow", index=False)
            return

        out_file = self._next_file_path(path, self._safe_token(table_name))
        data = self._serialize_nested_object_columns(data)
        data.to_parquet(out_file, engine="pyarrow", index=False)
