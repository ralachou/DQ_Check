from __future__ import annotations

import re
from pathlib import Path
from typing import Any

import pandas as pd
import yaml

from common.taxonomy import DEFAULT_NULL_TOKEN


def _normalize_text(value: str) -> str:
    return str(value or "").strip()


def _coalesce(*values: str) -> str:
    for val in values:
        text = _normalize_text(val)
        if text:
            return text
    return DEFAULT_NULL_TOKEN


def _default_parse(driver_name: str) -> dict[str, str]:
    text = _normalize_text(driver_name)
    if not text:
        return {
            "assetClass": DEFAULT_NULL_TOKEN,
            "ccy": DEFAULT_NULL_TOKEN,
            "rf_level1": DEFAULT_NULL_TOKEN,
            "rf_level2": DEFAULT_NULL_TOKEN,
            "rf_level3": DEFAULT_NULL_TOKEN,
            "rf_level4": DEFAULT_NULL_TOKEN,
            "rf_level5": DEFAULT_NULL_TOKEN,
        }

    split = re.split(r"[|/:;,>\-]+", text)
    if len(split) <= 1:
        split = text.split("_")
    parts = [p.strip() for p in split if p and p.strip()]

    asset_class = parts[0] if parts else DEFAULT_NULL_TOKEN
    ccy = DEFAULT_NULL_TOKEN
    for p in parts:
        if re.fullmatch(r"[A-Z]{3}", p):
            ccy = p
            break

    rf_level1 = _coalesce(asset_class)
    rf_level2 = _coalesce(ccy, parts[1] if len(parts) > 1 else "")
    rf_level3 = _coalesce(parts[2] if len(parts) > 2 else "")
    rf_level4 = _coalesce(parts[3] if len(parts) > 3 else "")
    rf_level5 = _coalesce(parts[4] if len(parts) > 4 else "")
    return {
        "assetClass": _coalesce(asset_class),
        "ccy": _coalesce(ccy),
        "rf_level1": rf_level1,
        "rf_level2": rf_level2,
        "rf_level3": rf_level3,
        "rf_level4": rf_level4,
        "rf_level5": rf_level5,
    }


def _load_pattern_rules(path: str | Path | None) -> list[dict[str, Any]]:
    if not path:
        return []
    p = Path(path)
    if not p.exists():
        return []
    data = yaml.safe_load(p.read_text(encoding="utf-8")) or {}
    patterns = data.get("patterns", [])
    out: list[dict[str, Any]] = []
    for item in patterns:
        if not isinstance(item, dict) or "pattern" not in item:
            continue
        out.append(
            {
                "regex": re.compile(str(item["pattern"])),
                "defaults": {k: str(v) for k, v in (item.get("defaults", {}) or {}).items()},
            }
        )
    return out


def parse_driver_name(driver_name: str, pattern_rules: list[dict[str, Any]] | None = None) -> dict[str, str]:
    text = _normalize_text(driver_name)
    for rule in pattern_rules or []:
        match = rule["regex"].match(text)
        if not match:
            continue
        g = match.groupdict()
        defaults = rule.get("defaults", {})
        return {
            "assetClass": _coalesce(g.get("assetClass", ""), defaults.get("assetClass", "")),
            "ccy": _coalesce(g.get("ccy", ""), defaults.get("ccy", "")),
            "rf_level1": _coalesce(g.get("rf_level1", ""), g.get("assetClass", ""), defaults.get("rf_level1", "")),
            "rf_level2": _coalesce(g.get("rf_level2", ""), g.get("ccy", ""), defaults.get("rf_level2", "")),
            "rf_level3": _coalesce(g.get("rf_level3", ""), defaults.get("rf_level3", "")),
            "rf_level4": _coalesce(g.get("rf_level4", ""), defaults.get("rf_level4", "")),
            "rf_level5": _coalesce(g.get("rf_level5", ""), defaults.get("rf_level5", "")),
        }
    return _default_parse(text)


def parse_driver_names(
    driver_names: pd.Series | list[str],
    rules_path: str | Path | None = None,
) -> pd.DataFrame:
    rules = _load_pattern_rules(rules_path)
    s = pd.Series(driver_names, dtype="string").dropna().astype(str).drop_duplicates()
    rows: list[dict[str, str]] = []
    for driver_name in s.tolist():
        parsed = parse_driver_name(driver_name, pattern_rules=rules)
        parsed["risk_factor_id"] = driver_name
        rows.append(parsed)
    if not rows:
        return pd.DataFrame(
            columns=[
                "risk_factor_id",
                "assetClass",
                "ccy",
                "rf_level1",
                "rf_level2",
                "rf_level3",
                "rf_level4",
                "rf_level5",
            ]
        )
    out = pd.DataFrame(rows)
    cols = [
        "risk_factor_id",
        "assetClass",
        "ccy",
        "rf_level1",
        "rf_level2",
        "rf_level3",
        "rf_level4",
        "rf_level5",
    ]
    for col in cols:
        if col not in out.columns:
            out[col] = DEFAULT_NULL_TOKEN
        out[col] = out[col].fillna(DEFAULT_NULL_TOKEN).astype(str)
    return out[cols].drop_duplicates(subset=["risk_factor_id"]).reset_index(drop=True)
