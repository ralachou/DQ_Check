from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import pandas as pd
import yaml

TIMESERIES_COLUMNS = ("business_date", "risk_factor_id", "date", "value")
RESULT_COLUMNS = (
    "run_id",
    "universe_name",
    "business_date",
    "risk_factor_id",
    "date",
    "check_id",
    "model_id",
    "backend",
    "family",
    "raw_score",
    "norm_score",
    "threshold",
    "flag",
    "severity",
    "reason_code",
    "explain",
    "artifacts_json",
)


@dataclass(frozen=True)
class RunContext:
    run_id: str
    universe_name: str
    start_date: pd.Timestamp
    end_date: pd.Timestamp
    config_hash: str


def ensure_timeseries_schema(
    df: pd.DataFrame,
    default_business_date: str | pd.Timestamp | None = None,
    keep_extra_columns: bool = False,
) -> pd.DataFrame:
    out = df.copy()
    if "business_date" not in out.columns:
        if default_business_date is None:
            raise ValueError("Missing required time-series column: business_date")
        out["business_date"] = pd.to_datetime(default_business_date).normalize()
    missing = [col for col in TIMESERIES_COLUMNS if col not in out.columns]
    if missing:
        raise ValueError(f"Missing required time-series columns: {missing}")
    out["business_date"] = pd.to_datetime(out["business_date"], utc=False).dt.tz_localize(None).dt.normalize()
    out["risk_factor_id"] = out["risk_factor_id"].astype(str)
    out["date"] = pd.to_datetime(out["date"], utc=False).dt.tz_localize(None)
    out["value"] = pd.to_numeric(out["value"], errors="coerce")
    if keep_extra_columns:
        required = list(TIMESERIES_COLUMNS)
        extras = [c for c in out.columns if c not in required]
        return out[required + extras]
    return out[list(TIMESERIES_COLUMNS)]


def load_yaml(path: str | Path) -> dict[str, Any]:
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f) or {}


def config_hash(config: dict[str, Any]) -> str:
    payload = json.dumps(config, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()
