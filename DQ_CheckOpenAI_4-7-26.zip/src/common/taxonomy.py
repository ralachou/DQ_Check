from __future__ import annotations

import re
from typing import Any

import pandas as pd

TAXONOMY_LEVELS = ["rf_level1", "rf_level2", "rf_level3", "rf_level4", "rf_level5"]
TAXONOMY_COLUMNS = ["asset_class", "ccy"] + TAXONOMY_LEVELS
# Default peer grouping is intentionally compact; per-universe custom rules/keys can override this.
TAXONOMY_PEER_KEYS = ["asset_class", "ccy", "rf_level1"]
PEER_GROUP_ID_COL = "peer_group_id"
PEER_GROUP_RULE_COL = "peer_group_rule_id"
DEFAULT_NULL_TOKEN = "null"

_MISSING_STRINGS = {"", "nan", "none", "null", "<na>", "nat"}

_ALIASES: dict[str, list[str]] = {
    "risk_factor_id": ["risk_factor_id", "driverName", "driver_name"],
    "asset_class": ["asset_class", "assetClass", "rf_asset_class"],
    "ccy": ["ccy", "currency", "rf_ccy"],
    "rf_level1": ["rf_level1", "rfLevel1"],
    "rf_level2": ["rf_level2", "rfLevel2"],
    "rf_level3": ["rf_level3", "rfLevel3"],
    "rf_level4": ["rf_level4", "rfLevel4"],
    "rf_level5": ["rf_level5", "rfLevel5"],
}


def _to_list(value: Any) -> list[Any]:
    if value is None:
        return []
    if isinstance(value, (list, tuple, set)):
        return list(value)
    return [value]


def _sql_like_to_regex(pattern: str) -> str:
    # SQL-like wildcard support: % -> any sequence, _ -> any single char.
    out: list[str] = []
    for ch in str(pattern):
        if ch == "%":
            out.append(".*")
        elif ch == "_":
            out.append(".")
        else:
            out.append(re.escape(ch))
    return "^" + "".join(out) + "$"


def _match_condition(series: pd.Series, condition: Any) -> pd.Series:
    s = series.astype(str)

    # Backward compatible behavior: scalar ==, list -> isin.
    if not isinstance(condition, dict):
        if isinstance(condition, list):
            target = {str(x) for x in condition}
            return s.isin(target)
        return s == str(condition)

    mask = pd.Series(True, index=series.index, dtype=bool)
    for op, raw in condition.items():
        op_name = str(op).strip().lower().replace(" ", "_").replace("-", "_")
        values = [str(x) for x in _to_list(raw)]

        if op_name == "eq":
            mask &= s == (values[0] if values else "")
        elif op_name == "ne":
            mask &= s != (values[0] if values else "")
        elif op_name == "in":
            mask &= s.isin(set(values))
        elif op_name in {"not_in", "nin"}:
            mask &= ~s.isin(set(values))
        elif op_name in {"like", "ilike"}:
            like_mask = pd.Series(False, index=series.index, dtype=bool)
            for v in values:
                regex = _sql_like_to_regex(v)
                like_mask |= s.str.match(regex, case=False, na=False)
            mask &= like_mask
        elif op_name in {"not_like", "not_ilike"}:
            not_like_mask = pd.Series(True, index=series.index, dtype=bool)
            for v in values:
                regex = _sql_like_to_regex(v)
                not_like_mask &= ~s.str.match(regex, case=False, na=False)
            mask &= not_like_mask
        elif op_name == "contains":
            contains_mask = pd.Series(False, index=series.index, dtype=bool)
            for v in values:
                contains_mask |= s.str.contains(re.escape(v), case=False, na=False, regex=True)
            mask &= contains_mask
        elif op_name == "startswith":
            sw_mask = pd.Series(False, index=series.index, dtype=bool)
            for v in values:
                sw_mask |= s.str.startswith(v, na=False)
            mask &= sw_mask
        elif op_name == "endswith":
            ew_mask = pd.Series(False, index=series.index, dtype=bool)
            for v in values:
                ew_mask |= s.str.endswith(v, na=False)
            mask &= ew_mask
        else:
            raise ValueError(f"Unsupported taxonomy operator '{op_name}'.")
    return mask


def _compose_group_id(df: pd.DataFrame, keys: list[str], prefix: str, default: str = DEFAULT_NULL_TOKEN) -> pd.Series:
    if not keys:
        return pd.Series(f"{prefix}::ALL", index=df.index, dtype=object)
    out = pd.Series(prefix, index=df.index, dtype=object)
    for key in keys:
        values = df[key].astype(str).fillna(default) if key in df.columns else pd.Series(default, index=df.index, dtype=object)
        out = out + "|" + key + "=" + values
    return out


def _find_col(df: pd.DataFrame, names: list[str]) -> str | None:
    for n in names:
        if n in df.columns:
            return n
    lower_map = {str(c).strip().lower(): str(c) for c in df.columns}
    for n in names:
        hit = lower_map.get(str(n).strip().lower())
        if hit is not None:
            return hit
    return None


def _clean_text_series(series: pd.Series, default: str = DEFAULT_NULL_TOKEN) -> pd.Series:
    s = series.astype("string").fillna(default).str.strip()
    lower = s.str.lower()
    s = s.mask(lower.isin(_MISSING_STRINGS), default)
    return s.astype(str)


def _coalesce_series(parts: list[pd.Series], default: str = DEFAULT_NULL_TOKEN) -> pd.Series:
    if not parts:
        return pd.Series(dtype=str)
    out = _clean_text_series(parts[0], default=default)
    for p in parts[1:]:
        nxt = _clean_text_series(p, default=default)
        out = out.where(out != default, nxt)
    return _clean_text_series(out, default=default)


def normalize_taxonomy_frame(
    df: pd.DataFrame,
    *,
    default: str = DEFAULT_NULL_TOKEN,
    require_risk_factor_id: bool = False,
) -> pd.DataFrame:
    """Normalize taxonomy columns with consistent non-destructive fallbacks.

    Fallback rules:
    - asset_class <- asset_class OR rf_level1
    - ccy         <- ccy OR rf_level2
    - rf_level1   <- rf_level1 OR asset_class
    - rf_level2   <- rf_level2 OR ccy
    - rf_level3..5 default to "null" when missing
    """

    out = df.copy()

    id_col = _find_col(out, _ALIASES["risk_factor_id"])
    if id_col is None:
        if require_risk_factor_id:
            raise ValueError("Missing risk factor identifier column (risk_factor_id/driverName/driver_name).")
        out["risk_factor_id"] = default
    elif id_col != "risk_factor_id":
        out["risk_factor_id"] = out[id_col]

    for col in TAXONOMY_COLUMNS:
        src = _find_col(out, _ALIASES.get(col, [col]))
        if src is None:
            out[col] = default
        elif col not in out.columns:
            out[col] = out[src]

    out["asset_class"] = _coalesce_series([out["asset_class"], out["rf_level1"]], default=default)
    out["ccy"] = _coalesce_series([out["ccy"], out["rf_level2"]], default=default)
    out["rf_level1"] = _coalesce_series([out["rf_level1"], out["asset_class"]], default=default)
    out["rf_level2"] = _coalesce_series([out["rf_level2"], out["ccy"]], default=default)
    out["rf_level3"] = _clean_text_series(out["rf_level3"], default=default)
    out["rf_level4"] = _clean_text_series(out["rf_level4"], default=default)
    out["rf_level5"] = _clean_text_series(out["rf_level5"], default=default)
    out["risk_factor_id"] = _clean_text_series(out["risk_factor_id"], default=default)

    return out


def apply_taxonomy_filters(df: pd.DataFrame, filters: dict[str, Any] | None = None) -> pd.DataFrame:
    out = normalize_taxonomy_frame(df, require_risk_factor_id=False)
    for k, v in (filters or {}).items():
        if k not in out.columns:
            continue
        out = out[_match_condition(out[k], v)]
    return out.reset_index(drop=True)


def resolve_peer_group_config(
    catalog: dict[str, Any] | None,
    universe_name: str | None = None,
    *,
    membership: pd.DataFrame | None = None,
    default_keys: list[str] | None = None,
) -> dict[str, Any]:
    """
    Resolve peer-group configuration with precedence:
      1) universes.<name>.peer_group
      2) universes.<name>.peer_group_keys
      3) asset_class_defaults.<asset>.peer_group_keys (if resolvable)
      4) default_keys / TAXONOMY_PEER_KEYS
    """
    base_keys = list(default_keys or TAXONOMY_PEER_KEYS)
    rules: list[dict[str, Any]] = []
    source = "default"

    if not isinstance(catalog, dict):
        return {"keys": base_keys, "rules": rules, "source": source}

    uni_cfg = (catalog.get("universes", {}) or {}).get(str(universe_name or ""), {}) or {}
    peer_group_cfg = uni_cfg.get("peer_group", {}) or {}

    keys = []
    if isinstance(peer_group_cfg, dict):
        keys = [str(x) for x in _to_list(peer_group_cfg.get("keys")) if str(x)]
        rules = [r for r in _to_list(peer_group_cfg.get("rules")) if isinstance(r, dict)]
        if keys or rules:
            source = f"universes.{universe_name}.peer_group"
    if not keys:
        legacy_keys = [str(x) for x in _to_list(uni_cfg.get("peer_group_keys")) if str(x)]
        if legacy_keys:
            keys = legacy_keys
            source = f"universes.{universe_name}.peer_group_keys"

    if not keys:
        asset_defaults = catalog.get("asset_class_defaults", {}) or {}
        uni_filters = uni_cfg.get("filters", {}) or {}
        candidate_assets = []
        for col in ("asset_class", "rf_level1"):
            v = uni_filters.get(col)
            candidate_assets.extend([str(x) for x in _to_list(v) if str(x)])
        if membership is not None and "asset_class" in membership.columns and not membership.empty:
            inferred = sorted(membership["asset_class"].astype(str).dropna().unique().tolist())
            if len(inferred) == 1:
                candidate_assets.append(inferred[0])
        for asset in candidate_assets:
            cfg = asset_defaults.get(asset, {}) or {}
            ac_keys = [str(x) for x in _to_list(cfg.get("peer_group_keys")) if str(x)]
            if ac_keys:
                keys = ac_keys
                source = f"asset_class_defaults.{asset}.peer_group_keys"
                break

    if not keys:
        keys = base_keys

    valid_keys = [str(k) for k in keys if str(k)]
    if not valid_keys:
        valid_keys = list(base_keys)

    return {"keys": valid_keys, "rules": rules, "source": source}


def apply_peer_grouping(
    membership: pd.DataFrame,
    *,
    peer_keys: list[str],
    peer_rules: list[dict[str, Any]] | None = None,
    default: str = DEFAULT_NULL_TOKEN,
) -> tuple[pd.DataFrame, list[str]]:
    """
    Apply peer grouping keys and optional rule overrides.

    Rule format example:
      {
        "id": "cp_rate_usd_custom",
        "when": {
          "asset_class": {"eq": "CP_RATE"},
          "ccy": {"in": ["USD", "EUR"]},
          "rf_level1": {"like": "CP_%"},
          "rf_level2": {"not_like": "TEST%"},
          "rf_level3": {"like": "CORP%"}
        },
        "keys": ["asset_class", "ccy", "rf_level1", "rf_level2"]
      }
    """
    out = normalize_taxonomy_frame(membership, require_risk_factor_id=True, default=default).copy()
    valid_keys = [k for k in peer_keys if k in out.columns]
    if not valid_keys:
        valid_keys = [k for k in TAXONOMY_PEER_KEYS if k in out.columns]
    if not valid_keys:
        valid_keys = ["risk_factor_id"]

    out[PEER_GROUP_RULE_COL] = "default"
    out[PEER_GROUP_ID_COL] = _compose_group_id(out, valid_keys, prefix="default", default=default)

    rules = [r for r in _to_list(peer_rules) if isinstance(r, dict)]
    for i, rule in enumerate(rules):
        rule_id = str(rule.get("id", f"rule_{i+1}"))
        when = rule.get("when", {}) or {}
        if not isinstance(when, dict) or not when:
            continue

        mask = pd.Series(True, index=out.index, dtype=bool)
        for col, cond in when.items():
            if col not in out.columns:
                mask &= False
                continue
            mask &= _match_condition(out[col], cond)
        if not bool(mask.any()):
            continue

        rule_keys = [str(x) for x in _to_list(rule.get("keys")) if str(x) in out.columns]
        if not rule_keys:
            rule_keys = valid_keys
        out.loc[mask, PEER_GROUP_RULE_COL] = rule_id
        out.loc[mask, PEER_GROUP_ID_COL] = _compose_group_id(
            out.loc[mask], rule_keys, prefix=f"rule:{rule_id}", default=default
        )

    return out, [PEER_GROUP_ID_COL]
