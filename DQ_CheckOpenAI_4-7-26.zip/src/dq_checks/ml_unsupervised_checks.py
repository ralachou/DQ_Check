from __future__ import annotations

import json
from typing import Any

import numpy as np
import pandas as pd
from sklearn.decomposition import PCA
from sklearn.ensemble import IsolationForest

from dq_checks.base import DQCheck, severity_from_ratio
from dq_checks.taxonomy import ML_UNSUPERVISED


def _finalize_ml_output(
    df: pd.DataFrame,
    raw_score: pd.Series,
    threshold: float,
    reason_code: str,
    explain: str,
    artifacts: dict[str, Any] | None = None,
) -> pd.DataFrame:
    out = df[["risk_factor_id", "date"]].copy()
    out["raw_score"] = raw_score.astype(float).fillna(0.0)
    out["threshold"] = float(threshold)
    out["flag"] = out["raw_score"] >= threshold
    ratio = out["raw_score"] / (threshold + 1.0e-12)
    out["severity"] = severity_from_ratio(ratio)
    out.loc[~out["flag"], "severity"] = "Low"
    out["reason_code"] = np.where(out["flag"], reason_code, "OK")
    out["explain"] = np.where(out["flag"], explain, "No issue")
    out["artifacts_json"] = json.dumps(artifacts or {})
    return out


def _normalize_01(raw: np.ndarray) -> np.ndarray:
    raw = np.asarray(raw, dtype=float)
    lo = float(np.nanmin(raw)) if len(raw) else 0.0
    hi = float(np.nanmax(raw)) if len(raw) else 1.0
    return (raw - lo) / (hi - lo + 1.0e-12)


def _build_peer_relative_features(
    df: pd.DataFrame,
    windows: tuple[int, int] = (20, 60),
) -> pd.DataFrame:
    """Build 6 peer-relative features for each risk_factor_id per date.

    Input: long-form DataFrame with risk_factor_id, date, value (full peer group).
    Output: same shape with added feature columns.

    Features produced:
      1. value_minus_peer_median  — level deviation from peer center
      2. peer_z                   — standardized deviation (in IQR-scaled units)
      3. ret_minus_peer_ret       — move deviation from peer consensus move
      4. vol_minus_peer_vol       — volatility deviation from peers
      5. peer_rank                — percentile rank in cross-section (0=lowest, 1=highest)
      6. corr_to_peer_60d         — rolling 60-day correlation to peer median

    IMPORTANT: Uses diff() not pct_change() for returns, and difference not ratio
    for volatility. This avoids division-by-near-zero explosions on shift/spread
    data that crosses zero (e.g., a spread going from 0.000002 to 0.008 would
    produce a 431,150% pct_change but only a 0.008 diff).
    """
    w_short, w_long = windows
    d = df[["risk_factor_id", "date", "value"]].copy()
    d["date"] = pd.to_datetime(d["date"], errors="coerce")
    d["value"] = pd.to_numeric(d["value"], errors="coerce")
    d = d.dropna(subset=["date", "value"]).sort_values(["risk_factor_id", "date"])

    # --- Per-factor time-series features ---

    # Daily move (first difference, NOT pct_change)
    #   diff() is bounded and well-behaved even when value crosses zero.
    d["move_1d"] = d.groupby("risk_factor_id")["value"].diff().fillna(0.0)

    # Rolling 20-day volatility of moves (std of daily diffs)
    d["rolling_vol_20"] = (
        d.groupby("risk_factor_id")["move_1d"]
        .transform(lambda x: x.rolling(w_short, min_periods=5).std(ddof=0))
        .fillna(0.0)
    )

    # --- Per-date cross-sectional peer stats ---

    # Peer median, Q25, Q75, IQR across all factors on each date
    peer = d.groupby("date", as_index=False)["value"].agg(
        peer_median="median",                               # center of peer distribution today
        peer_q25=lambda s: s.quantile(0.25),
        peer_q75=lambda s: s.quantile(0.75),
    )
    peer["peer_iqr"] = peer["peer_q75"] - peer["peer_q25"]  # interquartile range

    # Peer median move and peer median vol on each date
    peer_move = d.groupby("date", as_index=False)["move_1d"].agg(peer_median_move="median")
    peer_vol = d.groupby("date", as_index=False)["rolling_vol_20"].agg(peer_median_vol="median")
    d = d.merge(peer, on="date", how="left")
    d = d.merge(peer_move, on="date", how="left")
    d = d.merge(peer_vol, on="date", how="left")

    # --- 6 peer-relative features (all use differences, not ratios) ---

    # Feature 1: Level deviation from peer center
    #   Positive = factor above peer median, negative = below
    d["value_minus_peer_median"] = d["value"] - d["peer_median"]

    # Feature 2: Standardized peer deviation (in IQR-scaled sigma units)
    #   1.349 ≈ IQR/sigma conversion factor under normality
    d["peer_z"] = d["value_minus_peer_median"] / (d["peer_iqr"] / 1.349 + 1e-9)

    # Feature 3: Move deviation — did this factor move differently from peers?
    #   Uses diff (not pct_change) to avoid near-zero denominator explosions
    d["ret_minus_peer_ret"] = d["move_1d"] - d["peer_median_move"]

    # Feature 4: Volatility deviation — is this factor more/less volatile than peers?
    #   Uses difference (not ratio) for same reason as Feature 3
    d["vol_minus_peer_vol"] = d["rolling_vol_20"] - d["peer_median_vol"]

    # Feature 5: Percentile rank in today's cross-section (0.0 = lowest, 1.0 = highest)
    d["peer_rank"] = d.groupby("date")["value"].rank(pct=True)

    # Rolling correlation to peer median (per factor)
    pivot = d.pivot(index="date", columns="risk_factor_id", values="value")
    pivot = pivot.sort_index().ffill().bfill().fillna(0.0)
    p_med = d.groupby("date")["value"].median()
    corr_parts = {}
    for rf_id in pivot.columns:
        corr_parts[rf_id] = pivot[rf_id].rolling(w_long, min_periods=10).corr(p_med).fillna(0.0)
    corr_df = pd.DataFrame(corr_parts).stack().reset_index()
    corr_df.columns = ["date", "risk_factor_id", "corr_to_peer_60d"]
    d = d.merge(corr_df, on=["date", "risk_factor_id"], how="left")
    d["corr_to_peer_60d"] = d["corr_to_peer_60d"].fillna(0.0)

    return d


# ---------------------------------------------------------------------------
# Check 1 — IForest on Peer-Relative Features (ML_UNSUPERVISED family)
# ---------------------------------------------------------------------------

class IForestPeerCheck(DQCheck):
    """Isolation Forest on peer-relative features.

    Builds peer-relative features from the full peer group, then runs
    sklearn IsolationForest to detect multivariate anomalies.
    Operates per peer group (fit_policy=per_peer_group).
    """

    FEATURE_COLS = [
        "value_minus_peer_median",
        "peer_z",
        "ret_minus_peer_ret",
        "vol_minus_peer_vol",
        "peer_rank",
        "corr_to_peer_60d",
    ]

    def __init__(self, **params: Any) -> None:
        super().__init__(
            name="iforest_peer",
            family=ML_UNSUPERVISED,
            scope="per_peer_group",
            fit_policy="per_peer_group",
            **params,
        )

    def fit(self, df: pd.DataFrame, context: dict[str, Any]) -> dict[str, Any] | None:
        """Fit Isolation Forest on peer-relative features.

        Step 1: Build 6 peer-relative features from the full peer group
        Step 2: Train IsolationForest on the feature matrix
        """
        del context
        # Guardrail: need at least 3 factors for meaningful peer stats
        if df.empty or df["risk_factor_id"].nunique() < 3:
            return None

        # Step 1: Build peer-relative features for ALL factors × ALL dates
        #   Each row gets 6 features: value_minus_peer_median, peer_z, ret_minus_peer_ret,
        #   vol_minus_peer_vol, peer_rank, corr_to_peer_60d
        feat = _build_peer_relative_features(df)
        feature_cols = [c for c in self.FEATURE_COLS if c in feat.columns]
        if not feature_cols:
            return None

        # Step 2: Build feature matrix (all factors × all dates × 6 features)
        x = feat[feature_cols].replace([np.inf, -np.inf], np.nan).fillna(0.0).to_numpy(dtype=float)
        # Optional: limit training data to most recent N rows
        retrain_window = int(self.params.get("retrain_window", 0))
        if retrain_window > 0 and len(x) > retrain_window:
            x_train = x[-retrain_window:]
        else:
            x_train = x

        # Step 3: Fit IsolationForest
        #   Each of 200 trees randomly picks a feature and split point, partitions data.
        #   Anomalies are isolated in fewer splits (shorter path length).
        #   contamination tells the model "expect ~1% of points to be anomalies" — affects
        #   the decision_function offset, NOT the scoring logic itself.
        contamination = float(self.params.get("contamination", 0.01))
        n_estimators = int(self.params.get("n_estimators", 200))
        model = IsolationForest(
            contamination=contamination,
            n_estimators=n_estimators,
            random_state=42,
        )
        model.fit(x_train)
        return {"model": model, "feature_cols": feature_cols}

    def score(
        self,
        df: pd.DataFrame,
        context: dict[str, Any],
        model_state: dict[str, Any] | None = None,
    ) -> pd.DataFrame:
        """Score each factor-date using the fitted IsolationForest.

        Step 1: Rebuild peer-relative features for scoring data
        Step 2: Get anomaly scores from IForest (shorter path = more anomalous)
        Step 3: Normalize to [0,1], flag if above threshold
        """
        if df.empty or df["risk_factor_id"].nunique() < 3:
            return self.empty_result(df, "Peer group too small for IForest.")

        state = model_state or self.fit(df, context)
        if state is None:
            return self.empty_result(df, "IForest model fitting failed.")

        model = state["model"]
        feature_cols = state["feature_cols"]

        # Step 1: Rebuild features (same as fit — features are stateless)
        feat = _build_peer_relative_features(df)
        x = feat[feature_cols].replace([np.inf, -np.inf], np.nan).fillna(0.0).to_numpy(dtype=float)

        # Step 2: Get anomaly scores
        #   sklearn decision_function: LOWER = more anomalous (negative = outlier)
        #   We negate so HIGHER = more anomalous (consistent with all other checks)
        raw = -model.decision_function(x)

        # Step 3: Min-max normalize to [0,1]
        #   Score near 1.0 = most anomalous (short path, easy to isolate)
        #   Score near 0.0 = normal (long path, hard to isolate)
        raw01 = _normalize_01(raw)

        # Step 4: Flag if normalized score >= threshold (default 0.95)
        threshold = float(self.params.get("threshold", 0.95))
        return _finalize_ml_output(
            df=feat,
            raw_score=pd.Series(raw01, index=feat.index),
            threshold=threshold,
            reason_code="IFOREST_PEER",
            explain=f"IForest peer-relative anomaly score exceeds {threshold}",
            artifacts={
                "model": "iforest_peer",
                "features_used": feature_cols,
                "n_estimators": int(self.params.get("n_estimators", 200)),
                "contamination": float(self.params.get("contamination", 0.01)),
            },
        )


# ---------------------------------------------------------------------------
# Check 2 — PCA Curve Reconstruction (ML_UNSUPERVISED family)
# ---------------------------------------------------------------------------

class PCACurveCheck(DQCheck):
    """PCA reconstruction error for curves and surfaces.

    Designed for peer groups that represent a curve (e.g., IR swap tenors,
    credit spread term structure, vol surface ATM). Fits PCA on the
    cross-section (dates x factors matrix), reconstructs each factor from
    the top-K components, and flags factors with large reconstruction error.

    Key difference from nowcast_pca_recon:
    - This check standardizes each factor before PCA (z-score normalization)
      so factors at different levels/scales contribute equally.
    - Computes per-factor rolling residual sigma for adaptive thresholding.
    - Tracks explained variance and per-component contribution for explainability.

    Best for:
    - IR rate curves (level/slope/curvature → 3 components)
    - Vol ATM term structure (4-5 components)
    - Credit spread term structure by rating/sector
    """

    def __init__(self, **params: Any) -> None:
        super().__init__(
            name="pca_curve",
            family=ML_UNSUPERVISED,
            scope="per_peer_group",
            fit_policy="per_peer_group",
            **params,
        )

    def _pivot_and_standardize(self, df: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame, dict[str, float], dict[str, float]]:
        """Pivot long-form data to wide matrix and z-score standardize each factor.

        Z-score standardization ensures factors at different levels/scales
        (e.g., 2Y rate at 3.5% vs 30Y at 4.8%) contribute equally to PCA.
        Without this, PCA is dominated by the highest-level factors.
        """
        d = df[["risk_factor_id", "date", "value"]].copy()
        d["value"] = pd.to_numeric(d["value"], errors="coerce")
        d = d.drop_duplicates(subset=["risk_factor_id", "date"], keep="last")
        # Pivot: rows=dates, columns=risk_factor_ids, cells=values
        matrix = d.pivot(index="date", columns="risk_factor_id", values="value").sort_index()
        matrix = matrix.ffill().bfill().fillna(0.0)

        # Store means/stds for each factor (used later in scoring to standardize with FIT-TIME stats)
        means = {c: float(matrix[c].mean()) for c in matrix.columns}
        stds = {c: float(matrix[c].std(ddof=0) + 1e-9) for c in matrix.columns}
        # Standardize: each factor has mean=0, std=1
        standardized = matrix.copy()
        for c in matrix.columns:
            standardized[c] = (matrix[c] - means[c]) / stds[c]
        return matrix, standardized, means, stds

    def fit(self, df: pd.DataFrame, context: dict[str, Any]) -> dict[str, Any] | None:
        """Fit PCA on the standardized cross-section and compute reconstruction residuals.

        Key design decisions:
          - PCA is fit on data EXCLUDING the last score_holdout days, so anomalies
            in the scoring window are not absorbed into the learned components.
          - Residuals are computed on the FULL history for rolling sigma computation.
          - Means/stds are stored for use during scoring (so scoring data is standardized
            with FIT-TIME stats, not re-computed — prevents anomaly from being normalized away).
        """
        del context
        if df.empty or df["risk_factor_id"].nunique() < 3:
            return None

        # Step 1: Pivot to wide matrix and standardize
        matrix, standardized, means, stds = self._pivot_and_standardize(df)
        min_history = int(self.params.get("min_history", 40))
        if len(matrix) < min_history:
            return None

        # Step 2: Determine number of PCA components
        #   n_components=3 → fixed 3 components (level/slope/curvature for rate curves)
        #   n_components=0.95 → auto-select to explain 95% of variance
        n_comp = self.params.get("n_components", 3)
        if isinstance(n_comp, float) and n_comp < 1.0:
            max_comp = min(standardized.shape[0], standardized.shape[1]) - 1
            n_comp_actual = min(max(1, max_comp), standardized.shape[1])
        else:
            n_comp = int(n_comp)
            max_comp = min(standardized.shape[0], standardized.shape[1])
            n_comp_actual = min(n_comp, max(1, max_comp - 1))

        # Step 3: Fit PCA on historical data EXCLUDING the last score_holdout days.
        #   CRITICAL: If we fit on ALL data including the anomalous last day,
        #   PCA learns to reconstruct the anomaly → reconstruction error ≈ 0 → miss.
        #   By excluding the last 5 days, the PCA only knows "normal" patterns.
        score_holdout = int(self.params.get("score_holdout", 5))
        train_data = standardized.to_numpy()
        if len(train_data) > score_holdout + min_history:
            train_data = train_data[:-score_holdout]

        # Step 4: Fit PCA — learns K dominant patterns (components) from historical data
        #   e.g., PC1="level shift" (all tenors move together), explains 65%
        #         PC2="slope change" (short up, long down), explains 20%
        #         PC3="curvature" (belly vs wings), explains 10%
        pca = PCA(n_components=n_comp_actual, svd_solver="full")
        pca.fit(train_data)

        # Step 5: Compute reconstruction residuals on FULL data using the trained PCA
        #   transform: project each date's cross-section onto the K components
        #   inverse_transform: reconstruct from the K components back to N factors
        #   residual = standardized_actual - standardized_reconstructed
        #   Large residual = this factor doesn't fit the dominant curve patterns today
        projected = pca.transform(standardized.to_numpy())
        reconstructed = pca.inverse_transform(projected)
        residual_std = pd.DataFrame(reconstructed, index=matrix.index, columns=matrix.columns)
        residual_std = standardized - residual_std

        # Step 6: Per-factor rolling sigma of reconstruction error
        #   Used to standardize the residual: raw_score = |residual| / rolling_sigma
        #   This makes the threshold adaptive — a factor that historically has
        #   larger errors gets a wider band before flagging.
        residual_window = int(self.params.get("residual_window", 60))
        rolling_sigma = {}
        for c in residual_std.columns:
            rolling_sigma[c] = residual_std[c].rolling(
                residual_window, min_periods=max(10, residual_window // 4)
            ).std(ddof=0).fillna(residual_std[c].iloc[:-score_holdout].std(ddof=0) + 1e-9)

        return {
            "pca": pca,
            "means": means,
            "stds": stds,
            "columns": list(matrix.columns),
            "rolling_sigma": rolling_sigma,
        }

    def score(
        self,
        df: pd.DataFrame,
        context: dict[str, Any],
        model_state: dict[str, Any] | None = None,
    ) -> pd.DataFrame:
        if df.empty or df["risk_factor_id"].nunique() < 3:
            return self.empty_result(df, "Peer group too small for PCA curve check.")

        state = model_state or self.fit(df, context)
        if state is None:
            return self.empty_result(df, "PCA curve model fitting failed.")

        pca = state["pca"]
        means = state["means"]
        stds = state["stds"]
        cols = state["columns"]
        rolling_sigma = state["rolling_sigma"]

        # Pivot scoring data but standardize using FIT-TIME means/stds
        # so anomalies in scoring data are NOT absorbed into normalization.
        d = df[["risk_factor_id", "date", "value"]].copy()
        d["value"] = pd.to_numeric(d["value"], errors="coerce")
        d = d.drop_duplicates(subset=["risk_factor_id", "date"], keep="last")
        matrix = d.pivot(index="date", columns="risk_factor_id", values="value").sort_index()
        matrix = matrix.ffill().bfill().fillna(0.0)

        available = [c for c in cols if c in matrix.columns]
        if len(available) != len(cols):
            return self.empty_result(df, "Column mismatch in PCA curve scoring.")

        standardized = matrix[cols].copy()
        for c in cols:
            standardized[c] = (matrix[c] - means[c]) / stds[c]

        data_std = standardized.to_numpy()
        projected = pca.transform(data_std)
        reconstructed = pca.inverse_transform(projected)
        residual_std_mat = data_std - reconstructed

        threshold = float(self.params.get("threshold", 3.5))
        explained = pca.explained_variance_ratio_.tolist()

        parts: list[pd.DataFrame] = []
        for i, rf_id in enumerate(cols):
            resid = pd.Series(residual_std_mat[:, i], index=matrix.index)
            sigma = rolling_sigma.get(rf_id)
            if sigma is not None:
                sigma = sigma.reindex(matrix.index).fillna(resid.std(ddof=0) + 1e-9)
            else:
                sigma = pd.Series(resid.std(ddof=0) + 1e-9, index=matrix.index)
            raw_score = resid.abs() / (sigma + 1e-9)

            target_df = df[df["risk_factor_id"] == rf_id].copy()
            target_df["date"] = pd.to_datetime(target_df["date"])
            target_df = target_df.sort_values("date").drop_duplicates(subset=["date"], keep="last")
            score_map = raw_score.to_dict()
            scores = target_df["date"].map(score_map).fillna(0.0)

            last_idx = min(len(reconstructed) - 1, len(matrix) - 1)
            recon_val = float(reconstructed[last_idx, i] * stds[rf_id] + means[rf_id])
            actual_val = float(matrix[rf_id].iloc[-1]) if rf_id in matrix.columns else 0.0

            out = _finalize_ml_output(
                df=target_df,
                raw_score=scores,
                threshold=threshold,
                reason_code="PCA_CURVE",
                explain=f"PCA curve reconstruction error exceeds {threshold} sigma",
                artifacts={
                    "model": "pca_curve",
                    "n_components": int(pca.n_components_),
                    "explained_variance_ratio": [round(v, 4) for v in explained[:5]],
                    "total_explained": round(sum(explained), 4),
                    "reconstructed_value": round(recon_val, 6),
                    "actual_value": round(actual_val, 6),
                    "residual_std_units": round(float(resid.iloc[-1]) if len(resid) > 0 else 0.0, 4),
                },
            )
            parts.append(out)

        if not parts:
            return self.empty_result(df, "No PCA curve scores produced.")
        return pd.concat(parts, ignore_index=True)
