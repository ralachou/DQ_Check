from __future__ import annotations

import json
import warnings
from abc import abstractmethod
from typing import Any

import numpy as np
import pandas as pd
from sklearn.decomposition import PCA
from sklearn.linear_model import ElasticNet, ElasticNetCV, Ridge

from dq_checks.base import DQCheck, severity_from_ratio
from dq_checks.taxonomy import NOWCAST_PEER


def _finalize_nowcast_output(
    df: pd.DataFrame,
    raw_score: pd.Series,
    threshold: float,
    reason_code: str,
    explain: str,
    artifacts: dict[str, Any] | None = None,
) -> pd.DataFrame:
    out = df[["risk_factor_id", "date"]].copy()
    out["raw_score"] = raw_score.astype(float).fillna(0.0)
    out["threshold"] = float(threshold)
    out["flag"] = out["raw_score"] >= threshold
    ratio = out["raw_score"] / (threshold + 1.0e-12)
    out["severity"] = severity_from_ratio(ratio)
    out.loc[~out["flag"], "severity"] = "Low"
    out["reason_code"] = np.where(out["flag"], reason_code, "OK")
    out["explain"] = np.where(out["flag"], explain, "No issue")
    out["artifacts_json"] = json.dumps(artifacts or {})
    return out


def _pivot_peer_matrix(df: pd.DataFrame) -> tuple[pd.DataFrame, list[str]]:
    """Pivot long-form peer data into (dates x risk_factors) matrix."""
    d = df[["risk_factor_id", "date", "value"]].copy()
    d["value"] = pd.to_numeric(d["value"], errors="coerce")
    d = d.drop_duplicates(subset=["risk_factor_id", "date"], keep="last")
    matrix = d.pivot(index="date", columns="risk_factor_id", values="value").sort_index()
    matrix = matrix.ffill().bfill().fillna(0.0)
    return matrix, list(matrix.columns)


class NowcastBaseCheck(DQCheck):
    """Abstract base for all nowcast checks.

    Subclasses override _select_peers(), _fit_model(), and _nowcast().
    Shared logic: residual computation, standardization, flagging.
    """

    def __init__(self, name: str, **params: Any) -> None:
        super().__init__(
            name=name,
            family=NOWCAST_PEER,
            scope="per_peer_group",
            fit_policy="per_peer_group",
            **params,
        )

    @abstractmethod
    def _select_peers(
        self, target_id: str, matrix: pd.DataFrame, all_ids: list[str]
    ) -> list[str]:
        raise NotImplementedError

    @abstractmethod
    def _fit_model(
        self, target_series: pd.Series, peer_matrix: pd.DataFrame
    ) -> Any:
        raise NotImplementedError

    @abstractmethod
    def _nowcast(
        self, model: Any, target_id: str, peer_matrix: pd.DataFrame, full_matrix: pd.DataFrame
    ) -> pd.Series:
        raise NotImplementedError

    def _residual(self, actual: pd.Series, predicted: pd.Series) -> pd.Series:
        return actual - predicted

    def _standardize_residual(self, residual: pd.Series) -> pd.Series:
        window = int(self.params.get("residual_window", 60))
        min_periods = max(10, window // 4)
        rolling_std = residual.rolling(window=window, min_periods=min_periods).std(ddof=0)
        return (residual.abs() / (rolling_std + 1.0e-9)).fillna(0.0)

    def fit(self, df: pd.DataFrame, context: dict[str, Any]) -> dict[str, Any] | None:
        """Fit a nowcast model for each risk factor in the peer group.

        For each target factor:
          1. Pivot all peers into a (dates × factors) matrix
          2. Select which peers to use as predictors (subclass-specific)
          3. Train a model: target = f(selected_peers) (subclass-specific)
          4. Compute historical residuals = actual - predicted
          5. Store model + peer IDs + residual history in model_state
        """
        del context
        # Guardrail: need at least 3 factors for meaningful cross-sectional model
        if df.empty or df["risk_factor_id"].nunique() < 3:
            return None

        # Step 1: Pivot long-form data to wide matrix (dates × factors)
        #   Each column = one risk_factor_id, each row = one date, cells = value
        matrix, all_ids = _pivot_peer_matrix(df)
        min_history = int(self.params.get("min_history", 40))
        if len(matrix) < min_history:
            return None

        per_rf: dict[str, dict[str, Any]] = {}
        for target_id in all_ids:
            if target_id not in matrix.columns:
                continue

            # Step 2: Select peers for this target (Ridge: top-K by correlation)
            peers = self._select_peers(target_id, matrix, all_ids)
            if not peers:
                continue

            # Step 3: Fit the model: target_value = f(peer_values) + residual
            target_series = matrix[target_id]
            peer_matrix = matrix[peers]
            try:
                model = self._fit_model(target_series, peer_matrix)
            except Exception:
                continue

            # Step 4: Compute predicted values and historical residuals
            #   predicted = model's estimate of what target should be given peer values
            #   residual = actual - predicted (positive = target above prediction)
            predicted = self._nowcast(model, target_id, peer_matrix, matrix)
            residual = self._residual(target_series, predicted)

            # Step 5: Store everything needed for scoring
            per_rf[target_id] = {
                "model": model,               # fitted model object (Ridge/PCA/etc.)
                "peer_ids": peers,             # which peers were selected
                "residual_history": residual,  # past residuals for standardization
                "fit_date": str(matrix.index.max()),
                "method": self.name,
            }
        return {"per_rf": per_rf} if per_rf else None

    def score(
        self,
        df: pd.DataFrame,
        context: dict[str, Any],
        model_state: dict[str, Any] | None = None,
    ) -> pd.DataFrame:
        """Score each factor using the fitted nowcast model.

        For each target factor:
          1. Use the fitted model to predict today's value from today's peer values
          2. Compute residual = actual - predicted
          3. Standardize: raw_score = |residual| / rolling_std(residual_history)
          4. Flag if raw_score >= threshold
        """
        if df.empty or df["risk_factor_id"].nunique() < 3:
            return self.empty_result(df, "Peer group too small for nowcast.")

        # Use pre-fitted model state, or fit now if not provided
        state = model_state or self.fit(df, context)
        if state is None:
            return self.empty_result(df, "Nowcast model fitting failed.")
        per_rf = state.get("per_rf", {})
        if not per_rf:
            return self.empty_result(df, "No nowcast models available.")

        # Pivot scoring data to wide matrix (same format as fit)
        matrix, all_ids = _pivot_peer_matrix(df)
        threshold = float(self.params.get("threshold", 4.0))
        parts: list[pd.DataFrame] = []

        for target_id, rf_state in per_rf.items():
            if target_id not in matrix.columns:
                continue
            model = rf_state["model"]
            peers = rf_state["peer_ids"]
            available_peers = [p for p in peers if p in matrix.columns]
            if not available_peers:
                continue

            # Step 1: Predict target value from today's peer values using fitted model
            #   e.g., predicted = 0.45 * peer005_today + 0.32 * peer002_today + ... + intercept
            peer_matrix = matrix[available_peers]
            try:
                predicted = self._nowcast(model, target_id, peer_matrix, matrix)
            except Exception:
                continue

            # Step 2: Compute residual = actual - predicted
            #   If actual = 0.048 and predicted = -0.001, residual = 0.049
            #   Large residual = the model didn't expect this value = suspicious
            actual = matrix[target_id]
            residual = self._residual(actual, predicted)

            # Step 3: Standardize residual using rolling history
            #   Combine fit-time residual history with current residuals for stable sigma
            hist = rf_state.get("residual_history")
            if hist is not None and not hist.empty:
                combined = pd.concat([hist, residual]).drop_duplicates().sort_index()
                combined = combined[~combined.index.duplicated(keep="last")]
            else:
                combined = residual
            # raw_score = |residual| / rolling_std(residual, window=60)
            #   e.g., |0.049| / 0.007 = 7.0 sigma
            std_residual = self._standardize_residual(combined)
            # Keep only dates present in current scoring window
            std_residual = std_residual.reindex(matrix.index).fillna(0.0)

            # Step 4: Map scores back to original long-form rows for this target
            target_df = df[df["risk_factor_id"] == target_id].copy()
            target_df["date"] = pd.to_datetime(target_df["date"])
            target_df = target_df.sort_values("date").drop_duplicates(subset=["date"], keep="last")
            score_map = std_residual.to_dict()
            raw_scores = target_df["date"].map(score_map).fillna(0.0)

            # Step 5: Build explainability artifacts
            #   Includes: predicted value, actual value, residual, which peers used, their weights
            last_date = target_df["date"].max()
            nowcast_val = float(predicted.get(last_date, 0.0)) if hasattr(predicted, "get") else 0.0
            actual_val = float(actual.get(last_date, 0.0)) if hasattr(actual, "get") else 0.0
            top_peers = available_peers[:5]
            peer_weights = self._get_peer_weights(model, available_peers)

            # Step 6: Flag if raw_score >= threshold and assign severity
            out = _finalize_nowcast_output(
                df=target_df,
                raw_score=raw_scores,
                threshold=threshold,
                reason_code=self.name.upper().replace("NOWCAST_", "NC_"),
                explain=f"Nowcast residual ({self.name}) exceeds {threshold} sigma",
                artifacts={
                    "method": self.name,
                    "nowcast_value": round(nowcast_val, 6),
                    "actual_value": round(actual_val, 6),
                    "residual": round(actual_val - nowcast_val, 6),
                    "top_peers_used": top_peers,
                    "top_peer_weights": peer_weights[:5],
                    "n_peers": len(available_peers),
                    "days_since_refit": 0,
                },
            )
            parts.append(out)

        if not parts:
            return self.empty_result(df, "No nowcast scores produced.")
        return pd.concat(parts, ignore_index=True)

    def _get_peer_weights(self, model: Any, peer_ids: list[str]) -> list[float]:
        """Extract peer weights from model for explainability. Override in subclasses."""
        if hasattr(model, "coef_"):
            coef = np.asarray(model.coef_, dtype=float).flatten()
            if len(coef) == len(peer_ids):
                return [round(float(c), 4) for c in coef]
        return []


# ---------------------------------------------------------------------------
# Option 1 — Ridge Regression
# ---------------------------------------------------------------------------

class RidgeNowcastCheck(NowcastBaseCheck):
    """Predict each factor from its top-K most correlated peers using Ridge regression.

    For each factor i:
      predicted_i(t) = intercept + beta_1 * peer1(t) + beta_2 * peer2(t) + ... + beta_K * peerK(t)
      residual_i(t) = actual_i(t) - predicted_i(t)
      raw_score = |residual| / rolling_std(residual)

    The key advantage over peer_robust_z: Ridge LEARNS the specific beta of each factor
    to its peers. A structurally wide name gets a model that predicts it should be wide.
    """

    def __init__(self, **params: Any) -> None:
        super().__init__(name="nowcast_ridge", **params)

    def _select_peers(
        self, target_id: str, matrix: pd.DataFrame, all_ids: list[str]
    ) -> list[str]:
        """Select the top-K most correlated peers for this target factor.

        Uses rolling correlation over the last corr_window days.
        Only includes peers with |correlation| >= min_corr.
        """
        top_k = int(self.params.get("top_k", 10))
        corr_window = int(self.params.get("corr_window", 120))
        min_corr = float(self.params.get("min_corr", 0.3))

        # Step 1: Compute correlation of target with every other peer over recent window
        window = matrix.tail(corr_window)
        if target_id not in window.columns:
            return []
        corr = window.corr()[target_id].drop(target_id, errors="ignore")

        # Step 2: Filter by minimum absolute correlation and take top-K
        #   e.g., peer_005: 0.82, peer_002: 0.71, peer_009: 0.55 → all selected
        #         peer_007: 0.02 → below min_corr → excluded
        corr = corr[corr.abs() >= min_corr].sort_values(ascending=False, key=abs)
        return corr.head(top_k).index.tolist()

    def _fit_model(
        self, target_series: pd.Series, peer_matrix: pd.DataFrame
    ) -> Any:
        """Fit Ridge regression: target = intercept + sum(beta_j * peer_j).

        Ridge (L2 penalty) prevents overfitting when peers are highly correlated
        with each other (collinear). alpha=1.0 works well as default.
        """
        alpha = float(self.params.get("alpha", 1.0))
        mask = target_series.notna() & peer_matrix.notna().all(axis=1)
        model = Ridge(alpha=alpha)
        model.fit(peer_matrix.loc[mask], target_series.loc[mask])
        return model

    def _nowcast(
        self, model: Any, target_id: str, peer_matrix: pd.DataFrame, full_matrix: pd.DataFrame
    ) -> pd.Series:
        return pd.Series(model.predict(peer_matrix), index=peer_matrix.index)


# ---------------------------------------------------------------------------
# Option 2 — PCA Reconstruction
# ---------------------------------------------------------------------------

class PCAReconstructionCheck(NowcastBaseCheck):
    """Reconstruct each factor from top-K principal components of the peer group."""

    def __init__(self, **params: Any) -> None:
        super().__init__(name="nowcast_pca_recon", **params)

    def _select_peers(
        self, target_id: str, matrix: pd.DataFrame, all_ids: list[str]
    ) -> list[str]:
        # PCA uses the whole group; return all IDs including target
        return [c for c in all_ids if c in matrix.columns]

    def _fit_model(
        self, target_series: pd.Series, peer_matrix: pd.DataFrame
    ) -> Any:
        n_comp = self.params.get("n_components", 0.95)
        if isinstance(n_comp, float) and n_comp >= 1.0:
            n_comp = int(n_comp)
        max_comp = min(peer_matrix.shape[0], peer_matrix.shape[1])
        if isinstance(n_comp, int) and n_comp >= max_comp:
            n_comp = max(1, max_comp - 1)
        pca = PCA(n_components=n_comp, svd_solver="full")
        pca.fit(peer_matrix.fillna(0.0).to_numpy())
        return pca

    def _nowcast(
        self, model: Any, target_id: str, peer_matrix: pd.DataFrame, full_matrix: pd.DataFrame
    ) -> pd.Series:
        data = peer_matrix.fillna(0.0).to_numpy()
        projected = model.transform(data)
        reconstructed = model.inverse_transform(projected)
        cols = list(peer_matrix.columns)
        if target_id in cols:
            idx = cols.index(target_id)
            return pd.Series(reconstructed[:, idx], index=peer_matrix.index)
        return pd.Series(0.0, index=peer_matrix.index)

    def _get_peer_weights(self, model: Any, peer_ids: list[str]) -> list[float]:
        if hasattr(model, "explained_variance_ratio_"):
            return [round(float(v), 4) for v in model.explained_variance_ratio_[:5]]
        return []


# ---------------------------------------------------------------------------
# Option 3 — Elastic Net (auto-select peers)
# ---------------------------------------------------------------------------

class ElasticNetNowcastCheck(NowcastBaseCheck):
    """Predict each factor using all peers with Elastic Net auto-selection."""

    def __init__(self, **params: Any) -> None:
        super().__init__(name="nowcast_elastic_net", **params)

    def _select_peers(
        self, target_id: str, matrix: pd.DataFrame, all_ids: list[str]
    ) -> list[str]:
        # Use all peers; Elastic Net will zero out irrelevant ones
        return [c for c in all_ids if c != target_id and c in matrix.columns]

    def _fit_model(
        self, target_series: pd.Series, peer_matrix: pd.DataFrame
    ) -> Any:
        l1_ratio = float(self.params.get("l1_ratio", 0.5))
        mask = target_series.notna() & peer_matrix.notna().all(axis=1)
        x, y = peer_matrix.loc[mask], target_series.loc[mask]
        if len(x) < 20:
            return Ridge(alpha=1.0).fit(x, y)
        try:
            cv = ElasticNetCV(l1_ratio=l1_ratio, cv=3, random_state=42, max_iter=2000)
            cv.fit(x, y)
            model = ElasticNet(alpha=cv.alpha_, l1_ratio=l1_ratio, max_iter=2000)
            model.fit(x, y)
            return model
        except Exception:
            return Ridge(alpha=1.0).fit(x, y)

    def _nowcast(
        self, model: Any, target_id: str, peer_matrix: pd.DataFrame, full_matrix: pd.DataFrame
    ) -> pd.Series:
        return pd.Series(model.predict(peer_matrix), index=peer_matrix.index)


# ---------------------------------------------------------------------------
# Option 4 — XGBoost Regression
# ---------------------------------------------------------------------------

class XGBoostNowcastCheck(NowcastBaseCheck):
    """Non-linear nowcast using XGBoost (or GradientBoosting fallback) on top-K peers."""

    def __init__(self, **params: Any) -> None:
        super().__init__(name="nowcast_xgboost", **params)

    def _select_peers(
        self, target_id: str, matrix: pd.DataFrame, all_ids: list[str]
    ) -> list[str]:
        top_k = int(self.params.get("top_k", 15))
        corr_window = int(self.params.get("corr_window", 120))
        min_corr = float(self.params.get("min_corr", 0.3))
        window = matrix.tail(corr_window)
        if target_id not in window.columns:
            return []
        corr = window.corr()[target_id].drop(target_id, errors="ignore")
        corr = corr[corr.abs() >= min_corr].sort_values(ascending=False, key=abs)
        return corr.head(top_k).index.tolist()

    def _fit_model(
        self, target_series: pd.Series, peer_matrix: pd.DataFrame
    ) -> Any:
        n_estimators = int(self.params.get("n_estimators", 100))
        max_depth = int(self.params.get("max_depth", 4))
        learning_rate = float(self.params.get("learning_rate", 0.1))
        mask = target_series.notna() & peer_matrix.notna().all(axis=1)
        x, y = peer_matrix.loc[mask], target_series.loc[mask]

        try:
            from xgboost import XGBRegressor
            model = XGBRegressor(
                n_estimators=n_estimators,
                max_depth=max_depth,
                learning_rate=learning_rate,
                random_state=42,
                verbosity=0,
            )
            model.fit(x, y)
            return model
        except Exception:
            pass

        from sklearn.ensemble import GradientBoostingRegressor
        model = GradientBoostingRegressor(
            n_estimators=min(n_estimators, 200),
            max_depth=max_depth,
            learning_rate=learning_rate,
            random_state=42,
        )
        model.fit(x, y)
        return model

    def _nowcast(
        self, model: Any, target_id: str, peer_matrix: pd.DataFrame, full_matrix: pd.DataFrame
    ) -> pd.Series:
        return pd.Series(model.predict(peer_matrix), index=peer_matrix.index)

    def _get_peer_weights(self, model: Any, peer_ids: list[str]) -> list[float]:
        if hasattr(model, "feature_importances_"):
            imp = np.asarray(model.feature_importances_, dtype=float)
            if len(imp) == len(peer_ids):
                return [round(float(v), 4) for v in imp]
        return []


# ---------------------------------------------------------------------------
# Option 5 — Autoencoder (with PCA fallback)
# ---------------------------------------------------------------------------

class AutoencoderNowcastCheck(NowcastBaseCheck):
    """Compress-decompress reconstruction using a neural autoencoder (fallback: PCA)."""

    def __init__(self, **params: Any) -> None:
        super().__init__(name="nowcast_autoencoder", **params)
        self._used_fallback = False

    def _select_peers(
        self, target_id: str, matrix: pd.DataFrame, all_ids: list[str]
    ) -> list[str]:
        return [c for c in all_ids if c in matrix.columns]

    def _fit_model(
        self, target_series: pd.Series, peer_matrix: pd.DataFrame
    ) -> Any:
        bottleneck = int(self.params.get("bottleneck", max(2, peer_matrix.shape[1] // 4)))
        epochs = int(self.params.get("epochs", 50))
        data = peer_matrix.fillna(0.0).to_numpy(dtype=np.float32)

        try:
            import torch
            import torch.nn as nn

            d = data.shape[1]
            h = max(d // 2, bottleneck + 1)

            class AE(nn.Module):
                def __init__(self):
                    super().__init__()
                    self.encoder = nn.Sequential(
                        nn.Linear(d, h), nn.ReLU(),
                        nn.Linear(h, bottleneck), nn.ReLU(),
                    )
                    self.decoder = nn.Sequential(
                        nn.Linear(bottleneck, h), nn.ReLU(),
                        nn.Linear(h, d),
                    )

                def forward(self, x):
                    return self.decoder(self.encoder(x))

            model = AE()
            optimizer = torch.optim.Adam(model.parameters(), lr=1e-3)
            loss_fn = nn.MSELoss()
            tensor = torch.from_numpy(data)

            model.train()
            for _ in range(epochs):
                optimizer.zero_grad()
                loss = loss_fn(model(tensor), tensor)
                loss.backward()
                optimizer.step()
            model.eval()
            self._used_fallback = False
            return {"type": "torch", "model": model, "d": d}
        except Exception:
            pass

        # PCA fallback
        n_comp = min(bottleneck, peer_matrix.shape[1] - 1, peer_matrix.shape[0] - 1)
        n_comp = max(1, n_comp)
        pca = PCA(n_components=n_comp, svd_solver="full")
        pca.fit(data)
        self._used_fallback = True
        return {"type": "pca", "model": pca}

    def _nowcast(
        self, model: Any, target_id: str, peer_matrix: pd.DataFrame, full_matrix: pd.DataFrame
    ) -> pd.Series:
        data = peer_matrix.fillna(0.0)
        cols = list(peer_matrix.columns)
        if target_id not in cols:
            return pd.Series(0.0, index=peer_matrix.index)
        idx = cols.index(target_id)

        if model["type"] == "torch":
            import torch
            tensor = torch.from_numpy(data.to_numpy(dtype=np.float32))
            with torch.no_grad():
                recon = model["model"](tensor).numpy()
            return pd.Series(recon[:, idx], index=peer_matrix.index)

        # PCA fallback
        pca = model["model"]
        projected = pca.transform(data.to_numpy())
        reconstructed = pca.inverse_transform(projected)
        return pd.Series(reconstructed[:, idx], index=peer_matrix.index)

    def _get_peer_weights(self, model: Any, peer_ids: list[str]) -> list[float]:
        if model.get("type") == "pca" and hasattr(model["model"], "explained_variance_ratio_"):
            return [round(float(v), 4) for v in model["model"].explained_variance_ratio_[:5]]
        return []


# ---------------------------------------------------------------------------
# Option 6 — Dynamic Factor Model with Kalman Filter (with PCA+AR fallback)
# ---------------------------------------------------------------------------

class DynamicFactorKalmanCheck(NowcastBaseCheck):
    """Evolving factor model using DFM/Kalman filter (fallback: PCA + AR(1))."""

    def __init__(self, **params: Any) -> None:
        super().__init__(name="nowcast_dfm_kalman", **params)

    def _select_peers(
        self, target_id: str, matrix: pd.DataFrame, all_ids: list[str]
    ) -> list[str]:
        return [c for c in all_ids if c in matrix.columns]

    def _fit_model(
        self, target_series: pd.Series, peer_matrix: pd.DataFrame
    ) -> Any:
        k_factors = int(self.params.get("k_factors", 2))
        factor_order = int(self.params.get("factor_order", 1))
        data = peer_matrix.fillna(0.0)
        n_cols = data.shape[1]
        k_factors = min(k_factors, max(1, n_cols - 1))

        try:
            from statsmodels.tsa.statespace.dynamic_factor import DynamicFactor

            # DynamicFactor requires DatetimeIndex
            df_indexed = data.copy()
            df_indexed.index = pd.DatetimeIndex(df_indexed.index)
            if not hasattr(df_indexed.index, "freq") or df_indexed.index.freq is None:
                df_indexed = df_indexed.asfreq("B", method="ffill")
            model = DynamicFactor(
                df_indexed,
                k_factors=k_factors,
                factor_order=factor_order,
            )
            result = model.fit(disp=False, maxiter=100)
            return {"type": "dfm", "result": result, "columns": list(data.columns)}
        except Exception:
            pass

        # PCA + AR(1) fallback
        n_comp = min(k_factors, data.shape[1] - 1, data.shape[0] - 1)
        n_comp = max(1, n_comp)
        pca = PCA(n_components=n_comp, svd_solver="full")
        factors = pca.fit_transform(data.to_numpy(dtype=float))

        # Fit AR(1) on each factor: factor(t) = phi * factor(t-1) + noise
        ar_params = []
        for j in range(factors.shape[1]):
            f = factors[:, j]
            if len(f) < 3:
                ar_params.append(0.0)
                continue
            x_prev = f[:-1]
            x_curr = f[1:]
            denom = float(np.dot(x_prev, x_prev))
            phi = float(np.dot(x_prev, x_curr)) / (denom + 1e-12)
            ar_params.append(np.clip(phi, -0.99, 0.99))

        return {
            "type": "pca_ar",
            "pca": pca,
            "ar_params": ar_params,
            "last_factors": factors[-1] if len(factors) > 0 else np.zeros(n_comp),
            "columns": list(data.columns),
        }

    def _nowcast(
        self, model: Any, target_id: str, peer_matrix: pd.DataFrame, full_matrix: pd.DataFrame
    ) -> pd.Series:
        cols = model["columns"]
        if target_id not in cols:
            return pd.Series(0.0, index=peer_matrix.index)
        idx = cols.index(target_id)

        if model["type"] == "dfm":
            result = model["result"]
            fitted = result.fittedvalues
            if isinstance(fitted, pd.DataFrame) and target_id in fitted.columns:
                return fitted[target_id].reindex(peer_matrix.index).fillna(0.0)
            if isinstance(fitted, pd.DataFrame) and idx < fitted.shape[1]:
                return pd.Series(
                    fitted.iloc[:, idx].values,
                    index=fitted.index,
                ).reindex(peer_matrix.index).fillna(0.0)
            return pd.Series(0.0, index=peer_matrix.index)

        # PCA + AR(1) fallback: reconstruct from predicted factors
        pca = model["pca"]
        data = peer_matrix.fillna(0.0)

        # Align columns: use only those present in the model
        available = [c for c in cols if c in data.columns]
        if len(available) != len(cols):
            return pd.Series(0.0, index=peer_matrix.index)

        data_aligned = data[cols].to_numpy(dtype=float)
        factors = pca.transform(data_aligned)

        # For each row, the "nowcast" uses the previous row's factors + AR(1)
        predicted_factors = np.zeros_like(factors)
        predicted_factors[0] = factors[0]
        for t in range(1, len(factors)):
            for j in range(factors.shape[1]):
                predicted_factors[t, j] = model["ar_params"][j] * factors[t - 1, j]

        reconstructed = pca.inverse_transform(predicted_factors)
        return pd.Series(reconstructed[:, idx], index=peer_matrix.index)

    def _get_peer_weights(self, model: Any, peer_ids: list[str]) -> list[float]:
        if model.get("type") == "pca_ar" and hasattr(model.get("pca"), "explained_variance_ratio_"):
            return [round(float(v), 4) for v in model["pca"].explained_variance_ratio_[:5]]
        return []


# ---------------------------------------------------------------------------
# Option 7 — Nowcast IForest (IForest on nowcast residuals + peer features)
# ---------------------------------------------------------------------------

def _normalize_01(raw: np.ndarray) -> np.ndarray:
    raw = np.asarray(raw, dtype=float)
    lo = float(np.nanmin(raw)) if len(raw) else 0.0
    hi = float(np.nanmax(raw)) if len(raw) else 1.0
    return (raw - lo) / (hi - lo + 1.0e-12)


def _build_peer_relative_features(
    df: pd.DataFrame,
    windows: tuple[int, int] = (20, 60),
) -> pd.DataFrame:
    """Build peer-relative features for each risk_factor_id per date."""
    w_short, w_long = windows
    d = df[["risk_factor_id", "date", "value"]].copy()
    d["date"] = pd.to_datetime(d["date"], errors="coerce")
    d["value"] = pd.to_numeric(d["value"], errors="coerce")
    d = d.dropna(subset=["date", "value"]).sort_values(["risk_factor_id", "date"])

    d["move_1d"] = d.groupby("risk_factor_id")["value"].diff().fillna(0.0)
    d["rolling_vol_20"] = (
        d.groupby("risk_factor_id")["move_1d"]
        .transform(lambda x: x.rolling(w_short, min_periods=5).std(ddof=0))
        .fillna(0.0)
    )

    peer = d.groupby("date", as_index=False)["value"].agg(
        peer_median="median",
        peer_q25=lambda s: s.quantile(0.25),
        peer_q75=lambda s: s.quantile(0.75),
    )
    peer["peer_iqr"] = peer["peer_q75"] - peer["peer_q25"]
    peer_move = d.groupby("date", as_index=False)["move_1d"].agg(peer_median_move="median")
    peer_vol = d.groupby("date", as_index=False)["rolling_vol_20"].agg(peer_median_vol="median")
    d = d.merge(peer, on="date", how="left")
    d = d.merge(peer_move, on="date", how="left")
    d = d.merge(peer_vol, on="date", how="left")

    d["value_minus_peer_median"] = d["value"] - d["peer_median"]
    d["peer_z"] = d["value_minus_peer_median"] / (d["peer_iqr"] / 1.349 + 1e-9)
    d["ret_minus_peer_ret"] = d["move_1d"] - d["peer_median_move"]
    d["vol_minus_peer_vol"] = d["rolling_vol_20"] - d["peer_median_vol"]
    d["peer_rank"] = d.groupby("date")["value"].rank(pct=True)

    pivot = d.pivot(index="date", columns="risk_factor_id", values="value")
    pivot = pivot.sort_index().ffill().bfill().fillna(0.0)
    p_med = d.groupby("date")["value"].median()
    corr_parts = {}
    for rf_id in pivot.columns:
        corr_parts[rf_id] = pivot[rf_id].rolling(w_long, min_periods=10).corr(p_med).fillna(0.0)
    corr_df = pd.DataFrame(corr_parts).stack().reset_index()
    corr_df.columns = ["date", "risk_factor_id", "corr_to_peer_60d"]
    d = d.merge(corr_df, on=["date", "risk_factor_id"], how="left")
    d["corr_to_peer_60d"] = d["corr_to_peer_60d"].fillna(0.0)
    return d


class NowcastIForestCheck(DQCheck):
    """Isolation Forest on nowcast residuals + peer-relative features.

    Step 1: Fit Ridge nowcast per factor (predict value from top-K peers).
    Step 2: Compute residual = actual - predicted.
    Step 3: Build feature vector: [nowcast_residual, residual_zscore,
            peer_rank, vol_ratio, ret_vs_peer_ret, corr_to_peer_60d].
    Step 4: Run IForest on these features.

    This catches the multivariate anomalies that the linear nowcast misses.
    """

    FEATURE_COLS = [
        "nowcast_residual",
        "nowcast_residual_zscore",
        "peer_rank",
        "vol_minus_peer_vol",
        "ret_minus_peer_ret",
        "corr_to_peer_60d",
    ]

    def __init__(self, **params: Any) -> None:
        super().__init__(
            name="nowcast_iforest",
            family=NOWCAST_PEER,
            scope="per_peer_group",
            fit_policy="per_peer_group",
            **params,
        )

    def _build_nowcast_residuals(self, df: pd.DataFrame) -> pd.DataFrame:
        """Fit Ridge per factor and compute residuals, merge with peer-relative features."""
        feat = _build_peer_relative_features(df)
        d = df[["risk_factor_id", "date", "value"]].copy()
        d["value"] = pd.to_numeric(d["value"], errors="coerce")
        d = d.drop_duplicates(subset=["risk_factor_id", "date"], keep="last")
        matrix = d.pivot(index="date", columns="risk_factor_id", values="value").sort_index()
        matrix = matrix.ffill().bfill().fillna(0.0)
        all_ids = list(matrix.columns)

        top_k = int(self.params.get("top_k", 10))
        corr_window = int(self.params.get("corr_window", 120))
        min_corr = float(self.params.get("min_corr", 0.05))
        alpha = float(self.params.get("alpha", 1.0))
        residual_window = int(self.params.get("residual_window", 60))

        residuals = pd.DataFrame(index=matrix.index, columns=all_ids, dtype=float)
        residual_z = pd.DataFrame(index=matrix.index, columns=all_ids, dtype=float)

        window_data = matrix.tail(corr_window)
        for target_id in all_ids:
            if target_id not in window_data.columns:
                continue
            corr = window_data.corr()[target_id].drop(target_id, errors="ignore")
            corr = corr[corr.abs() >= min_corr].sort_values(ascending=False, key=abs)
            peers = corr.head(top_k).index.tolist()
            if not peers:
                continue
            target = matrix[target_id]
            peer_matrix = matrix[peers]
            mask = target.notna() & peer_matrix.notna().all(axis=1)
            if mask.sum() < 20:
                continue
            try:
                model = Ridge(alpha=alpha)
                model.fit(peer_matrix.loc[mask], target.loc[mask])
                predicted = pd.Series(model.predict(peer_matrix), index=matrix.index)
                resid = target - predicted
                residuals[target_id] = resid
                roll_std = resid.rolling(residual_window, min_periods=max(10, residual_window // 4)).std(ddof=0)
                residual_z[target_id] = resid.abs() / (roll_std + 1e-9)
            except Exception:
                continue

        res_long = residuals.stack().reset_index()
        res_long.columns = ["date", "risk_factor_id", "nowcast_residual"]
        resz_long = residual_z.stack().reset_index()
        resz_long.columns = ["date", "risk_factor_id", "nowcast_residual_zscore"]

        out = feat.merge(res_long, on=["date", "risk_factor_id"], how="left")
        out = out.merge(resz_long, on=["date", "risk_factor_id"], how="left")
        out["nowcast_residual"] = out["nowcast_residual"].fillna(0.0)
        out["nowcast_residual_zscore"] = out["nowcast_residual_zscore"].fillna(0.0)
        return out

    def fit(self, df: pd.DataFrame, context: dict[str, Any]) -> dict[str, Any] | None:
        del context
        if df.empty or df["risk_factor_id"].nunique() < 3:
            return None

        from sklearn.ensemble import IsolationForest

        feat = self._build_nowcast_residuals(df)
        feature_cols = [c for c in self.FEATURE_COLS if c in feat.columns]
        if not feature_cols:
            return None

        x = feat[feature_cols].replace([np.inf, -np.inf], np.nan).fillna(0.0).to_numpy(dtype=float)
        retrain_window = int(self.params.get("retrain_window", 0))
        if retrain_window > 0 and len(x) > retrain_window:
            x_train = x[-retrain_window:]
        else:
            x_train = x

        contamination = float(self.params.get("contamination", 0.01))
        n_estimators = int(self.params.get("n_estimators", 200))
        model = IsolationForest(
            contamination=contamination,
            n_estimators=n_estimators,
            random_state=42,
        )
        model.fit(x_train)
        return {"model": model, "feature_cols": feature_cols}

    def score(
        self,
        df: pd.DataFrame,
        context: dict[str, Any],
        model_state: dict[str, Any] | None = None,
    ) -> pd.DataFrame:
        if df.empty or df["risk_factor_id"].nunique() < 3:
            return self.empty_result(df, "Peer group too small for Nowcast IForest.")

        state = model_state or self.fit(df, context)
        if state is None:
            return self.empty_result(df, "Nowcast IForest model fitting failed.")

        model = state["model"]
        feature_cols = state["feature_cols"]
        feat = self._build_nowcast_residuals(df)
        x = feat[feature_cols].replace([np.inf, -np.inf], np.nan).fillna(0.0).to_numpy(dtype=float)

        raw = -model.decision_function(x)
        raw01 = _normalize_01(raw)

        threshold = float(self.params.get("threshold", 0.95))
        return _finalize_nowcast_output(
            df=feat,
            raw_score=pd.Series(raw01, index=feat.index),
            threshold=threshold,
            reason_code="NC_IFOREST",
            explain=f"Nowcast IForest residual anomaly score exceeds {threshold}",
            artifacts={
                "model": "nowcast_iforest",
                "features_used": feature_cols,
                "n_estimators": int(self.params.get("n_estimators", 200)),
                "contamination": float(self.params.get("contamination", 0.01)),
                "top_k_nowcast_peers": int(self.params.get("top_k", 10)),
            },
        )
