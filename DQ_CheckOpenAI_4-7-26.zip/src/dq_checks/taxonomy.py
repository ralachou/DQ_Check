from __future__ import annotations

from typing import Any

# Canonical Layer-3 taxonomy from docs/features/family_Models_Mapping.MD.
STATISTICAL_BASIC = "STATISTICAL_BASIC"
STATISTICAL_ROBUST = "STATISTICAL_ROBUST"
RULE_BASED = "RULE_BASED"
ML_UNSUPERVISED = "ML_UNSUPERVISED"
ML_FORECAST_BASED = "ML_FORECAST_BASED"
PEER_CROSS_GROUP = "PEER_CROSS_GROUP"
NOWCAST_PEER = "NOWCAST_PEER"
ENSEMBLE = "ENSEMBLE"

CANONICAL_FAMILIES = {
    STATISTICAL_BASIC,
    STATISTICAL_ROBUST,
    RULE_BASED,
    ML_UNSUPERVISED,
    ML_FORECAST_BASED,
    PEER_CROSS_GROUP,
    NOWCAST_PEER,
    ENSEMBLE,
}

FAMILY_ALIASES = {
    "statistical_basic": STATISTICAL_BASIC,
    "statistical_robust": STATISTICAL_ROBUST,
    "rule_based": RULE_BASED,
    "ml_unsupervised": ML_UNSUPERVISED,
    "ml_forecast_based": ML_FORECAST_BASED,
    "peer_cross_group": PEER_CROSS_GROUP,
    "nowcast_peer": NOWCAST_PEER,
    "nowcast": NOWCAST_PEER,
    "ensemble": ENSEMBLE,
    # Legacy families used in older configs/results.
    "stat_univariate": STATISTICAL_BASIC,
    "integrity": RULE_BASED,
    "changepoint": ML_FORECAST_BASED,
    "peer": PEER_CROSS_GROUP,
}

ROBUST_MODEL_NAMES = {
    "robust_zscore",
    "robust_zscore_median_mad",
    "robust_zscore_skip_flat_data",
    "robust_zscore_mean_std",
    "quantile_band",
    "iqr",
    "jump_spike",
    "rolling_ks",
    "cusum_drift",
}

BASIC_MODEL_NAMES = {
    "mean_std_shift_4",
    "mean_std_shift_4sigma",
    "legacy_4sigma_shift",
    "rolling_zscore",
    "zscore_mean_std",
}

RULE_MODEL_NAMES = {
    "stale_values",
    "missing_gaps",
    "rule_abs_shift_gt",
}

FORECAST_MODEL_NAMES = {
    "arima_residual",
    "autoregressionad",
    "stl",
    "prophet",
    "changepoint",
    "bocpd",
    "levelshiftad",
    "seasonalad",
    "persistad",
    "quantilead",
    "interquartilerangead",
}

PEER_MODEL_NAMES = {
    "peer_median_dev",
    "peer_mad",
    "peer_robust_z",
    "peer_percentile",
}

NOWCAST_MODEL_NAMES = {
    "nowcast_ridge",
    "nowcast_pca_recon",
    "nowcast_elastic_net",
    "nowcast_xgboost",
    "nowcast_autoencoder",
    "nowcast_dfm_kalman",
    "nowcast_iforest",
}

ML_UNSUPERVISED_MODEL_NAMES = {
    "iforest_peer",
    "pca_curve",
}


def canonicalize_family(family: str | None, model_name: str | None = None, backend: str | None = None) -> str:
    fam = str(family or "").strip()
    key = fam.lower()
    if key in FAMILY_ALIASES:
        mapped = FAMILY_ALIASES[key]
    elif fam in CANONICAL_FAMILIES:
        mapped = fam
    else:
        mapped = STATISTICAL_BASIC

    name = str(model_name or "").strip().lower()
    back = str(backend or "").strip().lower()
    if name in BASIC_MODEL_NAMES:
        return STATISTICAL_BASIC
    if name in ROBUST_MODEL_NAMES:
        return STATISTICAL_ROBUST
    if name in RULE_MODEL_NAMES:
        return RULE_BASED
    if name in FORECAST_MODEL_NAMES:
        return ML_FORECAST_BASED
    if name in PEER_MODEL_NAMES:
        return PEER_CROSS_GROUP
    if name in NOWCAST_MODEL_NAMES:
        return NOWCAST_PEER
    if name in ML_UNSUPERVISED_MODEL_NAMES:
        return ML_UNSUPERVISED
    if name == "ensemble":
        return ENSEMBLE
    if back == "pyod":
        return ML_UNSUPERVISED
    if back in {"adtk", "merlion"}:
        return ML_FORECAST_BASED
    return mapped


def normalize_family_series(values: Any) -> Any:
    try:
        return values.map(lambda x: canonicalize_family(str(x)))
    except Exception:
        return values
