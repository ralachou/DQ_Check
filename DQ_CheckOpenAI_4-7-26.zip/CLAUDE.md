# CLAUDE.md — Project Context for AI Assistants

## Project Overview
**Advanced DQ Checks on RF** — A layered data quality (DQ) anomaly detection framework for financial risk factors. Built in Python with Dash UI. Designed for market risk teams to detect outliers, stale data, structural breaks, and peer deviations across large risk factor universes.

## Architecture (7 Layers)

### Layer 1 — Data Access (`src/data_access/`)
- Repository pattern: `TimeSeriesRepository` abstraction with Parquet, SQLite, REST backends.
- Canonical schema: `business_date, risk_factor_id, date, value`.
- `business_date` is a first-class snapshot dimension (partition key).
- Shared taxonomy normalizer in `src/common/taxonomy.py`.
- Parquet write path serializes nested objects to JSON to avoid pyarrow struct errors.

### Layer 2 — Universe (`src/universe/`)
- Config-driven membership from `configs/model_catalog.yaml` (`universes.<name>.filters`).
- `UniverseBuilder` applies filters, include/exclude overrides, hierarchy normalization.
- Output carries canonical taxonomy: `asset_class, ccy, rf_level1..rf_level5`.

### Layer 3 — DQ Model Library (`src/dq_checks/`)
- Unified `DQCheck` interface: `fit(df, context)` and `score(df, context, model_state)`.
- **18 local checks**: robust_zscore, rolling_zscore, mean_std_shift_4sigma, quantile_band, iqr, jump_spike, cusum_drift, rolling_ks, rule_abs_shift_gt, stale_values, missing_gaps, arima_residual, peer_median_dev, peer_mad, peer_robust_z, peer_percentile, zscore_mean_std, robust_zscore_mean_std.
- **Adapters**: PyOD (iforest, lof, ecod, hbos, knn, copod, pca, iqr), ADTK, Merlion — with graceful fallback when deps missing.
- **Ensemble**: weighted_avg, max, rank_aggregation, majority_vote.
- **Registry** (`registry.py`): YAML-driven `ModelSpec` -> concrete check instantiation. Supports `common_checks` block.
- **Fit policies**: `per_series`, `per_peer_group`, `global`.
- **Series semantics**: `level` vs `shift` — checks avoid double-differencing when `analysis_field=shift`.
- Flag rule: `raw_score >= threshold`. Severity: ratio-based (Low/Med/High/Critical).
- **Nowcast checks** (`nowcast_checks.py`): `NowcastBaseCheck` base + 7 subclasses. Shared pipeline: `_pivot_peer_matrix()`, `_residual()`, `_standardize_residual()`. Each overrides: `_select_peers()`, `_fit_model()`, `_nowcast()`. Includes: `RidgeNowcastCheck` (top-K correlated peers), `PCAReconstructionCheck`, `ElasticNetNowcastCheck`, `XGBoostNowcastCheck` (xgboost->GradientBoosting fallback), `AutoencoderNowcastCheck` (torch->PCA fallback), `DynamicFactorKalmanCheck` (statsmodels DFM->PCA+AR(1) fallback), `NowcastIForestCheck` (IForest on nowcast residuals + peer-relative features).
- **ML Unsupervised checks** (`ml_unsupervised_checks.py`): `IForestPeerCheck` (IForest on 6 peer-relative features built by `_build_peer_relative_features()`), `PCACurveCheck` (PCA reconstruction with z-score standardization, score_holdout, fit-time normalization for curves/surfaces). Shared helper `_build_peer_relative_features()` uses `diff()` not `pct_change()` to avoid near-zero denominator explosions on shift data.
- Canonical families: `STATISTICAL_BASIC, STATISTICAL_ROBUST, RULE_BASED, ML_UNSUPERVISED, ML_FORECAST_BASED, PEER_CROSS_GROUP, NOWCAST_PEER, ENSEMBLE`.

### Layer 4 — Configuration (`configs/model_catalog.yaml`)
- Single declarative source for universes, checks, normalization profiles, severity thresholds, peer group rules, regime windows, supervised triage config.
- `config_hash()` for deterministic audit fingerprints.
- Common checks applied per universe via `apply_to_universes` selector.

### Layer 5 — Run Engine (`src/engine/run_engine.py`)
- End-to-end orchestrator: membership -> load series -> execute checks -> normalize -> triage -> persist.
- `RunRequest` dataclass with `analysis_field` support.
- Writes partitioned outputs: `dq_results`, `audit_log`, `universe_membership`.
- Audit includes config hash, stage timings, row counts, analysis field traceability.

### Layer 6 — False Alarm / Triage (`src/triage/false_alarm.py`)
- `FalseAlarmReducer`: peer consistency, regime tagging, heuristic triage.
- Heuristic actions: `ACCEPT_MOVE`, `CONFIRM_BAD_DATA`, `NEEDS_REVIEW`.
- Optional supervised path: XGBoost/LightGBM/RF/LogReg candidates with calibration (sigmoid/isotonic).
- Feature table includes: detector scores, regime/event, family aggregates, cross-asset rates, reason codes, hierarchy one-hot.
- `--preserve-check-flags` (default True) keeps raw Layer 3 flags through normalization.

### Layer 7 — Dash UI (`src/ui/app_v2.py`)
- 5 tabs: DQ Outliers Summary, Hierarchy Drilldown, Model Comparison (hidden), Peer Group Explorer, Supervised Diagnostics.
- `dcc.Store` central state pattern with global filters (asset_class, ccy, rf_level1, universe, family, check, severity, business_date, summary_scope).
- Summary scope modes: latest flagged date, entire range, selected UI range.
- Hierarchy grouping: asset_class or rf_level1..rf_level5 combos.
- VIX/MOVE/CDX regime indicators with fallback proxy values.
- Tab 2: tree rollup, branch KPI, RF investigation (overlay/separate/small_multiples), peer band overlay.
- Tab 5: supervised diagnostics (p_bad_data histograms, feature importance, drift).

## Key Shared Modules
- `src/common/schemas.py` — canonical schema constants, `load_yaml`, `config_hash`.
- `src/common/taxonomy.py` — `normalize_taxonomy_frame`, `resolve_peer_group_config`, `apply_peer_grouping`, peer group rule operators (eq/ne/in/not_in/like/not_like/contains/startswith/endswith).
- `src/normalization/normalizer.py` — `normalize_results`, `SeverityMapper`, `CalibrationArtifact`.
- `src/dq_checks/feature_builder.py` — `FeatureBuilder.build_features` / `build_batch` with caching.
- `src/dq_checks/taxonomy.py` — canonical family name mapper.

## Config Structure (`configs/model_catalog.yaml`)
```yaml
globals:          # version, default_severity_thresholds, regime_windows
feature_sets:     # named feature configurations
normalization:    # profiles (ecdf, quantile, etc.) and defaults
asset_class_defaults:  # per-asset-class check/peer defaults
common_checks:    # shared checks applied to listed universes
universes:        # per-universe filters, checks, peer_group config
triage:           # supervised config (target, candidates, calibration, hyperparams)
```

## Peer Group Configuration
```yaml
universes:
  MARS_SUBSET:
    peer_group:
      keys: [asset_class, ccy, rf_level1]
      rules:
        - id: rule_name
          when:
            asset_class: {eq: CP_RATE}
            ccy: {in: [USD]}
            rf_level3: {like: "CORP%"}
          keys: [asset_class, ccy, rf_level1, rf_level2, rf_level3]
```
Fallback order: universe peer_group -> legacy peer_group_keys -> asset_class_defaults -> default keys.

## Analysis Field / Series Semantics
- `analysis_field` selects which numeric column becomes canonical `value` (e.g., `value`, `shift`).
- `series_semantics` derived from resolved field: `shift` -> precomputed move; else `level`.
- Propagated to all fit-policy paths (per_series, per_peer_group, global).
- Diff-sensitive checks (mean_std_shift_4sigma, rule_abs_shift_gt, jump_spike, cusum_drift) honor semantics to avoid double differencing.

## Data Layout
```
data/
  raw/
    risk_factors/          # metadata parquet
    timeseries_raw/
      business_date=YYYY-MM-DD/  # partitioned time series
  processed/
    dq_results/            # Layer 5 engine output
    audit_log/             # run audit
    universe_membership/   # resolved membership
    layer3_dq_checks_demo/ # Layer 3 demo artifacts
    layer6_false_alarm_demo/ # Layer 6 demo artifacts
  artifacts/
    normalization/         # calibration artifacts
```

## Key Commands

### Generate MARS_SUBSET synthetic data
```bash
python -m pipeline.run_demo_generate_mars_subset --raw-path data/raw --start-date 2019-01-02 --end-date 2020-12-31 --business-date 2026-02-27 --output-format parquet --clean-target
```

### Layer 3 checks
```bash
python -m pipeline.run_demo_layer3_dqChecks --no-generate-demo-data --universe-name MARS_SUBSET --analysis-field shift --start-date 2019-01-02 --end-date 2020-12-31 --business-date 2026-02-27 --raw-path data/raw --processed-path data/processed --config-path configs/model_catalog.yaml --max-series 0 --output-format parquet
```

### Layer 5 run engine
```bash
python -m pipeline.run_demo_layer5_runEngine --universe-name MARS_SUBSET --start-date 2019-01-02 --end-date 2020-12-31 --business-date 2026-02-27 --analysis-field shift --output-format parquet
```

### Layer 6 false alarm with supervised
```bash
python -m pipeline.run_demo_layer6_false_alarm --no-generate-demo-data --universe-name MARS_SUBSET --analysis-field shift --start-date 2019-01-02 --end-date 2020-12-31 --business-date 2026-02-27 --raw-path data/raw --processed-path data/processed --config-path configs/model_catalog.yaml --with-supervised --generate-demo-labels --label-rate 0.20 --supervised-candidates xgboost --calibration-method sigmoid --output-format parquet
```

### Launch UI
```bash
python -m ui.app_v2 --results-path data/processed/dq_results --raw-path data/raw/timeseries_raw --membership-path data/processed/universe_membership --config-path configs/model_catalog.yaml --business-date 2026-02-27 --port 8061
```

### Single-factor tuning notebook
- Config: `configs/local_single_factor_tuning.yaml`
- Script: `tests/layer3_single_risk_factor_tuning_notebook.py`
- Dash UI with check_id filter: launches on port 8050 by default

### Diagnostic comparison report
```bash
python tests/layer3_diagnostic_comparison.py              # UI + Excel
python tests/layer3_diagnostic_comparison.py --no-ui      # Excel only
python tests/layer3_diagnostic_comparison.py --port 8070  # custom port
```
Output: `data/processed/diagnostic_comparison_<RF_ID>.xlsx` (5 tabs)

## Current Dataset: MARS_SUBSET
- 930 risk factors: CP_RATE (401), IR_RATE_BASISFXSOFR (373), EQ_VOL_CURV_M06_M09 (156)
- Date range: 2019-01-02 to 2020-12-31
- Business date: 2026-02-27
- Default analysis field: `shift`

## Environment Setup
```bash
pip install -r requirements.txt
pip install -e .
```
- `src` must be on PYTHONPATH or package installed.
- Optional deps: pyod, adtk, merlion, xgboost, lightgbm, statsmodels, openpyxl.

## Important Conventions
- All layers use shared canonical taxonomy from `src/common/taxonomy.py`.
- Fallback policy: `asset_class <- asset_class OR rf_level1`, `ccy <- ccy OR rf_level2`, `rf_level3..5 <- "NA"` when missing.
- Flag/severity: `flag = raw_score >= threshold`, severity from `severity_from_ratio(raw_score/threshold)`.
- Normalized outputs keep both raw and norm: `flag_raw/severity_raw` and `flag_norm/severity_norm`.
- Use full parquet files for analysis (`dq_results_full.parquet`, `dq_flags_full.parquet`, `triaged_full.parquet`), not preview files.
- `model_id` column mirrors `check_id` for model-level comparison support.
- Default null token for taxonomy is `"null"` (not `"NA"` — see `DEFAULT_NULL_TOKEN` in taxonomy.py).
- Nowcast checks use `robust_stat_profile` normalization (NOT `ecdf_profile`) because nowcast residuals are already in sigma units. ECDF re-normalization distorts them.
- IForest/nowcast peer-relative features use `diff()` not `pct_change()` to avoid near-zero denominator explosions on shift/spread data that crosses zero.
- PCA Curve check uses `score_holdout` (exclude last N days from PCA training) so anomalies in scoring window are not absorbed into components.
- PCA Curve check standardizes scoring data with **fit-time** means/stds, not recomputed from scoring data.

## Docs Map

| Doc | Content |
|-----|---------|
| `docs/3_DQ_Model_Methodology_PeerGroup.MD` | Peer check formulas, peer group failure modes (heterogeneous beta, contamination, too small/large, regime shifts, stale peers), size sweet spots |
| `docs/3_DQ_Model_Methodology_Nowcasting.MD` | 6 nowcast options (Ridge/PCA/ElasticNet/XGBoost/Autoencoder/DFM), simple guide with analogies, decision tree, implementation steps, failure modes, asset-class map, operational rules |
| `docs/3_DQ_Nowcasting_Options_SimpleGuide.MD` | Standalone lightweight version of nowcast options for sharing |
| `docs/3_DQ_Model_Methodology_Nowcasting_Benchmark.MD` | Full reference with 4 implementation levels, best model by asset class, 35K factor reality check, failure maps |
| `docs/3_DQ_Model_Methodology_ML_Unsupervised.MD` | IForest honest assessment (claims vs reality), PCA comparison, IForestPeerCheck + PCACurveCheck + NowcastIForestCheck implementation details, feature explanations, complementarity table |

## Source Code Map

### `src/common/`
- `schemas.py` (75 lines) — `TIMESERIES_COLUMNS`, `RESULT_COLUMNS`, `RunContext` dataclass, `ensure_timeseries_schema()`, `load_yaml()`, `config_hash()`.
- `taxonomy.py` (322 lines) — Column aliases (`_ALIASES`), `_match_condition()` with SQL-like operators, `normalize_taxonomy_frame()`, `apply_taxonomy_filters()`, `resolve_peer_group_config()`, `apply_peer_grouping()`. Generates `peer_group_id` and `peer_group_rule_id` columns.
- `driver_name_parser.py` (147 lines) — Parses risk factor IDs into hierarchy fields using regex pattern rules from YAML. `parse_driver_name()`, `parse_driver_names()`.

### `src/data_access/`
- `base.py` (34 lines) — `TimeSeriesRepository` ABC: `get_series()`, `list_risk_factors()`, `write_results()`.
- `parquet_repository.py` (178 lines) — `ParquetTimeSeriesRepository`: reads hive-partitioned parquet dirs, writes with partition folders, serializes nested objects. `_read_parquet_dir()` reconstructs partition columns from folder names.
- `sqlite_repository.py` (72 lines) — `SQLiteTimeSeriesRepository`: SQL-backed alternative. Uses `apply_taxonomy_filters()` for metadata.
- `rest_repository.py` (39 lines) — `RestTimeSeriesRepositoryStub`: placeholder, raises `NotImplementedError`.

### `src/universe/`
- `definitions.py` (15 lines) — `UniverseDefinition` dataclass: `name, description, filter_rules, include_ids, exclude_ids`.
- `builder.py` (39 lines) — `UniverseBuilder.build()`: calls `list_risk_factors()` with filters, normalizes taxonomy, applies include/exclude, deduplicates, validates required columns.

### `src/dq_checks/`
- `base.py` (93 lines) — `DQCheck` ABC with `fit()`/`score()`, `empty_result()`, `severity_from_ratio()`, `series_semantics()`, `value_is_precomputed_shift()`.
- `local_checks.py` (732 lines) — All local check implementations. `_finalize_output()` helper. Includes `RobustZScoreCheck_SkipFlatData` with explicit flat-data handling (stale window -> -1, MAD zero -> 0, small MAD -> capped). `_peer_stats()` helper for peer checks computes per-date median/Q25/Q75/MAD.
- `adapters.py` (444 lines) — `PyODAdapterCheck` (10 model names, sklearn fallbacks), `ADTKAdapterCheck` (6 model names, heuristic fallbacks), `MerlionAdapterCheck` (5 model names, fallback proxies). All use `_normalize_01()` min-max scaling and `_emit_output()`.
- `ensemble.py` (97 lines) — `EnsembleCheck`: runs child checks, normalizes per-child scores to [0,1], aggregates by strategy.
- `registry.py` (~210 lines) — `ModelSpec` dataclass, `ModelRegistry` with `_register_defaults()` (18 local checks + aliases + 7 nowcast checks + 2 ML unsupervised checks), `validate()`, `build_from_spec()`, `load_universe_specs()` (merges common_checks with universe checks, canonicalizes families).
- `taxonomy.py` (~145 lines) — Family constants (`STATISTICAL_BASIC`, `STATISTICAL_ROBUST`, `RULE_BASED`, `ML_UNSUPERVISED`, `ML_FORECAST_BASED`, `PEER_CROSS_GROUP`, `NOWCAST_PEER`, `ENSEMBLE`). Model name sets: `BASIC_MODEL_NAMES`, `ROBUST_MODEL_NAMES`, `RULE_MODEL_NAMES`, `FORECAST_MODEL_NAMES`, `PEER_MODEL_NAMES`, `NOWCAST_MODEL_NAMES` (7 models including `nowcast_iforest`), `ML_UNSUPERVISED_MODEL_NAMES` (`iforest_peer`, `pca_curve`). `canonicalize_family()` maps model_name/backend to canonical family.
- `nowcast_checks.py` (~850 lines) — `NowcastBaseCheck` abstract base + 7 subclasses for cross-sectional nowcasting. Shared pipeline: `_pivot_peer_matrix()`, `_residual()`, `_standardize_residual()`. Subclasses override `_select_peers()`, `_fit_model()`, `_nowcast()`. Includes: `RidgeNowcastCheck`, `PCAReconstructionCheck`, `ElasticNetNowcastCheck`, `XGBoostNowcastCheck`, `AutoencoderNowcastCheck`, `DynamicFactorKalmanCheck`, `NowcastIForestCheck` (IForest on Ridge residuals + 6 peer-relative features). Also contains `_build_peer_relative_features()` (shared with `ml_unsupervised_checks.py`) and `_normalize_01()`. Reason codes: `NC_RIDGE`, `NC_PCA_RECON`, `NC_ELASTIC_NET`, `NC_XGBOOST`, `NC_AUTOENCODER`, `NC_DFM_KALMAN`, `NC_IFOREST`.
- `ml_unsupervised_checks.py` (~350 lines) — Standalone ML unsupervised checks. `IForestPeerCheck` (IForest on 6 peer-relative features: `value_minus_peer_median`, `peer_z`, `ret_minus_peer_ret`, `vol_minus_peer_vol`, `peer_rank`, `corr_to_peer_60d`). `PCACurveCheck` (PCA reconstruction for curves with z-score standardization per factor, `score_holdout` to exclude last N days from training, fit-time means/stds for scoring, per-factor rolling sigma). Shared helpers: `_build_peer_relative_features()` (uses `diff()` not `pct_change()`), `_normalize_01()`, `_finalize_ml_output()`. Reason codes: `IFOREST_PEER`, `PCA_CURVE`.
- `feature_builder.py` (101 lines) — `FeatureBuilder.build_features()`: returns, rolling stats, vol, drawdown, optional peer features. `build_batch()` with ThreadPoolExecutor. Internal cache by `(rf_id, last_date, len)`.

### `src/normalization/`
- `normalizer.py` (239 lines) — `ScoreNormalizer`: strategies `ecdf` (default), `robust_zscore`, `quantile`, `backend_aware` (Merlion calibrator + fallback). `SeverityMapper`: fixed or quantile thresholds, returns `(severity, flag, threshold, severity_score_100)`. `normalize_results()`: per-check normalization + artifact persistence.

### `src/triage/`
- `false_alarm.py` (879 lines) — `FalseAlarmReducer`:
  - `tag_regime()`: absolute or relative date windows.
  - `_peer_move_frame()`: computes series_move, peer_median_move, peer_iqr_move.
  - `peer_consistency()`: `peer_flag_ratio`, `peer_confidence`, `peer_confirmed`.
  - `_apply_event_and_regime_adjustments()`: downgrades severity for event-proximate or stress-regime non-integrity alerts.
  - `triage_heuristic()`: ACCEPT_MOVE / CONFIRM_BAD_DATA / NEEDS_REVIEW.
  - `_feature_table()`: builds supervised feature matrix with family aggregates, cross-asset rates, one-hot reason codes, one-hot taxonomy.
  - `triage_supervised()`: ablation or ensemble training mode, candidate fitting, calibration, feature importance (global via xgb_gain/feature_importances_/coef_, local via SHAP or importance proxy).
  - `_apply_policy()`: decision policy based on p_bad_data + severity.
  - `run()`: full pipeline (peer -> regime -> heuristic -> optional supervised -> policy).

### `src/engine/`
- `run_engine.py` (463 lines) — `RunRequest` dataclass, `RunEngine`:
  - `_build_universe()`: config -> UniverseDefinition -> UniverseBuilder.build().
  - `_check_profiles()`: resolves normalization strategy per check from config profiles.
  - `_apply_analysis_field()`: maps selected column to canonical `value`, fallback logic.
  - `_execute_per_series/per_peer_group/global()`: fit-policy dispatch, passes `series_semantics` in context.
  - `_preserve_raw_alert_flags()`: merges raw flag/severity back after normalization.
  - `run()`: full orchestration with timing, writes dq_results + audit_log + triage artifacts.

### `src/pipeline/` (demo runners)
- `run_demo.py` — MVP pipeline entrypoint.
- `run_demo_data_layer.py` — Layer 1 standalone demo.
- `run_demo_layer2_universe.py` — Layer 2 standalone demo.
- `run_demo_layer3_dqChecks.py` — Layer 3 demo with balanced preview sampling, full parquet output.
- `run_demo_layer4_config.py` — Layer 4 config mapping demo.
- `run_demo_layer5_runEngine.py` — Layer 5 engine demo wrapper.
- `run_demo_layer6_false_alarm.py` — Layer 6 demo with `--preserve-check-flags`, supervised options.
- `run_demo_layer7_dash_ui.py` — UI debug/demo helper (print layout/callbacks, run callbacks in isolation).
- `run_demo_generate_mars_subset.py` — MARS_SUBSET synthetic data generator.
- `run_demo_ingest_sql_marketdata.py` — External dataset ingestion with taxonomy normalization.
- `run_demo_integrate_with_Mar.py` — Manual dataset integration pipeline.
- `run_demo_ui_full_dataset.py` — Full UI demo dataset generator.
- `clean_data.py` — Data cleanup utility.

### `src/ui/`
- `app.py` — Original v1 Dash UI (3 tabs: Summary, Drilldown, Model Compare).
- `app_v2.py` — Current v2 Dash UI (5 tabs). `SHOW_MODEL_COMPARISON_TAB = False` hides Tab 3. Extensive callback system with `_ensure_data()`, `_apply_filters()`, `_filtered_ts()` helpers.
- `BackupApp.py` — Backup of earlier UI version.

### `configs/`
- `model_catalog.yaml` (~1000 lines) — Full config: globals, feature_sets, normalization profiles, triage/supervised config, asset_class_defaults (10 classes), common_checks (26 checks for MARS_SUBSET: 17 original + 6 nowcast + `iforest_peer_common` + `nowcast_iforest_common` + `pca_curve_common`; enabled: `nowcast_ridge`, `nowcast_pca_recon`, `nowcast_iforest`, `iforest_peer`, `pca_curve` + original checks), universes (MARS_SUBSET, EQ_PRICE_US, EQ_VOL_USD, IR_RATE_USD, FX_VOL_G10, COMM_PRICE_METALS, CP_RATE_CORP, CP_RATE_CDX, CP_RATE_RMBS). Nowcast checks use `robust_stat_profile` normalization (not ecdf) because residuals are already in sigma units.
- `local_single_factor_tuning.yaml` — Config for single-factor tuning notebook: paths, run params (universe, dates, analysis_field, target RF `CP_RATE_VAR_USD_RMBSLTCMO_001`, 9 selected checks including nowcast/iforest/pca_curve), per-check param overrides. Nowcast Ridge: `top_k=8, min_corr=0.05, threshold=3.0`. IForest: `contamination=0.01, threshold=0.95`. PCA Curve: `n_components=3, threshold=3.5`.
- `driver_name_parser.yaml` — Pattern rules for parsing driver names into hierarchy.

### `tests/`
- `test_normalization.py` (36 lines) — Tests ECDF monotonicity and severity consistency across model distributions.
- `test_business_date_repository.py` (45 lines) — Tests Parquet repo business_date filtering and partition writing.
- `layer3_single_risk_factor_tuning_notebook.py` (~1200 lines) — Interactive single-RF tuning script. Loads config, builds universe, runs selected checks on one RF, normalizes, builds results_view with raw+norm flags/severity. Features: severity_source raw/norm filtering, check_id multi-select dropdown filter in Dash UI, overlay/separate chart modes, nowcast vs peer comparison figure (3-row: all peer lines + nowcast prediction + flag markers, raw scores, flag timeline), severity-based row highlighting. Captures `nowcast_model_states` for visualization. Works in notebook or CLI with Dash browser UI.
- `layer3_diagnostic_comparison.py` (~400 lines) — Standalone diagnostic comparison report. Runs all selected checks from `local_single_factor_tuning.yaml` and produces 5-tab output: (1) Raw Data + Scoring Breakdown on all flagged dates, (2) Agreement Matrix (which checks agree/disagree), (3) Nowcast Internals (predicted, residual, peers, weights), (4) IForest Internals (6 features + percentile ranks + extreme flags), (5) PCA Curve Internals (component loadings, scores, reconstruction error, explained variance). Exports to Excel (`data/processed/diagnostic_comparison_<RF_ID>.xlsx`) and launches Dash UI. Usage: `python tests/layer3_diagnostic_comparison.py` or `--no-ui` for Excel only.
- `layer3_check_function_tester_notebook.py` (~400 lines) — Interactive check tester. Loads single-factor module, lets you pick individual checks, run them, inspect raw_score/flag/severity.
- `ui_options.py` (94 lines) — Plotly chart prototypes for alert distribution (bar, treemap, sunburst, heatmap, faceted bar).
