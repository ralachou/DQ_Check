


import plotly.express as px
import pandas as pd

df = pd.DataFrame({
    "check_id": [
        "mean_stdv_shift_4", "rolling_zscore", "iqr_common",
        "pyod_iqr_common", "robust_zscore_mad", "quantile_band", "rule_abs_gt_2"
    ],
    "family": [
        "STATISTIC_BASIC", "STATISTIC_BASIC",
        "STATISTICAL_ROBUST", "STATISTICAL_ROBUST", "STATISTICAL_ROBUST",
        "STATISTICAL_ROBUST", "RULE_BASED"
    ],
    "alerts": [500, 1000, 9000, 1000, 5000, 4000, 100]
})

def  option1():
    fig = px.bar(
        df,
        x="family",
        y="alerts",
        color="check_id",
        barmode="relative"
    )

    fig.update_layout(
        title="Alert Contribution per Check within Family",
        yaxis_title="Alerts",
        xaxis_title="Family"
    )

    fig.show()

def option2():
    fig = px.treemap(
        df,
        path=["family", "check_id"],
        values="alerts",
        title="Alert Contribution by Family and Check"
    )
    fig.show()

def option3():
    fig = px.sunburst(
        df,
        path=["family", "check_id"],
        values="alerts",
        title="Alert Distribution"
    )

def option4():
    fig = px.density_heatmap(
        df,
        x="family",
        y="check_id",
        z="alerts",
        color_continuous_scale="Reds",
        title="Alert Intensity per Check"
    )

    fig.show()

def option5():
    df_sorted = df.sort_values("alerts", ascending=False)

    fig = px.bar(df_sorted, x="check_id", y="alerts")

    fig.update_layout(title="Alert Distribution by Check")

    fig.show()

def option6():
    fig = px.bar(
        df,
        x="check_id",
        y="alerts",
        facet_col="family",
        title="Alert Contribution per Family"
    )

    fig.show()
def main ():
     option2()
     option3()
     option4()
     option5()
     option6()

if __name__ == "__main__":
    main()
