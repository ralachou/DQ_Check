"""
Layer 3 Diagnostic Comparison Report
=====================================
Produces a detailed comparison of all DQ checks on a single risk factor.
Reads config from local_single_factor_tuning.yaml, runs all selected checks,
and generates:

  Tab 1: Raw Data Context + Scoring Breakdown (all flagged dates, union)
  Tab 2: Agreement Matrix (which checks agree/disagree per date)
  Tab 3: Nowcast Internals (Ridge: predicted, residual, peers, weights)
  Tab 4: IForest Internals (6 features, percentiles, isolation drivers)
  Tab 5: PCA Curve Internals (components, reconstruction, explained variance)

Outputs:
  - Excel file: data/processed/diagnostic_comparison_<RF_ID>.xlsx
  - Dash UI on localhost for interactive exploration

Usage:
  python tests/layer3_diagnostic_comparison.py
  python tests/layer3_diagnostic_comparison.py --no-ui          # Excel only
  python tests/layer3_diagnostic_comparison.py --port 8070      # custom port
"""

from __future__ import annotations

import json
import os
import sys
import time
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

PROJECT_ROOT = Path.cwd()
if not (PROJECT_ROOT / "src").exists() and (PROJECT_ROOT.parent / "src").exists():
    PROJECT_ROOT = PROJECT_ROOT.parent
SRC_PATH = PROJECT_ROOT / "src"
if str(SRC_PATH) not in sys.path:
    sys.path.insert(0, str(SRC_PATH))
TESTS_PATH = PROJECT_ROOT / "tests"
if str(TESTS_PATH) not in sys.path:
    sys.path.insert(0, str(TESTS_PATH))

from layer3_single_risk_factor_tuning_notebook import (
    _apply_analysis_field,
    _apply_check_overrides,
    _build_check_profiles,
    _build_universe_definition,
    load_runtime_settings,
    normalize_and_build_view,
    prepare_universe_and_specs,
    load_target_series,
    run_selected_checks,
)
from common.schemas import load_yaml
from common.taxonomy import PEER_GROUP_ID_COL
from dq_checks.ml_unsupervised_checks import _build_peer_relative_features
from dq_checks.nowcast_checks import _pivot_peer_matrix, _build_peer_relative_features as _nc_build_peer_features


# ============================================================================
# Tab 1: Raw Data Context + Scoring Breakdown
# ============================================================================

def build_raw_data_context(
    results_view: pd.DataFrame,
    target_series: pd.DataFrame,
    peer_series: pd.DataFrame,
    target_risk_factor_id: str,
) -> pd.DataFrame:
    """For every flagged date (union across all checks), show raw data + per-check scores."""

    rv = results_view.copy()
    rv["date"] = pd.to_datetime(rv["date"])

    # Get union of all flagged dates (raw OR norm)
    flagged_mask = rv["flag_raw"].fillna(False).astype(bool) | rv["flag_norm"].fillna(False).astype(bool)
    flagged_dates = sorted(rv.loc[flagged_mask, "date"].unique())
    if not flagged_dates:
        return pd.DataFrame(columns=["date", "info"])

    # Build raw data context for target
    ts = target_series[["date", "value"]].copy()
    ts["date"] = pd.to_datetime(ts["date"])
    ts = ts.sort_values("date").drop_duplicates(subset=["date"], keep="last")
    ts["prev_value"] = ts["value"].shift(1)
    ts["move_1d"] = ts["value"].diff()

    # Peer context (if available)
    if not peer_series.empty:
        ps = peer_series[["risk_factor_id", "date", "value"]].copy()
        ps["date"] = pd.to_datetime(ps["date"])
        ps["value"] = pd.to_numeric(ps["value"], errors="coerce")
        peer_stats = ps.groupby("date", as_index=False)["value"].agg(
            peer_median="median",
            peer_count="count",
        )
        peer_moves = ps.copy()
        peer_moves["move"] = peer_moves.groupby("risk_factor_id")["value"].diff()
        peer_move_stats = peer_moves.groupby("date", as_index=False)["move"].agg(peer_median_move="median")
        ts = ts.merge(peer_stats, on="date", how="left")
        ts = ts.merge(peer_move_stats, on="date", how="left")
    else:
        ts["peer_median"] = np.nan
        ts["peer_count"] = 0
        ts["peer_median_move"] = np.nan

    # Pivot check scores: one column per check_id
    all_checks = sorted(rv["check_id"].unique())
    rows = []
    for dt in flagged_dates:
        ctx = ts[ts["date"] == dt]
        row: dict[str, Any] = {
            "date": dt,
            "value": float(ctx["value"].iloc[0]) if not ctx.empty else np.nan,
            "prev_value": float(ctx["prev_value"].iloc[0]) if not ctx.empty else np.nan,
            "move_1d": float(ctx["move_1d"].iloc[0]) if not ctx.empty else np.nan,
            "peer_median": float(ctx["peer_median"].iloc[0]) if not ctx.empty and "peer_median" in ctx.columns else np.nan,
            "peer_median_move": float(ctx["peer_median_move"].iloc[0]) if not ctx.empty and "peer_median_move" in ctx.columns else np.nan,
            "peer_count": int(ctx["peer_count"].iloc[0]) if not ctx.empty and "peer_count" in ctx.columns else 0,
        }
        dt_scores = rv[rv["date"] == dt]
        for cid in all_checks:
            c_row = dt_scores[dt_scores["check_id"] == cid]
            if c_row.empty:
                row[f"{cid}__raw_score"] = np.nan
                row[f"{cid}__flag"] = False
                row[f"{cid}__severity"] = ""
            else:
                row[f"{cid}__raw_score"] = round(float(c_row["raw_score"].iloc[0]), 4)
                row[f"{cid}__flag"] = bool(c_row["flag_raw"].iloc[0])
                row[f"{cid}__severity"] = str(c_row["severity_raw"].iloc[0])
        rows.append(row)

    return pd.DataFrame(rows).sort_values("date").reset_index(drop=True)


# ============================================================================
# Tab 2: Agreement Matrix
# ============================================================================

def build_agreement_matrix(results_view: pd.DataFrame) -> pd.DataFrame:
    """For each flagged date, show which checks flagged it (1/0 matrix)."""
    rv = results_view.copy()
    rv["date"] = pd.to_datetime(rv["date"])
    flagged_mask = rv["flag_raw"].fillna(False).astype(bool)
    flagged_dates = sorted(rv.loc[flagged_mask, "date"].unique())
    all_checks = sorted(rv["check_id"].unique())

    rows = []
    for dt in flagged_dates:
        dt_data = rv[rv["date"] == dt]
        row: dict[str, Any] = {"date": dt}
        flagged_count = 0
        for cid in all_checks:
            c_row = dt_data[dt_data["check_id"] == cid]
            is_flagged = bool(c_row["flag_raw"].iloc[0]) if not c_row.empty else False
            row[cid] = 1 if is_flagged else 0
            flagged_count += int(is_flagged)
        row["total_checks_flagged"] = flagged_count
        row["total_checks"] = len(all_checks)
        row["agreement_pct"] = round(100.0 * flagged_count / max(len(all_checks), 1), 1)
        rows.append(row)

    out = pd.DataFrame(rows)
    if not out.empty:
        out = out.sort_values("date").reset_index(drop=True)
    return out


# ============================================================================
# Tab 3: Nowcast Internals
# ============================================================================

def build_nowcast_internals(
    results_view: pd.DataFrame,
    peer_series: pd.DataFrame,
    target_risk_factor_id: str,
    nowcast_model_states: dict[str, dict[str, Any]],
) -> pd.DataFrame:
    """For nowcast checks: show predicted, residual, peers, weights on flagged dates."""

    rv = results_view.copy()
    rv["date"] = pd.to_datetime(rv["date"])
    nowcast_checks = [c for c in rv["check_id"].unique() if "nowcast" in c and "iforest" not in c]
    if not nowcast_checks:
        return pd.DataFrame(columns=["date", "check_id", "info"])

    flagged = rv[rv["flag_raw"].fillna(False).astype(bool)]
    flagged_dates = sorted(flagged["date"].unique())
    if not flagged_dates:
        return pd.DataFrame(columns=["date", "check_id", "info"])

    # Get peer matrix for predictions
    if peer_series.empty:
        return pd.DataFrame(columns=["date", "check_id", "no_peer_data"])

    matrix, all_ids = _pivot_peer_matrix(peer_series)

    rows = []
    for cid in nowcast_checks:
        nc_state = nowcast_model_states.get(cid, {})
        per_rf = nc_state.get("per_rf", {}) if nc_state else {}
        target_info = per_rf.get(target_risk_factor_id, {})
        model = target_info.get("model")
        peer_ids = target_info.get("peer_ids", [])

        if model is None:
            continue

        # Reconstruct predictions
        available = [p for p in peer_ids if p in matrix.columns]
        if not available or target_risk_factor_id not in matrix.columns:
            continue

        try:
            if hasattr(model, "predict"):
                predicted = pd.Series(model.predict(matrix[available]), index=matrix.index)
            elif hasattr(model, "transform"):
                proj = model.transform(matrix[all_ids].to_numpy() if cid == "nowcast_pca_recon_common" else matrix[available].to_numpy())
                recon = model.inverse_transform(proj)
                col_idx = list(matrix.columns).index(target_risk_factor_id) if target_risk_factor_id in matrix.columns else 0
                predicted = pd.Series(recon[:, col_idx], index=matrix.index)
            else:
                continue
        except Exception:
            continue

        actual = matrix[target_risk_factor_id]
        residual = actual - predicted
        residual_window = 60
        rolling_std = residual.rolling(residual_window, min_periods=15).std(ddof=0)
        residual_zscore = residual.abs() / (rolling_std + 1e-9)

        # Extract weights
        weights = {}
        if hasattr(model, "coef_"):
            coef = np.asarray(model.coef_, dtype=float).flatten()
            if len(coef) == len(available):
                weights = {p: round(float(c), 4) for p, c in zip(available, coef)}

        for dt in flagged_dates:
            if dt not in matrix.index:
                continue
            row = {
                "date": dt,
                "check_id": cid,
                "actual_value": round(float(actual.get(dt, np.nan)), 6),
                "predicted_value": round(float(predicted.get(dt, np.nan)), 6),
                "residual": round(float(residual.get(dt, np.nan)), 6),
                "residual_zscore": round(float(residual_zscore.get(dt, np.nan)), 4),
                "n_peers_used": len(available),
                "peer_ids": ", ".join(available[:5]),
                "peer_weights": json.dumps(weights) if weights else "",
            }
            # Add peer values on this date
            for i, pid in enumerate(available[:5]):
                row[f"peer{i+1}_id"] = pid
                row[f"peer{i+1}_value"] = round(float(matrix[pid].get(dt, np.nan)), 6)
                row[f"peer{i+1}_weight"] = weights.get(pid, 0.0)
            rows.append(row)

    return pd.DataFrame(rows).sort_values(["date", "check_id"]).reset_index(drop=True) if rows else pd.DataFrame()


# ============================================================================
# Tab 4: IForest Internals
# ============================================================================

def build_iforest_internals(
    results_view: pd.DataFrame,
    peer_series: pd.DataFrame,
    target_risk_factor_id: str,
) -> pd.DataFrame:
    """For IForest checks: show all 6 feature values and their percentile rank on flagged dates."""

    rv = results_view.copy()
    rv["date"] = pd.to_datetime(rv["date"])
    iforest_checks = [c for c in rv["check_id"].unique() if "iforest" in c]
    if not iforest_checks or peer_series.empty:
        return pd.DataFrame(columns=["date", "check_id", "info"])

    flagged = rv[rv["flag_raw"].fillna(False).astype(bool)]
    all_flagged_dates = sorted(flagged["date"].unique())
    if not all_flagged_dates:
        return pd.DataFrame()

    # Build features
    feat = _build_peer_relative_features(peer_series)
    feat["date"] = pd.to_datetime(feat["date"])
    target_feat = feat[feat["risk_factor_id"] == target_risk_factor_id].sort_values("date")

    feature_cols = ["value_minus_peer_median", "peer_z", "ret_minus_peer_ret", "vol_minus_peer_vol", "peer_rank", "corr_to_peer_60d"]
    available_cols = [c for c in feature_cols if c in target_feat.columns]

    rows = []
    for dt in all_flagged_dates:
        row_data = target_feat[target_feat["date"] == dt]
        if row_data.empty:
            continue
        row: dict[str, Any] = {"date": dt, "check_ids": ", ".join(iforest_checks)}
        for c in available_cols:
            val = float(row_data[c].iloc[0])
            # Percentile rank in full history
            all_vals = target_feat[c].dropna()
            pct = float((all_vals < val).mean())
            row[f"{c}"] = round(val, 6)
            row[f"{c}__pctl"] = round(pct * 100, 1)
            # Flag if in top/bottom 2%
            row[f"{c}__extreme"] = "YES" if (pct <= 0.02 or pct >= 0.98) else ""
        rows.append(row)

    return pd.DataFrame(rows).sort_values("date").reset_index(drop=True) if rows else pd.DataFrame()


# ============================================================================
# Tab 5: PCA Curve Internals
# ============================================================================

def build_pca_internals(
    results_view: pd.DataFrame,
    peer_series: pd.DataFrame,
    target_risk_factor_id: str,
) -> pd.DataFrame:
    """For PCA curve check: show components, reconstruction error, explained variance on flagged dates."""

    rv = results_view.copy()
    rv["date"] = pd.to_datetime(rv["date"])
    pca_checks = [c for c in rv["check_id"].unique() if "pca" in c.lower() and "nowcast" not in c]
    if not pca_checks or peer_series.empty:
        return pd.DataFrame(columns=["date", "info"])

    flagged = rv[rv["flag_raw"].fillna(False).astype(bool)]
    all_flagged_dates = sorted(flagged["date"].unique())

    from sklearn.decomposition import PCA
    d = peer_series[["risk_factor_id", "date", "value"]].copy()
    d["value"] = pd.to_numeric(d["value"], errors="coerce")
    d = d.drop_duplicates(subset=["risk_factor_id", "date"], keep="last")
    matrix = d.pivot(index="date", columns="risk_factor_id", values="value").sort_index()
    matrix = matrix.ffill().bfill().fillna(0.0)
    matrix.index = pd.to_datetime(matrix.index)

    cols = list(matrix.columns)
    if target_risk_factor_id not in cols:
        return pd.DataFrame(columns=["date", "info"])
    target_idx = cols.index(target_risk_factor_id)

    # Standardize
    means = {c: float(matrix[c].mean()) for c in cols}
    stds = {c: float(matrix[c].std(ddof=0) + 1e-9) for c in cols}
    std_matrix = matrix.copy()
    for c in cols:
        std_matrix[c] = (matrix[c] - means[c]) / stds[c]

    # Fit PCA (holdout last 5 days)
    n_comp = min(3, len(cols) - 1, len(matrix) - 6)
    if n_comp < 1:
        return pd.DataFrame(columns=["date", "info"])
    pca = PCA(n_components=n_comp, svd_solver="full")
    pca.fit(std_matrix.iloc[:-5].to_numpy())

    projected = pca.transform(std_matrix.to_numpy())
    reconstructed = pca.inverse_transform(projected)
    residual_mat = std_matrix.to_numpy() - reconstructed

    rows = []
    for dt in all_flagged_dates:
        if dt not in matrix.index:
            continue
        dt_idx = list(matrix.index).index(dt)
        row: dict[str, Any] = {
            "date": dt,
            "check_id": ", ".join(pca_checks),
            "actual_value": round(float(matrix.iloc[dt_idx, target_idx]), 6),
            "actual_standardized": round(float(std_matrix.iloc[dt_idx, target_idx]), 4),
            "reconstructed_standardized": round(float(reconstructed[dt_idx, target_idx]), 4),
            "reconstruction_error_std": round(float(residual_mat[dt_idx, target_idx]), 4),
            "reconstruction_error_original": round(float(residual_mat[dt_idx, target_idx] * stds[target_risk_factor_id]), 6),
        }
        # Component loadings for this factor
        for k in range(n_comp):
            row[f"PC{k+1}_loading"] = round(float(pca.components_[k, target_idx]), 4)
            row[f"PC{k+1}_score_today"] = round(float(projected[dt_idx, k]), 4)
            row[f"PC{k+1}_explained_var"] = round(float(pca.explained_variance_ratio_[k]) * 100, 1)

        # How the target compares to peers in reconstruction error on this date
        all_errors = np.abs(residual_mat[dt_idx, :])
        target_error = abs(residual_mat[dt_idx, target_idx])
        row["error_rank_in_group"] = int((all_errors < target_error).sum()) + 1
        row["group_size"] = len(cols)
        row["total_explained_var_pct"] = round(float(pca.explained_variance_ratio_.sum()) * 100, 1)
        rows.append(row)

    return pd.DataFrame(rows).sort_values("date").reset_index(drop=True) if rows else pd.DataFrame()


# ============================================================================
# Excel Export
# ============================================================================

def export_to_excel(
    tab1: pd.DataFrame,
    tab2: pd.DataFrame,
    tab3: pd.DataFrame,
    tab4: pd.DataFrame,
    tab5: pd.DataFrame,
    output_path: Path,
) -> Path:
    """Write all tabs to one Excel file."""
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with pd.ExcelWriter(output_path, engine="openpyxl") as writer:
        if not tab1.empty:
            t1 = tab1.copy()
            if "date" in t1.columns:
                t1["date"] = pd.to_datetime(t1["date"]).dt.strftime("%Y-%m-%d")
            t1.to_excel(writer, sheet_name="1_RawData_Scoring", index=False)
        if not tab2.empty:
            t2 = tab2.copy()
            if "date" in t2.columns:
                t2["date"] = pd.to_datetime(t2["date"]).dt.strftime("%Y-%m-%d")
            t2.to_excel(writer, sheet_name="2_Agreement_Matrix", index=False)
        if not tab3.empty:
            t3 = tab3.copy()
            if "date" in t3.columns:
                t3["date"] = pd.to_datetime(t3["date"]).dt.strftime("%Y-%m-%d")
            t3.to_excel(writer, sheet_name="3_Nowcast_Internals", index=False)
        if not tab4.empty:
            t4 = tab4.copy()
            if "date" in t4.columns:
                t4["date"] = pd.to_datetime(t4["date"]).dt.strftime("%Y-%m-%d")
            t4.to_excel(writer, sheet_name="4_IForest_Internals", index=False)
        if not tab5.empty:
            t5 = tab5.copy()
            if "date" in t5.columns:
                t5["date"] = pd.to_datetime(t5["date"]).dt.strftime("%Y-%m-%d")
            t5.to_excel(writer, sheet_name="5_PCA_Curve_Internals", index=False)
    print(f"Excel exported: {output_path}")
    return output_path


# ============================================================================
# Dash UI
# ============================================================================

def launch_diagnostic_ui(
    tab1: pd.DataFrame,
    tab2: pd.DataFrame,
    tab3: pd.DataFrame,
    tab4: pd.DataFrame,
    tab5: pd.DataFrame,
    target_risk_factor_id: str,
    host: str = "127.0.0.1",
    port: int = 8070,
) -> None:
    """Launch a Dash UI with 5 tabs showing all diagnostic tables."""
    try:
        from dash import Dash, dash_table, dcc, html
    except ImportError:
        print("Dash not installed. Skipping UI. Install with: pip install dash")
        return

    def _make_table(df: pd.DataFrame, table_id: str) -> dash_table.DataTable:
        d = df.copy()
        if "date" in d.columns:
            d["date"] = pd.to_datetime(d["date"], errors="coerce").dt.strftime("%Y-%m-%d")
        for c in d.select_dtypes(include=[float]).columns:
            d[c] = d[c].round(4)
        return dash_table.DataTable(
            id=table_id,
            columns=[{"name": c, "id": c} for c in d.columns],
            data=d.to_dict("records"),
            page_size=30,
            sort_action="native",
            filter_action="native",
            style_table={"overflowX": "auto"},
            style_cell={"textAlign": "left", "fontFamily": "monospace", "fontSize": "11px", "padding": "4px"},
            style_header={"fontWeight": "bold", "backgroundColor": "#f0f0f0"},
            style_data_conditional=[
                {"if": {"filter_query": "{agreement_pct} >= 50"}, "backgroundColor": "#ffe0e0"} if "agreement_pct" in d.columns else {},
            ],
        )

    app = Dash(__name__)
    app.layout = html.Div([
        html.H3(f"Diagnostic Comparison Report — {target_risk_factor_id}"),
        dcc.Tabs([
            dcc.Tab(label="1. Raw Data + Scoring", children=[
                html.P("Union of all flagged dates. Shows raw data context and per-check raw_score/flag/severity."),
                _make_table(tab1, "diag-tab1") if not tab1.empty else html.P("No flagged dates."),
            ]),
            dcc.Tab(label="2. Agreement Matrix", children=[
                html.P("Which checks agree/disagree on each flagged date. 1=flagged, 0=not flagged."),
                _make_table(tab2, "diag-tab2") if not tab2.empty else html.P("No data."),
            ]),
            dcc.Tab(label="3. Nowcast Internals", children=[
                html.P("Nowcast Ridge/PCA: predicted value, residual, residual z-score, peer IDs, peer weights."),
                _make_table(tab3, "diag-tab3") if not tab3.empty else html.P("No nowcast data."),
            ]),
            dcc.Tab(label="4. IForest Internals", children=[
                html.P("IForest: 6 feature values, percentile rank in history, extreme flag (top/bottom 2%)."),
                _make_table(tab4, "diag-tab4") if not tab4.empty else html.P("No IForest data."),
            ]),
            dcc.Tab(label="5. PCA Curve Internals", children=[
                html.P("PCA: component loadings, scores, reconstruction error, explained variance."),
                _make_table(tab5, "diag-tab5") if not tab5.empty else html.P("No PCA data."),
            ]),
        ]),
    ], style={"padding": "12px"})

    import webbrowser
    url = f"http://{host}:{port}/"
    print(f"Launching diagnostic UI: {url}")
    try:
        webbrowser.open(url)
    except Exception:
        pass
    app.run(host=host, port=port, debug=False)


# ============================================================================
# Main
# ============================================================================

def main(launch_ui: bool = True, port: int = 8070) -> dict[str, pd.DataFrame]:
    print("=" * 70)
    print("Layer 3 Diagnostic Comparison Report")
    print("=" * 70)

    # Step 1: Load settings and run all checks (reuse notebook infrastructure)
    print("\nStep 1: Loading settings and running checks...")
    settings = load_runtime_settings(PROJECT_ROOT)
    prepared = prepare_universe_and_specs(settings)
    target_payload = load_target_series(settings, prepared)
    raw_results, run_aux = run_selected_checks(settings, prepared, target_payload, return_aux=True)
    normalized = normalize_and_build_view(settings, prepared, raw_results)
    results_view = normalized["results_view"]

    target_rf = target_payload["target_risk_factor_id"]
    peer_series = run_aux.get("peer_series", pd.DataFrame())
    nowcast_states = run_aux.get("nowcast_model_states", {})

    # Step 2: Build all diagnostic tabs
    print("\nStep 2: Building diagnostic tables...")

    t0 = time.perf_counter()
    tab1 = build_raw_data_context(results_view, target_payload["target_series"], peer_series, target_rf)
    print(f"  Tab 1 (Raw Data + Scoring): {len(tab1)} rows, {time.perf_counter()-t0:.2f}s")

    t0 = time.perf_counter()
    tab2 = build_agreement_matrix(results_view)
    print(f"  Tab 2 (Agreement Matrix): {len(tab2)} rows, {time.perf_counter()-t0:.2f}s")

    t0 = time.perf_counter()
    tab3 = build_nowcast_internals(results_view, peer_series, target_rf, nowcast_states)
    print(f"  Tab 3 (Nowcast Internals): {len(tab3)} rows, {time.perf_counter()-t0:.2f}s")

    t0 = time.perf_counter()
    tab4 = build_iforest_internals(results_view, peer_series, target_rf)
    print(f"  Tab 4 (IForest Internals): {len(tab4)} rows, {time.perf_counter()-t0:.2f}s")

    t0 = time.perf_counter()
    tab5 = build_pca_internals(results_view, peer_series, target_rf)
    print(f"  Tab 5 (PCA Internals): {len(tab5)} rows, {time.perf_counter()-t0:.2f}s")

    # Step 3: Export to Excel
    print("\nStep 3: Exporting to Excel...")
    excel_path = PROJECT_ROOT / "data" / "processed" / f"diagnostic_comparison_{target_rf}.xlsx"
    try:
        export_to_excel(tab1, tab2, tab3, tab4, tab5, excel_path)
    except Exception as e:
        print(f"  Excel export failed: {e}")

    # Step 4: Print summary
    print("\n" + "=" * 70)
    print("SUMMARY")
    print("=" * 70)
    if not tab2.empty:
        print(f"\nFlagged dates (union): {len(tab2)}")
        print(f"Checks in scope: {len([c for c in tab2.columns if c not in ['date','total_checks_flagged','total_checks','agreement_pct']])}")
        high_agreement = tab2[tab2["agreement_pct"] >= 50]
        print(f"Dates with >= 50% check agreement: {len(high_agreement)}")
        if not high_agreement.empty:
            print(high_agreement[["date", "total_checks_flagged", "agreement_pct"]].to_string(index=False))

    outputs = {"tab1": tab1, "tab2": tab2, "tab3": tab3, "tab4": tab4, "tab5": tab5}

    # Step 5: Launch UI
    if launch_ui:
        print("\nStep 5: Launching UI...")
        launch_diagnostic_ui(tab1, tab2, tab3, tab4, tab5, target_rf, port=port)

    return outputs


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Layer 3 Diagnostic Comparison Report")
    parser.add_argument("--no-ui", action="store_true", help="Skip UI, Excel only")
    parser.add_argument("--port", type=int, default=8070, help="Dash UI port")
    args = parser.parse_args()
    main(launch_ui=not args.no_ui, port=args.port)
