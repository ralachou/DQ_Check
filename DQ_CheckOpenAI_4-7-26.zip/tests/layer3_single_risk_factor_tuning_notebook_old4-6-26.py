
from __future__ import annotations

import copy
import os
import socket
import sys
import time
import webbrowser
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import plotly.graph_objects as go

try:
    from IPython.display import clear_output, display
except Exception:
    def display(obj):
        print(obj)

    def clear_output(wait: bool = False):
        del wait
        return None

try:
    import ipywidgets as widgets
except Exception:
    widgets = None

try:
    import dash
    from dash import Dash, Input, Output, dash_table, dcc, html
except Exception:
    dash = None
    Dash = None
    Input = None
    Output = None
    dash_table = None
    dcc = None
    html = None


PROJECT_ROOT = Path.cwd()
if not (PROJECT_ROOT / "src").exists() and (PROJECT_ROOT.parent / "src").exists():
    PROJECT_ROOT = PROJECT_ROOT.parent

SRC_PATH = PROJECT_ROOT / "src"
if str(SRC_PATH) not in sys.path:
    sys.path.insert(0, str(SRC_PATH))

PROJECT_ROOT


from common.schemas import config_hash, load_yaml
from common.taxonomy import (
    PEER_GROUP_ID_COL,
    TAXONOMY_PEER_KEYS,
    apply_peer_grouping,
    normalize_taxonomy_frame,
    resolve_peer_group_config,
)
from data_access.parquet_repository import ParquetTimeSeriesRepository
from dq_checks.feature_builder import FeatureBuilder
from dq_checks.registry import ModelRegistry, ModelSpec
from normalization.normalizer import normalize_results
from universe.builder import UniverseBuilder
from universe.definitions import UniverseDefinition

SEVERITY_OPTIONS = ["Low", "Med", "High", "Critical"]


def _in_notebook() -> bool:
    try:
        from IPython import get_ipython
        shell = get_ipython()
        if shell is None:
            return False
        shell_name = shell.__class__.__name__
        if shell_name == "ZMQInteractiveShell":
            return True
        if hasattr(shell, "kernel"):
            return True
        if os.environ.get("JPY_PARENT_PID"):
            return True
        cfg = getattr(shell, "config", {}) or {}
        return "IPKernelApp" in cfg
    except Exception:
        return False


def _prompt_choice(label: str, options: list[tuple[str, str]], default_value: str) -> str:
    def _read(prompt: str) -> str:
        try:
            return input(prompt).strip()
        except (EOFError, KeyboardInterrupt):
            return ""

    print(f"\n{label}")
    for i, (name, value) in enumerate(options, start=1):
        d = " (default)" if value == default_value else ""
        print(f"  {i}. {name}{d}")
    raw = _read("Choose number (Enter for default): ")
    if not raw:
        return default_value
    try:
        idx = int(raw)
        if 1 <= idx <= len(options):
            return options[idx - 1][1]
    except ValueError:
        pass
    print("Invalid choice. Using default.")
    return default_value


def _prompt_multi_severity(default_value: list[str] | None = None) -> list[str] | None:
    def _read(prompt: str) -> str:
        try:
            return input(prompt).strip()
        except (EOFError, KeyboardInterrupt):
            return ""

    default_value = default_value or []
    print("\nseverity_filter options:")
    for i, sev in enumerate(SEVERITY_OPTIONS, start=1):
        print(f"  {i}. {sev}")
    print("Use comma-separated numbers (e.g. 2,3,4).")
    print("Press Enter for no severity filter.")
    raw = _read("Choose severity filter: ")
    if not raw:
        return None
    picks: list[str] = []
    for token in [x.strip() for x in raw.split(",") if x.strip()]:
        try:
            idx = int(token)
            if 1 <= idx <= len(SEVERITY_OPTIONS):
                val = SEVERITY_OPTIONS[idx - 1]
                if val not in picks:
                    picks.append(val)
        except ValueError:
            token_norm = token.lower()
            for sev in SEVERITY_OPTIONS:
                if token_norm == sev.lower():
                    if sev not in picks:
                        picks.append(sev)
                    break
    if not picks:
        print("No valid severity selected. Using no severity filter.")
        return None
    return picks


def _prompt_yes_no(label: str, default: bool) -> bool:
    def _read(prompt: str) -> str:
        try:
            return input(prompt).strip().lower()
        except (EOFError, KeyboardInterrupt):
            return ""

    suffix = "Y/n" if default else "y/N"
    raw = _read(f"{label} [{suffix}]: ")
    if not raw:
        return default
    if raw in {"y", "yes", "1", "true"}:
        return True
    if raw in {"n", "no", "0", "false"}:
        return False
    print("Invalid input. Using default.")
    return default


def terminal_controls() -> dict[str, Any]:
    print("\nLayer 3 Single Risk Factor Tuning - Terminal Controls")
    print("Set filtering options for this run:\n")

    severity_source = _prompt_choice(
        label="1) severity_source",
        options=[("Raw/preNorm", "raw"), ("PostNorm", "norm")],
        default_value="raw",
    )
    severity_filter = _prompt_multi_severity(default_value=None)
    use_normalized_flags = _prompt_yes_no("Use normalized flags", default=True)
    enforce_raw_flag = _prompt_yes_no("Enforce raw flag=True filter", default=True)
    show_plot = _prompt_yes_no("Show plot", default=True)

    print("\nSelected options:")
    print("  severity_source:", severity_source)
    print("  severity_filter:", severity_filter if severity_filter else "None")
    print("  use_normalized_flags:", use_normalized_flags)
    print("  enforce_raw_flag:", enforce_raw_flag)
    print("  show_plot:", show_plot)

    return {
        "severity_source": severity_source,
        "severity_filter": severity_filter,
        "use_normalized_flags": use_normalized_flags,
        "enforce_raw_flag": enforce_raw_flag,
        "show_plot": show_plot,
    }


def _build_universe_definition(catalog_dict: dict[str, Any], universe_name: str) -> UniverseDefinition:
    uni = catalog_dict.get("universes", {}).get(universe_name)
    if not uni:
        raise ValueError(f"Universe '{universe_name}' not found in YAML.")
    return UniverseDefinition(
        name=universe_name,
        description=str(uni.get("description", "")),
        filter_rules=uni.get("filters", {}),
    )


def _apply_analysis_field(series_df: pd.DataFrame, requested_field: str) -> tuple[pd.DataFrame, str]:
    field = str(requested_field or "value").strip()
    if field in series_df.columns:
        selected = field
    elif "value" in series_df.columns:
        selected = "value"
        print(f"Warning: analysis field '{field}' not found. Falling back to 'value'.")
    else:
        raise ValueError(f"Neither '{field}' nor 'value' exists. Columns: {list(series_df.columns)}")

    out = series_df.copy()
    out["date"] = pd.to_datetime(out["date"], errors="coerce")
    out["value"] = pd.to_numeric(out[selected], errors="coerce")
    out = out.dropna(subset=["risk_factor_id", "date", "value"]).sort_values(["risk_factor_id", "date"]).reset_index(drop=True)
    return out, selected


def _apply_check_overrides(specs: list[ModelSpec], override_cfg: dict[str, Any]) -> list[ModelSpec]:
    override_map = override_cfg.get("overrides", {}).get("checks", {}) or {}
    out: list[ModelSpec] = []
    for spec in specs:
        spec2 = copy.deepcopy(spec)
        row = override_map.get(spec2.id, {})
        if isinstance(row, dict):
            if "fit_policy" in row:
                spec2.fit_policy = str(row["fit_policy"])
            if "normalization_profile" in row:
                spec2.normalization_profile = str(row["normalization_profile"])
            if "severity_profile" in row:
                spec2.severity_profile = str(row["severity_profile"])
            if "enabled" in row:
                spec2.enabled = bool(row["enabled"])
            params_override = row.get("params", {})
            if isinstance(params_override, dict) and params_override:
                p = dict(spec2.params)
                p.update(params_override)
                spec2.params = p
        if spec2.enabled:
            out.append(spec2)
    return out


def _display_specs(specs: list[ModelSpec]) -> pd.DataFrame:
    return pd.DataFrame(
        [
            {
                "check_id": s.id,
                "backend": s.backend,
                "model_name": s.model_name,
                "family": s.family,
                "fit_policy": s.fit_policy,
                "normalization_profile": s.normalization_profile,
                "params": s.params,
            }
            for s in specs
        ]
    )


def _build_check_profiles(specs: list[ModelSpec], catalog_dict: dict[str, Any]) -> dict[str, dict[str, Any]]:
    profiles_cfg = catalog_dict.get("normalization", {}).get("profiles", {})
    defaults_cfg = catalog_dict.get("normalization", {}).get("defaults", {})
    sev_cfg = catalog_dict.get("globals", {}).get("default_severity_thresholds", {})
    out: dict[str, dict[str, Any]] = {}
    for spec in specs:
        profile_cfg = profiles_cfg.get(spec.normalization_profile, {})
        out[spec.id] = {
            "normalization_strategy": profile_cfg.get("strategy", defaults_cfg.get("strategy", "ecdf")),
            "normalization_params": profile_cfg,
            "backend": spec.backend,
            "severity_mode": "fixed",
            "severity_thresholds": sev_cfg.get("quantile", {}),
            "fixed_thresholds": sev_cfg.get("fixed", {}),
            "model_version": spec.version_tag,
        }
    return out


def load_runtime_settings(project_root: Path, local_override_rel: str = "configs/local_single_factor_tuning.yaml") -> dict[str, Any]:
    local_override_path = project_root / local_override_rel
    local_cfg = load_yaml(local_override_path)

    paths_cfg = local_cfg.get("paths", {})
    run_cfg = local_cfg.get("run", {})

    base_config_path = project_root / str(paths_cfg.get("base_config_path", "configs/model_catalog.yaml"))
    raw_path = project_root / str(paths_cfg.get("raw_path", "data/raw"))
    artifact_root = project_root / str(paths_cfg.get("artifact_root", "data/artifacts/normalization/notebook_single_factor"))

    settings = {
        "local_override_path": local_override_path,
        "local_cfg": local_cfg,
        "base_config_path": base_config_path,
        "raw_path": raw_path,
        "artifact_root": artifact_root,
        "universe_name": str(run_cfg.get("universe_name", "MARS_SUBSET")),
        "business_date": str(run_cfg.get("business_date", "2026-02-27")),
        "start_date": str(run_cfg.get("start_date", "2019-01-02")),
        "end_date": str(run_cfg.get("end_date", "2020-12-31")),
        "analysis_field": str(run_cfg.get("analysis_field", "shift")),
        "target_risk_factor_id": run_cfg.get("target_risk_factor_id"),
        "selected_check_ids": [str(x) for x in run_cfg.get("selected_check_ids", []) if str(x).strip()],
    }

    print("Local override YAML:", settings["local_override_path"])
    print("Base model config:", settings["base_config_path"])
    print("Universe:", settings["universe_name"])
    print("Business date:", settings["business_date"])
    return settings


def prepare_universe_and_specs(settings: dict[str, Any]) -> dict[str, Any]:
    catalog = load_yaml(settings["base_config_path"])
    cfg_hash = config_hash(catalog)

    repo = ParquetTimeSeriesRepository(base_path=settings["raw_path"])
    definition = _build_universe_definition(catalog, settings["universe_name"])
    membership = UniverseBuilder(repo).build(definition)
    membership = normalize_taxonomy_frame(membership, require_risk_factor_id=True)
    peer_cfg = resolve_peer_group_config(catalog, settings["universe_name"], membership=membership)
    membership, peer_group_keys = apply_peer_grouping(
        membership,
        peer_keys=peer_cfg.get("keys", TAXONOMY_PEER_KEYS),
        peer_rules=peer_cfg.get("rules", []),
    )

    registry = ModelRegistry()
    base_specs = [s for s in registry.load_universe_specs(catalog, settings["universe_name"]) if s.enabled]
    effective_specs = _apply_check_overrides(base_specs, settings["local_cfg"])
    selected_check_ids = set(settings["selected_check_ids"])
    selected_specs = [s for s in effective_specs if s.id in selected_check_ids] if selected_check_ids else effective_specs

    if not selected_specs:
        raise ValueError("No checks selected after applying local overrides/selection.")

    print(f"Universe members: {membership['risk_factor_id'].nunique():,}")
    print(f"Enabled checks in base config: {len(base_specs)}")
    print(f"Checks selected to run: {len(selected_specs)}")
    print("Peer group keys:", peer_group_keys)
    print("Peer group source:", peer_cfg.get("source", "default"))
    print("Config hash:", cfg_hash[:16], "...")
    display(_display_specs(selected_specs))

    return {
        "catalog": catalog,
        "cfg_hash": cfg_hash,
        "repo": repo,
        "membership": membership,
        "peer_group_keys": peer_group_keys,
        "peer_group_source": peer_cfg.get("source", "default"),
        "registry": registry,
        "selected_specs": selected_specs,
    }


def load_target_series(settings: dict[str, Any], prepared: dict[str, Any]) -> dict[str, Any]:
    membership = prepared["membership"]
    repo = prepared["repo"]

    target_risk_factor_id = settings["target_risk_factor_id"]
    if target_risk_factor_id is None:
        target_risk_factor_id = str(membership["risk_factor_id"].iloc[0])
    else:
        target_risk_factor_id = str(target_risk_factor_id)

    universe_ids = set(membership["risk_factor_id"].astype(str))
    if target_risk_factor_id not in universe_ids:
        raise ValueError(f"target_risk_factor_id '{target_risk_factor_id}' not in universe '{settings['universe_name']}'.")

    target_series_raw = repo.get_series(
        risk_factor_ids=[target_risk_factor_id],
        start_date=settings["start_date"],
        end_date=settings["end_date"],
        business_date=settings["business_date"],
    )
    target_series, analysis_field_used = _apply_analysis_field(target_series_raw, settings["analysis_field"])
    if target_series.empty:
        raise ValueError("No target series rows found. Check date range, business date, and risk_factor_id.")

    print("Target risk_factor_id:", target_risk_factor_id)
    print("Analysis field used:", analysis_field_used)
    print("Rows:", len(target_series))
    display(target_series.head(5))
    display(target_series.tail(5))

    return {
        "target_risk_factor_id": target_risk_factor_id,
        "analysis_field_used": analysis_field_used,
        "target_series": target_series,
    }


def run_selected_checks(settings: dict[str, Any], prepared: dict[str, Any], target_payload: dict[str, Any]) -> pd.DataFrame:
    membership = prepared["membership"]
    repo = prepared["repo"]
    registry = prepared["registry"]
    selected_specs = prepared["selected_specs"]
    target_series = target_payload["target_series"]
    target_risk_factor_id = target_payload["target_risk_factor_id"]
    analysis_field_used = str(target_payload.get("analysis_field_used", settings.get("analysis_field", "value")))
    series_semantics = "shift" if analysis_field_used.strip().lower() == "shift" else "level"

    target_meta = membership[membership["risk_factor_id"].astype(str) == target_risk_factor_id].iloc[0]
    if PEER_GROUP_ID_COL in membership.columns:
        peer_mask = membership[PEER_GROUP_ID_COL].astype(str) == str(target_meta[PEER_GROUP_ID_COL])
    else:
        peer_keys = [k for k in prepared.get("peer_group_keys", TAXONOMY_PEER_KEYS) if k in membership.columns]
        peer_mask = pd.Series(True, index=membership.index)
        for k in peer_keys:
            peer_mask &= membership[k].astype(str) == str(target_meta[k])
    peer_membership = membership[peer_mask].copy()
    peer_ids = sorted(peer_membership["risk_factor_id"].astype(str).unique().tolist())

    needs_peer = any(s.fit_policy == "per_peer_group" for s in selected_specs)
    needs_global = any(s.fit_policy == "global" for s in selected_specs)

    peer_series = pd.DataFrame()
    if needs_peer:
        peer_raw = repo.get_series(
            risk_factor_ids=peer_ids,
            start_date=settings["start_date"],
            end_date=settings["end_date"],
            business_date=settings["business_date"],
        )
        peer_series, _ = _apply_analysis_field(peer_raw, settings["analysis_field"])
        print("Peer-group size:", peer_series["risk_factor_id"].nunique())

    global_series = pd.DataFrame()
    if needs_global:
        all_ids = membership["risk_factor_id"].astype(str).tolist()
        global_raw = repo.get_series(
            risk_factor_ids=all_ids,
            start_date=settings["start_date"],
            end_date=settings["end_date"],
            business_date=settings["business_date"],
        )
        global_series, _ = _apply_analysis_field(global_raw, settings["analysis_field"])
        print("Global series factors:", global_series["risk_factor_id"].nunique())

    checks: dict[str, Any] = {}
    for spec in selected_specs:
        checks[spec.id] = registry.build_from_spec(spec, checks)

    feature_builder = FeatureBuilder()
    raw_parts: list[pd.DataFrame] = []

    for spec in selected_specs:
        check = checks[spec.id]
        t0 = time.perf_counter()

        if spec.fit_policy == "per_series":
            df_in = target_series[["risk_factor_id", "date", "value"]].copy().sort_values("date").reset_index(drop=True)
            ctx = {"risk_factor_id": target_risk_factor_id, "series_semantics": series_semantics}
            state = check.fit(df_in, ctx)
            scored = check.score(df_in, ctx, state)

        elif spec.fit_policy == "per_peer_group":
            if peer_series.empty:
                raise ValueError(f"Peer-group data empty for check '{spec.id}'.")
            if peer_series["risk_factor_id"].nunique() < 3:
                parts = []
                for rf_id, sdf in peer_series.groupby("risk_factor_id", sort=False):
                    sdf = sdf[["risk_factor_id", "date", "value"]].copy().sort_values("date").reset_index(drop=True)
                    feat = feature_builder.build_features(sdf)
                    ctx = {"risk_factor_id": str(rf_id), "series_semantics": series_semantics}
                    st = check.fit(feat, ctx)
                    parts.append(check.score(feat, ctx, st))
                scored_all = pd.concat(parts, ignore_index=True) if parts else pd.DataFrame()
            else:
                feat_grp = feature_builder.build_batch(peer_series[["risk_factor_id", "date", "value"]].copy(), max_workers=4)
                ctx = {"peer_group": True, "series_semantics": series_semantics}
                st = check.fit(feat_grp, ctx)
                scored_all = check.score(feat_grp, ctx, st)
            scored = scored_all[scored_all["risk_factor_id"].astype(str) == target_risk_factor_id].copy()

        elif spec.fit_policy == "global":
            if global_series.empty:
                raise ValueError(f"Global data empty for check '{spec.id}'.")
            feat_all = feature_builder.build_batch(global_series[["risk_factor_id", "date", "value"]].copy(), max_workers=4)
            ctx = {"global": True, "series_semantics": series_semantics}
            st = check.fit(feat_all, ctx)
            scored_all = check.score(feat_all, ctx, st)
            scored = scored_all[scored_all["risk_factor_id"].astype(str) == target_risk_factor_id].copy()

        else:
            raise ValueError(f"Unsupported fit_policy '{spec.fit_policy}' for check '{spec.id}'.")

        elapsed = time.perf_counter() - t0
        scored["check_id"] = spec.id
        scored["backend"] = spec.backend
        scored["family"] = spec.family
        scored["fit_policy"] = spec.fit_policy
        scored["run_seconds"] = round(elapsed, 4)
        raw_parts.append(scored)
        print(f"{spec.id:35s} | {spec.fit_policy:14s} | rows={len(scored):5d} | sec={elapsed:8.3f}")

    raw_results = pd.concat(raw_parts, ignore_index=True) if raw_parts else pd.DataFrame()
    if raw_results.empty:
        raise ValueError("No check outputs produced.")
    raw_results["date"] = pd.to_datetime(raw_results["date"], errors="coerce")
    raw_results = raw_results.sort_values(["date", "check_id"]).reset_index(drop=True)
    display(raw_results.head(10))
    return raw_results


def normalize_and_build_view(settings: dict[str, Any], prepared: dict[str, Any], raw_results: pd.DataFrame) -> dict[str, Any]:
    selected_specs = prepared["selected_specs"]
    catalog = prepared["catalog"]
    cfg_hash = prepared["cfg_hash"]

    profiles = _build_check_profiles(selected_specs, catalog)
    run_id = f"nb_single_factor_{pd.Timestamp.utcnow().strftime('%Y%m%d_%H%M%S')}"
    artifact_root = Path(settings["artifact_root"])
    artifact_root.mkdir(parents=True, exist_ok=True)

    norm_results = normalize_results(
        results_df=raw_results.copy(),
        check_profiles=profiles,
        run_id=run_id,
        config_hash=cfg_hash,
        business_date=str(pd.to_datetime(settings["business_date"]).date()),
        artifact_root=artifact_root,
    )

    keys = ["risk_factor_id", "date", "check_id"]
    raw_flag_view = raw_results[keys + ["flag", "severity", "threshold"]].rename(
        columns={"flag": "flag_raw", "severity": "severity_raw", "threshold": "threshold_raw"}
    )
    results_view = norm_results.rename(
        columns={"flag": "flag_norm", "severity": "severity_norm", "threshold": "threshold_norm"}
    ).merge(raw_flag_view, on=keys, how="left")

    results_view = results_view[
        [
            "risk_factor_id",
            "date",
            "check_id",
            "backend",
            "family",
            "fit_policy",
            "raw_score",
            "norm_score",
            "threshold_raw",
            "threshold_norm",
            "flag_raw",
            "flag_norm",
            "severity_raw",
            "severity_norm",
            "reason_code",
            "explain",
            "run_seconds",
        ]
    ].sort_values(["date", "check_id"]).reset_index(drop=True)

    print("Normalization artifacts:", artifact_root)
    print("Run ID:", run_id)
    display(results_view.tail(20))

    return {"run_id": run_id, "results_view": results_view}


def build_flagged_rows(
    results_view: pd.DataFrame,
    use_normalized_flags: bool = True,
    severity_filter: str | list[str] | None = None,
    severity_source: str = "raw",
    enforce_raw_flag: bool = True,
) -> tuple[str, pd.DataFrame]:
    flag_col, severity_col, flagged_only = _filter_flagged_rows(
        results_view=results_view,
        use_normalized_flags=use_normalized_flags,
        severity_filter=severity_filter,
        severity_source=severity_source,
        enforce_raw_flag=enforce_raw_flag,
    )
    print("Flag column:", flag_col)
    print("Enforce raw flag:", enforce_raw_flag)
    print("Severity source:", severity_col)
    if severity_filter is not None:
        print("Severity filter:", severity_filter)
    print("Flagged rows:", len(flagged_only))
    display(
        flagged_only[
            [
                "date",
                "check_id",
                "raw_score",
                "norm_score",
                "flag_raw",
                "flag_norm",
                "severity_raw",
                "severity_norm",
                "reason_code",
                "explain",
            ]
        ].sort_values(["date", "check_id"]).reset_index(drop=True)
    )
    return flag_col, flagged_only


def _filter_flagged_rows(
    results_view: pd.DataFrame,
    use_normalized_flags: bool = True,
    severity_filter: str | list[str] | None = None,
    severity_source: str = "raw",
    enforce_raw_flag: bool = True,
) -> tuple[str, str, pd.DataFrame]:
    flag_col = "flag_norm" if use_normalized_flags else "flag_raw"
    severity_col = "severity_norm" if str(severity_source).strip().lower() == "norm" else "severity_raw"

    def _canon_severity(x: Any) -> str:
        s = str(x).strip().lower()
        if s in {"med", "medium"}:
            return "med"
        if s in {"high"}:
            return "high"
        if s in {"low"}:
            return "low"
        if s in {"critical", "crit"}:
            return "critical"
        return s

    base = results_view.copy()
    if enforce_raw_flag and "flag_raw" in base.columns:
        base = base[base["flag_raw"].fillna(False)]
    else:
        base = base[base[flag_col].fillna(False)]

    if severity_filter is not None:
        allowed = [severity_filter] if isinstance(severity_filter, str) else list(severity_filter)
        allowed = {_canon_severity(x) for x in allowed if str(x).strip()}
        if allowed:
            base = base[base[severity_col].map(_canon_severity).isin(allowed)]

    flagged_only = base.copy()
    return flag_col, severity_col, flagged_only


def build_raw_vs_flags_figure(target_series: pd.DataFrame, flagged_rows: pd.DataFrame, target_risk_factor_id: str, flag_col: str) -> go.Figure:
    plot_df = target_series[["date", "value"]].drop_duplicates().sort_values("date")
    fig = go.Figure()
    fig.add_trace(
        go.Scatter(
            x=plot_df["date"],
            y=plot_df["value"],
            mode="lines",
            name="raw value",
            line=dict(color="royalblue", width=1.5),
        )
    )

    plot_flags = flagged_rows.copy().merge(plot_df, on="date", how="left")
    for check_id, g in plot_flags.groupby("check_id", sort=False):
        fig.add_trace(
            go.Scatter(
                x=g["date"],
                y=g["value"],
                mode="markers",
                name=f"flag:{check_id}",
                marker=dict(size=9, line=dict(width=1)),
                customdata=np.stack(
                    [
                        g["check_id"],
                        g["raw_score"].round(6),
                        g["norm_score"].round(6),
                        g["severity_raw"].astype(str),
                        g["severity_norm"].astype(str),
                        g["reason_code"].astype(str),
                    ],
                    axis=-1,
                ),
                hovertemplate=(
                    "date=%{x|%Y-%m-%d}<br>"
                    "value=%{y:.6f}<br>"
                    "check=%{customdata[0]}<br>"
                    "raw_score=%{customdata[1]}<br>"
                    "norm_score=%{customdata[2]}<br>"
                    "severity_raw=%{customdata[3]}<br>"
                    "severity_norm=%{customdata[4]}<br>"
                    "reason=%{customdata[5]}<extra></extra>"
                ),
            )
        )
    fig.update_layout(
        template="plotly_white",
        title=f"{target_risk_factor_id} | Raw Series + Flags ({flag_col})",
        xaxis_title="date",
        yaxis_title="value",
        legend_title="series/check",
        height=560,
    )
    return fig


def plot_raw_vs_flags(target_series: pd.DataFrame, flagged_rows: pd.DataFrame, target_risk_factor_id: str, flag_col: str) -> go.Figure:
    fig = build_raw_vs_flags_figure(
        target_series=target_series,
        flagged_rows=flagged_rows,
        target_risk_factor_id=target_risk_factor_id,
        flag_col=flag_col,
    )
    fig.show()
    return fig


def build_model_summary(results_view: pd.DataFrame) -> pd.DataFrame:
    summary = (
        results_view.groupby(["check_id", "backend", "family", "fit_policy"], as_index=False)
        .agg(
            points=("date", "count"),
            flags_raw=("flag_raw", "sum"),
            flags_norm=("flag_norm", "sum"),
            max_raw_score=("raw_score", "max"),
            max_norm_score=("norm_score", "max"),
            mean_norm_score=("norm_score", "mean"),
            run_seconds=("run_seconds", "max"),
        )
        .sort_values(["flags_norm", "max_norm_score", "flags_raw"], ascending=[False, False, False])
        .reset_index(drop=True)
    )
    display(summary)
    return summary


def main(
    use_normalized_flags: bool = True,
    show_plot: bool = True,
    severity_filter: str | list[str] | None = None,
    severity_source: str = "raw",
    enforce_raw_flag: bool = True,
) -> dict[str, Any]:
    """
    to help my team pick one single-risk-factor and debug it
    """
    print("Step 1: load_runtime_settings()")
    settings = load_runtime_settings(PROJECT_ROOT)

    print("Step 2: prepare_universe_and_specs()")
    prepared = prepare_universe_and_specs(settings)

    print("Step 3: load_target_series()")
    target_payload = load_target_series(settings, prepared)

    print("Step 4: run_selected_checks()")
    raw_results = run_selected_checks(settings, prepared, target_payload)

    print("Step 5: normalize_and_build_view()")
    normalized_payload = normalize_and_build_view(settings, prepared, raw_results)
    results_view = normalized_payload["results_view"]

    print("Step 6: build_flagged_rows()")
    flag_col, flagged_only = build_flagged_rows(
        results_view,
        use_normalized_flags=use_normalized_flags,
        severity_filter=severity_filter,
        severity_source=severity_source,
        enforce_raw_flag=enforce_raw_flag,
    )

    fig = None
    if show_plot:
        print("Step 7: plot_raw_vs_flags()")
        fig = plot_raw_vs_flags(
            target_series=target_payload["target_series"],
            flagged_rows=flagged_only,
            target_risk_factor_id=target_payload["target_risk_factor_id"],
            flag_col=flag_col,
        )

    print("Step 8: build_model_summary()")
    summary = build_model_summary(results_view)

    return {
        "settings": settings,
        "prepared": prepared,
        "target_payload": target_payload,
        "raw_results": raw_results,
        "normalized_payload": normalized_payload,
        "results_view": results_view,
        "flag_col": flag_col,
        "flagged_only": flagged_only,
        "figure": fig,
        "summary": summary,
    }



# ## main  Pipeline
#`use_normalized_flags=True`-->  uses normalized flag/severity for  plot.
def runPipeline(launch_browser_ui: bool | None = None):
    run_kwargs: dict[str, Any] = {
        "use_normalized_flags": True,
        "show_plot": True,
        "severity_filter": None,
        "severity_source": "raw",
        "enforce_raw_flag": True,
    }

    if _in_notebook():
        ui = notebook_controls()
        if ui is not None:
            print("Notebook controls launched. Use the widgets and click 'Run Tuning'.")
            return {"ui": ui}
    elif widgets is not None:
        if sys.stdin.isatty():
            run_kwargs.update(terminal_controls())
        else:
            print("Running outside notebook without interactive terminal input; using defaults.")
    else:
        if sys.stdin.isatty():
            run_kwargs.update(terminal_controls())
        else:
            print("ipywidgets not installed and no interactive terminal input; using defaults.")

    outputs = main(**run_kwargs)
    outputs["summary"].head()
    if launch_browser_ui is None:
        launch_browser_ui = (not _in_notebook())
    if launch_browser_ui and not _in_notebook():
        launch_browser_filter_ui(outputs)
    return outputs


def notebook_controls():
    """
    Notebook UI controls for one-click tuning runs.

    Adds:
      1) severity_source: Raw/preNorm | PostNorm
      2) severity_filter options: Low, Med, High, Critical
    """
    if widgets is None:
        print("ipywidgets is not installed. Install it with: pip install ipywidgets")
        print("Fallback: call main(...) directly.")
        return None

    severity_source_widget = widgets.ToggleButtons(
        options=[("Raw/preNorm", "raw"), ("PostNorm", "norm")],
        value="raw",
        description="severity_source",
    )
    severity_filter_widget = widgets.SelectMultiple(
        options=["Low", "Med", "High", "Critical"],
        value=(),
        description="severity_filter",
        rows=4,
    )
    use_norm_flags_widget = widgets.Checkbox(value=True, description="use_normalized_flags")
    enforce_raw_flag_widget = widgets.Checkbox(value=True, description="enforce_raw_flag")
    show_plot_widget = widgets.Checkbox(value=True, description="show_plot")
    run_button = widgets.Button(description="Run Tuning", button_style="primary")
    out = widgets.Output()

    def _on_run(_):
        with out:
            clear_output(wait=True)
            sev = list(severity_filter_widget.value) if severity_filter_widget.value else None
            _ = main(
                use_normalized_flags=bool(use_norm_flags_widget.value),
                show_plot=bool(show_plot_widget.value),
                severity_filter=sev,
                severity_source=str(severity_source_widget.value),
                enforce_raw_flag=bool(enforce_raw_flag_widget.value),
            )

    run_button.on_click(_on_run)

    ui = widgets.VBox(
        [
            widgets.HTML("<b>Layer 3 Single Risk Factor Tuning Controls</b>"),
            severity_source_widget,
            severity_filter_widget,
            widgets.HBox([use_norm_flags_widget, enforce_raw_flag_widget, show_plot_widget]),
            run_button,
            out,
        ]
    )
    display(ui)
    return ui


def _find_open_port(preferred: int = 8050) -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        if s.connect_ex(("127.0.0.1", int(preferred))) != 0:
            return int(preferred)
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        return int(s.getsockname()[1])


def launch_browser_filter_ui(outputs: dict[str, Any], host: str = "127.0.0.1", port: int | None = None, open_browser: bool = True) -> None:
    """
    Launch a lightweight local Dash UI for post-run filtering.

    Filters available in browser:
      1) severity_source: Raw/preNorm or PostNorm
      2) severity_filter: Low/Med/High/Critical
    """
    if Dash is None:
        print("Dash is not installed. Install with: pip install dash")
        return

    results_view = outputs["results_view"].copy()
    target_series = outputs["target_payload"]["target_series"].copy()
    target_risk_factor_id = str(outputs["target_payload"]["target_risk_factor_id"])

    app = Dash(__name__)
    app.layout = html.Div(
        [
            html.H3("Layer 3 Single Risk Factor Tuning - Browser Filters"),
            html.Div(
                [
                    html.Div(
                        [
                            html.Div("Severity source"),
                            dcc.RadioItems(
                                id="l3-severity-source",
                                options=[
                                    {"label": "Raw/preNorm", "value": "raw"},
                                    {"label": "PostNorm", "value": "norm"},
                                ],
                                value="raw",
                                inline=True,
                            ),
                        ]
                    ),
                    html.Div(
                        [
                            html.Div("Severity filter"),
                            dcc.Dropdown(
                                id="l3-severity-filter",
                                options=[{"label": s, "value": s} for s in SEVERITY_OPTIONS],
                                value=[],
                                multi=True,
                                placeholder="Select one or many severities",
                            ),
                        ]
                    ),
                    html.Div(
                        [
                            dcc.Checklist(
                                id="l3-use-norm-flag",
                                options=[{"label": "use_normalized_flags", "value": "on"}],
                                value=["on"],
                            ),
                            dcc.Checklist(
                                id="l3-enforce-raw-flag",
                                options=[{"label": "enforce_raw_flag", "value": "on"}],
                                value=["on"],
                            ),
                        ]
                    ),
                ],
                style={"display": "grid", "gridTemplateColumns": "1fr 1.2fr 1fr", "gap": "12px", "marginBottom": "10px"},
            ),
            html.Div(id="l3-filter-summary", style={"marginBottom": "8px", "fontWeight": 600}),
            dcc.Graph(id="l3-flagged-figure"),
            dash_table.DataTable(
                id="l3-flagged-table",
                columns=[
                    {"name": "date", "id": "date"},
                    {"name": "check_id", "id": "check_id"},
                    {"name": "raw_score", "id": "raw_score"},
                    {"name": "norm_score", "id": "norm_score"},
                    {"name": "flag_raw", "id": "flag_raw"},
                    {"name": "flag_norm", "id": "flag_norm"},
                    {"name": "severity_raw", "id": "severity_raw"},
                    {"name": "severity_norm", "id": "severity_norm"},
                    {"name": "reason_code", "id": "reason_code"},
                ],
                data=[],
                page_size=20,
                sort_action="native",
                filter_action="native",
                style_table={"overflowX": "auto"},
                style_cell={"textAlign": "left", "fontFamily": "monospace", "fontSize": "12px"},
            ),
        ],
        style={"padding": "12px"},
    )

    @app.callback(
        Output("l3-filter-summary", "children"),
        Output("l3-flagged-figure", "figure"),
        Output("l3-flagged-table", "data"),
        Input("l3-severity-source", "value"),
        Input("l3-severity-filter", "value"),
        Input("l3-use-norm-flag", "value"),
        Input("l3-enforce-raw-flag", "value"),
    )
    def _refresh_view(severity_source: str, severity_filter: list[str] | None, use_norm_flag_val: list[str], enforce_raw_val: list[str]):
        use_norm_flag = "on" in (use_norm_flag_val or [])
        enforce_raw_flag = "on" in (enforce_raw_val or [])
        sev = severity_filter if severity_filter else None

        flag_col, severity_col, flagged = _filter_flagged_rows(
            results_view=results_view,
            use_normalized_flags=use_norm_flag,
            severity_filter=sev,
            severity_source=str(severity_source or "raw"),
            enforce_raw_flag=enforce_raw_flag,
        )
        flagged_sorted = flagged.sort_values(["date", "check_id"]).reset_index(drop=True).copy()
        if "date" in flagged_sorted.columns:
            flagged_sorted["date"] = pd.to_datetime(flagged_sorted["date"], errors="coerce").dt.strftime("%Y-%m-%d")
        for c in ["raw_score", "norm_score"]:
            if c in flagged_sorted.columns:
                flagged_sorted[c] = pd.to_numeric(flagged_sorted[c], errors="coerce").round(6)

        fig = build_raw_vs_flags_figure(
            target_series=target_series,
            flagged_rows=flagged,
            target_risk_factor_id=target_risk_factor_id,
            flag_col=flag_col,
        )
        summary = (
            f"risk_factor_id={target_risk_factor_id} | "
            f"flag_col={flag_col} | severity_col={severity_col} | "
            f"rows={len(flagged_sorted):,}"
        )
        table_cols = ["date", "check_id", "raw_score", "norm_score", "flag_raw", "flag_norm", "severity_raw", "severity_norm", "reason_code"]
        table_data = flagged_sorted[table_cols].to_dict("records") if not flagged_sorted.empty else []
        return summary, fig, table_data

    run_port = int(port) if port is not None else _find_open_port()
    url = f"http://{host}:{run_port}/"
    print(f"Launching browser filter UI: {url}")
    if open_browser:
        try:
            webbrowser.open(url)
        except Exception:
            pass
    app.run(host=host, port=run_port, debug=False)


if __name__ == "__main__":
    runPipeline()
