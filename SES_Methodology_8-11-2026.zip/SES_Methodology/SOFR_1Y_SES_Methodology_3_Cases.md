# SOFR 1Y SES Methodology: Historical, Asymmetrical Sigma, and Fallback

## Purpose

This note explains how to calculate SES-style stress scenario shocks for one NMRF: **SOFR 1Y**. The goal is to show how the methodology changes depending on the number of available 10-business-day returns:

| Available 10d returns N = |X^j| | Method | SOFR example |
|---:|---|---|
| N >= 200 | Historical ES method | SOFR 1Y with 210 or more returns |
| 200 > N >= 12 | Asymmetrical sigma method | SOFR 1Y with 100 returns |
| N < 12 | Fallback method | SOFR 1Y with 5 or 0 returns |

The document source is the EBA staff paper **A universal stress scenario approach for capitalising non-modellable risk factors under the FRTB**. The paper builds a 10-business-day return sample `X^j`, calibrates up/down shocks, determines the extreme scenario of future shock, applies non-linearity correction, then scales to the liquidity horizon.

---

## 1. Common starting point for all three methods

### 1.1 Pick the risk factor

Risk factor:

```text
j = SOFR 1Y
```

For SOFR 1Y, the clean practical return definition is an **absolute rate change in bps**:

```text
Return(Dt, Dt') = SOFR_1Y(Dt') - SOFR_1Y(Dt)
```

The source document allows the return calculation to be appropriate to the risk factor, such as log, relative, or absolute return. For interest-rate tenors such as SOFR 1Y, absolute bp changes are usually easiest to interpret.

### 1.2 Build the 10-business-day return vector X^j

Let the observed SOFR 1Y dates in the stress period be:

```text
D1, D2, ..., DM
```

For each start date `Dt`, find the nearest next observation date around 10 business days later. The source paper calls this `tnn(t)`, the nearest-next-to-10-days date. Then compute:

```text
X_t^j = sqrt(10 / (D_tnn(t) - Dt)) * Return(Dt, D_tnn(t))
```

If you have daily observations, this simplifies to:

```text
X_t^j = SOFR_1Y(Dt+10bd) - SOFR_1Y(Dt)
```

So the result is a vector:

```text
X^j = {X_1^j, X_2^j, ..., X_N^j}
```

where `N = |X^j|` is the number of 10-business-day returns. In our examples, this N is the key method selector.

---

## 2. Method selector

| Case | Return count | Method | Reason |
|---|---:|---|---|
| Case A | N >= 200 | Historical ES | Enough tail observations to estimate 2.5% ES directly. |
| Case B | 200 > N >= 12 | Asymmetrical sigma | Not enough observations for robust historical ES, but enough to estimate half-sample mean and sigma. |
| Case C | N < 12 | Fallback | Too few observations to robustly estimate ES or sigma from the RF's own sample. |

Source-document interpretation:

- Historical method applies when `N >= 200`.
- Asymmetrical sigma applies when `N >= 12` but below 200.
- Below 12 returns, the document says there is insufficient data to robustly approximate ES, so fallback is needed.

---

## 3. Case A - Historical ES method for SOFR 1Y when N >= 200

### 3.1 Example setup

Assume:

```text
Risk factor = SOFR 1Y
N = 210 ten-business-day returns
Alpha = 2.5% = 0.025
SOFR liquidity horizon = 20 days
```

Because:

```text
N = 210 >= 200
```

we use the **historical method**.

### 3.2 What is alphaN?

`alphaN` is the amount of the sample included in the 2.5% tail:

```text
alphaN = alpha * N
alphaN = 0.025 * 210 = 5.25
```

Meaning: use the worst 5 full observations plus 25% of the 6th observation.

### 3.3 Downward ES shock

Sort returns from most negative to most positive:

```text
X_(1) <= X_(2) <= ... <= X_(N)
```

Then the left-tail ES estimator is:

```text
ES_down(X^j, alpha) = -1/(alphaN) * [sum of first floor(alphaN) observations + fractional part * next observation]
```

For `N=210`, this becomes:

```text
ES_down = -1/5.25 * [X_(1)+X_(2)+X_(3)+X_(4)+X_(5)+0.25*X_(6)]
```

The negative sign converts the left-tail negative move into a positive shock magnitude.

### 3.4 Upward ES shock

The right-tail ES is equivalent to applying the left-tail formula to `-X^j`:

```text
ES_up(X^j, alpha) = ES_down(-X^j, alpha)
```

Practically, this means sort the positive returns from largest to smaller and take:

```text
ES_up = 1/5.25 * [top 5 positive returns + 0.25 * 6th positive return]
```

### 3.5 What is UCF?

`UCF` means **uncertainty compensation factor**. It increases the calibrated shock when the number of effective observations is smaller. It compensates for estimation uncertainty in the shock calibration.

For the historical method:

```text
N_eff = N
```

The simplified formula used in the paper is:

```text
UCF(N_eff) = 0.95 + 1 / sqrt(N_eff - 1.5)
```

So for `N=210`:

```text
UCF(210) = 0.95 + 1 / sqrt(208.5)
         = 1.0193 approximately
```

### 3.6 What are CS_down and CS_up?

`CS_down` and `CS_up` are the **calibrated shocks** for the NMRF. They are the final up/down shock magnitudes after applying UCF.

```text
CS_down(j) = ES_down(X^j, alpha) * UCF(N)
CS_up(j)   = ES_up(X^j, alpha)   * UCF(N)
```

For SOFR 1Y, the final stress range is:

```text
[-CS_down, +CS_up]
```

Example using illustrative numbers:

| Item | Example value |
|---|---:|
| Raw ES_down | 31.70 bps |
| Raw ES_up | 44.10 bps |
| UCF(210) | 1.0193 |
| CS_down | 32.31 bps |
| CS_up | 44.95 bps |
| Shock range | [-32.31 bps, +44.95 bps] |

### 3.7 SES step after calibrated shocks

Build the four-point shock grid:

```text
- CS_down
- 0.8 * CS_down
+ 0.8 * CS_up
+ CS_up
```

Run full revaluation at each point:

```text
loss(x) = Base NPV - Shocked NPV(x)
```

The extreme scenario of future shock, `FS`, is the shock in the grid that produces the maximum loss.

Then, if FS is a boundary point, run one additional revaluation at:

```text
1.2 * FS
```

Calculate second difference:

```text
Second difference = l(0.8FS) - 2*l(FS) + l(1.2FS)
```

Because `N >= 200`, phi is estimated from the historical tail of the return distribution.

Then:

```text
K_tilde = 1 + (25/2) * [Second difference / l(FS)] * (phi - 1)
K       = max(0.9, min(K_tilde, 5))
SS(10d) = K * l(FS)
```

For SOFR 1Y, liquidity horizon is assumed to be 20 days:

```text
LH_floored = max(20, LH) = 20
SS(LH) = SS(10d) * sqrt(LH_floored / 10)
       = SS(10d) * sqrt(20/10)
       = SS(10d) * 1.4142
```

---

## 4. Case B - Asymmetrical sigma method for SOFR 1Y when 200 > N >= 12

### 4.1 Example setup

Assume:

```text
Risk factor = SOFR 1Y
N = 100 ten-business-day returns
Alpha = 2.5%
SOFR liquidity horizon = 20 days
```

Because:

```text
200 > N = 100 >= 12
```

we do **not** use historical ES. Instead, we use the **asymmetrical sigma method**.

### 4.2 Why we do not use historical ES

If `N=100`, then:

```text
alphaN = 0.025 * 100 = 2.5
```

That gives only 2 full observations plus 50% of the 3rd observation in the tail. The document considers that too small for robust historical ES. Instead of forcing tail ES from very few observations, the method estimates tail severity using median-split mean and sigma.

### 4.3 Split the return sample by median

Compute the median of all SOFR 1Y 10-day returns:

```text
median(X^j)
```

Then split:

```text
X_down = {X^j <= median(X^j)}
X_up   = {X^j >  median(X^j)}
```

For `N=100`:

```text
N_down = 50
N_up   = 50
```

### 4.4 Calculate half-sample mean and sigma

For the down half:

```text
Mean_down = average(X_down)
Sigma_down = standard deviation estimate of X_down
```

For the up half:

```text
Mean_up = average(X_up)
Sigma_up = standard deviation estimate of X_up
```

The paper uses an asymmetrical approach because return distributions may be skewed: the downside tail and upside tail do not have to behave the same way.

### 4.5 Calculate AS_down and AS_up

The paper sets the asymmetrical sigma constant to 3.

Simplified implementation:

```text
AS_down = -Mean_down + 3 * Sigma_down
AS_up   =  Mean_up   + 3 * Sigma_up
```

The minus sign on `Mean_down` converts a negative mean in the down half into a positive shock magnitude.

### 4.6 Apply UCF using half-sample effective counts

For asigma, the effective sample size is the half-sample count:

```text
N_eff_down = N_down
N_eff_up   = N_up
```

Then:

```text
UCF(N_eff) = 0.95 + 1 / sqrt(N_eff - 1.5)
```

For `N_down = N_up = 50`:

```text
UCF(50) = 0.95 + 1 / sqrt(48.5)
        = 1.0936 approximately
```

Then:

```text
CS_down = AS_down * UCF(N_down)
CS_up   = AS_up   * UCF(N_up)
```

### 4.7 SES step after asigma shocks

After `CS_down` and `CS_up` are calibrated, the SES process is the same as the historical case:

```text
Shock grid = {-CS_down, -0.8CS_down, +0.8CS_up, +CS_up}
FS = shock with maximum loss
```

For `N < 200`, phi is not historically estimated. In the simplified illustration, use the paper's asigma simplification:

```text
phi = 1.04
```

Then calculate:

```text
Second difference = l(0.8FS) - 2*l(FS) + l(1.2FS)
K_tilde = 1 + (25/2) * [Second difference / l(FS)] * (phi - 1)
K       = max(0.9, min(K_tilde, 5))
SS(10d) = K * l(FS)
SS(LH)  = SS(10d) * sqrt(20/10)
```

---

## 5. Case C - Fallback method for SOFR 1Y when N < 12

### 5.1 Example setup

Assume either:

```text
N = 5
```

or:

```text
N = 0
```

Because:

```text
N < 12
```

there is not enough data to robustly estimate ES or sigma from the SOFR 1Y sample.

### 5.2 What changes vs historical and asigma?

For `N < 12`, do **not** calculate:

```text
Historical ES_down / ES_up
Asigma AS_down / AS_up
UCF from the RF's own sample
```

The source document states that below 12 returns there are insufficient data to robustly approximate ES. It indicates that fallback is outside the main shock-estimation formulas and only sketched.

### 5.3 Practical fallback implementation for SOFR 1Y

A controlled implementation should select shocks through a governed fallback hierarchy. For example:

1. Use a similar modellable or better-observed SOFR tenor, such as SOFR 2Y or SOFR 6M, with documented mapping.
2. Use a broader USD OIS / interest-rate fallback table.
3. Use a conservative supervisory or internal standardized shock if no similar RF is appropriate.

This is an implementation illustration. The key governance point is that fallback shocks are **not estimated from 5 or 0 observations**. They are externally assigned through a governed proxy or fallback table.

Example fallback shocks:

| Scenario | Fallback CS_down | Fallback CS_up | Source of shock |
|---|---:|---:|---|
| N = 5 | 50 bps | 60 bps | Similar RF / governed fallback table |
| N = 0 | 60 bps | 70 bps | More conservative fallback table |

### 5.4 SES step after fallback shocks

Once fallback shocks are selected, the SES loss-profile process is the same:

```text
Shock grid = {-CS_down, -0.8CS_down, +0.8CS_up, +CS_up}
FS = shock with maximum loss
Second difference = l(0.8FS) - 2*l(FS) + l(1.2FS)
K_tilde = 1 + (25/2) * [Second difference / l(FS)] * (phi - 1)
K       = max(0.9, min(K_tilde, 5))
SS(10d) = K * l(FS)
SS(LH)  = SS(10d) * sqrt(20/10)
```

For fallback, phi should also be governed. A conservative implementation may use the asigma-style simplification or a fallback-table phi, depending on policy.

---

## 6. Side-by-side summary

| Topic | Historical method | Asymmetrical sigma method | Fallback method |
|---|---|---|---|
| Return count | N >= 200 | 200 > N >= 12 | N < 12 |
| Example | N = 210 | N = 100 | N = 5 or N = 0 |
| Uses X^j sample directly? | Yes, tail observations | Yes, median-split mean and sigma | No, not enough data |
| Tail method | Historical 2.5% ES | Approximate ES with half-sample mean and sigma | Governed proxy / fallback shock |
| alphaN used? | Yes | Not for shock calibration | No |
| UCF effective N | N | N_down and N_up | Not from own sample |
| CS_down | ES_down * UCF(N) | AS_down * UCF(N_down) | Assigned fallback down shock |
| CS_up | ES_up * UCF(N) | AS_up * UCF(N_up) | Assigned fallback up shock |
| Phi | Estimated historically | Simplified / prescribed estimate | Governed fallback assumption |
| SES loss-profile step | Same after shocks | Same after shocks | Same after shocks |
| SOFR LH | 20 days | 20 days | 20 days |

---

## 7. Implementation controls for Vasara / RFET / SES engine

For each SOFR 1Y SES run, store these fields:

| Field | Meaning |
|---|---|
| Risk factor ID | SOFR 1Y |
| Return type | Absolute bp change |
| Stress period | One-year stress period used to build X^j |
| N | Number of 10-business-day returns |
| Method flag | Historical / Asigma / Fallback |
| alpha | 2.5% |
| alphaN | Used only for historical ES |
| Median | Used only for asigma |
| N_down / N_up | Used only for asigma |
| UCF | Uncertainty compensation factor |
| CS_down / CS_up | Calibrated or fallback shock magnitudes |
| FS | Extreme scenario of future shock |
| l(FS) | Loss at FS |
| Second difference | Local curvature proxy around FS |
| phi | Tail curvature/dispersion parameter |
| K_tilde / K | Non-linearity adjustment before and after floor/cap |
| SS(10d) | 10-day stress scenario measure |
| LH_floored | max(LH, 20) |
| SS(LH) | Final single-NMRF stress scenario measure |

---

## 8. Key message for methodology document

For SOFR 1Y, the methodology is driven by the number of available 10-business-day returns:

- If we have **at least 200 returns**, we trust the historical 2.5% tail ES estimate.
- If we have **between 12 and 199 returns**, we do not trust the historical tail because the tail is too thin, so we use asymmetrical sigma.
- If we have **fewer than 12 returns**, we do not estimate shocks from SOFR 1Y's own sample. We use a governed fallback shock source.

After shocks are calibrated or assigned, the SES calculation becomes the same: build the four-point shock grid, find the extreme scenario of future shock, calculate loss and non-linearity correction, then scale from 10 days to the SOFR liquidity horizon of 20 days.

---

## Source notes

Primary source: EBA staff paper, **A universal stress scenario approach for capitalising non-modellable risk factors under the FRTB**.

Source-derived points used in this note:

- 10-business-day returns are built using nearest-next-to-10-day observations and rescaled to 10 business days where needed.
- Historical method applies when at least 200 returns are available.
- Historical left and right ES estimators use the 2.5% tail and account for fractional alphaN.
- Asymmetrical sigma method is used when historical ES is not robust but at least 12 returns exist.
- The uncertainty compensation factor is `UCF(N_eff) = 0.95 + 1 / sqrt(N_eff - 1.5)`.
- Below 12 returns, there is insufficient data to robustly approximate ES; fallback is required.
- After shocks are identified, the loss-profile / FS / K / liquidity-horizon scaling steps are applied.
