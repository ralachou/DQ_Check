# DQ Health Control Tower (MVP)

Production-minded MVP for risk-factor time-series data quality control across large financial universes.

## What It Includes
- Layered architecture: data access, universe control plane, checks library, config mapping, orchestrator, and false-alarm triage.
- Config-driven model catalog in `configs/model_catalog.yaml`.
- Unified score normalization framework in `src/normalization/normalizer.py`.
- Dash UI with summary, hierarchy drilldown, and model comparison in `src/ui/app.py`.
- Synthetic data generator + demo run pipeline.

## Project Layout
```text
configs/
  model_catalog.yaml
src/
  common/
  data_access/
  universe/
  dq_checks/
  normalization/
  triage/
  engine/
  data/
  pipeline/
  ui/
tests/
```

## Quick Start
1. Install:
```bash
pip install -e .[dev]
```
Or via requirements file:
```bash
pip install -r requirements.txt
```

2. Generate synthetic data + run DQ pipeline:
```bash
dq-demo --start-date 2019-01-01 --end-date 2024-12-31 --num-factors 400
```

3. Launch UI:
```bash
dq-ui --results-path data/processed/dq_results --raw-path data/raw/timeseries_raw --membership-path data/processed/universe_membership
```

## Optional Backends
- PyOD, ADTK, Merlion are optional.
- The engine degrades gracefully when unavailable and logs warnings.

Install examples:
```bash
pip install -e .[pyod]
pip install -e .[adtk]
pip install -e .[merlion]
```

## Auditing and Determinism
- Raw and derived outputs are stored separately.
- Normalization artifacts are versioned under `data/artifacts/normalization/check_id=...`.
- Config hash and run metadata are persisted with results.
