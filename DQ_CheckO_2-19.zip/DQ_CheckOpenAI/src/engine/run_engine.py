from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Any

import pandas as pd

from common.schemas import config_hash, load_yaml
from data_access.base import TimeSeriesRepository
from dq_checks.feature_builder import FeatureBuilder
from dq_checks.registry import ModelRegistry, ModelSpec
from normalization.normalizer import normalize_results
from triage.false_alarm import FalseAlarmReducer
from universe.builder import UniverseBuilder
from universe.definitions import UniverseDefinition


@dataclass
class RunRequest:
    run_id: str
    universe_name: str
    start_date: str
    end_date: str
    config_path: str = "configs/model_catalog.yaml"
    incremental: bool = True


class RunEngine:
    def __init__(self, repository: TimeSeriesRepository, artifact_root: str = "data/artifacts/normalization") -> None:
        self.repository = repository
        self.registry = ModelRegistry()
        self.feature_builder = FeatureBuilder()
        self.artifact_root = artifact_root

    def _build_universe(self, catalog: dict[str, Any], universe_name: str) -> pd.DataFrame:
        universe_cfg = catalog.get("universes", {}).get(universe_name)
        if not universe_cfg:
            raise ValueError(f"Universe '{universe_name}' not found in catalog.")
        definition = UniverseDefinition(
            name=universe_name,
            description=str(universe_cfg.get("description", "")),
            filter_rules=universe_cfg.get("filters", {}),
        )
        return UniverseBuilder(self.repository).build(definition)

    def _check_profiles(self, specs: list[ModelSpec], catalog: dict[str, Any]) -> dict[str, dict[str, Any]]:
        profiles = catalog.get("normalization", {}).get("profiles", {})
        defaults = catalog.get("normalization", {}).get("defaults", {})
        global_severity = catalog.get("globals", {}).get("default_severity_thresholds", {})
        out: dict[str, dict[str, Any]] = {}
        for spec in specs:
            profile_cfg = profiles.get(spec.normalization_profile, {})
            strategy = profile_cfg.get("strategy", defaults.get("strategy", "ecdf"))
            out[spec.id] = {
                "normalization_strategy": strategy,
                "normalization_params": profile_cfg,
                "backend": spec.backend,
                "severity_mode": "fixed",
                "severity_thresholds": global_severity.get("quantile", {}),
                "fixed_thresholds": global_severity.get("fixed", {}),
                "model_version": spec.version_tag,
            }
        return out

    def _execute_per_series(self, check, data: pd.DataFrame, check_id: str, backend: str, family: str) -> pd.DataFrame:
        parts = []
        for rf_id, series_df in data.groupby("risk_factor_id", sort=False):
            sdf = series_df.sort_values("date").reset_index(drop=True)
            context = {"risk_factor_id": rf_id}
            state = check.fit(sdf, context)
            scored = check.score(sdf, context, state)
            scored["check_id"] = check_id
            scored["backend"] = backend
            scored["family"] = family
            parts.append(scored)
        return pd.concat(parts, ignore_index=True) if parts else pd.DataFrame()

    def _execute_per_peer_group(
        self,
        check,
        data: pd.DataFrame,
        membership: pd.DataFrame,
        check_id: str,
        backend: str,
        family: str,
    ) -> pd.DataFrame:
        m = membership[["risk_factor_id", "rf_level1", "rf_level2", "rf_level3", "rf_level4", "rf_level5"]]
        merged = data.merge(m, on="risk_factor_id", how="left")
        parts = []
        group_keys = ["rf_level1", "rf_level2", "rf_level3", "rf_level4", "rf_level5"]
        for _, grp in merged.groupby(group_keys, dropna=False, sort=False):
            if grp["risk_factor_id"].nunique() < 3:
                for rf_id, sdf in grp.groupby("risk_factor_id", sort=False):
                    feat = self.feature_builder.build_features(sdf)
                    state = check.fit(feat, {"risk_factor_id": rf_id})
                    scored = check.score(feat, {"risk_factor_id": rf_id}, state)
                    scored["check_id"] = check_id
                    scored["backend"] = backend
                    scored["family"] = family
                    parts.append(scored)
                continue
            feat_grp = self.feature_builder.build_batch(grp[["risk_factor_id", "date", "value"]], max_workers=4)
            state = check.fit(feat_grp, {"peer_group": True})
            scored = check.score(feat_grp, {"peer_group": True}, state)
            scored["check_id"] = check_id
            scored["backend"] = backend
            scored["family"] = family
            parts.append(scored)
        return pd.concat(parts, ignore_index=True) if parts else pd.DataFrame()

    def _execute_global(self, check, data: pd.DataFrame, check_id: str, backend: str, family: str) -> pd.DataFrame:
        feat = self.feature_builder.build_batch(data[["risk_factor_id", "date", "value"]], max_workers=4)
        state = check.fit(feat, {"global": True})
        scored = check.score(feat, {"global": True}, state)
        scored["check_id"] = check_id
        scored["backend"] = backend
        scored["family"] = family
        return scored

    def run(self, request: RunRequest) -> dict[str, Any]:
        t0 = time.perf_counter()
        catalog = load_yaml(request.config_path)
        cfg_hash = config_hash(catalog)

        start_ts = pd.to_datetime(request.start_date)
        end_ts = pd.to_datetime(request.end_date)
        if request.incremental:
            prior = self.repository.get_series(None, request.start_date, request.end_date)
            if not prior.empty:
                start_ts = min(start_ts, pd.to_datetime(prior["date"]).min())

        t_universe = time.perf_counter()
        membership = self._build_universe(catalog, request.universe_name)
        if membership.empty:
            raise ValueError(f"No risk factors found for universe '{request.universe_name}'.")
        risk_factor_ids = membership["risk_factor_id"].astype(str).tolist()
        self.repository.write_results(membership, "universe_membership", partition_cols=["universe_name"])
        t_universe = time.perf_counter() - t_universe

        t_load = time.perf_counter()
        series = self.repository.get_series(risk_factor_ids, start_ts, end_ts)
        if series.empty:
            raise ValueError("No time-series data returned for selected universe/date range.")
        t_load = time.perf_counter() - t_load

        t_checks = time.perf_counter()
        specs = [s for s in self.registry.load_universe_specs(catalog, request.universe_name) if s.enabled]
        checks = {}
        for spec in specs:
            checks[spec.id] = self.registry.build_from_spec(spec, checks)
        raw_parts = []
        for spec in specs:
            check = checks[spec.id]
            if spec.fit_policy == "global":
                out = self._execute_global(check, series, spec.id, spec.backend, spec.family)
            elif spec.fit_policy == "per_peer_group":
                out = self._execute_per_peer_group(check, series, membership, spec.id, spec.backend, spec.family)
            else:
                out = self._execute_per_series(check, series, spec.id, spec.backend, spec.family)
            out["run_id"] = request.run_id
            out["universe_name"] = request.universe_name
            raw_parts.append(out)
        raw_results = pd.concat(raw_parts, ignore_index=True) if raw_parts else pd.DataFrame()
        t_checks = time.perf_counter() - t_checks

        t_norm = time.perf_counter()
        profiles = self._check_profiles(specs, catalog)
        normalized = normalize_results(
            results_df=raw_results,
            check_profiles=profiles,
            run_id=request.run_id,
            config_hash=cfg_hash,
            artifact_root=self.artifact_root,
        )
        t_norm = time.perf_counter() - t_norm

        t_triage = time.perf_counter()
        triager = FalseAlarmReducer(
            regime_windows=catalog.get("globals", {}).get("regime_windows", []),
            peer_keys=["rf_level1", "rf_level2", "rf_level3", "rf_level4", "rf_level5"],
        )
        membership_cols = ["risk_factor_id", "rf_level1", "rf_level2", "rf_level3", "rf_level4", "rf_level5"]
        triaged, triage_audit = triager.run(
            alerts_df=normalized.merge(membership[membership_cols], on="risk_factor_id", how="left"),
            raw_df=series,
            membership=membership[membership_cols],
            with_supervised=False,
        )
        t_triage = time.perf_counter() - t_triage

        result_cols = [
            "run_id",
            "universe_name",
            "risk_factor_id",
            "date",
            "check_id",
            "backend",
            "family",
            "raw_score",
            "norm_score",
            "threshold",
            "flag",
            "severity",
            "reason_code",
            "explain",
            "artifacts_json",
            "peer_confirmed",
            "peer_confidence",
            "regime_tag",
            "confidence_estimate",
            "recommended_action",
            "triage_artifacts_json",
        ]
        triaged = triaged.reindex(columns=result_cols)
        triaged = triaged.sort_values(["risk_factor_id", "date", "check_id"]).reset_index(drop=True)

        self.repository.write_results(
            triaged,
            table_name="dq_results",
            partition_cols=["run_id", "universe_name", "check_id"],
        )

        audit_log = pd.DataFrame(
            [
                {
                    "run_id": request.run_id,
                    "universe_name": request.universe_name,
                    "start_date": str(start_ts.date()),
                    "end_date": str(end_ts.date()),
                    "config_hash": cfg_hash,
                    "row_count_series": int(len(series)),
                    "row_count_results": int(len(triaged)),
                    "stage_universe_sec": t_universe,
                    "stage_load_sec": t_load,
                    "stage_checks_sec": t_checks,
                    "stage_normalization_sec": t_norm,
                    "stage_triage_sec": t_triage,
                    "elapsed_sec": time.perf_counter() - t0,
                    "triage_audit": str(triage_audit),
                }
            ]
        )
        self.repository.write_results(audit_log, "audit_log", partition_cols=["run_id", "universe_name"])
        return {"results": triaged, "audit_log": audit_log}

