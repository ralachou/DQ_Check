# Advanced DQ Checks on RF (MVP)

Production-minded MVP for risk-factor time-series data quality control across large financial universes.

## What It Includes
- Layered architecture: data access, universe control plane, checks library, config mapping, orchestrator, and false-alarm triage.
- Config-driven model catalog in `configs/model_catalog.yaml`.
- Unified score normalization framework in `src/normalization/normalizer.py`.
- Dash UI with summary, hierarchy drilldown, and model comparison in `src/ui/app.py`.
- Synthetic data generator + demo run pipeline.

## Project Layout
```text
configs/
  model_catalog.yaml
src/
  common/
  data_access/
  universe/
  dq_checks/
  normalization/
  triage/
  engine/
  data/
  pipeline/
  ui/
tests/
```

## Quick Start
1. Install:
```bash
pip install -e .[dev]
```
Or via requirements file:
```bash
pip install -r requirements.txt
```

2. Generate synthetic data + run DQ pipeline (business-date snapshot driven):
```bash
dq-demo --start-date 2019-01-01 --end-date 2024-12-31 --business-date 2024-12-31 --num-factors 400
```

3. Run data-layer-only demo (with optional Excel preview files):
```bash
dq-demo-data-layer --business-date 2024-12-31 --output-format parquet
```
Excel option:
```bash
dq-demo-data-layer --business-date 2024-12-31 --output-format excel
```
Notebook walkthrough:
- `tests/data_layer_demo.ipynb`

4. Run Layer 2 universe control-plane demo:
```bash
dq-demo-layer2-universe --universe-name CP_RATE_CORP --business-date 2024-12-31 --output-format parquet
```
Notebook walkthrough:
- `tests/layer2_universe_demo.ipynb`

5. Run Layer 3 DQ checks demo:
```bash
dq-demo-layer3-dqchecks --universe-name CP_RATE_CORP --business-date 2024-12-31 --max-series 20 --output-format parquet
```
Notebook walkthrough:
- `tests/layer3_dqChecks_demo.ipynb`

6. Run Layer 4 configuration mapping demo:
```bash
dq-demo-layer4-config --universe-name CP_RATE_CORP --business-date 2024-12-31 --output-format parquet
```
Notebook walkthrough:
- `tests/layer4_config_demo.ipynb`

7. Run Layer 5 Run Engine orchestration demo:
```bash
dq-demo-layer5-runengine --universe-name CP_RATE_CORP --business-date 2024-12-31 --output-format parquet
```
Notebook walkthrough:
- `tests/layer5_runEngine_demo.ipynb`

8. Run Layer 6 false-alarm reduction demo:
```bash
dq-demo-layer6-false-alarm --universe-name CP_RATE_CORP --business-date 2024-12-31 --output-format parquet
```
Notebook walkthrough:
- `tests/layer6_false_alarm_demo.ipynb`

9. Run Layer 7 Dash UI debug walkthrough:
```bash
dq-demo-layer7-dash-ui --print-data-summary --print-layout-tree --print-callbacks --validate-callback-ids
```
Debug a specific callback:
```bash
dq-ui-debug --run-callback refresh_summary --sample-args
```
Debug the new UI version callbacks:
```bash
dq-ui-debug --app-version v2 --run-callback refresh_summary --sample-args
```
Notebook walkthrough:
- `tests/layer7_dash_ui_debug_demo.ipynb`

10. Launch UI (v1):
```bash
dq-ui --results-path data/processed/dq_results --raw-path data/raw/timeseries_raw --membership-path data/processed/universe_membership
```

Launch UI (v2, 4 tabs with peer explorer and enhanced war-room views):
```bash
dq-ui-v2 --results-path data/processed/dq_results --raw-path data/raw/timeseries_raw --membership-path data/processed/universe_membership --port 8060
```
Generate full hierarchy demo data from `data/raw/risk_factors/risk_factor_hierarchy_20k.xlsx`, run DQ for all asset classes, and prepare app_v2 datasets:
```bash
dq-demo-ui-full --start-date 2025-01-01 --end-date 2025-12-31 --business-date 2025-12-31
```
Fast smoke run option:
```bash
dq-demo-ui-full --max-factors 2000 --start-date 2025-07-01 --end-date 2025-12-31 --business-date 2025-12-31
```
Per-asset controlled run (e.g., 100 factors for each asset class, business date January 31, 2026):
```bash
dq-demo-ui-full --max-factors-per-asset-class 100 --start-date 2025-01-01 --end-date 2026-01-31 --business-date 2026-01-31
```

11. Clean data folders and start fresh:
```bash
dq-clean --yes
```
Optional target selection:
```bash
dq-clean --targets raw processed --yes
```

## Optional Backends
- PyOD, ADTK, Merlion are optional.
- The engine degrades gracefully when unavailable and logs warnings.

Install examples:
```bash
pip install -e .[pyod]
pip install -e .[adtk]
pip install -e .[merlion]
```

## Auditing and Determinism
- Raw and derived outputs are stored separately.
- Raw snapshots and processed outputs are partitioned by `business_date=YYYY-MM-DD`.
- Normalization artifacts are versioned under `data/artifacts/normalization/business_date=.../check_id=...`.
- Config hash and run metadata are persisted with results.
