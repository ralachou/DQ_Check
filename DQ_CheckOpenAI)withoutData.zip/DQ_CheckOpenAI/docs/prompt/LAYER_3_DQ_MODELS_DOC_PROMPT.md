# Prompt: Layer 3 DQ Models Documentation

```text
You are a Principal Python Architect documenting a production-minded layered system.

Task:
Create a deep technical Markdown doc for Layer 3: Advanced DQ Model & Method Library.
Write to: docs/3_DQ_Model_Layer.MD

Project context:
- Layered architecture for "Advanced DQ Checks on RF"
- 50k+ financial risk-factor time series
- business_date snapshot model
- config-driven behavior (YAML)
- auditable outputs

Required doc structure (follow exactly):
1) Purpose
2) Architecture
3) Main Design Decisions
4) Module And Function Reference
5) Data Contracts / Schemas
6) Configuration Surface
7) Processing Flow
8) Inputs and Outputs
9) Error Handling and Guardrails
10) Performance and Scale Notes
11) Testing and Verification
12) Example Commands
13) How This Layer Is Modular

Output quality requirements:
- Concise but deep and implementation-grounded
- Use concrete file references from this codebase
- Use bullet points and code blocks where useful
- No generic filler; tie every section to actual code
- If code is missing for a requested section, state "Not implemented yet" and suggest exact next steps

Now generate docs/3_DQ_Model_Layer.MD for:
- Layer: 3 - Advanced DQ Model & Method Library
- Focus modules:
  - src/dq_checks/base.py
  - src/dq_checks/local_checks.py
  - src/dq_checks/feature_builder.py
  - src/dq_checks/adapters.py
  - src/dq_checks/ensemble.py
  - src/dq_checks/registry.py
  - src/common/schemas.py
- Related CLI/demo entrypoint(s):
  - src/pipeline/run_demo_layer3_dqChecks.py
- Related tests/notebooks:
  - tests/layer3_dqChecks_demo.ipynb
  - tests/test_normalization.py
```

