# Ideal Prompt Template: Layer Documentation

```text
You are a Principal Python Architect documenting a production-minded layered system.

Task:
Create a deep technical Markdown doc for Layer <LAYER_NUMBER>: <LAYER_NAME>.
Write to: docs/<TARGET_FILE>.md

Project context:
- Layered architecture for “Advanced DQ Checks on RF”
- 50k+ financial risk-factor time series
- business_date snapshot model
- config-driven behavior (YAML)
- auditable outputs

Required doc structure (follow exactly):

1) Purpose
- What this layer does
- What it does NOT do
- How it is used independently

2) Architecture
- List all relevant modules/files for this layer
- Explain each module’s role
- Add logical flow (step-by-step)

3) Main Design Decisions
- Key design principles
- Tradeoffs and why chosen

4) Module And Function Reference
For each module:
- Main classes/functions
- Signatures (short form)
- Inputs, outputs, side effects
- Important utilities/helpers

5) Data Contracts / Schemas
- Required columns/fields
- Types and constraints
- Validation rules
- Error behavior

6) Configuration Surface
- YAML/CLI/env inputs used by this layer
- Defaults
- Override behavior
- Example config snippets

7) Processing Flow
- End-to-end sequence from input to output
- Include minimal code snippets for key calls

8) Inputs and Outputs
- What raw inputs are consumed
- What transformed outputs are produced
- Exact storage paths and partition strategy
- Example folder tree

9) Error Handling and Guardrails
- Common failure modes
- Retries/fallbacks
- Determinism/auditability guarantees

10) Performance and Scale Notes
- Complexity hotspots
- Caching/parallelism behaviors
- Expected scaling patterns

11) Testing and Verification
- Existing tests for this layer
- Suggested missing tests
- Commands to validate layer in isolation

12) Example Commands
- 3–6 practical CLI examples
- One quick smoke test

13) How This Layer Is Modular
- How upper/lower layers interact via contracts only
- What can be reused independently

Output quality requirements:
- Concise but deep and implementation-grounded
- Use concrete file references from this codebase
- Use bullet points and code blocks where useful
- No generic filler; tie every section to actual code
- If code is missing for a requested section, state “Not implemented yet” and suggest exact next steps

Now generate docs/<TARGET_FILE>.md for:
- Layer: <LAYER_NUMBER> - <LAYER_NAME>
- Focus modules: <LIST_MODULE_PATHS>
- Related CLI/demo entrypoint(s): <ENTRYPOINTS>
- Related tests/notebooks: <TEST_FILES>
```

