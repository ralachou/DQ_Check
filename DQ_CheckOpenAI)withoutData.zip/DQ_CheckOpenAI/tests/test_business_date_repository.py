from __future__ import annotations

import pandas as pd

from data_access.parquet_repository import ParquetTimeSeriesRepository


def test_parquet_repository_filters_by_business_date(tmp_path) -> None:
    repo = ParquetTimeSeriesRepository(base_path=tmp_path, write_base_path=tmp_path)
    df = pd.DataFrame(
        {
            "business_date": pd.to_datetime(["2024-01-09", "2024-01-09", "2024-01-10", "2024-01-10"]),
            "risk_factor_id": ["RF_1", "RF_1", "RF_1", "RF_1"],
            "date": pd.to_datetime(["2024-01-05", "2024-01-08", "2024-01-05", "2024-01-08"]),
            "value": [100.0, 101.0, 99.5, 100.2],
        }
    )
    repo.write_results(df, table_name="timeseries_raw", partition_cols=["business_date"])

    out = repo.get_series(
        risk_factor_ids=["RF_1"],
        start_date="2024-01-01",
        end_date="2024-01-31",
        business_date="2024-01-10",
    )
    assert not out.empty
    assert out["business_date"].nunique() == 1
    assert out["business_date"].iloc[0] == pd.Timestamp("2024-01-10")
    assert out["date"].tolist() == [pd.Timestamp("2024-01-05"), pd.Timestamp("2024-01-08")]


def test_parquet_repository_writes_readable_business_date_partitions(tmp_path) -> None:
    repo = ParquetTimeSeriesRepository(base_path=tmp_path, write_base_path=tmp_path)
    df = pd.DataFrame(
        {
            "business_date": pd.to_datetime(["2024-01-10"]),
            "risk_factor_id": ["RF_1"],
            "date": pd.to_datetime(["2024-01-08"]),
            "value": [100.2],
        }
    )
    repo.write_results(df, table_name="timeseries_raw", partition_cols=["business_date"])
    expected_file = tmp_path / "timeseries_raw" / "business_date=2024-01-10" / "timeseries_raw.parquet"
    assert expected_file.exists()
