"""Common schemas and utility helpers."""

