from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class UniverseDefinition:
    name: str
    description: str
    filter_rules: dict[str, Any] = field(default_factory=dict)
    include_ids: list[str] = field(default_factory=list)
    exclude_ids: list[str] = field(default_factory=list)

