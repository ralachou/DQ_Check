from __future__ import annotations

from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

ASSET_CLASS_TEMPLATES: dict[str, list[tuple[str, str, str, str]]] = {
    "EQ_PRICE": [("USD", "SPX", "SPOT", "NA"), ("USD", "AMZN", "SPOT", "NA"), ("USD", "AAPL", "SPOT", "NA")],
    "EQ_VOL": [("USD", "SPX", "ATM", "M01"), ("USD", "SPX", "ATM", "M03")],
    "IR_RATE": [("USD", "Treasury", "ForwardRate", "M01"), ("USD", "Treasury", "ForwardRate", "Y05")],
    "IR_VOL": [("USD", "Swaption", "ATM", "Y01"), ("USD", "Swaption", "ATM", "Y05")],
    "FX_RATE": [("USD", "EUR", "SPOT", "NA"), ("USD", "JPY", "SPOT", "NA")],
    "FX_VOL": [("USD", "EURUSD", "ATM", "M01"), ("USD", "USDJPY", "ATM", "M01")],
    "COMM_PRICE": [("USD", "GOLD", "FUTURE", "M01"), ("USD", "SILVER", "FUTURE", "M01")],
    "COMM_VOL": [("USD", "GOLD", "ATM", "M01"), ("USD", "WTI", "ATM", "M01")],
    "CP_RATE": [("USD", "CORP", "BBB", "Y05"), ("USD", "CDX", "IG", "Y05"), ("USD", "RMBS", "TBA", "Coupon4.5")],
    "CP_VOL": [("USD", "CDX", "VOL", "Y05"), ("USD", "CORP", "VOL", "Y05")],
}


def _sample_rf_rows(num_factors: int, seed: int = 42) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    rows: list[dict[str, Any]] = []
    classes = list(ASSET_CLASS_TEMPLATES.keys())
    for i in range(num_factors):
        ac = classes[i % len(classes)]
        cur, prod, subtype, quote = ASSET_CLASS_TEMPLATES[ac][rng.integers(0, len(ASSET_CLASS_TEMPLATES[ac]))]
        rf_id = f"RF_{ac}_{i:06d}"
        rows.append(
            {
                "risk_factor_id": rf_id,
                "rf_level1": ac,
                "rf_level2": cur,
                "rf_level3": prod,
                "rf_level4": subtype,
                "rf_level5": quote,
                "tenor_bucket": quote if quote != "NA" else "SPOT",
                "vendor": rng.choice(["VENDOR_A", "VENDOR_B", "VENDOR_C"], p=[0.6, 0.3, 0.1]),
                "rating": rng.choice(["AAA", "AA", "A", "BBB", "BB"], p=[0.1, 0.2, 0.25, 0.25, 0.2]),
            }
        )
    return pd.DataFrame(rows)


def _regime_vol(date: pd.Timestamp) -> float:
    if pd.Timestamp("2008-09-01") <= date <= pd.Timestamp("2009-06-30"):
        return 3.5
    if pd.Timestamp("2020-02-15") <= date <= pd.Timestamp("2020-06-30"):
        return 2.8
    return 1.0


def _inject_anomalies(values: np.ndarray, rng: np.random.Generator) -> np.ndarray:
    out = values.copy()
    n = len(out)
    if n < 40:
        return out
    # Spikes
    for _ in range(max(1, n // 500)):
        idx = int(rng.integers(20, n - 1))
        out[idx] += rng.normal(0.0, np.std(out) * 8.0)
    # Stale patches
    for _ in range(max(1, n // 900)):
        start = int(rng.integers(10, n - 10))
        length = int(rng.integers(3, 7))
        out[start : start + length] = out[start]
    return out


def generate_synthetic_market_data(
    start_date: str = "2019-01-01",
    end_date: str = "2024-12-31",
    num_factors: int = 500,
    seed: int = 42,
    snapshot_days: int = 1,
    business_dates: list[str] | None = None,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    rng = np.random.default_rng(seed)
    risk_factors = _sample_rf_rows(num_factors=num_factors, seed=seed)
    dates = pd.bdate_range(start_date, end_date)
    if business_dates:
        snapshot_dates = sorted(pd.to_datetime(pd.Series(business_dates)).dt.normalize().unique())
    else:
        n = max(1, int(snapshot_days))
        snapshot_dates = list(pd.DatetimeIndex(dates[-n:]).normalize())
    ts_parts = []
    for _, row in risk_factors.iterrows():
        base = 100.0 + rng.normal(0, 10)
        drift = rng.normal(0.0, 0.02)
        vol = rng.uniform(0.6, 2.0)
        shocks = []
        for d in dates:
            shocks.append(rng.normal(drift, vol * _regime_vol(d)))
        path = base + np.cumsum(np.array(shocks))
        path = _inject_anomalies(path, rng=rng)
        base_df = pd.DataFrame(
            {
                "risk_factor_id": row["risk_factor_id"],
                "date": dates,
                "value": path,
            }
        )
        # Introduce random missing close dates in the base history.
        base_keep = rng.random(len(base_df)) > 0.005
        base_df = base_df.loc[base_keep].reset_index(drop=True)
        for biz_date in snapshot_dates:
            snap = base_df[base_df["date"] <= biz_date].copy()
            if snap.empty:
                continue
            # Simulate occasional historical revisions from one business date to another.
            rev_mask = rng.random(len(snap)) < 0.002
            if rev_mask.any():
                snap.loc[rev_mask, "value"] += rng.normal(0.0, max(float(np.nanstd(snap["value"])), 1.0) * 0.15, rev_mask.sum())
            drop_mask = rng.random(len(snap)) < 0.001
            snap = snap.loc[~drop_mask].copy()
            snap["business_date"] = pd.Timestamp(biz_date).normalize()
            ts_parts.append(snap)
    timeseries = pd.concat(ts_parts, ignore_index=True)
    timeseries["business_date"] = pd.to_datetime(timeseries["business_date"]).dt.normalize()
    timeseries["date"] = pd.to_datetime(timeseries["date"])
    return risk_factors, timeseries.sort_values(["business_date", "risk_factor_id", "date"]).reset_index(drop=True)


def write_demo_datasets(
    raw_path: str | Path = "data/raw",
    processed_path: str | Path = "data/processed",
    start_date: str = "2019-01-01",
    end_date: str = "2024-12-31",
    num_factors: int = 500,
    seed: int = 42,
    snapshot_days: int = 1,
    business_dates: list[str] | None = None,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    raw_root = Path(raw_path)
    proc_root = Path(processed_path)
    raw_root.mkdir(parents=True, exist_ok=True)
    proc_root.mkdir(parents=True, exist_ok=True)
    risk_factors, timeseries = generate_synthetic_market_data(
        start_date=start_date,
        end_date=end_date,
        num_factors=num_factors,
        seed=seed,
        snapshot_days=snapshot_days,
        business_dates=business_dates,
    )
    (raw_root / "risk_factors").mkdir(parents=True, exist_ok=True)
    risk_factors.to_parquet(raw_root / "risk_factors" / "part-000.parquet", index=False)
    timeseries_root = raw_root / "timeseries_raw"
    timeseries_root.mkdir(parents=True, exist_ok=True)
    for biz_date, part in timeseries.groupby("business_date", sort=True):
        biz_path = timeseries_root / f"business_date={pd.Timestamp(biz_date).date()}"
        biz_path.mkdir(parents=True, exist_ok=True)
        out_file = biz_path / "timeseries_raw.parquet"
        if out_file.exists():
            idx = 1
            while (biz_path / f"timeseries_raw_{idx}.parquet").exists():
                idx += 1
            out_file = biz_path / f"timeseries_raw_{idx}.parquet"
        part.drop(columns=["business_date"]).to_parquet(out_file, index=False)
    return risk_factors, timeseries


def _normalize_risk_factor_hierarchy(
    hierarchy_df: pd.DataFrame,
    max_factors: int | None = None,
    max_factors_per_asset_class: int | None = None,
    seed: int = 42,
) -> pd.DataFrame:
    if hierarchy_df.empty:
        return pd.DataFrame(
            columns=[
                "risk_factor_id",
                "rf_level1",
                "rf_level2",
                "rf_level3",
                "rf_level4",
                "rf_level5",
                "tenor_bucket",
                "vendor",
                "rating",
            ]
        )

    lower_map = {str(c).strip().lower(): c for c in hierarchy_df.columns}

    def _pick(*candidates: str) -> str | None:
        for name in candidates:
            if name in hierarchy_df.columns:
                return name
            hit = lower_map.get(name.lower())
            if hit is not None:
                return hit
        return None

    id_col = _pick("risk_factor_id", "driverName", "driver_name")
    l1_col = _pick("rf_level1", "assetClass", "asset_class")
    l2_col = _pick("rf_level2", "ccy")
    l3_col = _pick("rf_level3")
    l4_col = _pick("rf_level4")
    l5_col = _pick("rf_level5")
    vendor_col = _pick("vendor")
    rating_col = _pick("rating")
    tenor_col = _pick("tenor_bucket")

    if id_col is None or l1_col is None:
        raise ValueError("Hierarchy file must include risk-factor id and rf_level1/assetClass columns.")

    out = pd.DataFrame()
    out["risk_factor_id"] = hierarchy_df[id_col].astype(str).str.strip()
    out["rf_level1"] = hierarchy_df[l1_col].astype(str).str.strip()
    out["rf_level2"] = hierarchy_df[l2_col].astype(str).str.strip() if l2_col else "USD"
    out["rf_level3"] = hierarchy_df[l3_col].astype(str).str.strip() if l3_col else "NA"
    out["rf_level4"] = hierarchy_df[l4_col].astype(str).str.strip() if l4_col else "NA"
    out["rf_level5"] = hierarchy_df[l5_col].astype(str).str.strip() if l5_col else "NA"

    for c in ["rf_level1", "rf_level2", "rf_level3", "rf_level4", "rf_level5"]:
        out[c] = (
            out[c]
            .replace({"": "NA", "nan": "NA", "NaN": "NA", "None": "NA", "<NA>": "NA"})
            .fillna("NA")
            .astype(str)
        )

    if tenor_col:
        out["tenor_bucket"] = hierarchy_df[tenor_col].astype(str).str.strip()
    else:
        out["tenor_bucket"] = np.where(
            out["rf_level5"] != "NA",
            out["rf_level5"],
            np.where(out["rf_level4"] != "NA", out["rf_level4"], "SPOT"),
        )
    out["tenor_bucket"] = out["tenor_bucket"].replace({"": "SPOT", "nan": "SPOT", "NaN": "SPOT"}).fillna("SPOT")

    rng = np.random.default_rng(seed)
    if vendor_col:
        out["vendor"] = hierarchy_df[vendor_col].astype(str).str.strip()
    else:
        out["vendor"] = rng.choice(["VENDOR_A", "VENDOR_B", "VENDOR_C"], size=len(out), p=[0.6, 0.3, 0.1])
    if rating_col:
        out["rating"] = hierarchy_df[rating_col].astype(str).str.strip()
    else:
        out["rating"] = rng.choice(["AAA", "AA", "A", "BBB", "BB"], size=len(out), p=[0.1, 0.2, 0.25, 0.25, 0.2])

    out = out[out["risk_factor_id"].astype(str).str.len() > 0].drop_duplicates(subset=["risk_factor_id"]).reset_index(drop=True)
    if max_factors_per_asset_class is not None and max_factors_per_asset_class > 0:
        parts: list[pd.DataFrame] = []
        for _, grp in out.groupby("rf_level1", sort=True):
            if len(grp) > max_factors_per_asset_class:
                parts.append(grp.sample(n=max_factors_per_asset_class, random_state=seed))
            else:
                parts.append(grp)
        out = pd.concat(parts, ignore_index=True).sort_values(["rf_level1", "risk_factor_id"]).reset_index(drop=True)

    if max_factors is not None and max_factors > 0 and len(out) > max_factors:
        out = out.sample(n=max_factors, random_state=seed).sort_values("risk_factor_id").reset_index(drop=True)
    return out


def load_risk_factor_hierarchy(
    hierarchy_path: str | Path,
    max_factors: int | None = None,
    max_factors_per_asset_class: int | None = None,
    seed: int = 42,
) -> pd.DataFrame:
    path = Path(hierarchy_path)
    if not path.exists():
        raise FileNotFoundError(f"Hierarchy file not found: {path}")
    if path.suffix.lower() in {".xlsx", ".xls"}:
        raw = pd.read_excel(path)
    elif path.suffix.lower() == ".parquet":
        raw = pd.read_parquet(path)
    elif path.suffix.lower() == ".csv":
        raw = pd.read_csv(path)
    else:
        raise ValueError(f"Unsupported hierarchy file extension: {path.suffix}")
    return _normalize_risk_factor_hierarchy(
        raw,
        max_factors=max_factors,
        max_factors_per_asset_class=max_factors_per_asset_class,
        seed=seed,
    )


def generate_synthetic_market_data_for_risk_factors(
    risk_factors: pd.DataFrame,
    start_date: str = "2019-01-01",
    end_date: str = "2024-12-31",
    seed: int = 42,
    snapshot_days: int = 1,
    business_dates: list[str] | None = None,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    if risk_factors.empty:
        return risk_factors.copy(), pd.DataFrame(columns=["risk_factor_id", "date", "value", "business_date"])

    rng = np.random.default_rng(seed)
    factors = risk_factors.copy().reset_index(drop=True)
    dates = pd.bdate_range(start_date, end_date)
    if business_dates:
        snapshot_dates = sorted(pd.to_datetime(pd.Series(business_dates)).dt.normalize().unique())
    else:
        n = max(1, int(snapshot_days))
        snapshot_dates = list(pd.DatetimeIndex(dates[-n:]).normalize())

    vol_by_asset = {
        "EQ_PRICE": (0.6, 1.8),
        "EQ_VOL": (0.3, 1.0),
        "IR_RATE": (0.2, 0.9),
        "IR_VOL": (0.2, 0.8),
        "FX_RATE": (0.3, 1.2),
        "FX_VOL": (0.2, 0.8),
        "COMM_PRICE": (0.4, 1.6),
        "COMM_VOL": (0.2, 0.9),
        "CP_RATE": (0.3, 1.2),
        "CP_VOL": (0.2, 0.9),
    }

    ts_parts: list[pd.DataFrame] = []
    for _, row in factors.iterrows():
        rf_id = str(row["risk_factor_id"])
        asset = str(row.get("rf_level1", "EQ_PRICE"))
        lo, hi = vol_by_asset.get(asset, (0.3, 1.3))
        base = 100.0 + rng.normal(0, 10)
        drift = rng.normal(0.0, 0.015)
        vol = rng.uniform(lo, hi)
        shocks = np.array([rng.normal(drift, vol * _regime_vol(d)) for d in dates], dtype=float)
        path = base + np.cumsum(shocks)
        if asset.endswith("VOL"):
            path = np.abs(path)
        path = _inject_anomalies(path, rng=rng)
        base_df = pd.DataFrame({"risk_factor_id": rf_id, "date": dates, "value": path})
        base_keep = rng.random(len(base_df)) > 0.004
        base_df = base_df.loc[base_keep].reset_index(drop=True)
        for biz_date in snapshot_dates:
            snap = base_df[base_df["date"] <= biz_date].copy()
            if snap.empty:
                continue
            rev_mask = rng.random(len(snap)) < 0.0015
            if rev_mask.any():
                snap.loc[rev_mask, "value"] += rng.normal(0.0, max(float(np.nanstd(snap["value"])), 1.0) * 0.12, rev_mask.sum())
            drop_mask = rng.random(len(snap)) < 0.0008
            snap = snap.loc[~drop_mask].copy()
            snap["business_date"] = pd.Timestamp(biz_date).normalize()
            ts_parts.append(snap)

    timeseries = pd.concat(ts_parts, ignore_index=True)
    timeseries["business_date"] = pd.to_datetime(timeseries["business_date"]).dt.normalize()
    timeseries["date"] = pd.to_datetime(timeseries["date"])
    return factors, timeseries.sort_values(["business_date", "risk_factor_id", "date"]).reset_index(drop=True)


def write_demo_datasets_from_hierarchy(
    hierarchy_path: str | Path,
    raw_path: str | Path = "data/raw",
    processed_path: str | Path = "data/processed",
    start_date: str = "2019-01-01",
    end_date: str = "2024-12-31",
    seed: int = 42,
    snapshot_days: int = 1,
    business_dates: list[str] | None = None,
    max_factors: int | None = None,
    max_factors_per_asset_class: int | None = None,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    raw_root = Path(raw_path)
    proc_root = Path(processed_path)
    raw_root.mkdir(parents=True, exist_ok=True)
    proc_root.mkdir(parents=True, exist_ok=True)

    risk_factors = load_risk_factor_hierarchy(
        hierarchy_path,
        max_factors=max_factors,
        max_factors_per_asset_class=max_factors_per_asset_class,
        seed=seed,
    )
    risk_factors, timeseries = generate_synthetic_market_data_for_risk_factors(
        risk_factors=risk_factors,
        start_date=start_date,
        end_date=end_date,
        seed=seed,
        snapshot_days=snapshot_days,
        business_dates=business_dates,
    )

    rf_root = raw_root / "risk_factors"
    rf_root.mkdir(parents=True, exist_ok=True)
    risk_factors.to_parquet(rf_root / "part-000.parquet", index=False)

    timeseries_root = raw_root / "timeseries_raw"
    timeseries_root.mkdir(parents=True, exist_ok=True)
    for biz_date, part in timeseries.groupby("business_date", sort=True):
        biz_path = timeseries_root / f"business_date={pd.Timestamp(biz_date).date()}"
        biz_path.mkdir(parents=True, exist_ok=True)
        out_file = biz_path / "timeseries_raw.parquet"
        if out_file.exists():
            idx = 1
            while (biz_path / f"timeseries_raw_{idx}.parquet").exists():
                idx += 1
            out_file = biz_path / f"timeseries_raw_{idx}.parquet"
        part.drop(columns=["business_date"]).to_parquet(out_file, index=False)

    return risk_factors, timeseries
