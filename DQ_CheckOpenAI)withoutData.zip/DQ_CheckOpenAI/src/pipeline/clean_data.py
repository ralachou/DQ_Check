from __future__ import annotations

import argparse
import os
import shutil
import stat
import time
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[2]
ALL_TARGETS = ("raw", "processed", "artifacts")


def _on_rm_error(func, path, exc_info) -> None:  # type: ignore[no-untyped-def]
    del exc_info
    try:
        os.chmod(path, stat.S_IWRITE)
    except OSError:
        pass
    func(path)


def _remove_entry(child: Path, retries: int = 3, retry_delay_sec: float = 0.35) -> tuple[bool, str | None]:
    for attempt in range(1, retries + 1):
        try:
            if child.is_dir():
                shutil.rmtree(child, onerror=_on_rm_error)
            else:
                try:
                    os.chmod(child, stat.S_IWRITE)
                except OSError:
                    pass
                child.unlink(missing_ok=True)
            return True, None
        except (PermissionError, OSError) as exc:
            if attempt < retries:
                time.sleep(retry_delay_sec)
                continue
            return False, f"{child}: {exc}"
    return False, f"{child}: unknown removal error"


def _clean_directory(path: Path) -> int:
    removed = 0
    path.mkdir(parents=True, exist_ok=True)
    for child in path.iterdir():
        ok, err = _remove_entry(child)
        if ok:
            removed += 1
        else:
            print(f"Warning: could not remove {err}")
    return removed


def clean_data_roots(
    raw_path: str | Path,
    processed_path: str | Path,
    artifacts_path: str | Path,
    targets: list[str],
) -> dict[str, int]:
    target_set = set(targets)
    if "all" in target_set:
        target_set = set(ALL_TARGETS)
    unknown = sorted(target_set - set(ALL_TARGETS))
    if unknown:
        raise ValueError(f"Unsupported targets: {unknown}")

    paths = {
        "raw": Path(raw_path),
        "processed": Path(processed_path),
        "artifacts": Path(artifacts_path),
    }
    out: dict[str, int] = {}
    for name in ALL_TARGETS:
        if name not in target_set:
            continue
        out[name] = _clean_directory(paths[name])
    return out


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Clean DQ data directories (raw, processed, artifacts).")
    parser.add_argument("--raw-path", default=str(PROJECT_ROOT / "data" / "raw"))
    parser.add_argument("--processed-path", default=str(PROJECT_ROOT / "data" / "processed"))
    parser.add_argument("--artifacts-path", default=str(PROJECT_ROOT / "data" / "artifacts"))
    parser.add_argument(
        "--targets",
        nargs="+",
        default=["all"],
        choices=["all", "raw", "processed", "artifacts"],
        help="Which data roots to clean.",
    )
    parser.add_argument(
        "--yes",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="Confirm cleanup (default: true for IDE runs). Use --no-yes to abort.",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    if not args.yes:
        print("Cleanup aborted. Re-run with --yes to confirm.")
        return

    summary = clean_data_roots(
        raw_path=args.raw_path,
        processed_path=args.processed_path,
        artifacts_path=args.artifacts_path,
        targets=args.targets,
    )
    for name in ALL_TARGETS:
        if name in summary:
            print(f"Cleaned {name}: removed {summary[name]} entries")


if __name__ == "__main__":
    main()
