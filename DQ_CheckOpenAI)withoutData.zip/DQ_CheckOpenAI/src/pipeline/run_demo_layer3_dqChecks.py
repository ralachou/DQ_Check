from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

import pandas as pd

from common.schemas import load_yaml
from data.synthetic import write_demo_datasets
from data_access.parquet_repository import ParquetTimeSeriesRepository
from dq_checks.feature_builder import FeatureBuilder
from dq_checks.registry import ModelRegistry, ModelSpec
from universe.builder import UniverseBuilder
from universe.definitions import UniverseDefinition

PROJECT_ROOT = Path(__file__).resolve().parents[2]


def _parse_csv(raw: str | None) -> list[str]:
    if not raw:
        return []
    return [x.strip() for x in raw.split(",") if x.strip()]


def _write_demo_output(df: pd.DataFrame, output_root: Path, name: str, output_format: str) -> list[str]:
    output_root.mkdir(parents=True, exist_ok=True)
    out: list[str] = []
    if output_format in {"parquet", "both"}:
        p = output_root / f"{name}.parquet"
        df.to_parquet(p, index=False)
        out.append(str(p))
    if output_format in {"excel", "both"}:
        p = output_root / f"{name}.xlsx"
        try:
            df.to_excel(p, index=False)
        except ImportError as exc:  # pragma: no cover
            raise RuntimeError("Excel output requires openpyxl. Install with: pip install openpyxl") from exc
        out.append(str(p))
    return out


def _execute_per_series(check, data: pd.DataFrame, spec: ModelSpec) -> pd.DataFrame:
    parts = []
    for rf_id, series_df in data.groupby("risk_factor_id", sort=False):
        sdf = series_df.sort_values("date").reset_index(drop=True)
        state = check.fit(sdf, {"risk_factor_id": rf_id})
        scored = check.score(sdf, {"risk_factor_id": rf_id}, state)
        scored["check_id"] = spec.id
        scored["backend"] = spec.backend
        scored["family"] = spec.family
        scored["fit_policy"] = spec.fit_policy
        parts.append(scored)
    return pd.concat(parts, ignore_index=True) if parts else pd.DataFrame()


def _execute_per_peer_group(check, data: pd.DataFrame, membership: pd.DataFrame, spec: ModelSpec, fb: FeatureBuilder) -> pd.DataFrame:
    m = membership[["risk_factor_id", "rf_level1", "rf_level2", "rf_level3", "rf_level4", "rf_level5"]]
    merged = data.merge(m, on="risk_factor_id", how="left")
    group_keys = ["rf_level1", "rf_level2", "rf_level3", "rf_level4", "rf_level5"]
    parts = []
    for _, grp in merged.groupby(group_keys, dropna=False, sort=False):
        if grp["risk_factor_id"].nunique() < 3:
            for rf_id, sdf in grp.groupby("risk_factor_id", sort=False):
                feat = fb.build_features(sdf[["risk_factor_id", "date", "value"]].copy())
                state = check.fit(feat, {"risk_factor_id": rf_id})
                scored = check.score(feat, {"risk_factor_id": rf_id}, state)
                scored["check_id"] = spec.id
                scored["backend"] = spec.backend
                scored["family"] = spec.family
                scored["fit_policy"] = spec.fit_policy
                parts.append(scored)
            continue
        feat_grp = fb.build_batch(grp[["risk_factor_id", "date", "value"]], max_workers=4)
        state = check.fit(feat_grp, {"peer_group": True})
        scored = check.score(feat_grp, {"peer_group": True}, state)
        scored["check_id"] = spec.id
        scored["backend"] = spec.backend
        scored["family"] = spec.family
        scored["fit_policy"] = spec.fit_policy
        parts.append(scored)
    return pd.concat(parts, ignore_index=True) if parts else pd.DataFrame()


def _execute_global(check, data: pd.DataFrame, spec: ModelSpec, fb: FeatureBuilder) -> pd.DataFrame:
    feat = fb.build_batch(data[["risk_factor_id", "date", "value"]], max_workers=4)
    state = check.fit(feat, {"global": True})
    scored = check.score(feat, {"global": True}, state)
    scored["check_id"] = spec.id
    scored["backend"] = spec.backend
    scored["family"] = spec.family
    scored["fit_policy"] = spec.fit_policy
    return scored


def _build_universe_definition(catalog: dict[str, Any], universe_name: str) -> UniverseDefinition:
    uni = catalog.get("universes", {}).get(universe_name)
    if not uni:
        raise ValueError(f"Universe '{universe_name}' not found in catalog.")
    return UniverseDefinition(
        name=universe_name,
        description=str(uni.get("description", "")),
        filter_rules=uni.get("filters", {}),
    )


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run Advanced DQ Checks on RF Layer 3 DQ-checks demo.")
    parser.add_argument("--universe-name", default="CP_RATE_CORP")
    parser.add_argument("--config-path", default=str(PROJECT_ROOT / "configs" / "model_catalog.yaml"))
    parser.add_argument("--start-date", default="2024-01-01")
    parser.add_argument("--end-date", default="2024-12-31")
    parser.add_argument("--business-date", default="2024-12-31")
    parser.add_argument("--raw-path", default=str(PROJECT_ROOT / "data" / "raw"))
    parser.add_argument("--processed-path", default=str(PROJECT_ROOT / "data" / "processed"))
    parser.add_argument("--num-factors", type=int, default=300)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--snapshot-days", type=int, default=2)
    parser.add_argument("--max-series", type=int, default=25, help="Limit number of risk factors for demo runtime.")
    parser.add_argument("--check-ids", default="", help="Comma-separated check IDs to run. Empty = all enabled checks.")
    parser.add_argument("--max-checks", type=int, default=0, help="If >0, run only first N checks after filtering.")
    parser.add_argument(
        "--output-format",
        default="both",
        choices=["parquet", "excel", "both"],
        help="Demo artifact output format.",
    )
    parser.add_argument(
        "--generate-demo-data",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="Generate synthetic data before running Layer 3 demo.",
    )
    return parser.parse_args()


def run_demo_layer3_dqchecks(args: argparse.Namespace) -> dict[str, Any]:
    raw_path = Path(args.raw_path)
    processed_path = Path(args.processed_path)
    business_date = str(pd.to_datetime(args.business_date).date())

    if args.generate_demo_data:
        write_demo_datasets(
            raw_path=raw_path,
            processed_path=processed_path,
            start_date=args.start_date,
            end_date=args.end_date,
            num_factors=args.num_factors,
            seed=args.seed,
            snapshot_days=args.snapshot_days,
        )

    catalog = load_yaml(args.config_path)
    repo = ParquetTimeSeriesRepository(base_path=raw_path, write_base_path=processed_path)

    definition = _build_universe_definition(catalog, args.universe_name)
    membership = UniverseBuilder(repo).build(definition)
    if membership.empty:
        raise ValueError(f"No membership found for universe '{args.universe_name}'.")

    if args.max_series > 0:
        membership = membership.head(args.max_series).copy()
    risk_factor_ids = membership["risk_factor_id"].astype(str).tolist()

    series = repo.get_series(
        risk_factor_ids=risk_factor_ids,
        start_date=args.start_date,
        end_date=args.end_date,
        business_date=business_date,
    )
    if series.empty:
        raise ValueError("No time-series rows loaded for selected universe/date/business_date.")

    registry = ModelRegistry()
    specs = [s for s in registry.load_universe_specs(catalog, args.universe_name) if s.enabled]

    check_filter = set(_parse_csv(args.check_ids))
    if check_filter:
        specs = [s for s in specs if s.id in check_filter]
    if args.max_checks > 0:
        specs = specs[: args.max_checks]
    if not specs:
        raise ValueError("No checks selected to run for Layer 3 demo.")

    checks: dict[str, Any] = {}
    for spec in specs:
        checks[spec.id] = registry.build_from_spec(spec, checks)

    fb = FeatureBuilder()
    run_parts = []
    for spec in specs:
        check = checks[spec.id]
        if spec.fit_policy == "global":
            out = _execute_global(check, series, spec, fb)
        elif spec.fit_policy == "per_peer_group":
            out = _execute_per_peer_group(check, series, membership, spec, fb)
        else:
            out = _execute_per_series(check, series, spec)
        out["business_date"] = pd.to_datetime(business_date)
        out["universe_name"] = args.universe_name
        run_parts.append(out)

    results = pd.concat(run_parts, ignore_index=True) if run_parts else pd.DataFrame()
    if results.empty:
        raise ValueError("No results produced by selected checks.")

    summary_by_check = (
        results.groupby(["check_id", "backend", "family", "fit_policy"], as_index=False)
        .agg(
            rows=("date", "count"),
            alerts=("flag", "sum"),
            max_raw_score=("raw_score", "max"),
        )
        .sort_values(["alerts", "max_raw_score"], ascending=[False, False])
    )

    flags_preview = (
        results[results["flag"]]
        .sort_values(["check_id", "raw_score"], ascending=[True, False])
        .head(500)
        .reset_index(drop=True)
    )
    if flags_preview.empty:
        flags_preview = results.head(200).copy()

    output_root = (
        processed_path
        / "layer3_dq_checks_demo"
        / f"business_date={business_date}"
        / f"universe_name={args.universe_name}"
    )
    saved_files = {
        "membership": _write_demo_output(membership, output_root, "membership_input", args.output_format),
        "series_preview": _write_demo_output(series.head(2000), output_root, "series_input_preview", args.output_format),
        "results_preview": _write_demo_output(results.head(5000), output_root, "dq_results_preview", args.output_format),
        "summary_by_check": _write_demo_output(summary_by_check, output_root, "summary_by_check", args.output_format),
        "flags_preview": _write_demo_output(flags_preview, output_root, "flags_preview", args.output_format),
    }

    manifest = {
        "layer": "Layer 3 - Advanced DQ Model & Method Library",
        "universe_name": args.universe_name,
        "config_path": str(Path(args.config_path).resolve()),
        "business_date": business_date,
        "inputs": {
            "start_date": args.start_date,
            "end_date": args.end_date,
            "risk_factor_count": int(membership["risk_factor_id"].nunique()),
            "timeseries_rows": int(len(series)),
        },
        "checks_selected": [
            {
                "id": s.id,
                "backend": s.backend,
                "model_name": s.model_name,
                "family": s.family,
                "fit_policy": s.fit_policy,
                "params": s.params,
            }
            for s in specs
        ],
        "processing": {
            "fit_policy_paths": ["per_series", "per_peer_group", "global"],
            "feature_builder_used_for": ["per_peer_group", "global", "fallback per_series for feature-based checks"],
        },
        "outputs": {
            "output_root": str(output_root),
            "saved_files": saved_files,
            "result_rows": int(len(results)),
            "result_alerts": int(results["flag"].sum()) if "flag" in results.columns else 0,
        },
    }
    manifest_path = output_root / "manifest.json"
    manifest_path.write_text(json.dumps(manifest, indent=2), encoding="utf-8")

    print("=== Layer 3 DQ Checks Demo Summary ===")
    print(f"Universe: {args.universe_name}")
    print(f"Business date: {business_date}")
    print(f"Checks executed: {len(specs)}")
    print(f"Risk factors used: {membership['risk_factor_id'].nunique():,}")
    print(f"Series rows loaded: {len(series):,}")
    print(f"DQ output rows: {len(results):,}")
    print(f"DQ alerts: {int(results['flag'].sum()) if 'flag' in results.columns else 0:,}")
    print(f"Output root: {output_root}")
    print(f"Manifest: {manifest_path}")

    return manifest


def main() -> None:
    args = parse_args()
    run_demo_layer3_dqchecks(args)


if __name__ == "__main__":
    main()
