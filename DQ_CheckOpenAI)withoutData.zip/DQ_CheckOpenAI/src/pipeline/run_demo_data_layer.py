from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

import pandas as pd

from common.schemas import TIMESERIES_COLUMNS, ensure_timeseries_schema
from data.synthetic import write_demo_datasets
from data_access.parquet_repository import ParquetTimeSeriesRepository

PROJECT_ROOT = Path(__file__).resolve().parents[2]


def _write_demo_output(df: pd.DataFrame, output_root: Path, name: str, output_format: str) -> list[str]:
    output_root.mkdir(parents=True, exist_ok=True)
    paths: list[str] = []
    if output_format in {"parquet", "both"}:
        parquet_path = output_root / f"{name}.parquet"
        df.to_parquet(parquet_path, index=False)
        paths.append(str(parquet_path))
    if output_format in {"excel", "both"}:
        excel_path = output_root / f"{name}.xlsx"
        try:
            df.to_excel(excel_path, index=False)
        except ImportError as exc:  # pragma: no cover - optional runtime dependency
            raise RuntimeError(
                "Excel export requires 'openpyxl'. Install it with: pip install openpyxl"
            ) from exc
        paths.append(str(excel_path))
    return paths


def _transform_timeseries(raw_series: pd.DataFrame, risk_factors: pd.DataFrame) -> pd.DataFrame:
    ts = ensure_timeseries_schema(raw_series)
    ts = ts.drop_duplicates(subset=["business_date", "risk_factor_id", "date"]).sort_values(
        ["business_date", "risk_factor_id", "date"]
    )
    ts["prev_value"] = ts.groupby(["business_date", "risk_factor_id"])["value"].shift(1)
    ts["abs_change"] = (ts["value"] - ts["prev_value"]).abs()
    ts["pct_change_1d"] = ts.groupby(["business_date", "risk_factor_id"])["value"].pct_change()
    ts["is_stale"] = ts["value"].eq(ts["prev_value"])
    ts["is_missing_value"] = ts["value"].isna()

    enrich_cols = [
        "risk_factor_id",
        "rf_level1",
        "rf_level2",
        "rf_level3",
        "rf_level4",
        "rf_level5",
        "vendor",
    ]
    enrich = risk_factors[[c for c in enrich_cols if c in risk_factors.columns]].drop_duplicates(subset=["risk_factor_id"])
    out = ts.merge(enrich, on="risk_factor_id", how="left")
    return out.reset_index(drop=True)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run Advanced DQ Checks on RF data-layer demo.")
    parser.add_argument("--start-date", default="2019-01-01")
    parser.add_argument("--end-date", default="2024-12-31")
    parser.add_argument("--business-date", default="2024-12-31")
    parser.add_argument("--num-factors", type=int, default=200)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--snapshot-days", type=int, default=2)
    parser.add_argument("--raw-path", default=str(PROJECT_ROOT / "data" / "raw"))
    parser.add_argument("--processed-path", default=str(PROJECT_ROOT / "data" / "processed"))
    parser.add_argument(
        "--output-format",
        default="both",
        choices=["parquet", "excel", "both"],
        help="Demo artifact output format.",
    )
    return parser.parse_args()


def run_demo_data_layer(args: argparse.Namespace) -> dict[str, Any]:
    raw_path = Path(args.raw_path)
    processed_path = Path(args.processed_path)
    business_date = str(pd.to_datetime(args.business_date).date())

    write_demo_datasets(
        raw_path=raw_path,
        processed_path=processed_path,
        start_date=args.start_date,
        end_date=args.end_date,
        num_factors=args.num_factors,
        seed=args.seed,
        snapshot_days=args.snapshot_days,
    )

    repo = ParquetTimeSeriesRepository(base_path=raw_path, write_base_path=processed_path)
    risk_factors = repo.list_risk_factors({})
    raw_series = repo.get_series(
        risk_factor_ids=None,
        start_date=args.start_date,
        end_date=args.end_date,
        business_date=business_date,
    )
    transformed = _transform_timeseries(raw_series=raw_series, risk_factors=risk_factors)

    demo_out_root = processed_path / "data_layer_demo" / f"business_date={business_date}"
    raw_preview = raw_series.head(500).copy()
    transformed_preview = transformed.head(1000).copy()
    rf_preview = risk_factors.head(1000).copy()

    saved_paths = {
        "risk_factors_preview": _write_demo_output(rf_preview, demo_out_root, "risk_factors_preview", args.output_format),
        "raw_series_preview": _write_demo_output(raw_preview, demo_out_root, "raw_series_preview", args.output_format),
        "transformed_preview": _write_demo_output(transformed_preview, demo_out_root, "transformed_preview", args.output_format),
    }

    manifest = {
        "layer": "Layer 1 - Data Access",
        "expected_timeseries_schema": list(TIMESERIES_COLUMNS),
        "raw_data_loaded": {
            "risk_factors_rows": int(len(risk_factors)),
            "timeseries_rows": int(len(raw_series)),
            "business_date": business_date,
            "source_paths": {
                "risk_factors": str(raw_path / "risk_factors"),
                "timeseries_raw": str(raw_path / "timeseries_raw"),
            },
        },
        "transformations_applied": [
            "Schema validation via ensure_timeseries_schema()",
            "Drop duplicates by (business_date, risk_factor_id, date)",
            "Sort by (business_date, risk_factor_id, date)",
            "Compute prev_value, abs_change, pct_change_1d",
            "Tag is_stale and is_missing_value",
            "Join hierarchy columns from risk_factors",
        ],
        "storage": {
            "demo_output_root": str(demo_out_root),
            "saved_files": saved_paths,
            "output_format": args.output_format,
        },
        "loading_pattern": {
            "metadata": "repo.list_risk_factors(filters)",
            "series": "repo.get_series(risk_factor_ids, start_date, end_date, business_date)",
        },
    }
    manifest_path = demo_out_root / "manifest.json"
    manifest_path.write_text(json.dumps(manifest, indent=2), encoding="utf-8")

    print("=== Data Layer Demo Summary ===")
    print(f"Business date loaded: {business_date}")
    print(f"Risk factors loaded: {len(risk_factors):,}")
    print(f"Raw time-series rows loaded: {len(raw_series):,}")
    print("Expected timeseries schema:", list(TIMESERIES_COLUMNS))
    print("Transformations:", ", ".join(manifest["transformations_applied"]))
    print(f"Stored outputs at: {demo_out_root}")
    print(f"Manifest: {manifest_path}")

    return manifest


def main() -> None:
    args = parse_args()
    run_demo_data_layer(args)


if __name__ == "__main__":
    main()
