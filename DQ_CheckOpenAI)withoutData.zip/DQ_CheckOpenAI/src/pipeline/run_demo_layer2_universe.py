from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

import pandas as pd

from common.schemas import load_yaml
from data.synthetic import write_demo_datasets
from data_access.parquet_repository import ParquetTimeSeriesRepository
from universe.builder import UniverseBuilder
from universe.definitions import UniverseDefinition

PROJECT_ROOT = Path(__file__).resolve().parents[2]


def _parse_ids(raw: str | None) -> list[str]:
    if not raw:
        return []
    return [x.strip() for x in raw.split(",") if x.strip()]


def _write_demo_output(df: pd.DataFrame, output_root: Path, name: str, output_format: str) -> list[str]:
    output_root.mkdir(parents=True, exist_ok=True)
    paths: list[str] = []
    if output_format in {"parquet", "both"}:
        p = output_root / f"{name}.parquet"
        df.to_parquet(p, index=False)
        paths.append(str(p))
    if output_format in {"excel", "both"}:
        p = output_root / f"{name}.xlsx"
        try:
            df.to_excel(p, index=False)
        except ImportError as exc:  # pragma: no cover - optional runtime dependency
            raise RuntimeError("Excel output requires openpyxl. Install with: pip install openpyxl") from exc
        paths.append(str(p))
    return paths


def _build_definition(catalog: dict[str, Any], universe_name: str, include_ids: list[str], exclude_ids: list[str]) -> UniverseDefinition:
    universe_cfg = catalog.get("universes", {}).get(universe_name)
    if not universe_cfg:
        raise ValueError(f"Universe '{universe_name}' not found in config.")
    return UniverseDefinition(
        name=universe_name,
        description=str(universe_cfg.get("description", "")),
        filter_rules=universe_cfg.get("filters", {}),
        include_ids=include_ids,
        exclude_ids=exclude_ids,
    )


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run Advanced DQ Checks on RF Layer 2 universe demo.")
    parser.add_argument("--universe-name", default="CP_RATE_CORP")
    parser.add_argument("--config-path", default=str(PROJECT_ROOT / "configs" / "model_catalog.yaml"))
    parser.add_argument("--start-date", default="2024-01-01")
    parser.add_argument("--end-date", default="2024-12-31")
    parser.add_argument("--business-date", default="2024-12-31")
    parser.add_argument("--include-ids", default="", help="Comma-separated risk_factor_id values to force include.")
    parser.add_argument("--exclude-ids", default="", help="Comma-separated risk_factor_id values to force exclude.")
    parser.add_argument("--raw-path", default=str(PROJECT_ROOT / "data" / "raw"))
    parser.add_argument("--processed-path", default=str(PROJECT_ROOT / "data" / "processed"))
    parser.add_argument("--num-factors", type=int, default=250)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--snapshot-days", type=int, default=2)
    parser.add_argument(
        "--output-format",
        default="both",
        choices=["parquet", "excel", "both"],
        help="Demo artifact output format.",
    )
    parser.add_argument(
        "--generate-demo-data",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="Generate synthetic raw datasets before running the universe demo.",
    )
    return parser.parse_args()


def run_demo_layer2_universe(args: argparse.Namespace) -> dict[str, Any]:
    raw_path = Path(args.raw_path)
    processed_path = Path(args.processed_path)
    business_date = str(pd.to_datetime(args.business_date).date())
    include_ids = _parse_ids(args.include_ids)
    exclude_ids = _parse_ids(args.exclude_ids)

    if args.generate_demo_data:
        write_demo_datasets(
            raw_path=raw_path,
            processed_path=processed_path,
            start_date=args.start_date,
            end_date=args.end_date,
            num_factors=args.num_factors,
            seed=args.seed,
            snapshot_days=args.snapshot_days,
        )

    catalog = load_yaml(args.config_path)
    definition = _build_definition(
        catalog=catalog,
        universe_name=args.universe_name,
        include_ids=include_ids,
        exclude_ids=exclude_ids,
    )

    repo = ParquetTimeSeriesRepository(base_path=raw_path, write_base_path=processed_path)
    builder = UniverseBuilder(repo)

    all_rf = repo.list_risk_factors({})
    filtered_rf = repo.list_risk_factors(definition.filter_rules)
    membership = builder.build(definition)
    if membership.empty:
        raise ValueError("Universe membership is empty after filters/include/exclude.")

    membership = membership.copy()
    membership["business_date"] = pd.to_datetime(business_date)

    series = repo.get_series(
        risk_factor_ids=membership["risk_factor_id"].astype(str).tolist(),
        start_date=args.start_date,
        end_date=args.end_date,
        business_date=business_date,
    )

    level_cols = [c for c in ["rf_level1", "rf_level2", "rf_level3", "rf_level4", "rf_level5"] if c in membership.columns]
    level_summary = (
        membership.groupby(level_cols, as_index=False)["risk_factor_id"]
        .nunique()
        .rename(columns={"risk_factor_id": "risk_factor_count"})
        .sort_values("risk_factor_count", ascending=False)
    )
    control_summary = pd.DataFrame(
        [
            {"metric": "all_metadata_rows", "value": int(len(all_rf))},
            {"metric": "filtered_candidate_rows", "value": int(len(filtered_rf))},
            {"metric": "membership_rows", "value": int(len(membership))},
            {"metric": "include_ids_count", "value": int(len(include_ids))},
            {"metric": "exclude_ids_count", "value": int(len(exclude_ids))},
            {"metric": "timeseries_rows_for_membership", "value": int(len(series))},
            {"metric": "business_date", "value": business_date},
        ]
    )
    control_summary["value"] = control_summary["value"].astype(str)

    output_root = processed_path / "layer2_universe_demo" / f"business_date={business_date}" / f"universe_name={args.universe_name}"
    saved_paths = {
        "control_summary": _write_demo_output(control_summary, output_root, "control_summary", args.output_format),
        "membership": _write_demo_output(membership, output_root, "universe_membership", args.output_format),
        "level_summary": _write_demo_output(level_summary, output_root, "level_summary", args.output_format),
        "timeseries_preview": _write_demo_output(series.head(2000), output_root, "timeseries_preview", args.output_format),
    }

    repo.write_results(
        membership,
        table_name="universe_membership_demo",
        partition_cols=["business_date", "universe_name"],
    )

    manifest = {
        "layer": "Layer 2 - Universe",
        "universe_name": args.universe_name,
        "config_path": str(Path(args.config_path).resolve()),
        "universe_definition": {
            "name": definition.name,
            "description": definition.description,
            "filter_rules": definition.filter_rules,
            "include_ids": include_ids,
            "exclude_ids": exclude_ids,
        },
        "layer1_dependency": {
            "repository": "ParquetTimeSeriesRepository",
            "calls": [
                "list_risk_factors({})",
                "list_risk_factors(definition.filter_rules)",
                "get_series(risk_factor_ids, start_date, end_date, business_date)",
                "write_results(universe_membership_demo, partition_cols=[business_date, universe_name])",
            ],
            "raw_source_paths": {
                "risk_factors": str(raw_path / "risk_factors"),
                "timeseries_raw": str(raw_path / "timeseries_raw"),
            },
        },
        "inputs": {
            "start_date": args.start_date,
            "end_date": args.end_date,
            "business_date": business_date,
        },
        "outputs": {
            "output_root": str(output_root),
            "saved_files": saved_paths,
            "membership_table_path": str(processed_path / "universe_membership_demo"),
        },
    }
    manifest_path = output_root / "manifest.json"
    manifest_path.write_text(json.dumps(manifest, indent=2), encoding="utf-8")

    print("=== Layer 2 Universe Demo Summary ===")
    print(f"Universe: {args.universe_name}")
    print(f"Business date: {business_date}")
    print(f"Layer 1 metadata rows: {len(all_rf):,}")
    print(f"Filtered candidates: {len(filtered_rf):,}")
    print(f"Universe membership rows: {len(membership):,}")
    print(f"Timeseries rows loaded for membership: {len(series):,}")
    print(f"Output root: {output_root}")
    print(f"Manifest: {manifest_path}")

    return manifest


def main() -> None:
    args = parse_args()
    run_demo_layer2_universe(args)


if __name__ == "__main__":
    main()
