from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

import pandas as pd
import plotly.graph_objects as go

from ui.app import PROJECT_ROOT, load_data


def _to_json_text(value: Any) -> str:
    return json.dumps(value, ensure_ascii=True, sort_keys=True)


def _layout_nodes(layout: Any, max_depth: int = 20) -> list[dict[str, Any]]:
    nodes: list[dict[str, Any]] = []

    def walk(node: Any, path: str, depth: int) -> None:
        if depth > max_depth:
            return
        if node is None:
            return
        if isinstance(node, (list, tuple)):
            for i, child in enumerate(node):
                walk(child, f"{path}/{i}", depth)
            return

        comp_type = node.__class__.__name__
        comp_id = getattr(node, "id", None)
        children = getattr(node, "children", None)
        child_count = 0
        if isinstance(children, (list, tuple)):
            child_count = len(children)
        elif children is not None:
            child_count = 1

        nodes.append(
            {
                "path": path,
                "depth": depth,
                "component_type": comp_type,
                "component_id": comp_id,
                "child_count": child_count,
            }
        )

        if isinstance(children, (list, tuple)):
            for i, child in enumerate(children):
                walk(child, f"{path}/{i}", depth + 1)
        elif children is not None:
            walk(children, f"{path}/0", depth + 1)

    walk(layout, "root", 0)
    return nodes


def _callback_rows(app) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for key, meta in app.callback_map.items():
        callback_fn = meta.get("callback")
        inputs = meta.get("inputs", [])
        state = meta.get("state", [])
        output = meta.get("output")
        outputs: list[Any] = output if isinstance(output, list) else [output]
        outputs_txt = [f"{o.component_id}.{o.component_property}" for o in outputs if o is not None]
        rows.append(
            {
                "callback_key": key,
                "callback_name": callback_fn.__name__ if callback_fn is not None else "clientside_callback",
                "server_side": bool(callback_fn is not None),
                "outputs_count": len(outputs_txt),
                "inputs_count": len(inputs),
                "state_count": len(state),
                "outputs_json": _to_json_text(outputs_txt),
                "inputs_json": _to_json_text(inputs),
                "state_json": _to_json_text(state),
            }
        )
    return rows


def _validate_callback_ids(app, layout_ids: set[str]) -> pd.DataFrame:
    issues: list[dict[str, Any]] = []
    for key, meta in app.callback_map.items():
        for io_kind in ("inputs", "state"):
            for item in meta.get(io_kind, []):
                comp_id = str(item.get("id"))
                if comp_id not in layout_ids:
                    issues.append(
                        {
                            "callback_key": key,
                            "io_kind": io_kind,
                            "component_id": comp_id,
                            "property": item.get("property"),
                            "issue": "id_not_in_layout",
                        }
                    )
        outputs = meta.get("output")
        outs = outputs if isinstance(outputs, list) else [outputs]
        for out in outs:
            if out is None:
                continue
            comp_id = str(out.component_id)
            if comp_id not in layout_ids:
                issues.append(
                    {
                        "callback_key": key,
                        "io_kind": "output",
                        "component_id": comp_id,
                        "property": out.component_property,
                        "issue": "id_not_in_layout",
                    }
                )
    return pd.DataFrame(issues)


def _build_sample_args(callback_name: str, data: dict[str, pd.DataFrame]) -> list[Any]:
    dq_results = data["dq_results"]
    membership = data["membership"]
    timeseries_raw = data["timeseries_raw"]
    asset_classes = sorted(membership.get("rf_level1", pd.Series(dtype=str)).dropna().astype(str).unique().tolist())
    universes = sorted(dq_results.get("universe_name", pd.Series(dtype=str)).dropna().astype(str).unique().tolist())
    families = sorted(dq_results.get("family", pd.Series(dtype=str)).dropna().astype(str).unique().tolist())
    severities = sorted(dq_results.get("severity", pd.Series(dtype=str)).dropna().astype(str).unique().tolist())
    checks = sorted(dq_results.get("check_id", pd.Series(dtype=str)).dropna().astype(str).unique().tolist())
    business_dates: list[str] = []
    for frame in (dq_results, membership, timeseries_raw):
        if "business_date" in frame.columns:
            business_dates.extend(pd.to_datetime(frame["business_date"], errors="coerce").dropna().dt.strftime("%Y-%m-%d").unique().tolist())
    business_dates = sorted(set(business_dates))
    business_date = business_dates[-1] if business_dates else ""

    start_date: str | None = None
    end_date: str | None = None
    if "date" in dq_results.columns and not dq_results.empty:
        start_date = str(pd.to_datetime(dq_results["date"]).min().date())
        end_date = str(pd.to_datetime(dq_results["date"]).max().date())

    if callback_name == "sync_filter_state":
        return [
            asset_classes[:1],
            universes[:1],
            families[:1],
            severities[-1:] if severities else [],
            start_date,
            end_date,
            {"selected_risk_factor_id": None},
        ]

    if callback_name == "refresh_summary":
        return [
            {
                "filters": {
                    "asset": asset_classes[:1],
                    "asset_class": asset_classes[:1],
                    "universe": universes[:1],
                    "family": families[:1],
                    "severity": [],
                    "business_date": business_date,
                    "start": start_date,
                    "start_date": start_date,
                    "end": end_date,
                    "end_date": end_date,
                }
            }
        ]

    if callback_name == "refresh_drilldown":
        rf_id = None
        if not membership.empty and "risk_factor_id" in membership.columns:
            rf_id = str(membership["risk_factor_id"].astype(str).iloc[0])
        elif not dq_results.empty and "risk_factor_id" in dq_results.columns:
            rf_id = str(dq_results["risk_factor_id"].astype(str).iloc[0])
        return [{"selected_risk_factor_id": rf_id}, [], ["peer_band"], []]

    if callback_name == "refresh_model_compare":
        return [checks[:2], start_date, end_date]

    # app_v2 callback names
    if callback_name == "sync_filters":
        return [
            asset_classes[:1],
            universes[:1],
            families[:1],
            severities[-1:] if severities else [],
            business_date,
            ["all"],
            "all",
            start_date,
            end_date,
            {"selected_risk_factor_id": None},
        ]
    if callback_name == "refresh_compare":
        return [universes[0] if universes else None, checks[:2], start_date, end_date, [], {"filters": {}}, []]
    if callback_name == "refresh_peer":
        asset = asset_classes[0] if asset_classes else None
        group = None
        if not data["membership"].empty and asset is not None and "rf_level3" in data["membership"].columns:
            gvals = data["membership"][data["membership"]["rf_level1"] == asset]["rf_level3"].dropna().astype(str).unique().tolist()
            group = gvals[0] if gvals else None
        return [asset, None, group, start_date, end_date, [end_date] if end_date else [], 0, [], {"filters": {}}]

    return []


def _summarize_result(value: Any) -> Any:
    if isinstance(value, pd.DataFrame):
        return {"type": "DataFrame", "shape": list(value.shape), "columns": list(value.columns)}
    if isinstance(value, go.Figure):
        return {
            "type": "Figure",
            "traces": len(value.data),
            "title": str(getattr(value.layout.title, "text", "")),
        }
    if isinstance(value, dict):
        return {"type": "dict", "keys": list(value.keys())[:20]}
    if isinstance(value, list):
        sample = value[0] if value else None
        return {
            "type": "list",
            "length": len(value),
            "sample_item_type": type(sample).__name__ if sample is not None else "None",
        }
    if isinstance(value, tuple):
        return [_summarize_result(v) for v in value]
    return {"type": type(value).__name__, "repr": str(value)[:240]}


def _find_callback(app, callback_name: str):
    for key, meta in app.callback_map.items():
        callback_fn = meta.get("callback")
        if callback_fn is not None and callback_fn.__name__ == callback_name:
            return key, meta
        if key == callback_name:
            return key, meta
    return None, None


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run Layer 7 Dash UI debug walkthrough.")
    parser.add_argument("--results-path", default=str(PROJECT_ROOT / "data" / "processed" / "dq_results"))
    parser.add_argument("--raw-path", default=str(PROJECT_ROOT / "data" / "raw" / "timeseries_raw"))
    parser.add_argument("--membership-path", default=str(PROJECT_ROOT / "data" / "processed" / "universe_membership"))
    parser.add_argument("--business-date", default="", help="Optional business_date filter (YYYY-MM-DD) applied at load time.")
    parser.add_argument("--app-version", default="v1", choices=["v1", "v2"], help="Dash app version to introspect.")

    parser.add_argument("--print-data-summary", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--print-layout-tree", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--layout-max-depth", type=int, default=8)
    parser.add_argument("--layout-max-rows", type=int, default=200)
    parser.add_argument("--print-callbacks", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--validate-callback-ids", action=argparse.BooleanOptionalAction, default=True)

    parser.add_argument("--run-callback", default="", help="Server callback name from callback inventory (e.g., refresh_summary).")
    parser.add_argument("--args-json", default="", help="JSON list of positional args passed into selected callback.")
    parser.add_argument(
        "--sample-args",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="Use built-in sample args when --run-callback is provided and --args-json is not provided.",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    data = load_data(
        args.results_path,
        args.raw_path,
        args.membership_path,
        business_date=args.business_date or None,
    )
    if args.app_version == "v2":
        from ui.app_v2 import create_app as create_ui_app
    else:
        from ui.app import create_app as create_ui_app
    app = create_ui_app(data)

    if args.print_data_summary:
        print("=== Dash Data Summary ===")
        for name, df in data.items():
            print(f"{name}: rows={len(df):,}, cols={len(df.columns)}")
            print(f"  columns={list(df.columns)}")

    layout_nodes = _layout_nodes(app.layout, max_depth=args.layout_max_depth)
    layout_df = pd.DataFrame(layout_nodes)

    if args.print_layout_tree:
        print("\n=== Layout Tree (truncated) ===")
        print(layout_df.head(args.layout_max_rows).to_string(index=False))

    callback_df = pd.DataFrame(_callback_rows(app))
    if args.print_callbacks:
        print("\n=== Callback Inventory ===")
        print(callback_df.to_string(index=False))

    if args.validate_callback_ids:
        layout_ids = set(layout_df["component_id"].dropna().astype(str).tolist())
        issues = _validate_callback_ids(app, layout_ids)
        print("\n=== Callback/Layout ID Validation ===")
        if issues.empty:
            print("No missing component IDs in callback wiring.")
        else:
            print(issues.to_string(index=False))

    if args.run_callback:
        cb_key, meta = _find_callback(app, args.run_callback)
        if meta is None:
            available = sorted(callback_df["callback_name"].dropna().unique().tolist())
            raise ValueError(f"Callback '{args.run_callback}' not found. Available server callbacks: {available}")
        callback_fn = meta.get("callback")
        if callback_fn is None:
            raise ValueError(f"Callback '{args.run_callback}' is clientside-only and cannot run in Python debug mode.")
        callback_impl = getattr(callback_fn, "__wrapped__", callback_fn)

        expected = len(meta.get("inputs", [])) + len(meta.get("state", []))
        if args.args_json:
            call_args = json.loads(args.args_json)
            if not isinstance(call_args, list):
                raise ValueError("--args-json must decode to a JSON list.")
        elif args.sample_args:
            call_args = _build_sample_args(callback_impl.__name__, data)
        else:
            call_args = []

        # Version-specific callback signatures can differ between app v1/v2.
        if callback_impl.__name__ == "refresh_drilldown" and expected == 2 and len(call_args) == 1:
            call_args = [call_args[0], []]

        if len(call_args) != expected:
            raise ValueError(f"Callback '{callback_fn.__name__}' expects {expected} args, got {len(call_args)}.")

        print(f"\n=== Running Callback: {callback_impl.__name__} ===")
        print(f"callback_key={cb_key}")
        print(f"args={call_args}")
        result = callback_impl(*call_args)
        print("result_summary=")
        print(json.dumps(_summarize_result(result), indent=2))


if __name__ == "__main__":
    main()
