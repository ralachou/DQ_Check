from __future__ import annotations

import argparse
import json
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

from common.schemas import config_hash, load_yaml
from data.synthetic import write_demo_datasets
from data_access.parquet_repository import ParquetTimeSeriesRepository
from dq_checks.feature_builder import FeatureBuilder
from dq_checks.registry import ModelRegistry, ModelSpec
from normalization.normalizer import normalize_results
from triage.false_alarm import FalseAlarmReducer
from universe.builder import UniverseBuilder
from universe.definitions import UniverseDefinition

PROJECT_ROOT = Path(__file__).resolve().parents[2]
PEER_KEYS = ["rf_level1", "rf_level2", "rf_level3", "rf_level4", "rf_level5"]


def _parse_csv(raw: str | None) -> list[str]:
    if not raw:
        return []
    return [x.strip() for x in raw.split(",") if x.strip()]


def _write_demo_output(df: pd.DataFrame, output_root: Path, name: str, output_format: str) -> list[str]:
    output_root.mkdir(parents=True, exist_ok=True)
    out: list[str] = []
    if output_format in {"parquet", "both"}:
        p = output_root / f"{name}.parquet"
        df.to_parquet(p, index=False)
        out.append(str(p))
    if output_format in {"excel", "both"}:
        p = output_root / f"{name}.xlsx"
        try:
            df.to_excel(p, index=False)
        except ImportError as exc:  # pragma: no cover
            raise RuntimeError("Excel output requires openpyxl. Install with: pip install openpyxl") from exc
        out.append(str(p))
    return out


def _check_profiles(specs: list[ModelSpec], catalog: dict[str, Any]) -> dict[str, dict[str, Any]]:
    profiles = catalog.get("normalization", {}).get("profiles", {})
    defaults = catalog.get("normalization", {}).get("defaults", {})
    global_severity = catalog.get("globals", {}).get("default_severity_thresholds", {})
    out: dict[str, dict[str, Any]] = {}
    for spec in specs:
        profile_cfg = profiles.get(spec.normalization_profile, {})
        strategy = profile_cfg.get("strategy", defaults.get("strategy", "ecdf"))
        out[spec.id] = {
            "normalization_strategy": strategy,
            "normalization_params": profile_cfg,
            "backend": spec.backend,
            "severity_mode": "fixed",
            "severity_thresholds": global_severity.get("quantile", {}),
            "fixed_thresholds": global_severity.get("fixed", {}),
            "model_version": spec.version_tag,
        }
    return out


def _build_universe_definition(catalog: dict[str, Any], universe_name: str) -> UniverseDefinition:
    uni = catalog.get("universes", {}).get(universe_name)
    if not uni:
        raise ValueError(f"Universe '{universe_name}' not found in catalog.")
    return UniverseDefinition(
        name=universe_name,
        description=str(uni.get("description", "")),
        filter_rules=uni.get("filters", {}),
    )


def _execute_per_series(check, data: pd.DataFrame, spec: ModelSpec) -> pd.DataFrame:
    parts = []
    for rf_id, series_df in data.groupby("risk_factor_id", sort=False):
        sdf = series_df.sort_values("date").reset_index(drop=True)
        state = check.fit(sdf, {"risk_factor_id": rf_id})
        scored = check.score(sdf, {"risk_factor_id": rf_id}, state)
        scored["check_id"] = spec.id
        scored["backend"] = spec.backend
        scored["family"] = spec.family
        scored["fit_policy"] = spec.fit_policy
        parts.append(scored)
    return pd.concat(parts, ignore_index=True) if parts else pd.DataFrame()


def _execute_per_peer_group(check, data: pd.DataFrame, membership: pd.DataFrame, spec: ModelSpec, fb: FeatureBuilder) -> pd.DataFrame:
    m = membership[["risk_factor_id", "rf_level1", "rf_level2", "rf_level3", "rf_level4", "rf_level5"]]
    merged = data.merge(m, on="risk_factor_id", how="left")
    group_keys = ["rf_level1", "rf_level2", "rf_level3", "rf_level4", "rf_level5"]
    parts = []
    for _, grp in merged.groupby(group_keys, dropna=False, sort=False):
        if grp["risk_factor_id"].nunique() < 3:
            for rf_id, sdf in grp.groupby("risk_factor_id", sort=False):
                feat = fb.build_features(sdf[["risk_factor_id", "date", "value"]].copy())
                state = check.fit(feat, {"risk_factor_id": rf_id})
                scored = check.score(feat, {"risk_factor_id": rf_id}, state)
                scored["check_id"] = spec.id
                scored["backend"] = spec.backend
                scored["family"] = spec.family
                scored["fit_policy"] = spec.fit_policy
                parts.append(scored)
            continue
        feat_grp = fb.build_batch(grp[["risk_factor_id", "date", "value"]], max_workers=4)
        state = check.fit(feat_grp, {"peer_group": True})
        scored = check.score(feat_grp, {"peer_group": True}, state)
        scored["check_id"] = spec.id
        scored["backend"] = spec.backend
        scored["family"] = spec.family
        scored["fit_policy"] = spec.fit_policy
        parts.append(scored)
    return pd.concat(parts, ignore_index=True) if parts else pd.DataFrame()


def _execute_global(check, data: pd.DataFrame, spec: ModelSpec, fb: FeatureBuilder) -> pd.DataFrame:
    feat = fb.build_batch(data[["risk_factor_id", "date", "value"]], max_workers=4)
    state = check.fit(feat, {"global": True})
    scored = check.score(feat, {"global": True}, state)
    scored["check_id"] = spec.id
    scored["backend"] = spec.backend
    scored["family"] = spec.family
    scored["fit_policy"] = spec.fit_policy
    return scored


def _inject_demo_labels(df: pd.DataFrame, seed: int, label_rate: float) -> pd.DataFrame:
    out = df.copy()
    rng = np.random.default_rng(seed)
    base = np.full(len(out), max(min(label_rate, 0.95), 0.01), dtype=float)
    low_med = out["severity"].isin(["Low", "Med"]).to_numpy()
    flagged = out["flag"].astype(bool).to_numpy()
    base[low_med] = np.clip(base[low_med] * 1.6, 0.01, 0.95)
    base[~flagged] = np.clip(base[~flagged] * 0.6, 0.01, 0.95)
    out["is_false_alarm"] = (rng.random(len(out)) < base).astype(int)
    if len(out) >= 2 and out["is_false_alarm"].nunique() < 2:
        out.loc[out.index[0], "is_false_alarm"] = 0
        out.loc[out.index[1], "is_false_alarm"] = 1
    return out


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run Advanced DQ Checks on RF Layer 6 false-alarm demo.")
    parser.add_argument("--universe-name", default="CP_RATE_CORP")
    parser.add_argument("--config-path", default=str(PROJECT_ROOT / "configs" / "model_catalog.yaml"))
    parser.add_argument("--start-date", default="2024-01-01")
    parser.add_argument("--end-date", default="2024-12-31")
    parser.add_argument("--business-date", default="2024-12-31")
    parser.add_argument("--raw-path", default=str(PROJECT_ROOT / "data" / "raw"))
    parser.add_argument("--processed-path", default=str(PROJECT_ROOT / "data" / "processed"))
    parser.add_argument("--artifact-root", default=str(PROJECT_ROOT / "data" / "artifacts" / "normalization"))
    parser.add_argument("--num-factors", type=int, default=300)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--snapshot-days", type=int, default=2)
    parser.add_argument("--max-series", type=int, default=25, help="Limit number of risk factors for demo runtime.")
    parser.add_argument("--check-ids", default="", help="Comma-separated check IDs to run. Empty = all enabled checks.")
    parser.add_argument("--max-checks", type=int, default=0, help="If >0, run only first N checks after filtering.")
    parser.add_argument(
        "--with-supervised",
        action=argparse.BooleanOptionalAction,
        default=False,
        help="Enable supervised triage mode (demo labels required).",
    )
    parser.add_argument(
        "--generate-demo-labels",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="Generate synthetic is_false_alarm labels for supervised demo mode.",
    )
    parser.add_argument("--label-rate", type=float, default=0.15, help="Base false alarm label rate for demo label generation.")
    parser.add_argument(
        "--output-format",
        default="parquet",
        choices=["parquet", "excel", "both"],
        help="Demo artifact output format.",
    )
    parser.add_argument(
        "--generate-demo-data",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="Generate synthetic data before running Layer 6 demo.",
    )
    return parser.parse_args()


def run_demo_layer6_false_alarm(args: argparse.Namespace) -> dict[str, Any]:
    raw_path = Path(args.raw_path)
    processed_path = Path(args.processed_path)
    business_date = str(pd.to_datetime(args.business_date).date())
    run_id = f"layer6_demo_{datetime.now(UTC).strftime('%Y%m%d_%H%M%S_%f')}"

    if args.generate_demo_data:
        write_demo_datasets(
            raw_path=raw_path,
            processed_path=processed_path,
            start_date=args.start_date,
            end_date=args.end_date,
            num_factors=args.num_factors,
            seed=args.seed,
            snapshot_days=args.snapshot_days,
        )

    catalog = load_yaml(args.config_path)
    cfg_hash = config_hash(catalog)
    repo = ParquetTimeSeriesRepository(base_path=raw_path, write_base_path=processed_path)

    definition = _build_universe_definition(catalog, args.universe_name)
    membership = UniverseBuilder(repo).build(definition)
    if membership.empty:
        raise ValueError(f"No membership found for universe '{args.universe_name}'.")
    if args.max_series > 0:
        membership = membership.head(args.max_series).copy()
    risk_factor_ids = membership["risk_factor_id"].astype(str).tolist()

    series = repo.get_series(
        risk_factor_ids=risk_factor_ids,
        start_date=args.start_date,
        end_date=args.end_date,
        business_date=business_date,
    )
    if series.empty:
        raise ValueError("No time-series rows loaded for selected universe/date/business_date.")

    registry = ModelRegistry()
    specs = [s for s in registry.load_universe_specs(catalog, args.universe_name) if s.enabled]
    check_filter = set(_parse_csv(args.check_ids))
    if check_filter:
        specs = [s for s in specs if s.id in check_filter]
    if args.max_checks > 0:
        specs = specs[: args.max_checks]
    if not specs:
        raise ValueError("No checks selected for Layer 6 demo.")

    checks: dict[str, Any] = {}
    for spec in specs:
        checks[spec.id] = registry.build_from_spec(spec, checks)

    fb = FeatureBuilder()
    raw_parts = []
    for spec in specs:
        check = checks[spec.id]
        if spec.fit_policy == "global":
            out = _execute_global(check, series, spec, fb)
        elif spec.fit_policy == "per_peer_group":
            out = _execute_per_peer_group(check, series, membership, spec, fb)
        else:
            out = _execute_per_series(check, series, spec)
        out["run_id"] = run_id
        out["universe_name"] = args.universe_name
        out["business_date"] = pd.to_datetime(business_date)
        raw_parts.append(out)
    raw_results = pd.concat(raw_parts, ignore_index=True) if raw_parts else pd.DataFrame()
    if raw_results.empty:
        raise ValueError("No raw check results were produced.")

    profiles = _check_profiles(specs, catalog)
    normalized = normalize_results(
        results_df=raw_results,
        check_profiles=profiles,
        run_id=run_id,
        config_hash=cfg_hash,
        business_date=business_date,
        artifact_root=args.artifact_root,
    )
    if args.with_supervised and args.generate_demo_labels:
        normalized = _inject_demo_labels(normalized, seed=args.seed, label_rate=args.label_rate)

    membership_cols = ["risk_factor_id"] + PEER_KEYS
    triage_cfg = catalog.get("triage", {}) if isinstance(catalog, dict) else {}
    event_calendar = pd.DataFrame(triage_cfg.get("event_calendar", []))
    triager = FalseAlarmReducer(
        regime_windows=catalog.get("globals", {}).get("regime_windows", []),
        peer_keys=PEER_KEYS,
        event_calendar=event_calendar,
        event_window_days=int(triage_cfg.get("event_window_days", 1)),
        min_peer_group_size=int(triage_cfg.get("min_peer_group_size", 5)),
        peer_confirm_ratio=float(triage_cfg.get("peer_confirm_ratio", 0.60)),
        stress_threshold_multiplier=float(triage_cfg.get("stress_threshold_multiplier", 1.5)),
        supervised_candidates=list(triage_cfg.get("supervised_candidates", ["xgboost", "lightgbm", "random_forest", "logistic_regression"])),
    )
    triaged, triage_audit = triager.run(
        alerts_df=normalized.merge(membership[membership_cols], on="risk_factor_id", how="left"),
        raw_df=series,
        membership=membership[membership_cols],
        with_supervised=bool(args.with_supervised),
        label_col="is_false_alarm",
    )
    triaged["run_id"] = run_id
    triaged["universe_name"] = args.universe_name
    triaged["business_date"] = pd.to_datetime(business_date)

    summary_by_action = (
        triaged.groupby("recommended_action", as_index=False)
        .agg(
            row_count=("date", "count"),
            mean_confidence=("confidence_estimate", "mean"),
        )
        .sort_values("row_count", ascending=False)
    )
    summary_by_regime = (
        triaged.groupby("regime_tag", as_index=False)
        .agg(
            row_count=("date", "count"),
            flagged=("flag", "sum"),
            peer_confirmed=("peer_confirmed", "sum"),
        )
        .sort_values("row_count", ascending=False)
    )
    summary_by_check = (
        triaged.groupby(["check_id", "family"], as_index=False)
        .agg(
            row_count=("date", "count"),
            flagged=("flag", "sum"),
            confirm_bad_data=("recommended_action", lambda s: int((s == "CONFIRM_BAD_DATA").sum())),
            accept_move=("recommended_action", lambda s: int((s == "ACCEPT_MOVE").sum())),
        )
        .sort_values("flagged", ascending=False)
    )
    peer_summary = pd.DataFrame(
        [
            {
                "peer_confirmed_rows": int(triaged["peer_confirmed"].sum()),
                "peer_unconfirmed_rows": int((~triaged["peer_confirmed"].astype(bool)).sum()),
                "avg_peer_confidence": float(pd.to_numeric(triaged["peer_confidence"], errors="coerce").fillna(0.0).mean()),
            }
        ]
    )
    triage_model_df = pd.DataFrame([triage_audit.get("triage_model", {})])

    triaged_preview = triaged.sort_values(["recommended_action", "confidence_estimate"], ascending=[True, False]).head(5000).reset_index(drop=True)
    normalized_preview = normalized.sort_values("norm_score", ascending=False).head(5000).reset_index(drop=True)

    output_root = (
        processed_path
        / "layer6_false_alarm_demo"
        / f"business_date={business_date}"
        / f"universe_name={args.universe_name}"
        / f"run_id={run_id}"
    )
    saved_files = {
        "normalized_input_preview": _write_demo_output(normalized_preview, output_root, "normalized_input_preview", args.output_format),
        "triaged_preview": _write_demo_output(triaged_preview, output_root, "triaged_preview", args.output_format),
        "summary_by_action": _write_demo_output(summary_by_action, output_root, "summary_by_action", args.output_format),
        "summary_by_regime": _write_demo_output(summary_by_regime, output_root, "summary_by_regime", args.output_format),
        "summary_by_check": _write_demo_output(summary_by_check, output_root, "summary_by_check", args.output_format),
        "peer_summary": _write_demo_output(peer_summary, output_root, "peer_summary", args.output_format),
        "triage_model": _write_demo_output(triage_model_df, output_root, "triage_model", args.output_format),
    }

    manifest = {
        "layer": "Layer 6 - False Alarm Reduction + Triage Scorer",
        "run_id": run_id,
        "universe_name": args.universe_name,
        "config_path": str(Path(args.config_path).resolve()),
        "config_hash": cfg_hash,
        "inputs": {
            "business_date": business_date,
            "start_date": args.start_date,
            "end_date": args.end_date,
            "risk_factor_count": int(membership["risk_factor_id"].nunique()),
            "timeseries_rows": int(len(series)),
            "checks_executed": [s.id for s in specs],
            "with_supervised": bool(args.with_supervised),
            "generate_demo_labels": bool(args.generate_demo_labels),
            "label_rate": float(args.label_rate),
        },
        "triage_audit": triage_audit,
        "outputs": {
            "output_root": str(output_root),
            "saved_files": saved_files,
            "normalized_rows": int(len(normalized)),
            "triaged_rows": int(len(triaged)),
            "confirm_bad_data_rows": int((triaged["recommended_action"] == "CONFIRM_BAD_DATA").sum()),
            "accept_move_rows": int((triaged["recommended_action"] == "ACCEPT_MOVE").sum()),
            "needs_review_rows": int((triaged["recommended_action"] == "NEEDS_REVIEW").sum()),
        },
    }
    manifest_path = output_root / "manifest.json"
    manifest_path.write_text(json.dumps(manifest, indent=2), encoding="utf-8")

    print("=== Layer 6 False Alarm Demo Summary ===")
    print(f"Run ID: {run_id}")
    print(f"Universe: {args.universe_name}")
    print(f"Business date: {business_date}")
    print(f"Normalized rows: {len(normalized):,}")
    print(f"Triaged rows: {len(triaged):,}")
    print(f"CONFIRM_BAD_DATA rows: {(triaged['recommended_action'] == 'CONFIRM_BAD_DATA').sum():,}")
    print(f"ACCEPT_MOVE rows: {(triaged['recommended_action'] == 'ACCEPT_MOVE').sum():,}")
    print(f"NEEDS_REVIEW rows: {(triaged['recommended_action'] == 'NEEDS_REVIEW').sum():,}")
    print(f"Output root: {output_root}")
    print(f"Manifest: {manifest_path}")

    return manifest


def main() -> None:
    args = parse_args()
    run_demo_layer6_false_alarm(args)


if __name__ == "__main__":
    main()
