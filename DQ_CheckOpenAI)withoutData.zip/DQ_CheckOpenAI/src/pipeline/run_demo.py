from __future__ import annotations

import argparse
from datetime import UTC, datetime
from pathlib import Path

from data.synthetic import write_demo_datasets
from data_access.parquet_repository import ParquetTimeSeriesRepository
from engine.run_engine import RunEngine, RunRequest

PROJECT_ROOT = Path(__file__).resolve().parents[2]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run Advanced DQ Checks on RF demo pipeline.")
    parser.add_argument("--start-date", default="2019-01-01")
    parser.add_argument("--end-date", default="2025-12-31")
    parser.add_argument("--business-date", default=None, help="Snapshot business date (defaults to --end-date).")
    parser.add_argument("--snapshot-days", type=int, default=1, help="How many last business-date snapshots to generate.")
    parser.add_argument("--num-factors", type=int, default=400)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--raw-path", default=str(PROJECT_ROOT / "data" / "raw"))
    parser.add_argument("--processed-path", default=str(PROJECT_ROOT / "data" / "processed"))
    parser.add_argument("--config-path", default=str(PROJECT_ROOT / "configs" / "model_catalog.yaml"))
    parser.add_argument("--universe-name", default="CP_RATE_CORP")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    write_demo_datasets(
        raw_path=args.raw_path,
        processed_path=args.processed_path,
        start_date=args.start_date,
        end_date=args.end_date,
        num_factors=args.num_factors,
        seed=args.seed,
        snapshot_days=args.snapshot_days,
    )
    repo = ParquetTimeSeriesRepository(base_path=args.raw_path, write_base_path=args.processed_path)
    engine = RunEngine(repository=repo, artifact_root="data/artifacts/normalization")
    run_id = f"demo_{datetime.now(UTC).strftime('%Y%m%d_%H%M%S')}"
    result = engine.run(
        RunRequest(
            run_id=run_id,
            universe_name=args.universe_name,
            start_date=args.start_date,
            end_date=args.end_date,
            business_date=args.business_date or args.end_date,
            config_path=args.config_path,
            incremental=False,
        )
    )
    print(f"Run completed: run_id={run_id}")
    print(result["audit_log"].to_string(index=False))


if __name__ == "__main__":
    main()
