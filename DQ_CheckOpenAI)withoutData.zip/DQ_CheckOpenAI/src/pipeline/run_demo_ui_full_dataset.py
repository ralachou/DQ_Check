from __future__ import annotations

import argparse
import os
import shutil
import stat
from datetime import datetime
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import yaml

from common.schemas import load_yaml
from data.synthetic import ASSET_CLASS_TEMPLATES, write_demo_datasets_from_hierarchy
from data_access.parquet_repository import ParquetTimeSeriesRepository
from engine.run_engine import RunEngine, RunRequest
from ui.app import PROJECT_ROOT, load_data
from ui.app_v2 import create_app


def _slug(v: str) -> str:
    return "".join(ch.lower() if ch.isalnum() else "_" for ch in v).strip("_")


def _default_universe_checks(asset_class: str) -> list[dict[str, Any]]:
    suffix = _slug(asset_class)
    robust_id = f"robust_zscore_{suffix}"
    jump_id = f"jump_spike_{suffix}"
    pyod_id = f"pyod_iforest_{suffix}"
    return [
        {
            "id": robust_id,
            "backend": "local",
            "model_name": "robust_zscore",
            "family": "stat_univariate",
            "fit_policy": "per_series",
            "params": {"window": 130, "threshold": 6.0, "min_periods": 20},
            "normalization_profile": "robust_stat_profile",
            "severity_profile": "default",
            "enabled": True,
        },
        {
            "id": "legacy_4sigma_shift_" + suffix,
            "backend": "local",
            "model_name": "mean_std_shift_4sigma",
            "family": "stat_univariate",
            "fit_policy": "per_series",
            "params": {"window": 126, "shift_lag": 1, "threshold": 4.0},
            "normalization_profile": "robust_stat_profile",
            "severity_profile": "default",
            "enabled": True,
        },
        {
            "id": "stale_values_" + suffix,
            "backend": "local",
            "model_name": "stale_values",
            "family": "integrity",
            "fit_policy": "per_series",
            "params": {"stale_days": 5},
            "normalization_profile": "quantile_profile",
            "severity_profile": "default",
            "enabled": True,
        },
        {
            "id": "missing_gaps_" + suffix,
            "backend": "local",
            "model_name": "missing_gaps",
            "family": "integrity",
            "fit_policy": "per_series",
            "params": {"calendar": "business_day"},
            "normalization_profile": "quantile_profile",
            "severity_profile": "default",
            "enabled": True,
        },
        {
            "id": jump_id,
            "backend": "local",
            "model_name": "jump_spike",
            "family": "changepoint",
            "fit_policy": "per_series",
            "params": {"window": 45, "threshold": 5.0},
            "normalization_profile": "ecdf_profile",
            "severity_profile": "default",
            "enabled": True,
        },
        {
            "id": pyod_id,
            "backend": "pyod",
            "model_name": "iforest",
            "family": "ml_unsupervised",
            "fit_policy": "per_peer_group",
            "params": {"contamination": 0.002, "retrain_window": 45},
            "normalization_profile": "ecdf_profile",
            "severity_profile": "default",
            "enabled": True,
        },
        {
            "id": "ensemble_" + suffix,
            "backend": "local",
            "model_name": "ensemble",
            "family": "ensemble",
            "fit_policy": "per_series",
            "params": {
                "method": "weighted_average",
                "children": [robust_id, jump_id, pyod_id],
                "weights": [0.4, 0.35, 0.25],
            },
            "normalization_profile": "ecdf_profile",
            "severity_profile": "default",
            "enabled": True,
        },
    ]


def _build_config_for_all_asset_classes(base_cfg: dict[str, Any], asset_classes: list[str]) -> dict[str, Any]:
    cfg = dict(base_cfg)
    universes = dict(cfg.get("universes", {}))
    for ac in sorted(set(asset_classes)):
        universe_name = f"{ac}_ALL"
        universes[universe_name] = {
            "description": f"Auto-generated full-asset-class universe for {ac}",
            "filters": {"rf_level1": ac},
            "checks": _default_universe_checks(ac),
        }
    cfg["universes"] = universes
    return cfg


def _ensure_hierarchy_file(path: Path, seed: int, default_rows: int = 20_000) -> None:
    if path.exists():
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(seed)
    classes = list(ASSET_CLASS_TEMPLATES.keys())
    rows: list[dict[str, Any]] = []
    for i in range(default_rows):
        ac = classes[i % len(classes)]
        ccy, l3, l4, l5 = ASSET_CLASS_TEMPLATES[ac][int(rng.integers(0, len(ASSET_CLASS_TEMPLATES[ac])))]
        rows.append(
            {
                "driverName": f"{ac}_{ccy}_{l3}_{l4}_{l5}_{i:05d}",
                "assetClass": ac,
                "ccy": ccy,
                "rf_level1": ac,
                "rf_level2": ccy,
                "rf_level3": l3,
                "rf_level4": l4,
                "rf_level5": l5,
            }
        )
    pd.DataFrame(rows).to_excel(path, index=False)
    print(f"[WARN] Hierarchy file was missing. Created fallback synthetic hierarchy at: {path}")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Generate full hierarchy synthetic data, run DQ checks, and analyze in app_v2.")
    parser.add_argument("--hierarchy-path", default=str(PROJECT_ROOT / "data" / "raw" / "risk_factors" / "risk_factor_hierarchy_20k.xlsx"))
    parser.add_argument("--start-date", default="2025-01-01")
    parser.add_argument("--end-date", default="2025-12-31")
    parser.add_argument("--business-date", default=None, help="Snapshot business date (default: --end-date)")
    parser.add_argument("--snapshot-days", type=int, default=1)
    parser.add_argument("--max-factors", type=int, default=0, help="0 means all factors in hierarchy.")
    parser.add_argument(
        "--max-factors-per-asset-class",
        type=int,
        default=0,
        help="0 means no per-asset cap. Example: 100 -> up to 100 factors for each rf_level1.",
    )
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--asset-classes", nargs="*", default=[], help="Optional subset, e.g. EQ_PRICE FX_RATE")
    parser.add_argument("--raw-path", default=str(PROJECT_ROOT / "data" / "demo_ui_full" / "raw"))
    parser.add_argument("--processed-path", default=str(PROJECT_ROOT / "data" / "demo_ui_full" / "processed"))
    parser.add_argument("--base-config-path", default=str(PROJECT_ROOT / "configs" / "model_catalog.yaml"))
    parser.add_argument("--generated-config-path", default=str(PROJECT_ROOT / "data" / "demo_ui_full" / "processed" / "ui_full_demo" / "model_catalog_ui_full.yaml"))
    parser.add_argument("--artifact-root", default=str(PROJECT_ROOT / "data" / "demo_ui_full" / "artifacts" / "normalization"))
    parser.add_argument(
        "--clean-before-run",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="Clear raw/processed targets used by this demo before generating data.",
    )
    parser.add_argument("--run-id", default="", help="Optional run id.")
    parser.add_argument("--launch-ui", action=argparse.BooleanOptionalAction, default=False)
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8060)
    parser.add_argument("--debug", action=argparse.BooleanOptionalAction, default=False)
    return parser.parse_args()


def _reset_demo_paths(raw_path: Path, processed_path: Path, artifact_root: Path) -> None:
    def _handle_remove_readonly(func, path, exc_info):
        del exc_info
        try:
            os.chmod(path, stat.S_IWRITE)
            func(path)
        except Exception:
            pass

    targets = [
        raw_path / "risk_factors",
        raw_path / "timeseries_raw",
        processed_path / "dq_results",
        processed_path / "universe_membership",
        processed_path / "audit_log",
        processed_path / "triage_labels",
        processed_path / "ui_full_demo",
        artifact_root,
    ]
    for t in targets:
        if t.exists():
            shutil.rmtree(t, onerror=_handle_remove_readonly)


def main() -> None:
    args = parse_args()
    raw_path = Path(args.raw_path)
    processed_path = Path(args.processed_path)
    hierarchy_path = Path(args.hierarchy_path)
    artifact_root = Path(args.artifact_root)
    business_date = str(pd.to_datetime(args.business_date or args.end_date).date())

    _ensure_hierarchy_file(hierarchy_path, seed=args.seed)

    if args.clean_before_run:
        _reset_demo_paths(raw_path=raw_path, processed_path=processed_path, artifact_root=artifact_root)

    max_factors = args.max_factors if args.max_factors > 0 else None
    max_factors_per_asset_class = args.max_factors_per_asset_class if args.max_factors_per_asset_class > 0 else None
    risk_factors, timeseries = write_demo_datasets_from_hierarchy(
        hierarchy_path=hierarchy_path,
        raw_path=raw_path,
        processed_path=processed_path,
        start_date=args.start_date,
        end_date=args.end_date,
        seed=args.seed,
        snapshot_days=args.snapshot_days,
        business_dates=[business_date],
        max_factors=max_factors,
        max_factors_per_asset_class=max_factors_per_asset_class,
    )
    if risk_factors.empty or timeseries.empty:
        raise ValueError("Synthetic data generation produced empty datasets.")

    asset_classes = sorted(risk_factors["rf_level1"].dropna().astype(str).unique().tolist())
    if args.asset_classes:
        wanted = set(str(v).strip() for v in args.asset_classes)
        asset_classes = [ac for ac in asset_classes if ac in wanted]
        if not asset_classes:
            raise ValueError(f"No matching asset classes found in hierarchy for: {sorted(wanted)}")

    base_cfg = load_yaml(args.base_config_path)
    ui_cfg = _build_config_for_all_asset_classes(base_cfg, asset_classes)
    cfg_out = Path(args.generated_config_path)
    cfg_out.parent.mkdir(parents=True, exist_ok=True)
    cfg_out.write_text(yaml.safe_dump(ui_cfg, sort_keys=False), encoding="utf-8")

    run_id = args.run_id.strip() or f"ui_full_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
    repo = ParquetTimeSeriesRepository(base_path=raw_path, write_base_path=processed_path)
    engine = RunEngine(repository=repo, artifact_root=args.artifact_root)

    run_rows: list[dict[str, Any]] = []
    for ac in asset_classes:
        universe_name = f"{ac}_ALL"
        req = RunRequest(
            run_id=run_id,
            universe_name=universe_name,
            start_date=args.start_date,
            end_date=args.end_date,
            business_date=business_date,
            config_path=str(cfg_out),
            incremental=False,
        )
        out = engine.run(req)
        audit = out["audit_log"].iloc[0].to_dict() if not out["audit_log"].empty else {}
        run_rows.append(
            {
                "run_id": run_id,
                "asset_class": ac,
                "universe_name": universe_name,
                "result_rows": int(len(out["results"])),
                "flagged_rows": int(out["results"]["flag"].sum()) if "flag" in out["results"].columns else 0,
                "elapsed_sec": float(audit.get("elapsed_sec", 0.0)),
            }
        )
        print(f"[OK] {universe_name}: rows={run_rows[-1]['result_rows']:,}, flagged={run_rows[-1]['flagged_rows']:,}")

    summary = pd.DataFrame(run_rows).sort_values("asset_class").reset_index(drop=True)
    out_root = processed_path / "ui_full_demo" / f"business_date={business_date}" / f"run_id={run_id}"
    out_root.mkdir(parents=True, exist_ok=True)
    summary_path = out_root / "run_summary.parquet"
    summary.to_parquet(summary_path, index=False)

    print("\n=== UI Full Dataset Demo Complete ===")
    print(f"Run ID: {run_id}")
    print(f"Business date: {business_date}")
    print(f"Risk factors generated: {len(risk_factors):,}")
    print(f"Asset classes covered: {len(asset_classes)} -> {asset_classes}")
    print(f"Generated config: {cfg_out}")
    print(f"Run summary: {summary_path}")
    print(f"Launch UI: python -m ui.app_v2 --results-path {processed_path / 'dq_results'} --raw-path {raw_path / 'timeseries_raw'} --membership-path {processed_path / 'universe_membership'} --config-path {cfg_out}")

    if args.launch_ui:
        data = load_data(
            results_path=str(processed_path / "dq_results"),
            raw_path=str(raw_path / "timeseries_raw"),
            membership_path=str(processed_path / "universe_membership"),
        )
        app = create_app(
            data=data,
            config_path=str(cfg_out),
            triage_path=str(processed_path / "triage_labels" / "triage_labels.parquet"),
            analyst_id=os.getenv("USERNAME", "analyst"),
        )
        app.run(host=args.host, port=args.port, debug=bool(args.debug))


if __name__ == "__main__":
    main()
