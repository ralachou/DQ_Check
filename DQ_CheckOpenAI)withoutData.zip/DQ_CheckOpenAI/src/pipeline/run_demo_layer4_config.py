from __future__ import annotations

import argparse
import json
from dataclasses import asdict
from pathlib import Path
from typing import Any

import pandas as pd

from common.schemas import config_hash, load_yaml
from data.synthetic import write_demo_datasets
from data_access.parquet_repository import ParquetTimeSeriesRepository
from dq_checks.registry import ModelRegistry, ModelSpec
from universe.builder import UniverseBuilder
from universe.definitions import UniverseDefinition

PROJECT_ROOT = Path(__file__).resolve().parents[2]


def _write_demo_output(df: pd.DataFrame, output_root: Path, name: str, output_format: str) -> list[str]:
    output_root.mkdir(parents=True, exist_ok=True)
    out: list[str] = []
    if output_format in {"parquet", "both"}:
        p = output_root / f"{name}.parquet"
        df.to_parquet(p, index=False)
        out.append(str(p))
    if output_format in {"excel", "both"}:
        p = output_root / f"{name}.xlsx"
        try:
            df.to_excel(p, index=False)
        except ImportError as exc:  # pragma: no cover
            raise RuntimeError("Excel output requires openpyxl. Install with: pip install openpyxl") from exc
        out.append(str(p))
    return out


def _check_profiles(specs: list[ModelSpec], catalog: dict[str, Any]) -> dict[str, dict[str, Any]]:
    profiles = catalog.get("normalization", {}).get("profiles", {})
    defaults = catalog.get("normalization", {}).get("defaults", {})
    global_severity = catalog.get("globals", {}).get("default_severity_thresholds", {})
    out: dict[str, dict[str, Any]] = {}
    for spec in specs:
        profile_cfg = profiles.get(spec.normalization_profile, {})
        strategy = profile_cfg.get("strategy", defaults.get("strategy", "ecdf"))
        out[spec.id] = {
            "normalization_strategy": strategy,
            "normalization_params": profile_cfg,
            "backend": spec.backend,
            "severity_mode": "fixed",
            "severity_thresholds": global_severity.get("quantile", {}),
            "fixed_thresholds": global_severity.get("fixed", {}),
            "model_version": spec.version_tag,
        }
    return out


def _build_universe_membership(
    repo: ParquetTimeSeriesRepository,
    catalog: dict[str, Any],
    universe_name: str,
) -> pd.DataFrame:
    uni = catalog.get("universes", {}).get(universe_name)
    if not uni:
        return pd.DataFrame()
    definition = UniverseDefinition(
        name=universe_name,
        description=str(uni.get("description", "")),
        filter_rules=uni.get("filters", {}),
    )
    return UniverseBuilder(repo).build(definition)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run Advanced DQ Checks on RF Layer 4 config demo.")
    parser.add_argument("--config-path", default=str(PROJECT_ROOT / "configs" / "model_catalog.yaml"))
    parser.add_argument("--universe-name", default="CP_RATE_CORP")
    parser.add_argument("--raw-path", default=str(PROJECT_ROOT / "data" / "raw"))
    parser.add_argument("--processed-path", default=str(PROJECT_ROOT / "data" / "processed"))
    parser.add_argument("--start-date", default="2024-01-01")
    parser.add_argument("--end-date", default="2024-12-31")
    parser.add_argument("--business-date", default="2024-12-31")
    parser.add_argument("--num-factors", type=int, default=250)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--snapshot-days", type=int, default=2)
    parser.add_argument(
        "--output-format",
        default="both",
        choices=["parquet", "excel", "both"],
        help="Demo artifact output format.",
    )
    parser.add_argument(
        "--generate-demo-data",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="Generate synthetic raw datasets to demonstrate config impact on membership.",
    )
    return parser.parse_args()


def run_demo_layer4_config(args: argparse.Namespace) -> dict[str, Any]:
    raw_path = Path(args.raw_path)
    processed_path = Path(args.processed_path)
    business_date = str(pd.to_datetime(args.business_date).date())

    if args.generate_demo_data:
        write_demo_datasets(
            raw_path=raw_path,
            processed_path=processed_path,
            start_date=args.start_date,
            end_date=args.end_date,
            num_factors=args.num_factors,
            seed=args.seed,
            snapshot_days=args.snapshot_days,
        )

    catalog = load_yaml(args.config_path)
    cfg_hash = config_hash(catalog)

    universe_cfg = catalog.get("universes", {}).get(args.universe_name, {})
    if not universe_cfg:
        raise ValueError(f"Universe '{args.universe_name}' not found in config.")

    registry = ModelRegistry()
    specs = registry.load_universe_specs(catalog, args.universe_name)
    profiles = _check_profiles(specs, catalog)

    validation_rows = []
    for spec in specs:
        ok = True
        err = ""
        try:
            registry.validate(spec)
        except Exception as exc:
            ok = False
            err = str(exc)
        validation_rows.append(
            {
                "check_id": spec.id,
                "backend": spec.backend,
                "model_name": spec.model_name,
                "fit_policy": spec.fit_policy,
                "enabled": spec.enabled,
                "validation_ok": ok,
                "validation_error": err,
            }
        )

    specs_df = pd.DataFrame(
        [
            {
                **asdict(spec),
                "params_json": json.dumps(spec.params, sort_keys=True),
            }
            for spec in specs
        ]
    )
    if "params" in specs_df.columns:
        specs_df = specs_df.drop(columns=["params"])

    profile_rows = []
    for check_id, p in profiles.items():
        profile_rows.append(
            {
                "check_id": check_id,
                "backend": p.get("backend"),
                "normalization_strategy": p.get("normalization_strategy"),
                "severity_mode": p.get("severity_mode"),
                "model_version": p.get("model_version"),
                "normalization_params_json": json.dumps(p.get("normalization_params", {}), sort_keys=True),
                "fixed_thresholds_json": json.dumps(p.get("fixed_thresholds", {}), sort_keys=True),
                "severity_thresholds_json": json.dumps(p.get("severity_thresholds", {}), sort_keys=True),
            }
        )
    profiles_df = pd.DataFrame(profile_rows)

    repo = ParquetTimeSeriesRepository(base_path=raw_path, write_base_path=processed_path)
    membership = _build_universe_membership(repo, catalog, args.universe_name)
    membership_summary = pd.DataFrame(
        [
            {
                "universe_name": args.universe_name,
                "membership_rows": int(len(membership)),
                "risk_factor_count": int(membership["risk_factor_id"].nunique()) if not membership.empty else 0,
                "asset_classes": ",".join(sorted(membership["rf_level1"].dropna().astype(str).unique().tolist())) if not membership.empty and "rf_level1" in membership.columns else "",
            }
        ]
    )

    asset_defaults = catalog.get("asset_class_defaults", {})
    assets_in_scope = (
        sorted(membership["rf_level1"].dropna().astype(str).unique().tolist())
        if not membership.empty and "rf_level1" in membership.columns
        else []
    )
    asset_defaults_rows = []
    for ac in assets_in_scope:
        ac_cfg = asset_defaults.get(ac, {})
        asset_defaults_rows.append(
            {
                "asset_class": ac,
                "peer_group_keys_json": json.dumps(ac_cfg.get("peer_group_keys", [])),
                "model_families_json": json.dumps(ac_cfg.get("model_families", [])),
                "windows_json": json.dumps(ac_cfg.get("windows", {}), sort_keys=True),
                "contamination_default": ac_cfg.get("contamination_default"),
                "severity_profile": ac_cfg.get("severity_profile"),
            }
        )
    asset_defaults_df = pd.DataFrame(asset_defaults_rows)

    config_overview = pd.DataFrame(
        [
            {"metric": "config_hash", "value": cfg_hash},
            {"metric": "globals_keys_count", "value": str(len(catalog.get("globals", {})))},
            {"metric": "feature_sets_count", "value": str(len(catalog.get("feature_sets", {})))},
            {"metric": "normalization_profiles_count", "value": str(len(catalog.get("normalization", {}).get("profiles", {})))},
            {"metric": "asset_class_defaults_count", "value": str(len(catalog.get("asset_class_defaults", {})))},
            {"metric": "universes_count", "value": str(len(catalog.get("universes", {})))},
            {"metric": "selected_universe", "value": args.universe_name},
            {"metric": "selected_universe_checks", "value": str(len(specs))},
        ]
    )

    output_root = (
        processed_path
        / "layer4_config_demo"
        / f"business_date={business_date}"
        / f"universe_name={args.universe_name}"
    )
    saved_files = {
        "config_overview": _write_demo_output(config_overview, output_root, "config_overview", args.output_format),
        "universe_checks": _write_demo_output(specs_df, output_root, "universe_checks", args.output_format),
        "check_validation": _write_demo_output(pd.DataFrame(validation_rows), output_root, "check_validation", args.output_format),
        "resolved_profiles": _write_demo_output(profiles_df, output_root, "resolved_profiles", args.output_format),
        "membership_summary": _write_demo_output(membership_summary, output_root, "membership_summary", args.output_format),
        "asset_class_defaults_in_scope": _write_demo_output(asset_defaults_df, output_root, "asset_class_defaults_in_scope", args.output_format),
    }

    manifest = {
        "layer": "Layer 4 - Configuration & Mapping",
        "config_path": str(Path(args.config_path).resolve()),
        "config_hash": cfg_hash,
        "selected_universe": args.universe_name,
        "inputs": {
            "business_date": business_date,
            "start_date": args.start_date,
            "end_date": args.end_date,
            "generate_demo_data": bool(args.generate_demo_data),
        },
        "processing": {
            "steps": [
                "Load YAML catalog",
                "Compute config hash",
                "Load universe model specs from registry",
                "Validate required model params",
                "Resolve normalization profiles for checks",
                "Map asset-class defaults for assets present in universe membership",
            ],
            "notes": [
                "Per-rf_level override mapping is not implemented in runtime yet.",
                "severity_profile is stored in specs but runtime currently derives severity thresholds from globals.default_severity_thresholds.",
            ],
        },
        "outputs": {
            "output_root": str(output_root),
            "saved_files": saved_files,
        },
    }
    manifest_path = output_root / "manifest.json"
    manifest_path.write_text(json.dumps(manifest, indent=2), encoding="utf-8")

    print("=== Layer 4 Config Demo Summary ===")
    print(f"Universe: {args.universe_name}")
    print(f"Config hash: {cfg_hash}")
    print(f"Checks in universe config: {len(specs)}")
    print(f"Membership rows (from Layer 2 path): {int(len(membership))}")
    print(f"Output root: {output_root}")
    print(f"Manifest: {manifest_path}")

    return manifest


def main() -> None:
    args = parse_args()
    run_demo_layer4_config(args)


if __name__ == "__main__":
    main()
