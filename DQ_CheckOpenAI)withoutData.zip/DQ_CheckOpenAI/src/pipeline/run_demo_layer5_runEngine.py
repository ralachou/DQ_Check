from __future__ import annotations

import argparse
import json
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import pandas as pd

from data.synthetic import write_demo_datasets
from data_access.parquet_repository import ParquetTimeSeriesRepository
from engine.run_engine import RunEngine, RunRequest

PROJECT_ROOT = Path(__file__).resolve().parents[2]


def _write_demo_output(df: pd.DataFrame, output_root: Path, name: str, output_format: str) -> list[str]:
    output_root.mkdir(parents=True, exist_ok=True)
    out: list[str] = []
    if output_format in {"parquet", "both"}:
        p = output_root / f"{name}.parquet"
        df.to_parquet(p, index=False)
        out.append(str(p))
    if output_format in {"excel", "both"}:
        p = output_root / f"{name}.xlsx"
        try:
            df.to_excel(p, index=False)
        except ImportError as exc:  # pragma: no cover
            raise RuntimeError("Excel output requires openpyxl. Install with: pip install openpyxl") from exc
        out.append(str(p))
    return out


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run Advanced DQ Checks on RF Layer 5 RunEngine demo.")
    parser.add_argument("--config-path", default=str(PROJECT_ROOT / "configs" / "model_catalog.yaml"))
    parser.add_argument("--universe-name", default="CP_RATE_CORP")
    parser.add_argument("--start-date", default="2024-01-01")
    parser.add_argument("--end-date", default="2024-12-31")
    parser.add_argument("--business-date", default="2024-12-31")
    parser.add_argument("--raw-path", default=str(PROJECT_ROOT / "data" / "raw"))
    parser.add_argument("--processed-path", default=str(PROJECT_ROOT / "data" / "processed"))
    parser.add_argument("--artifact-root", default=str(PROJECT_ROOT / "data" / "artifacts" / "normalization"))
    parser.add_argument("--num-factors", type=int, default=300)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--snapshot-days", type=int, default=2)
    parser.add_argument("--run-id", default="", help="Optional explicit run_id. If omitted, a timestamped run_id is generated.")
    parser.add_argument(
        "--incremental",
        action=argparse.BooleanOptionalAction,
        default=False,
        help="Enable incremental mode in RunEngine.",
    )
    parser.add_argument(
        "--output-format",
        default="both",
        choices=["parquet", "excel", "both"],
        help="Demo artifact output format.",
    )
    parser.add_argument(
        "--generate-demo-data",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="Generate synthetic data before running Layer 5 demo.",
    )
    return parser.parse_args()


def run_demo_layer5_runengine(args: argparse.Namespace) -> dict[str, Any]:
    raw_path = Path(args.raw_path)
    processed_path = Path(args.processed_path)
    business_date = str(pd.to_datetime(args.business_date).date())

    if args.generate_demo_data:
        write_demo_datasets(
            raw_path=raw_path,
            processed_path=processed_path,
            start_date=args.start_date,
            end_date=args.end_date,
            num_factors=args.num_factors,
            seed=args.seed,
            snapshot_days=args.snapshot_days,
        )

    run_id = args.run_id.strip() if args.run_id else ""
    if not run_id:
        run_id = f"layer5_demo_{datetime.now(UTC).strftime('%Y%m%d_%H%M%S')}"

    repo = ParquetTimeSeriesRepository(base_path=raw_path, write_base_path=processed_path)
    engine = RunEngine(repository=repo, artifact_root=args.artifact_root)
    run_out = engine.run(
        RunRequest(
            run_id=run_id,
            universe_name=args.universe_name,
            start_date=args.start_date,
            end_date=args.end_date,
            business_date=business_date,
            config_path=args.config_path,
            incremental=bool(args.incremental),
        )
    )

    results = run_out["results"].copy()
    audit_log = run_out["audit_log"].copy()

    summary_by_check = (
        results.groupby(["check_id", "backend", "family"], as_index=False)
        .agg(
            row_count=("date", "count"),
            alert_count=("flag", "sum"),
            critical_count=("severity", lambda s: int((s == "Critical").sum())),
            max_norm_score=("norm_score", "max"),
        )
        .sort_values(["alert_count", "max_norm_score"], ascending=[False, False])
    )
    summary_by_action = (
        results.groupby("recommended_action", as_index=False)
        .agg(
            row_count=("date", "count"),
            mean_confidence=("confidence_estimate", "mean"),
        )
        .sort_values("row_count", ascending=False)
    )
    severity_breakdown = (
        results.groupby("severity", as_index=False)
        .agg(
            row_count=("date", "count"),
            flagged=("flag", "sum"),
        )
        .sort_values("row_count", ascending=False)
    )

    flagged_preview = (
        results[results["flag"]]
        .sort_values(["severity", "norm_score"], ascending=[False, False])
        .head(1000)
        .reset_index(drop=True)
    )
    if flagged_preview.empty:
        flagged_preview = results.sort_values("norm_score", ascending=False).head(1000).reset_index(drop=True)

    output_root = (
        processed_path
        / "layer5_run_engine_demo"
        / f"business_date={business_date}"
        / f"universe_name={args.universe_name}"
        / f"run_id={run_id}"
    )
    saved_files = {
        "results_preview": _write_demo_output(results.head(5000), output_root, "dq_results_preview", args.output_format),
        "summary_by_check": _write_demo_output(summary_by_check, output_root, "summary_by_check", args.output_format),
        "summary_by_action": _write_demo_output(summary_by_action, output_root, "summary_by_action", args.output_format),
        "severity_breakdown": _write_demo_output(severity_breakdown, output_root, "severity_breakdown", args.output_format),
        "flagged_preview": _write_demo_output(flagged_preview, output_root, "flagged_preview", args.output_format),
        "audit_log": _write_demo_output(audit_log, output_root, "audit_log", args.output_format),
    }

    audit_row = audit_log.iloc[0].to_dict() if not audit_log.empty else {}
    manifest = {
        "layer": "Layer 5 - Run Engine / Orchestrator",
        "run_id": run_id,
        "universe_name": args.universe_name,
        "config_path": str(Path(args.config_path).resolve()),
        "inputs": {
            "start_date": args.start_date,
            "end_date": args.end_date,
            "business_date": business_date,
            "incremental": bool(args.incremental),
            "generate_demo_data": bool(args.generate_demo_data),
            "num_factors": int(args.num_factors),
            "snapshot_days": int(args.snapshot_days),
        },
        "run_engine_metrics": audit_row,
        "outputs": {
            "output_root": str(output_root),
            "saved_files": saved_files,
            "dq_results_rows": int(len(results)),
            "dq_alert_rows": int(results["flag"].sum()) if "flag" in results.columns else 0,
        },
    }
    manifest_path = output_root / "manifest.json"
    manifest_path.write_text(json.dumps(manifest, indent=2), encoding="utf-8")

    print("=== Layer 5 RunEngine Demo Summary ===")
    print(f"Run ID: {run_id}")
    print(f"Universe: {args.universe_name}")
    print(f"Business date: {business_date}")
    print(f"DQ result rows: {len(results):,}")
    print(f"Flagged rows: {int(results['flag'].sum()) if 'flag' in results.columns else 0:,}")
    print(f"Output root: {output_root}")
    print(f"Manifest: {manifest_path}")

    return manifest


def main() -> None:
    args = parse_args()
    run_demo_layer5_runengine(args)


if __name__ == "__main__":
    main()
