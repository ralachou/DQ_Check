from __future__ import annotations

import argparse
from pathlib import Path
from typing import Any

import dash
import dash_ag_grid as dag
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from dash import Dash, Input, Output, State, dcc, html

PROJECT_ROOT = Path(__file__).resolve().parents[2]


def _normalize_business_dates(business_date: str | list[str] | tuple[str, ...] | None) -> list[str]:
    if business_date is None:
        return []
    if isinstance(business_date, (list, tuple)):
        vals = business_date
    else:
        vals = [business_date]
    out: list[str] = []
    for v in vals:
        if v is None:
            continue
        text = str(v).strip()
        if not text:
            continue
        out.append(str(pd.to_datetime(text).normalize().date()))
    return sorted(set(out))


def _read_parquet_dir(path: str | Path, business_date: str | list[str] | tuple[str, ...] | None = None) -> pd.DataFrame:
    root = Path(path)
    if not root.exists():
        return pd.DataFrame()
    business_dates = _normalize_business_dates(business_date)
    filters = None
    if business_dates:
        if len(business_dates) == 1:
            filters = [("business_date", "==", business_dates[0])]
        else:
            filters = [("business_date", "in", business_dates)]
    # Preferred path: read as a partitioned dataset so partition keys
    # (e.g., run_id/universe_name/check_id) are materialized as columns.
    try:
        if filters is None:
            df = pd.read_parquet(root)
        else:
            df = pd.read_parquet(root, filters=filters)
        if not df.empty:
            return df
    except Exception:
        pass

    files: list[Path] = []
    if business_dates:
        for bd in business_dates:
            part_root = root / f"business_date={bd}"
            if part_root.exists():
                files.extend(part_root.rglob("*.parquet"))
        if not files:
            files = list(root.rglob("*.parquet"))
    else:
        files = list(root.rglob("*.parquet"))
    if not files:
        return pd.DataFrame()

    parts = []
    for f in files:
        part = pd.read_parquet(f)
        # Fallback path: recover hive-style partition columns from the path.
        rel_parts = f.relative_to(root).parts[:-1]
        for segment in rel_parts:
            if "=" in segment:
                key, value = segment.split("=", 1)
                if key and key not in part.columns:
                    part[key] = value
        if business_dates and "business_date" in part.columns:
            keep = set(business_dates)
            part = part[pd.to_datetime(part["business_date"], errors="coerce").dt.strftime("%Y-%m-%d").isin(keep)]
        parts.append(part)
    if not parts:
        return pd.DataFrame()
    return pd.concat(parts, ignore_index=True)


def load_data(
    results_path: str,
    raw_path: str,
    membership_path: str,
    business_date: str | list[str] | tuple[str, ...] | None = None,
) -> dict[str, pd.DataFrame]:
    business_dates = _normalize_business_dates(business_date)
    dq_results = _read_parquet_dir(results_path, business_dates)
    timeseries_raw = _read_parquet_dir(raw_path, business_dates)
    membership = _read_parquet_dir(membership_path, business_dates)
    for df in [dq_results, timeseries_raw, membership]:
        if "date" in df.columns:
            df["date"] = pd.to_datetime(df["date"])
        if "business_date" in df.columns:
            df["business_date"] = pd.to_datetime(df["business_date"]).dt.normalize()
            if business_dates:
                keep_ts = {pd.to_datetime(v).normalize() for v in business_dates}
                df.drop(df.index[~df["business_date"].isin(keep_ts)], inplace=True)
    return {"dq_results": dq_results, "timeseries_raw": timeseries_raw, "membership": membership}


def _empty_fig(title: str) -> go.Figure:
    fig = go.Figure()
    fig.update_layout(title=title, template="plotly_white", xaxis={"visible": False}, yaxis={"visible": False})
    return fig


def create_app(data: dict[str, pd.DataFrame]) -> Dash:
    dq_results = data["dq_results"]
    timeseries_raw = data["timeseries_raw"]
    membership = data["membership"]
    asset_classes = sorted(membership.get("rf_level1", pd.Series(dtype=str)).dropna().unique().tolist())
    universes = sorted(dq_results.get("universe_name", pd.Series(dtype=str)).dropna().unique().tolist())
    families = sorted(dq_results.get("family", pd.Series(dtype=str)).dropna().unique().tolist())
    severities = ["Low", "Med", "High", "Critical"]

    app = Dash(__name__)
    app.layout = html.Div(
        [
            html.H2("Advanced DQ Checks on RF"),
            dcc.Store(id="store-state", data={"selected_risk_factor_id": None}),
            html.Div(
                [
                    dcc.Dropdown(id="filter-asset-class", options=[{"label": x, "value": x} for x in asset_classes], multi=True, placeholder="Asset class"),
                    dcc.Dropdown(id="filter-universe", options=[{"label": x, "value": x} for x in universes], multi=True, placeholder="Universe"),
                    dcc.Dropdown(id="filter-family", options=[{"label": x, "value": x} for x in families], multi=True, placeholder="Model family"),
                    dcc.Dropdown(id="filter-severity", options=[{"label": x, "value": x} for x in severities], multi=True, placeholder="Severity"),
                    dcc.DatePickerRange(id="filter-date-range"),
                ],
                style={"display": "grid", "gridTemplateColumns": "repeat(5, minmax(160px, 1fr))", "gap": "8px", "marginBottom": "12px"},
            ),
            dcc.Tabs(
                id="tabs-main",
                value="tab-summary",
                children=[
                    dcc.Tab(
                        label="Summary",
                        value="tab-summary",
                        children=[
                            html.Div(id="summary-kpis", style={"display": "grid", "gridTemplateColumns": "repeat(4, 1fr)", "gap": "8px", "margin": "8px 0"}),
                            dcc.Graph(id="summary-alerts-over-time"),
                            dcc.Graph(id="summary-breakdown"),
                            dcc.Graph(id="summary-heatmap"),
                        ],
                    ),
                    dcc.Tab(
                        label="Hierarchy Drilldown",
                        value="tab-drilldown",
                        children=[
                            dag.AgGrid(
                                id="drilldown-tree",
                                columnDefs=[
                                    {"field": "hierarchy", "headerName": "Hierarchy"},
                                    {"field": "risk_factor_id"},
                                    {"field": "rf_level1"},
                                    {"field": "rf_level2"},
                                    {"field": "rf_level3"},
                                    {"field": "rf_level4"},
                                    {"field": "rf_level5"},
                                ],
                                rowData=[],
                                defaultColDef={"flex": 1, "sortable": True, "filter": True, "resizable": True},
                                dashGridOptions={
                                    "treeData": True,
                                    "animateRows": True,
                                    "getDataPath": {"function": "getDataPath(params.data)"},
                                    "autoGroupColumnDef": {"headerName": "Hierarchy", "minWidth": 280},
                                    "rowSelection": "single",
                                },
                                style={"height": 360},
                            ),
                            dcc.Graph(id="drilldown-series"),
                            dag.AgGrid(
                                id="drilldown-issues",
                                columnDefs=[
                                    {"field": "date"},
                                    {"field": "check_id"},
                                    {"field": "raw_score"},
                                    {"field": "norm_score"},
                                    {"field": "severity"},
                                    {"field": "reason_code"},
                                ],
                                rowData=[],
                                defaultColDef={"flex": 1, "sortable": True, "filter": True, "resizable": True},
                                style={"height": 280},
                            ),
                            dcc.Graph(id="drilldown-model-overlay"),
                        ],
                    ),
                    dcc.Tab(
                        label="Model Comparison",
                        value="tab-model-compare",
                        children=[
                            html.Div(
                                [
                                    dcc.Dropdown(id="compare-models", multi=True, placeholder="Select checks/models"),
                                    dcc.DatePickerRange(id="compare-date-range"),
                                ],
                                style={"display": "grid", "gridTemplateColumns": "2fr 1fr", "gap": "8px", "margin": "8px 0"},
                            ),
                            dag.AgGrid(
                                id="compare-ranked",
                                columnDefs=[
                                    {"field": "risk_factor_id"},
                                    {"field": "check_id"},
                                    {"field": "max_norm_score"},
                                    {"field": "max_severity"},
                                    {"field": "alerts"},
                                ],
                                rowData=[],
                                defaultColDef={"flex": 1, "sortable": True, "filter": True, "resizable": True},
                                style={"height": 320},
                            ),
                            dcc.Graph(id="compare-overlap"),
                            dcc.Graph(id="compare-severity-dist"),
                        ],
                    ),
                ],
            ),
        ],
        style={"padding": "12px"},
    )

    app.clientside_callback(
        """
        function(rows, state) {
            if (!rows || rows.length === 0) { return window.dash_clientside.no_update; }
            const cur = state || {};
            cur.selected_risk_factor_id = rows[0].risk_factor_id;
            return cur;
        }
        """,
        Output("store-state", "data", allow_duplicate=True),
        Input("drilldown-tree", "selectedRows"),
        State("store-state", "data"),
        prevent_initial_call=True,
    )

    @app.callback(
        Output("store-state", "data", allow_duplicate=True),
        Input("filter-asset-class", "value"),
        Input("filter-universe", "value"),
        Input("filter-family", "value"),
        Input("filter-severity", "value"),
        Input("filter-date-range", "start_date"),
        Input("filter-date-range", "end_date"),
        State("store-state", "data"),
        prevent_initial_call=True,
    )
    def sync_filter_state(
        asset_class_v: list[str] | None,
        universe_v: list[str] | None,
        family_v: list[str] | None,
        severity_v: list[str] | None,
        start_date: str | None,
        end_date: str | None,
        state: dict[str, Any] | None,
    ) -> dict[str, Any]:
        cur = dict(state or {})
        cur["filters"] = {
            "asset_class": asset_class_v or [],
            "universe": universe_v or [],
            "family": family_v or [],
            "severity": severity_v or [],
            "start_date": start_date,
            "end_date": end_date,
        }
        return cur

    @app.callback(
        Output("summary-kpis", "children"),
        Output("summary-alerts-over-time", "figure"),
        Output("summary-breakdown", "figure"),
        Output("summary-heatmap", "figure"),
        Output("drilldown-tree", "rowData"),
        Input("store-state", "data"),
    )
    def refresh_summary(state: dict[str, Any] | None):
        filters = (state or {}).get("filters", {})
        asset_class_v = filters.get("asset_class") or []
        universe_v = filters.get("universe") or []
        family_v = filters.get("family") or []
        severity_v = filters.get("severity") or []
        start_date = filters.get("start_date")
        end_date = filters.get("end_date")
        res = dq_results.copy()
        mem = membership.copy()
        if len(asset_class_v) > 0 and "rf_level1" in mem.columns:
            mem = mem[mem["rf_level1"].isin(asset_class_v)]
            res = res[res["risk_factor_id"].isin(mem["risk_factor_id"])]
        if len(universe_v) > 0 and "universe_name" in res.columns:
            res = res[res["universe_name"].isin(universe_v)]
        if len(family_v) > 0 and "family" in res.columns:
            res = res[res["family"].isin(family_v)]
        if len(severity_v) > 0 and "severity" in res.columns:
            res = res[res["severity"].isin(severity_v)]
        if start_date:
            res = res[res["date"] >= pd.to_datetime(start_date)]
        if end_date:
            res = res[res["date"] <= pd.to_datetime(end_date)]

        total_series = int(mem["risk_factor_id"].nunique()) if not mem.empty else 0
        total_alerts = int(res["flag"].sum()) if "flag" in res.columns else 0
        critical_alerts = int(((res["severity"] == "Critical") & (res["flag"])).sum()) if "severity" in res.columns else 0
        checks_covered = int(res["check_id"].nunique()) if "check_id" in res.columns else 0
        kpis = [
            html.Div([html.B("Total Series"), html.Div(f"{total_series:,}")], style={"border": "1px solid #ddd", "padding": "8px"}),
            html.Div([html.B("Alerts"), html.Div(f"{total_alerts:,}")], style={"border": "1px solid #ddd", "padding": "8px"}),
            html.Div([html.B("Critical"), html.Div(f"{critical_alerts:,}")], style={"border": "1px solid #ddd", "padding": "8px"}),
            html.Div([html.B("Checks"), html.Div(f"{checks_covered:,}")], style={"border": "1px solid #ddd", "padding": "8px"}),
        ]

        if res.empty:
            return kpis, _empty_fig("Alerts Over Time"), _empty_fig("Breakdown"), _empty_fig("Asset Class x Currency"), []

        alerts_ts = res[res["flag"]].groupby("date", as_index=False).size().rename(columns={"size": "alerts"})
        fig_alerts = px.line(alerts_ts, x="date", y="alerts", title="Alerts Over Time")

        if "rf_level1" not in res.columns and not mem.empty:
            res = res.merge(mem[["risk_factor_id", "rf_level1", "rf_level2", "rf_level3", "rf_level4", "rf_level5"]], on="risk_factor_id", how="left")

        breakdown = (
            res[res["flag"]]
            .groupby(["rf_level1", "family"], as_index=False)
            .size()
            .rename(columns={"size": "alerts"})
        )
        fig_breakdown = px.bar(breakdown, x="rf_level1", y="alerts", color="family", barmode="group", title="Alert Breakdown")

        heat = (
            res[res["flag"]]
            .groupby(["rf_level1", "rf_level2"], as_index=False)
            .size()
            .rename(columns={"size": "alerts"})
        )
        fig_heat = px.density_heatmap(heat, x="rf_level1", y="rf_level2", z="alerts", title="Alerts Heatmap (Asset Class x Currency)")

        tree_src = mem.copy()
        if not tree_src.empty:
            tree_src["hierarchy"] = tree_src.apply(
                lambda r: [str(r.get("rf_level1", "NA")), str(r.get("rf_level2", "NA")), str(r.get("rf_level3", "NA")), str(r.get("rf_level4", "NA")), str(r.get("rf_level5", "NA")), str(r.get("risk_factor_id"))],
                axis=1,
            )
        return kpis, fig_alerts, fig_breakdown, fig_heat, tree_src.to_dict("records")

    @app.callback(
        Output("drilldown-series", "figure"),
        Output("drilldown-issues", "rowData"),
        Output("drilldown-model-overlay", "figure"),
        Input("store-state", "data"),
    )
    def refresh_drilldown(state: dict[str, Any]):
        rf_id = (state or {}).get("selected_risk_factor_id")
        if not rf_id:
            return _empty_fig("Select a risk factor from the tree"), [], _empty_fig("Model overlay")
        ts = timeseries_raw[timeseries_raw["risk_factor_id"] == rf_id].sort_values("date")
        issues = dq_results[(dq_results["risk_factor_id"] == rf_id) & (dq_results["flag"])].sort_values("date")
        if ts.empty:
            return _empty_fig(f"No time series for {rf_id}"), issues.to_dict("records"), _empty_fig("Model overlay")
        fig_ts = go.Figure()
        fig_ts.add_trace(go.Scatter(x=ts["date"], y=ts["value"], mode="lines", name="value"))
        if not issues.empty:
            ts_join = ts.merge(issues[["date", "check_id", "severity", "norm_score"]], on="date", how="inner")
            fig_ts.add_trace(
                go.Scatter(
                    x=ts_join["date"],
                    y=ts_join["value"],
                    mode="markers",
                    marker={"size": 7, "color": ts_join["norm_score"], "colorscale": "Reds", "showscale": True},
                    text=ts_join["check_id"].astype(str) + " | " + ts_join["severity"].astype(str),
                    name="flags",
                )
            )
        fig_ts.update_layout(template="plotly_white", title=f"Time Series with Flags: {rf_id}")

        overlay = dq_results[dq_results["risk_factor_id"] == rf_id].copy()
        if overlay.empty:
            return fig_ts, issues.to_dict("records"), _empty_fig("Model overlay")
        fig_overlay = px.scatter(
            overlay,
            x="date",
            y="norm_score",
            color="check_id",
            symbol="severity",
            title=f"Model Comparison Overlay: {rf_id}",
        )
        return fig_ts, issues.to_dict("records"), fig_overlay

    @app.callback(
        Output("compare-models", "options"),
        Output("compare-ranked", "rowData"),
        Output("compare-overlap", "figure"),
        Output("compare-severity-dist", "figure"),
        Input("compare-models", "value"),
        Input("compare-date-range", "start_date"),
        Input("compare-date-range", "end_date"),
    )
    def refresh_model_compare(selected_models: list[str] | None, start_date: str | None, end_date: str | None):
        res = dq_results.copy()
        if start_date:
            res = res[res["date"] >= pd.to_datetime(start_date)]
        if end_date:
            res = res[res["date"] <= pd.to_datetime(end_date)]
        model_options = [{"label": m, "value": m} for m in sorted(res.get("check_id", pd.Series(dtype=str)).dropna().unique().tolist())]
        if selected_models:
            res = res[res["check_id"].isin(selected_models)]
        flagged = res[res["flag"]] if "flag" in res.columns else pd.DataFrame()
        if flagged.empty:
            return model_options, [], _empty_fig("Overlap"), _empty_fig("Severity Distribution")

        ranked = (
            flagged.groupby(["risk_factor_id", "check_id"], as_index=False)
            .agg(max_norm_score=("norm_score", "max"), max_severity=("severity", "max"), alerts=("date", "count"))
            .sort_values("max_norm_score", ascending=False)
            .head(500)
        )

        overlap = (
            flagged.groupby(["date", "check_id"], as_index=False)["risk_factor_id"]
            .nunique()
            .rename(columns={"risk_factor_id": "flagged_series"})
        )
        fig_overlap = px.line(overlap, x="date", y="flagged_series", color="check_id", title="Model Overlap Through Time")

        sev = (
            flagged.groupby(["check_id", "severity"], as_index=False)
            .size()
            .rename(columns={"size": "count"})
        )
        fig_sev = px.bar(sev, x="check_id", y="count", color="severity", title="Severity Distribution by Model")

        return model_options, ranked.to_dict("records"), fig_overlap, fig_sev

    return app


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run Dash UI for Advanced DQ Checks on RF.")
    parser.add_argument("--results-path", default=str(PROJECT_ROOT / "data" / "processed" / "dq_results"))
    parser.add_argument("--raw-path", default=str(PROJECT_ROOT / "data" / "raw" / "timeseries_raw"))
    parser.add_argument("--membership-path", default=str(PROJECT_ROOT / "data" / "processed" / "universe_membership"))
    parser.add_argument("--business-date", default="", help="Optional business_date filter (YYYY-MM-DD) applied at load time.")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8050)
    parser.add_argument("--debug", action="store_true")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    data = load_data(
        args.results_path,
        args.raw_path,
        args.membership_path,
        business_date=args.business_date or None,
    )
    app = create_app(data)
    app.run(host=args.host, port=args.port, debug=args.debug)


if __name__ == "__main__":
    main()
