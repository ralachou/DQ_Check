﻿from __future__ import annotations

import argparse
import os
from pathlib import Path
from typing import Any

import dash
import dash_ag_grid as dag
import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import yaml
from dash import Dash, Input, Output, State, dcc, html

from ui.app import PROJECT_ROOT, load_data

RF_LEVELS = ["rf_level1", "rf_level2", "rf_level3", "rf_level4", "rf_level5"]
SEV_MAP = {"Low": 0, "Med": 1, "High": 2, "Critical": 3}
REV_SEV = {0: "Low", 1: "Med", 2: "High", 3: "Critical"}


def _empty_fig(title: str) -> go.Figure:
    fig = go.Figure()
    fig.update_layout(title=title, template="plotly_white", xaxis={"visible": False}, yaxis={"visible": False})
    return fig


def _sev_rank(s: pd.Series) -> pd.Series:
    return s.map(SEV_MAP).fillna(0).astype(int)


def _rank_to_sev(v: int | float) -> str:
    return REV_SEV.get(int(v), "Low")


def _norm_regime(v: Any) -> str:
    t = str(v or "").lower().strip()
    if t in {"stress", "high_vol", "crisis"}:
        return "stress"
    if t in {"elevated", "watch"}:
        return "elevated"
    return "normal"


def _read_yaml(path: str | Path | None) -> dict[str, Any]:
    if not path:
        return {}
    p = Path(path)
    if not p.exists():
        return {}
    with p.open("r", encoding="utf-8") as fh:
        data = yaml.safe_load(fh) or {}
    return data if isinstance(data, dict) else {}


def _load_triage_labels(path: str | Path | None) -> pd.DataFrame:
    if not path:
        return pd.DataFrame()
    p = Path(path)
    if not p.exists():
        return pd.DataFrame()
    try:
        if p.suffix.lower() == ".csv":
            out = pd.read_csv(p)
        else:
            out = pd.read_parquet(p)
        if "timestamp" in out.columns:
            out["timestamp"] = pd.to_datetime(out["timestamp"], errors="coerce")
        if "date" in out.columns:
            out["date"] = pd.to_datetime(out["date"], errors="coerce")
        return out
    except Exception:
        return pd.DataFrame()


def _persist_triage_labels(path: str | Path | None, rows: list[dict[str, Any]]) -> None:
    if not path:
        return
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    out = pd.DataFrame(rows)
    if out.empty:
        return
    if "timestamp" in out.columns:
        out["timestamp"] = pd.to_datetime(out["timestamp"], errors="coerce")
    if "date" in out.columns:
        out["date"] = pd.to_datetime(out["date"], errors="coerce")
    if p.suffix.lower() == ".csv":
        out.to_csv(p, index=False)
    else:
        out.to_parquet(p, index=False)


def _regime_windows(cfg: dict[str, Any]) -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []
    for row in cfg.get("globals", {}).get("regime_windows", []) or []:
        s = pd.to_datetime(row.get("start_date"), errors="coerce")
        e = pd.to_datetime(row.get("end_date"), errors="coerce")
        if pd.notna(s) and pd.notna(e):
            out.append({"id": str(row.get("id", "regime")), "start": s.normalize(), "end": e.normalize(), "tag": _norm_regime(row.get("regime_tag"))})
    return out


def _event_calendar(cfg: dict[str, Any]) -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []
    for row in cfg.get("triage", {}).get("event_calendar", []) or []:
        d = pd.to_datetime(row.get("date") or row.get("event_date"), errors="coerce")
        if pd.notna(d):
            out.append({"date": d.normalize(), "label": str(row.get("type", row.get("name", "Event")))})
    return out


def _hierarchy_cols(asset: str) -> list[str]:
    ac = str(asset or "").upper()
    if ac.startswith("IR_") or "TREASURY" in ac:
        return ["rf_level1", "rf_level2", "rf_level3", "tenor_bucket", "risk_factor_id"]
    if ac.startswith("CP_"):
        return ["rf_level1", "rating", "rf_level3", "risk_factor_id"]
    if ac.startswith("EQ_"):
        return ["rf_level1", "rf_level3", "rf_level2", "risk_factor_id"]
    if ac.startswith("FX_"):
        return ["rf_level1", "rf_level3", "rf_level5", "risk_factor_id"]
    return ["rf_level1", "universe_name", "risk_factor_id"]


def _ensure_data(data: dict[str, pd.DataFrame]) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    dq = data["dq_results"].copy()
    ts = data["timeseries_raw"].copy()
    mem = data["membership"].copy()

    for c in RF_LEVELS:
        if c not in mem.columns:
            mem[c] = "NA"
    for c in ["universe_name", "vendor", "rating", "tenor_bucket"]:
        if c not in mem.columns:
            mem[c] = "NA"

    if "date" in dq.columns:
        dq["date"] = pd.to_datetime(dq["date"], errors="coerce")
    if "date" in ts.columns:
        ts["date"] = pd.to_datetime(ts["date"], errors="coerce")
    dq["date_norm"] = pd.to_datetime(dq.get("date"), errors="coerce").dt.normalize()
    ts["date_norm"] = pd.to_datetime(ts.get("date"), errors="coerce").dt.normalize()

    if "flag" not in dq.columns:
        dq["flag"] = False
    dq["flag"] = dq["flag"].fillna(False).astype(bool)

    if "severity" not in dq.columns:
        dq["severity"] = "Low"
    dq["severity"] = dq["severity"].astype(str)
    dq["severity_rank"] = _sev_rank(dq["severity"])

    if "norm_score" not in dq.columns:
        dq["norm_score"] = 0.0
    dq["norm_score"] = pd.to_numeric(dq["norm_score"], errors="coerce").fillna(0.0)

    if "family" not in dq.columns:
        dq["family"] = "unknown"
    if "check_id" not in dq.columns:
        dq["check_id"] = "unknown"
    if "reason_code" not in dq.columns:
        dq["reason_code"] = "NA"
    if "peer_confirmed" not in dq.columns:
        dq["peer_confirmed"] = False
    dq["regime_bucket"] = dq.get("regime_tag", "normal").map(_norm_regime)

    if "rf_level1" not in dq.columns and not mem.empty:
        join_cols = ["risk_factor_id"] + [c for c in RF_LEVELS + ["universe_name", "vendor", "rating", "tenor_bucket"] if c in mem.columns]
        dq = dq.merge(mem[join_cols].drop_duplicates(), on="risk_factor_id", how="left")

    return dq, ts, mem


def _leaf_paths(mem: pd.DataFrame) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    for _, r in mem.iterrows():
        cols = _hierarchy_cols(str(r.get("rf_level1", "")))
        path = []
        for c in cols:
            if c == "risk_factor_id":
                path.append(str(r.get("risk_factor_id", "NA")))
            else:
                v = r.get(c, "NA")
                path.append(str(v) if pd.notna(v) and str(v) else "NA")
        rec = {"risk_factor_id": str(r.get("risk_factor_id", "")), "hierarchy": path, "path_len": len(path)}
        for i in range(1, 7):
            rec[f"path_{i}"] = path[i - 1] if i <= len(path) else None
        rows.append(rec)
    return pd.DataFrame(rows)

def _latest_date(df: pd.DataFrame) -> pd.Timestamp:
    if df.empty:
        return pd.Timestamp.utcnow().normalize()
    d = pd.to_datetime(df.get("date_norm"), errors="coerce").max()
    return pd.Timestamp(d).normalize() if pd.notna(d) else pd.Timestamp.utcnow().normalize()


def _branch_members(mem: pd.DataFrame, branch_path: list[str]) -> pd.Series:
    if not branch_path:
        return mem["risk_factor_id"].astype(str)
    p = _leaf_paths(mem)
    key = tuple(str(x) for x in branch_path)

    def prefix(v: list[str]) -> bool:
        t = tuple(str(x) for x in v[: len(key)])
        return t == key

    return p[p["hierarchy"].map(prefix)]["risk_factor_id"].astype(str)


def _tree_rows(mem: pd.DataFrame, latest_flags: pd.DataFrame, flags_30d: pd.DataFrame) -> list[dict[str, Any]]:
    p = _leaf_paths(mem)
    if p.empty:
        return []

    lf = pd.DataFrame(columns=["risk_factor_id", "flagged", "critical", "worst_rank"])
    if not latest_flags.empty:
        lf = latest_flags.groupby("risk_factor_id", as_index=False).agg(
            flagged=("flag", "max"),
            critical=("severity", lambda s: (s == "Critical").any()),
            worst_rank=("severity_rank", "max"),
        )
    leaf = p.merge(lf, on="risk_factor_id", how="left")
    leaf["flagged"] = leaf["flagged"].fillna(False).astype(bool)
    leaf["critical"] = leaf["critical"].fillna(False).astype(bool)
    leaf["worst_rank"] = pd.to_numeric(leaf["worst_rank"], errors="coerce").fillna(0).astype(int)

    latest = _latest_date(latest_flags)
    idx = pd.date_range(latest - pd.Timedelta(days=29), latest, freq="D")

    t = pd.DataFrame(columns=["risk_factor_id", "date_norm", "cnt"])
    if not flags_30d.empty:
        t = flags_30d.groupby(["risk_factor_id", "date_norm"], as_index=False).size().rename(columns={"size": "cnt"})
    t = t.merge(leaf[["risk_factor_id", "path_1", "path_2", "path_3", "path_4", "path_5", "path_6"]], on="risk_factor_id", how="left")

    out: list[dict[str, Any]] = []
    max_depth = int(leaf["path_len"].max()) if not leaf.empty else 1

    for depth in range(1, max_depth):
        cols = [f"path_{i}" for i in range(1, depth + 1)]
        node = leaf[leaf[f"path_{depth}"].notna()]
        if node.empty:
            continue
        agg = node.groupby(cols, as_index=False).agg(
            total_factors=("risk_factor_id", "nunique"),
            flagged=("flagged", "sum"),
            critical=("critical", "sum"),
            worst_rank=("worst_rank", "max"),
        )

        trend_map: dict[tuple[Any, ...], str] = {}
        if not t.empty:
            tr = t[t[f"path_{depth}"].notna()].groupby(cols + ["date_norm"], as_index=False)["risk_factor_id"].nunique().rename(columns={"risk_factor_id": "cnt"})
            for key, g in tr.groupby(cols):
                k = key if isinstance(key, tuple) else (key,)
                vals = (
                    g.groupby("date_norm", as_index=True)["cnt"]
                    .sum()
                    .reindex(idx, fill_value=0)
                    .astype(int)
                    .tolist()
                )
                trend_map[k] = ",".join(str(x) for x in vals)

        for _, r in agg.iterrows():
            k = tuple(r[c] for c in cols)
            f = int(r["flagged"])
            n = int(r["total_factors"])
            out.append(
                {
                    "hierarchy": [str(r[c]) for c in cols],
                    "name": str(r[cols[-1]]),
                    "is_leaf": False,
                    "risk_factor_id": "",
                    "total_factors": n,
                    "flagged": f,
                    "critical": int(r["critical"]),
                    "worst_severity": _rank_to_sev(int(r["worst_rank"])),
                    "flag_rate": round(100.0 * f / n, 2) if n > 0 else 0.0,
                    "trend_30d": trend_map.get(k, ""),
                    "peer_health": round(100.0 * f / n, 2) if n > 0 else 0.0,
                }
            )

    leaf_trend: dict[str, str] = {}
    if not t.empty:
        for rf, g in t.groupby("risk_factor_id"):
            vals = (
                g.groupby("date_norm", as_index=True)["cnt"]
                .sum()
                .reindex(idx, fill_value=0)
                .astype(int)
                .tolist()
            )
            leaf_trend[str(rf)] = ",".join(str(x) for x in vals)

    for _, r in leaf.iterrows():
        out.append(
            {
                "hierarchy": r["hierarchy"],
                "name": str(r["risk_factor_id"]),
                "is_leaf": True,
                "risk_factor_id": str(r["risk_factor_id"]),
                "total_factors": 1,
                "flagged": int(bool(r["flagged"])),
                "critical": int(bool(r["critical"])),
                "worst_severity": _rank_to_sev(int(r["worst_rank"])),
                "flag_rate": float(100.0 if bool(r["flagged"]) else 0.0),
                "trend_30d": leaf_trend.get(str(r["risk_factor_id"]), ""),
                "peer_health": float(100.0 if bool(r["flagged"]) else 0.0),
            }
        )
    return out


def _indicator_status(name: str, value: float | None) -> tuple[str, str, str]:
    if value is None or np.isnan(value):
        return name, "N/A", "#6c757d"
    key = name.lower()
    if key == "vix":
        if value < 20:
            return name, f"{value:.1f} (normal)", "#1a7f37"
        if value < 30:
            return name, f"{value:.1f} (elevated)", "#b26a00"
        return name, f"{value:.1f} (stress)", "#b42318"
    if key == "move":
        if value < 100:
            return name, f"{value:.1f} (normal)", "#1a7f37"
        if value < 140:
            return name, f"{value:.1f} (elevated)", "#b26a00"
        return name, f"{value:.1f} (stress)", "#b42318"
    if value < 80:
        return name, f"{value:.1f} (normal)", "#1a7f37"
    if value < 120:
        return name, f"{value:.1f} (elevated)", "#b26a00"
    return name, f"{value:.1f} (stress)", "#b42318"


def _latest_numeric(df: pd.DataFrame, cols: list[str]) -> float | None:
    for c in cols:
        if c in df.columns:
            s = pd.to_numeric(df[c], errors="coerce").dropna()
            if not s.empty:
                return float(s.iloc[-1])
    return None


def _trend_arrow(cur: int, prev: int) -> str:
    if cur > prev:
        return "? degrading"
    if cur < prev:
        return "? improving"
    return "? flat"


def _action_truth(action: str) -> int | None:
    a = str(action or "").upper()
    if a == "CONFIRM_ISSUE":
        return 1
    if a in {"DISMISS_FALSE_ALARM", "KNOWN_EXPECTED"}:
        return 0
    return None

def create_app(
    data: dict[str, pd.DataFrame],
    config_path: str | Path | None = None,
    triage_path: str | Path | None = None,
    analyst_id: str | None = None,
) -> Dash:
    dq, ts, mem = _ensure_data(data)
    cfg = _read_yaml(config_path)
    regimes = _regime_windows(cfg)
    events = _event_calendar(cfg)

    if analyst_id is None:
        analyst_id = os.getenv("USERNAME", "analyst")

    first_flag = pd.DataFrame(columns=["risk_factor_id", "check_id", "first_flag_date"])
    if not dq.empty:
        first_flag = dq[dq["flag"]].groupby(["risk_factor_id", "check_id"], as_index=False)["date_norm"].min().rename(columns={"date_norm": "first_flag_date"})

    dmin = _latest_date(dq) - pd.Timedelta(days=90)
    dmax = _latest_date(dq)

    assets = sorted(mem.get("rf_level1", pd.Series(dtype=str)).dropna().astype(str).unique().tolist())
    universes = sorted(mem.get("universe_name", pd.Series(dtype=str)).dropna().astype(str).unique().tolist())
    families = sorted(dq.get("family", pd.Series(dtype=str)).dropna().astype(str).unique().tolist())
    checks = sorted(dq.get("check_id", pd.Series(dtype=str)).dropna().astype(str).unique().tolist())
    business_dates: list[str] = []
    for frame in [dq, ts, mem]:
        if "business_date" in frame.columns:
            vals = pd.to_datetime(frame["business_date"], errors="coerce").dropna().dt.strftime("%Y-%m-%d").unique().tolist()
            business_dates.extend(vals)
    business_dates = sorted(set(business_dates))
    default_business_date = business_dates[-1] if business_dates else ""

    triage_df = _load_triage_labels(triage_path)

    app = Dash(__name__)
    app.layout = html.Div(
        [
            html.H2("Advanced DQ Checks on RF - Control Tower (UI v2)"),
            html.Details(
                [
                    html.Summary("Debug State"),
                    html.Pre(id="v2-debug-info", style={"whiteSpace": "pre-wrap", "fontSize": "12px"}),
                ],
                open=False,
            ),
            dcc.Store(
                id="v2-store",
                data={
                    "selected_risk_factor_id": None,
                    "selected_branch_path": [],
                    "filters": {
                        "asset_class": [],
                        "universe": [],
                        "family": [],
                        "severity": [],
                        "business_date": default_business_date,
                        "regime": ["all"],
                        "show_only": "all",
                        "start_date": str(dmin.date()),
                        "end_date": str(dmax.date()),
                    },
                },
            ),
            dcc.Store(id="v2-triage-labels", data=triage_df.to_dict("records") if not triage_df.empty else []),
            dcc.Store(id="v2-peer-date-map", data=[]),
            html.Div(
                [
                    dcc.Dropdown(id="v2-filter-asset", options=[{"label": x, "value": x} for x in assets], multi=True, placeholder="asset_class"),
                    dcc.Dropdown(id="v2-filter-universe", options=[{"label": x, "value": x} for x in universes], multi=True, placeholder="universe"),
                    dcc.Dropdown(id="v2-filter-family", options=[{"label": x, "value": x} for x in families], multi=True, placeholder="check family"),
                    dcc.Dropdown(id="v2-filter-sev", options=[{"label": x, "value": x} for x in ["Low", "Med", "High", "Critical"]], multi=True, placeholder="severity"),
                    dcc.Dropdown(
                        id="v2-filter-business-date",
                        options=[{"label": d, "value": d} for d in business_dates],
                        value=default_business_date if default_business_date else None,
                        multi=False,
                        placeholder="business_date",
                    ),
                    dcc.Dropdown(id="v2-filter-regime", options=[{"label": "All", "value": "all"}, {"label": "Normal", "value": "normal"}, {"label": "Elevated", "value": "elevated"}, {"label": "Stress", "value": "stress"}], value=["all"], multi=True),
                    dcc.Dropdown(id="v2-filter-show-only", options=[{"label": "all", "value": "all"}, {"label": "new_today", "value": "new_today"}, {"label": "persisting", "value": "persisting"}], value="all"),
                    dcc.DatePickerRange(id="v2-filter-range", start_date=str(dmin.date()), end_date=str(dmax.date())),
                ],
                style={"display": "grid", "gridTemplateColumns": "repeat(8,minmax(150px,1fr))", "gap": "8px", "marginBottom": "10px"},
            ),
            dcc.Tabs(
                id="v2-tabs",
                value="tab1",
                children=[
                    dcc.Tab(
                        label="War Room",
                        value="tab1",
                        children=[
                            html.Div(id="v2-regime-banner", style={"border": "1px solid #d0d7de", "padding": "8px"}),
                            html.Div(id="v2-kpis", style={"display": "grid", "gridTemplateColumns": "repeat(5,1fr)", "gap": "8px", "margin": "8px 0"}),
                            dcc.Graph(id="v2-health-matrix"),
                            html.Div([dcc.Graph(id="v2-alert-trend"), dcc.Graph(id="v2-breakdown")], style={"display": "grid", "gridTemplateColumns": "1.2fr 1fr", "gap": "8px"}),
                            html.Div(
                                [
                                    dcc.Graph(id="v2-new-vs-persist"),
                                    dag.AgGrid(
                                        id="v2-top10",
                                        columnDefs=[
                                            {"field": "risk_factor_id"},
                                            {"field": "rf_level1"},
                                            {"field": "family"},
                                            {"field": "worst_severity"},
                                            {"field": "composite_score"},
                                            {"field": "peer_confirmed"},
                                        ],
                                        rowData=[],
                                        defaultColDef={"flex": 1, "sortable": True, "filter": True, "resizable": True},
                                        dashGridOptions={"rowSelection": "single"},
                                        style={"height": 320},
                                    ),
                                ],
                                style={"display": "grid", "gridTemplateColumns": "1fr 1.2fr", "gap": "8px"},
                            ),
                        ],
                    ),
                    dcc.Tab(
                        label="Hierarchy Drilldown",
                        value="tab2",
                        children=[
                            html.Div(
                                [
                                    dag.AgGrid(
                                        id="v2-tree",
                                        columnDefs=[
                                            {"field": "name", "minWidth": 220},
                                            {"field": "total_factors"},
                                            {"field": "flagged"},
                                            {"field": "critical"},
                                            {"field": "worst_severity"},
                                            {"field": "flag_rate"},
                                            {"field": "trend_30d"},
                                            {"field": "peer_health"},
                                        ],
                                        rowData=[],
                                        defaultColDef={"flex": 1, "sortable": True, "filter": True, "resizable": True},
                                        dashGridOptions={"treeData": True, "getDataPath": {"function": "getDataPath(params.data)"}, "autoGroupColumnDef": {"headerName": "Hierarchy", "minWidth": 280}, "rowSelection": "single", "rowBuffer": 30},
                                        style={"height": 520},
                                    ),
                                    html.Div(
                                        [
                                            html.H4("Branch Summary"),
                                            html.Div([dcc.Graph(id="v2-branch-heatmap"), dcc.Graph(id="v2-branch-trend")], style={"display": "grid", "gridTemplateColumns": "1fr 1fr", "gap": "8px"}),
                                            dag.AgGrid(id="v2-branch-top-offenders", columnDefs=[{"field": "risk_factor_id"}, {"field": "worst_severity"}, {"field": "max_norm_score"}, {"field": "check_count"}], rowData=[], defaultColDef={"flex": 1, "sortable": True, "filter": True}, style={"height": 170}),
                                        ]
                                    ),
                                ],
                                style={"display": "grid", "gridTemplateColumns": "1.3fr 1fr", "gap": "8px"},
                            ),
                            html.H4("Risk Factor Detail"),
                            dcc.Checklist(id="v2-overlay-toggle", options=[{"label": "Peer median +/-1s", "value": "peer_band"}, {"label": "Bollinger", "value": "bollinger"}, {"label": "Regime", "value": "regime"}, {"label": "Events", "value": "events"}], value=["peer_band", "bollinger", "regime"], inline=True),
                            html.Div([dcc.Graph(id="v2-series"), dcc.Graph(id="v2-model-overlay")], style={"display": "grid", "gridTemplateColumns": "1fr 1fr", "gap": "8px"}),
                            html.Div(
                                [
                                    dag.AgGrid(
                                        id="v2-issues",
                                        columnDefs=[
                                            {"field": "date"},
                                            {"field": "check_name"},
                                            {"field": "check_family"},
                                            {"field": "raw_score"},
                                            {"field": "norm_score"},
                                            {"field": "threshold"},
                                            {"field": "severity"},
                                            {"field": "reason_code"},
                                            {"field": "explain"},
                                            {"field": "peer_confirmed"},
                                            {"field": "event_proximate"},
                                            {"field": "false_alarm_prob"},
                                            {"field": "flag_id"},
                                        ],
                                        rowData=[],
                                        defaultColDef={"flex": 1, "sortable": True, "filter": True, "resizable": True},
                                        dashGridOptions={"rowSelection": "single"},
                                        style={"height": 260},
                                    ),
                                    html.Div(
                                        [
                                            html.H4("Context"),
                                            html.Div(id="v2-context"),
                                            html.H4("Triage Actions"),
                                            html.Div(
                                                [
                                                    html.Button("Confirm Issue", id="v2-btn-confirm"),
                                                    html.Button("Dismiss (False Alarm)", id="v2-btn-dismiss", style={"marginLeft": "8px"}),
                                                    html.Button("Known/Expected", id="v2-btn-known", style={"marginLeft": "8px"}),
                                                    html.Button("Needs Investigation", id="v2-btn-investigate", style={"marginLeft": "8px"}),
                                                ]
                                            ),
                                            html.H4("Historical Triage"),
                                            dag.AgGrid(id="v2-triage-history", columnDefs=[{"field": "timestamp"}, {"field": "action"}, {"field": "check_id"}, {"field": "severity"}], rowData=[], defaultColDef={"flex": 1, "sortable": True, "filter": True}, style={"height": 180}),
                                        ],
                                        style={"border": "1px solid #d0d7de", "padding": "8px"},
                                    ),
                                ],
                                style={"display": "grid", "gridTemplateColumns": "1.9fr 1fr", "gap": "8px"},
                            ),
                        ],
                    ),
                    dcc.Tab(
                        label="Model Comparison & Outliers Explorer",
                        value="tab3",
                        children=[
                            html.Div([dcc.Dropdown(id="v2-compare-universe", options=[{"label": u, "value": u} for u in universes], placeholder="universe"), dcc.DatePickerRange(id="v2-compare-range", start_date=str(dmin.date()), end_date=str(dmax.date())), dcc.Dropdown(id="v2-compare-models", options=[{"label": c, "value": c} for c in checks], multi=True, placeholder="select 2-4 models"), dcc.Checklist(id="v2-compare-solo", options=[{"label": "Solo flags only", "value": "solo"}], value=[])], style={"display": "grid", "gridTemplateColumns": "1fr 1fr 2fr 1fr", "gap": "8px", "margin": "8px 0"}),
                            dag.AgGrid(id="v2-compare-ranked", columnDefs=[], rowData=[], defaultColDef={"flex": 1, "sortable": True, "filter": True}, dashGridOptions={"rowSelection": "single"}, style={"height": 260}),
                            html.Div([dcc.Graph(id="v2-overlap"), dcc.Graph(id="v2-score-corr")], style={"display": "grid", "gridTemplateColumns": "1fr 1fr", "gap": "8px"}),
                            dag.AgGrid(id="v2-disagreement", columnDefs=[], rowData=[], defaultColDef={"flex": 1, "sortable": True, "filter": True}, style={"height": 220}),
                            html.Div(id="v2-model-metrics", style={"border": "1px solid #d0d7de", "padding": "8px", "marginTop": "8px"}),
                            dcc.Graph(id="v2-model-perf"),
                            html.Details([html.Summary("Severity distribution"), dcc.Graph(id="v2-severity-dist")], open=True),
                            html.Details([html.Summary("Score histogram"), dcc.Graph(id="v2-score-hist")], open=False),
                        ],
                    ),
                    dcc.Tab(
                        label="Peer Group Explorer",
                        value="tab4",
                        children=[
                            html.Div([dcc.Dropdown(id="v2-peer-universe", options=[{"label": u, "value": u} for u in universes], placeholder="universe (optional)"), dcc.Dropdown(id="v2-peer-asset", options=[{"label": x, "value": x} for x in assets], placeholder="asset_class"), dcc.Dropdown(id="v2-peer-group", placeholder="peer group"), dcc.DatePickerRange(id="v2-peer-range", start_date=str(dmin.date()), end_date=str(dmax.date()))], style={"display": "grid", "gridTemplateColumns": "1fr 1fr 1fr 1fr", "gap": "8px", "margin": "8px 0"}),
                            dcc.Slider(id="v2-peer-date-slider", min=0, max=0, step=1, value=0, marks={0: "N/A"}),
                            html.Div([dcc.Graph(id="v2-peer-multiline"), dcc.Graph(id="v2-peer-cross")], style={"display": "grid", "gridTemplateColumns": "1fr 1fr", "gap": "8px"}),
                            dcc.Graph(id="v2-peer-corr"),
                            dag.AgGrid(id="v2-peer-health", columnDefs=[{"field": "peer_group"}, {"field": "member_count"}, {"field": "flagged_pct"}, {"field": "dispersion_mad"}, {"field": "worst_member"}, {"field": "avg_corr"}, {"field": "corr_stability"}], rowData=[], defaultColDef={"flex": 1, "sortable": True, "filter": True}, dashGridOptions={"rowSelection": "single"}, style={"height": 240}),
                            dcc.Graph(id="v2-factor-vs-peer"),
                        ],
                    ),
                ],
            ),
        ],
        style={"padding": "12px"},
    )

    def _apply_filters(state: dict[str, Any] | None) -> tuple[pd.DataFrame, pd.DataFrame]:
        f = (state or {}).get("filters", {})
        r = dq.copy()
        m = mem.copy()
        asset = f.get("asset_class") or []
        universe = f.get("universe") or []
        family = f.get("family") or []
        sev = f.get("severity") or []
        business_date = f.get("business_date")
        regime = f.get("regime") or ["all"]

        if asset:
            m = m[m["rf_level1"].isin(asset)]
            r = r[r["risk_factor_id"].isin(m["risk_factor_id"])]
        if universe:
            if "universe_name" in m.columns:
                m = m[m["universe_name"].isin(universe)]
                r = r[r["risk_factor_id"].isin(m["risk_factor_id"])]
            if "universe_name" in r.columns:
                r = r[r["universe_name"].isin(universe)]
        if family:
            r = r[r["family"].isin(family)]
        if sev:
            r = r[r["severity"].isin(sev)]
        if business_date:
            biz_ts = pd.to_datetime(business_date, errors="coerce")
            if pd.notna(biz_ts):
                if "business_date" in r.columns:
                    r = r[pd.to_datetime(r["business_date"], errors="coerce").dt.normalize() == biz_ts.normalize()]
                if "business_date" in m.columns:
                    m = m[pd.to_datetime(m["business_date"], errors="coerce").dt.normalize() == biz_ts.normalize()]
        if regime and "all" not in regime:
            r = r[r["regime_bucket"].isin(regime)]

        sd = f.get("start_date")
        ed = f.get("end_date")
        if sd:
            r = r[r["date_norm"] >= pd.to_datetime(sd).normalize()]
        if ed:
            r = r[r["date_norm"] <= pd.to_datetime(ed).normalize()]

        show_only = f.get("show_only") or "all"
        if show_only in {"new_today", "persisting"}:
            latest = _latest_date(r)
            keys = r[(r["flag"]) & (r["date_norm"] == latest)][["risk_factor_id", "check_id"]].drop_duplicates()
            keys = keys.merge(first_flag, on=["risk_factor_id", "check_id"], how="left")
            if show_only == "new_today":
                keys = keys[keys["first_flag_date"] == latest]
            else:
                keys = keys[keys["first_flag_date"] < latest]
            r = r.merge(keys[["risk_factor_id", "check_id"]], on=["risk_factor_id", "check_id"], how="inner")

        return r, m

    def _filtered_ts(state: dict[str, Any] | None) -> pd.DataFrame:
        out = ts.copy()
        f = (state or {}).get("filters", {})
        business_date = f.get("business_date")
        if business_date and "business_date" in out.columns:
            biz_ts = pd.to_datetime(business_date, errors="coerce")
            if pd.notna(biz_ts):
                out = out[pd.to_datetime(out["business_date"], errors="coerce").dt.normalize() == biz_ts.normalize()]
        return out

    @app.callback(
        Output("v2-filter-universe", "options"),
        Output("v2-filter-universe", "value"),
        Input("v2-filter-asset", "value"),
        State("v2-filter-universe", "value"),
    )
    def sync_universe_options(asset_vals, current_vals):
        x = mem.copy()
        if asset_vals:
            x = x[x["rf_level1"].isin(asset_vals)]
        vals = sorted(x.get("universe_name", pd.Series(dtype=str)).dropna().astype(str).unique().tolist())
        keep = [v for v in (current_vals or []) if v in vals]
        return [{"label": v, "value": v} for v in vals], keep

    @app.callback(
        Output("v2-store", "data", allow_duplicate=True),
        Input("v2-filter-asset", "value"),
        Input("v2-filter-universe", "value"),
        Input("v2-filter-family", "value"),
        Input("v2-filter-sev", "value"),
        Input("v2-filter-business-date", "value"),
        Input("v2-filter-regime", "value"),
        Input("v2-filter-show-only", "value"),
        Input("v2-filter-range", "start_date"),
        Input("v2-filter-range", "end_date"),
        State("v2-store", "data"),
        prevent_initial_call=True,
    )
    def sync_filters(a, u, f, s, business_date, regime, show_only, start, end, state):
        cur = dict(state or {})
        cur["filters"] = {
            "asset_class": a or [],
            "universe": u or [],
            "family": f or [],
            "severity": s or [],
            "business_date": business_date or "",
            "regime": regime or ["all"],
            "show_only": show_only or "all",
            "start_date": start,
            "end_date": end,
        }
        return cur

    @app.callback(
        Output("v2-store", "data", allow_duplicate=True),
        Input("v2-tree", "selectedRows"),
        State("v2-store", "data"),
        prevent_initial_call=True,
    )
    def sync_tree_selection(rows, state):
        if not rows:
            return dash.no_update
        row = rows[0]
        cur = dict(state or {})
        cur["selected_branch_path"] = row.get("hierarchy", [])
        if row.get("is_leaf") and row.get("risk_factor_id"):
            cur["selected_risk_factor_id"] = row.get("risk_factor_id")
        return cur

    @app.callback(
        Output("v2-store", "data", allow_duplicate=True),
        Output("v2-tabs", "value", allow_duplicate=True),
        Input("v2-health-matrix", "clickData"),
        Input("v2-top10", "selectedRows"),
        Input("v2-compare-ranked", "selectedRows"),
        Input("v2-peer-health", "selectedRows"),
        State("v2-store", "data"),
        prevent_initial_call=True,
    )
    def nav_to_drilldown(heatmap_click, top10_rows, compare_rows, peer_rows, state):
        cur = dict(state or {})
        trig = dash.ctx.triggered_id
        if trig == "v2-health-matrix" and heatmap_click:
            p = heatmap_click.get("points", [{}])[0]
            fam = p.get("x")
            ac = p.get("y")
            filters = dict(cur.get("filters", {}))
            if ac:
                filters["asset_class"] = [ac]
            if fam:
                filters["family"] = [fam]
            cur["filters"] = filters
            cur["selected_branch_path"] = [ac] if ac else []
            return cur, "tab2"
        if trig == "v2-top10" and top10_rows:
            rf = top10_rows[0].get("risk_factor_id")
            if rf:
                cur["selected_risk_factor_id"] = rf
                return cur, "tab2"
        if trig == "v2-compare-ranked" and compare_rows:
            rf = compare_rows[0].get("risk_factor_id")
            if rf:
                cur["selected_risk_factor_id"] = rf
                return cur, "tab2"
        if trig == "v2-peer-health" and peer_rows:
            rf = peer_rows[0].get("selected_factor") or peer_rows[0].get("worst_member")
            if rf:
                cur["selected_risk_factor_id"] = rf
                return cur, "tab2"
        return dash.no_update, dash.no_update

    @app.callback(
        Output("v2-regime-banner", "children"),
        Output("v2-kpis", "children"),
        Output("v2-health-matrix", "figure"),
        Output("v2-alert-trend", "figure"),
        Output("v2-breakdown", "figure"),
        Output("v2-new-vs-persist", "figure"),
        Output("v2-top10", "rowData"),
        Output("v2-tree", "rowData"),
        Output("v2-debug-info", "children"),
        Input("v2-store", "data"),
    )
    def refresh_summary(state):
        r, m = _apply_filters(state)
        if r.empty:
            return "No rows for current filters", [], _empty_fig("DQ Health Matrix"), _empty_fig("Alerts"), _empty_fig("Breakdown"), _empty_fig("New vs Persisting"), [], [], str(state or {})

        latest = _latest_date(r)
        f_today = r[(r["flag"]) & (r["date_norm"] == latest)].copy()

        vix = _latest_numeric(r.sort_values("date_norm"), ["vix", "vix_level", "regime_vix"])
        move = _latest_numeric(r.sort_values("date_norm"), ["move", "move_level", "regime_move"])
        cdx = _latest_numeric(r.sort_values("date_norm"), ["cdx_ig", "cdx_ig_level"])
        if vix is None or move is None or cdx is None:
            stress_ratio = float((f_today["regime_bucket"] == "stress").mean()) if not f_today.empty else 0.0
            vix = 15.0 + 35.0 * stress_ratio if vix is None else vix
            move = 80.0 + 80.0 * stress_ratio if move is None else move
            cdx = 60.0 + 100.0 * stress_ratio if cdx is None else cdx

        cards = []
        for nm, vv in [("VIX", vix), ("MOVE", move), ("CDX IG", cdx)]:
            t, val, color = _indicator_status(nm, vv)
            cards.append(html.Div([html.B(t), html.Div(val)], style={"border": f"2px solid {color}", "padding": "6px", "borderRadius": "4px", "minWidth": "140px"}))
        banner = html.Div([html.Div(f"Business date: {latest.date()}"), html.Div(cards, style={"display": "flex", "gap": "8px", "marginTop": "6px"})])

        keys = f_today[["risk_factor_id", "check_id"]].drop_duplicates().merge(first_flag, on=["risk_factor_id", "check_id"], how="left")
        newf = int((keys["first_flag_date"] == latest).sum())
        pers = int((keys["first_flag_date"] < latest).sum())
        l7 = r[(r["flag"]) & (r["date_norm"] > latest - pd.Timedelta(days=7)) & (r["date_norm"] <= latest)].shape[0]
        p7 = r[(r["flag"]) & (r["date_norm"] > latest - pd.Timedelta(days=14)) & (r["date_norm"] <= latest - pd.Timedelta(days=7))].shape[0]

        kpis = [
            html.Div([html.B("Total Series"), html.Div(f"{int(m['risk_factor_id'].nunique()):,}")], style={"border": "1px solid #d0d7de", "padding": "8px"}),
            html.Div([html.B("Flagged Today"), html.Div(f"{int(f_today.shape[0]):,}")], style={"border": "1px solid #d0d7de", "padding": "8px"}),
            html.Div([html.B("New Flags"), html.Div(f"{newf:,}")], style={"border": "1px solid #d0d7de", "padding": "8px"}),
            html.Div([html.B("Critical"), html.Div(f"{int((f_today['severity'] == 'Critical').sum()):,}")], style={"border": "1px solid #d0d7de", "padding": "8px"}),
            html.Div([html.B("7d Trend"), html.Div(_trend_arrow(l7, p7))], style={"border": "1px solid #d0d7de", "padding": "8px"}),
        ]

        hm = f_today.groupby(["rf_level1", "family"], as_index=False).agg(severity_rank=("severity_rank", "max"), flags=("risk_factor_id", "count"), top_reason=("reason_code", lambda s: s.astype(str).value_counts().index[0] if not s.empty else "NA")) if not f_today.empty else pd.DataFrame()
        fig_hm = _empty_fig("DQ Health Matrix") if hm.empty else px.density_heatmap(
            hm,
            x="family",
            y="rf_level1",
            z="severity_rank",
            hover_data={"flags": True, "top_reason": True},
            color_continuous_scale="YlOrRd",
            title="DQ Health Heatmap Matrix",
        )

        ta = r[r["flag"]].groupby("date_norm", as_index=False).size().rename(columns={"size": "alerts"})
        fig_tr = _empty_fig("Alerts") if ta.empty else px.line(ta, x="date_norm", y="alerts", title="Alerts over time")
        for rw in regimes:
            fig_tr.add_vrect(x0=rw["start"], x1=rw["end"], fillcolor="#f8b4b4" if rw["tag"] == "stress" else "#ffcf99", opacity=0.18, line_width=0, annotation_text=rw["id"], annotation_position="top left")

        b = f_today.groupby(["rf_level1", "severity"], as_index=False).size().rename(columns={"size": "count"}) if not f_today.empty else pd.DataFrame()
        fig_b = _empty_fig("Breakdown") if b.empty else px.bar(b, x="rf_level1", y="count", color="severity", barmode="stack", title="Breakdown by asset class")
        fig_np = px.pie(pd.DataFrame({"type": ["new_today", "persisting"], "count": [newf, pers]}), names="type", values="count", hole=0.45, title="New vs Persisting")

        top_rows = []
        if not f_today.empty:
            top = f_today.groupby("risk_factor_id", as_index=False).agg(max_norm_score=("norm_score", "max"), worst_rank=("severity_rank", "max"), rf_level1=("rf_level1", "first"), family=("family", lambda s: s.mode().iloc[0] if not s.mode().empty else "NA"), peer_confirmed=("peer_confirmed", "max"))
            top["worst_severity"] = top["worst_rank"].map(REV_SEV)
            top["composite_score"] = top["max_norm_score"] + top["worst_rank"] / 3.0
            top_rows = top.sort_values("composite_score", ascending=False).head(10).round(4).to_dict("records")

        f30 = r[(r["flag"]) & (r["date_norm"] >= latest - pd.Timedelta(days=29)) & (r["date_norm"] <= latest)]
        tree = _tree_rows(m, f_today, f30)

        dbg = {
            "filters": (state or {}).get("filters", {}),
            "selected_risk_factor_id": (state or {}).get("selected_risk_factor_id"),
            "selected_branch_path": (state or {}).get("selected_branch_path"),
            "rows_filtered": int(len(r)),
            "members_filtered": int(m["risk_factor_id"].nunique()) if not m.empty else 0,
            "latest_date": str(latest.date()),
            "flags_today": int(len(f_today)),
            "tree_nodes": int(len(tree)),
        }
        return banner, kpis, fig_hm, fig_tr, fig_b, fig_np, top_rows, tree, str(dbg)

    @app.callback(
        Output("v2-triage-labels", "data"),
        Input("v2-btn-confirm", "n_clicks"),
        Input("v2-btn-dismiss", "n_clicks"),
        Input("v2-btn-known", "n_clicks"),
        Input("v2-btn-investigate", "n_clicks"),
        State("v2-store", "data"),
        State("v2-issues", "selectedRows"),
        State("v2-triage-labels", "data"),
        prevent_initial_call=True,
    )
    def save_action(_, __, ___, ____, state, issue_rows, labels):
        action_map = {
            "v2-btn-confirm": "CONFIRM_ISSUE",
            "v2-btn-dismiss": "DISMISS_FALSE_ALARM",
            "v2-btn-known": "KNOWN_EXPECTED",
            "v2-btn-investigate": "NEEDS_INVESTIGATION",
        }
        action = action_map.get(dash.ctx.triggered_id)
        if not action:
            return labels or []

        rf = (state or {}).get("selected_risk_factor_id")
        sel = (issue_rows or [{}])[0]
        row = {
            "timestamp": pd.Timestamp.utcnow(),
            "analyst_id": analyst_id,
            "action": action,
            "risk_factor_id": rf,
            "flag_id": sel.get("flag_id", ""),
            "date": pd.to_datetime(sel.get("date"), errors="coerce"),
            "check_id": sel.get("check_name", sel.get("check_id", "")),
            "severity": sel.get("severity", ""),
        }
        out = list(labels or [])
        out.append(row)
        try:
            _persist_triage_labels(triage_path, out)
        except Exception as exc:
            out.append({"timestamp": pd.Timestamp.utcnow(), "analyst_id": analyst_id, "action": "WRITE_FAILED", "risk_factor_id": rf, "severity": str(exc)})
        return out

    @app.callback(
        Output("v2-branch-heatmap", "figure"),
        Output("v2-branch-trend", "figure"),
        Output("v2-branch-top-offenders", "rowData"),
        Output("v2-series", "figure"),
        Output("v2-issues", "rowData"),
        Output("v2-model-overlay", "figure"),
        Output("v2-context", "children"),
        Output("v2-triage-history", "rowData"),
        Input("v2-store", "data"),
        Input("v2-tree", "selectedRows"),
        Input("v2-overlay-toggle", "value"),
        Input("v2-triage-labels", "data"),
    )
    def refresh_drilldown(state, selected_rows, overlays, triage_labels):
        r, m = _apply_filters(state)
        ts_view = _filtered_ts(state)
        if r.empty:
            return _empty_fig("Branch heatmap"), _empty_fig("Branch trend"), [], _empty_fig("Risk factor"), [], _empty_fig("Model comparison"), "No rows for current filters.", []

        latest = _latest_date(r)
        sel = (selected_rows or [{}])[0]
        path = sel.get("hierarchy") or (state or {}).get("selected_branch_path", [])
        ids = _branch_members(m, [str(x) for x in path])
        if ids.empty:
            ids = m["risk_factor_id"].astype(str)

        b_latest = r[(r["flag"]) & (r["date_norm"] == latest) & (r["risk_factor_id"].isin(ids))]
        b_hist = r[(r["flag"]) & (r["risk_factor_id"].isin(ids)) & (r["date_norm"] >= latest - pd.Timedelta(days=30))]

        bh = b_latest.groupby(["rf_level1", "family"], as_index=False).agg(severity_rank=("severity_rank", "max"), flags=("risk_factor_id", "count")) if not b_latest.empty else pd.DataFrame()
        fig_bh = _empty_fig("Branch Mini Heatmap") if bh.empty else px.density_heatmap(bh, x="family", y="rf_level1", z="severity_rank", title="Branch Mini Heatmap")
        bt = b_hist.groupby("date_norm", as_index=False).size().rename(columns={"size": "alerts"}) if not b_hist.empty else pd.DataFrame()
        fig_bt = _empty_fig("Branch Alerts") if bt.empty else px.line(bt, x="date_norm", y="alerts", title="Branch Alerts Over Time")

        top_off = []
        if not b_latest.empty:
            t = b_latest.groupby("risk_factor_id", as_index=False).agg(max_norm_score=("norm_score", "max"), check_count=("check_id", "nunique"), worst_rank=("severity_rank", "max")).sort_values("max_norm_score", ascending=False).head(15)
            t["worst_severity"] = t["worst_rank"].map(REV_SEV)
            top_off = t[["risk_factor_id", "worst_severity", "max_norm_score", "check_count"]].round(4).to_dict("records")

        rf = (state or {}).get("selected_risk_factor_id")
        if sel.get("is_leaf") and sel.get("risk_factor_id"):
            rf = sel.get("risk_factor_id")
        if not rf:
            return fig_bh, fig_bt, top_off, _empty_fig("Select leaf risk factor"), [], _empty_fig("Model comparison"), "Select a leaf node to load details.", []

        t = ts_view[ts_view["risk_factor_id"] == rf].sort_values("date_norm")
        f = (state or {}).get("filters", {})
        if f.get("start_date"):
            t = t[t["date_norm"] >= pd.to_datetime(f["start_date"]).normalize()]
        if f.get("end_date"):
            t = t[t["date_norm"] <= pd.to_datetime(f["end_date"]).normalize()]

        issues = r[(r["risk_factor_id"] == rf) & (r["flag"])].copy().sort_values(["date_norm", "severity_rank"], ascending=[False, False])

        fig_series = _empty_fig(f"Series: {rf}")
        if not t.empty:
            fig_series = go.Figure()
            fig_series.add_trace(go.Scatter(x=t["date_norm"], y=t["value"], mode="lines", name="value", line={"color": "#274c77"}))
            if not issues.empty:
                j = t.merge(issues[["date_norm", "severity", "norm_score", "check_id"]], on="date_norm", how="inner")
                fig_series.add_trace(go.Scatter(x=j["date_norm"], y=j["value"], mode="markers", marker={"size": 8, "color": j["norm_score"], "colorscale": "Reds", "showscale": True}, text=j["check_id"].astype(str) + " | " + j["severity"].astype(str), name="flags"))

            meta = m[m["risk_factor_id"] == rf]
            if "peer_band" in (overlays or []) and not meta.empty:
                mm = meta.iloc[0]
                peers = m[(m["rf_level1"] == mm["rf_level1"]) & (m["rf_level2"] == mm["rf_level2"]) & (m["rf_level3"] == mm["rf_level3"])]["risk_factor_id"].astype(str)
                p = ts_view[(ts_view["risk_factor_id"].isin(peers)) & (ts_view["date_norm"].isin(t["date_norm"]))]
                if not p.empty:
                    pa = p.groupby("date_norm", as_index=False)["value"].agg(peer_median="median", peer_std="std")
                    jj = t.merge(pa, on="date_norm", how="left")
                    fig_series.add_trace(go.Scatter(x=jj["date_norm"], y=jj["peer_median"], mode="lines", name="peer median", line={"dash": "dash"}))
                    fig_series.add_trace(go.Scatter(x=jj["date_norm"], y=jj["peer_median"] + jj["peer_std"].fillna(0.0), mode="lines", name="peer +1s", line={"dash": "dot"}))
                    fig_series.add_trace(go.Scatter(x=jj["date_norm"], y=jj["peer_median"] - jj["peer_std"].fillna(0.0), mode="lines", name="peer -1s", line={"dash": "dot"}))

            if "bollinger" in (overlays or []):
                rm = t["value"].rolling(20, min_periods=10).mean()
                rs = t["value"].rolling(20, min_periods=10).std().fillna(0.0)
                fig_series.add_trace(go.Scatter(x=t["date_norm"], y=rm + 2.0 * rs, mode="lines", name="boll+2s", line={"dash": "dot"}))
                fig_series.add_trace(go.Scatter(x=t["date_norm"], y=rm - 2.0 * rs, mode="lines", name="boll-2s", line={"dash": "dot"}))

            if "regime" in (overlays or []):
                for rw in regimes:
                    fig_series.add_vrect(x0=rw["start"], x1=rw["end"], fillcolor="#f8b4b4" if rw["tag"] == "stress" else "#ffcf99", opacity=0.15, line_width=0)
            if "events" in (overlays or []):
                for ev in events:
                    fig_series.add_vline(x=ev["date"], line_dash="dot", line_color="#7f1d1d")
                    fig_series.add_annotation(x=ev["date"], y=1.0, yref="paper", text=ev["label"], showarrow=False, yanchor="bottom")

            fig_series.update_layout(template="plotly_white", title=f"Time Series with flags: {rf}")

        model_fig = _empty_fig("Model comparison")
        if not issues.empty:
            model_fig = px.line(issues.sort_values("date_norm"), x="date_norm", y="norm_score", color="check_id", title="Score ribbons and disagreement")

        issue_rows = []
        if not issues.empty:
            tmp = issues.copy()
            tmp["check_name"] = tmp["check_id"]
            tmp["check_family"] = tmp["family"]
            if "false_alarm_probability" in tmp.columns:
                tmp["false_alarm_prob"] = pd.to_numeric(tmp["false_alarm_probability"], errors="coerce").round(4)
            else:
                tmp["false_alarm_prob"] = np.nan
            tmp["event_proximate"] = False
            tmp["flag_id"] = tmp["risk_factor_id"].astype(str) + "|" + tmp["date_norm"].dt.strftime("%Y-%m-%d") + "|" + tmp["check_id"].astype(str)
            if events:
                evd = pd.Series([e["date"] for e in events])
                for i in tmp.index:
                    d = tmp.at[i, "date_norm"]
                    tmp.at[i, "event_proximate"] = bool(((evd - d).abs() <= pd.Timedelta(days=2)).any()) if pd.notna(d) else False
            out = tmp[["date_norm", "check_name", "check_family", "raw_score", "norm_score", "threshold", "severity", "reason_code", "explain", "peer_confirmed", "event_proximate", "false_alarm_prob", "flag_id"]].rename(columns={"date_norm": "date"})
            out = out.head(2000)
            out["date"] = out["date"].dt.strftime("%Y-%m-%d")
            issue_rows = out.to_dict("records")

        meta = m[m["risk_factor_id"] == rf]
        vendor = str(meta["vendor"].iloc[0]) if not meta.empty else "NA"
        source = str(issues["backend"].mode().iloc[0]) if not issues.empty and "backend" in issues.columns and not issues["backend"].mode().empty else "NA"
        li = issues.iloc[0] if not issues.empty else None
        nearest_event = "N/A"
        if events and li is not None:
            dd = pd.to_datetime(li["date_norm"])
            dist = sorted([(abs((e["date"] - dd).days), e) for e in events], key=lambda x: x[0])
            if dist:
                nearest_event = f"{dist[0][1]['label']} ({dist[0][0]} days)"

        peer_text = "N/A"
        if li is not None:
            conf = li.get("peer_confidence", np.nan)
            pc = li.get("peer_confirmed", np.nan)
            peer_text = f"peer_confirmed={bool(pc)} | confidence={float(conf):.2f}" if pd.notna(conf) else str(bool(pc))

        fa_text = "N/A"
        if li is not None and pd.notna(li.get("false_alarm_probability", np.nan)):
            fa_text = f"{float(li.get('false_alarm_probability')):.3f}"

        context = html.Ul([
            html.Li(f"Risk factor: {rf}"),
            html.Li(f"Current regime: {str(li.get('regime_tag', 'normal')) if li is not None else 'normal'}"),
            html.Li(f"Nearest event: {nearest_event}"),
            html.Li(f"Peer confirmation: {peer_text}"),
            html.Li(f"False alarm probability: {fa_text}"),
            html.Li(f"Vendor: {vendor}"),
            html.Li(f"Data source: {source}"),
        ])

        hist = pd.DataFrame(triage_labels or [])
        if not hist.empty:
            hist["timestamp"] = pd.to_datetime(hist["timestamp"], errors="coerce")
            hist = hist[hist["risk_factor_id"].astype(str) == str(rf)].sort_values("timestamp", ascending=False)
            hist["timestamp"] = hist["timestamp"].dt.strftime("%Y-%m-%d %H:%M:%S")
            hist_rows = hist[[c for c in ["timestamp", "action", "check_id", "severity"] if c in hist.columns]].to_dict("records")
        else:
            hist_rows = []

        return fig_bh, fig_bt, top_off, fig_series, issue_rows, model_fig, context, hist_rows

    @app.callback(
        Output("v2-compare-ranked", "columnDefs"),
        Output("v2-compare-ranked", "rowData"),
        Output("v2-overlap", "figure"),
        Output("v2-disagreement", "columnDefs"),
        Output("v2-disagreement", "rowData"),
        Output("v2-score-corr", "figure"),
        Output("v2-model-metrics", "children"),
        Output("v2-model-perf", "figure"),
        Output("v2-severity-dist", "figure"),
        Output("v2-score-hist", "figure"),
        Input("v2-compare-universe", "value"),
        Input("v2-compare-models", "value"),
        Input("v2-compare-range", "start_date"),
        Input("v2-compare-range", "end_date"),
        Input("v2-compare-solo", "value"),
        State("v2-store", "data"),
        State("v2-triage-labels", "data"),
    )
    def refresh_compare(universe, models, start, end, solo, state, triage_labels):
        r, _ = _apply_filters(state)
        if universe and "universe_name" in r.columns:
            r = r[r["universe_name"] == universe]
        if start:
            r = r[r["date_norm"] >= pd.to_datetime(start).normalize()]
        if end:
            r = r[r["date_norm"] <= pd.to_datetime(end).normalize()]
        if r.empty:
            return [], [], _empty_fig("Overlap"), [], [], _empty_fig("Score correlation"), "No rows", _empty_fig("Performance"), _empty_fig("Severity"), _empty_fig("Histogram")

        sel_models = [str(m) for m in (models or []) if str(m).strip()]
        if not sel_models:
            sel_models = r.groupby("check_id")["flag"].sum().sort_values(ascending=False).head(3).index.astype(str).tolist()
        sel_models = sel_models[:4]

        f = r[r["check_id"].astype(str).isin(sel_models)].copy()
        if "solo" in (solo or []):
            c = f[f["flag"]].groupby(["risk_factor_id", "date_norm"], as_index=False)["check_id"].nunique().rename(columns={"check_id": "n"})
            keys = c[c["n"] == 1][["risk_factor_id", "date_norm"]]
            f = f.merge(keys, on=["risk_factor_id", "date_norm"], how="inner")
        if f.empty:
            return [], [], _empty_fig("Overlap"), [], [], _empty_fig("Score correlation"), "No rows after model filters", _empty_fig("Performance"), _empty_fig("Severity"), _empty_fig("Histogram")

        score = f.groupby(["risk_factor_id", "check_id"], as_index=False)["norm_score"].max().pivot(index="risk_factor_id", columns="check_id", values="norm_score")
        fp = f.groupby(["risk_factor_id", "check_id"], as_index=False)["flag"].max().pivot(index="risk_factor_id", columns="check_id", values="flag").fillna(False).astype(bool)

        ranked = pd.DataFrame(index=score.index.union(fp.index))
        ranked.index.name = "risk_factor_id"
        ranked = ranked.reset_index()
        for m in sel_models:
            ranked[f"score_{m}"] = score.get(m, pd.Series(dtype=float)).reindex(ranked["risk_factor_id"]).values
            ranked[f"flag_{m}"] = fp.get(m, pd.Series(dtype=bool)).reindex(ranked["risk_factor_id"]).fillna(False).values
        ranked["max_norm_score"] = ranked[[c for c in ranked.columns if c.startswith("score_")]].max(axis=1, skipna=True)
        ranked["consensus"] = ranked[[c for c in ranked.columns if c.startswith("flag_")]].sum(axis=1)
        ranked = ranked.merge(mem[["risk_factor_id", "rf_level1"]].drop_duplicates(), on="risk_factor_id", how="left").sort_values("max_norm_score", ascending=False).head(800)

        cdefs = [{"field": "risk_factor_id"}, {"field": "rf_level1"}, {"field": "max_norm_score"}, {"field": "consensus"}]
        for m in sel_models:
            cdefs.extend([{"field": f"score_{m}"}, {"field": f"flag_{m}"}])

        sets = {m: set(f[(f["check_id"].astype(str) == m) & (f["flag"])]["risk_factor_id"].astype(str).unique().tolist()) for m in sel_models}
        combos = []
        all_ids = sorted(set().union(*sets.values())) if sets else []
        for rf in all_ids:
            bits = tuple(1 if rf in sets[m] else 0 for m in sel_models)
            combos.append({"signature": "|".join([sel_models[i] for i, b in enumerate(bits) if b == 1]) or "none", "bits": "".join(str(b) for b in bits)})
        ov = pd.DataFrame(combos).groupby(["bits", "signature"], as_index=False).size().rename(columns={"size": "count"}) if combos else pd.DataFrame()
        fig_ov = _empty_fig("Overlap") if ov.empty else px.bar(ov.sort_values("count", ascending=False), x="signature", y="count", title="Model agreement overlap (Upset-style)")

        ddefs = [{"field": "risk_factor_id"}, {"field": "date"}, {"field": "model_a"}, {"field": "model_b"}, {"field": "score_a"}, {"field": "score_b"}, {"field": "flag_a"}, {"field": "flag_b"}]
        drows: list[dict[str, Any]] = []
        fig_corr = _empty_fig("Score correlation")
        if len(sel_models) >= 2:
            a, b = sel_models[:2]
            base = f[f["check_id"].astype(str).isin([a, b])].groupby(["risk_factor_id", "date_norm", "check_id"], as_index=False).agg(score=("norm_score", "max"), flag=("flag", "max"))
            a_df = base[base["check_id"].astype(str) == a].rename(columns={"score": "score_a", "flag": "flag_a"})
            b_df = base[base["check_id"].astype(str) == b].rename(columns={"score": "score_b", "flag": "flag_b"})
            cmp = a_df[["risk_factor_id", "date_norm", "score_a", "flag_a"]].merge(b_df[["risk_factor_id", "date_norm", "score_b", "flag_b"]], on=["risk_factor_id", "date_norm"], how="outer")
            cmp[["flag_a", "flag_b"]] = cmp[["flag_a", "flag_b"]].fillna(False)
            dis = cmp[cmp["flag_a"] != cmp["flag_b"]].head(1000)
            if not dis.empty:
                dis["date"] = pd.to_datetime(dis["date_norm"]).dt.strftime("%Y-%m-%d")
                dis["model_a"] = a
                dis["model_b"] = b
                drows = dis[["risk_factor_id", "date", "model_a", "model_b", "score_a", "score_b", "flag_a", "flag_b"]].to_dict("records")

            corr = f[f["check_id"].astype(str).isin([a, b])].groupby(["risk_factor_id", "check_id"], as_index=False)["norm_score"].max().pivot(index="risk_factor_id", columns="check_id", values="norm_score").dropna().reset_index()
            if not corr.empty and a in corr.columns and b in corr.columns:
                corr["group"] = "all"
                fig_corr = px.scatter(corr, x=a, y=b, color="group", title=f"Score correlation: {a} vs {b}")

        sev = f[f["flag"]].groupby(["check_id", "severity"], as_index=False).size().rename(columns={"size": "count"})
        fig_sev = _empty_fig("Severity distribution") if sev.empty else px.bar(sev, x="check_id", y="count", color="severity", title="Severity distribution per model")
        fig_hist = _empty_fig("Score histogram") if f.empty else px.histogram(f, x="norm_score", color="check_id", nbins=40, barmode="overlay", title="Score histogram")

        metrics = "No triage labels yet"
        fig_perf = _empty_fig("Model performance")
        lbl = pd.DataFrame(triage_labels or [])
        if not lbl.empty and {"risk_factor_id", "action"}.issubset(lbl.columns):
            lbl["date"] = pd.to_datetime(lbl.get("date"), errors="coerce").dt.normalize()
            lbl["truth"] = lbl["action"].map(_action_truth)
            lbl = lbl[lbl["truth"].notna()]
            if not lbl.empty:
                events_df = lbl[["risk_factor_id", "date", "truth"]].dropna().drop_duplicates()
                preds = r[r["check_id"].astype(str).isin(sel_models)].groupby(["risk_factor_id", "date_norm", "check_id"], as_index=False)["flag"].max().rename(columns={"date_norm": "date"})
                rows = []
                for m in sel_models:
                    pm = preds[preds["check_id"].astype(str) == m][["risk_factor_id", "date", "flag"]]
                    j = events_df.merge(pm, on=["risk_factor_id", "date"], how="left")
                    j["flag"] = j["flag"].fillna(False)
                    tp = int(((j["truth"] == 1) & (j["flag"])).sum())
                    fp = int(((j["truth"] == 0) & (j["flag"])).sum())
                    fn = int(((j["truth"] == 1) & (~j["flag"])).sum())
                    precision = tp / (tp + fp) if (tp + fp) > 0 else np.nan
                    recall = tp / (tp + fn) if (tp + fn) > 0 else np.nan
                    far = fp / (tp + fp) if (tp + fp) > 0 else np.nan
                    rows.append({"model": m, "precision": precision, "recall": recall, "false_alarm_rate": far})
                perf = pd.DataFrame(rows)
                if not perf.empty:
                    fig_perf = px.bar(perf.melt(id_vars=["model"], value_vars=["precision", "recall", "false_alarm_rate"], var_name="metric", value_name="value"), x="model", y="value", color="metric", barmode="group", title="Model performance from triage labels")
                    metrics = html.Ul([html.Li(f"{x['model']}: precision={x['precision']:.3f} recall={x['recall']:.3f} false_alarm_rate={x['false_alarm_rate']:.3f}") for _, x in perf.iterrows()])

        return cdefs, ranked.round(4).to_dict("records"), fig_ov, ddefs, drows, fig_corr, metrics, fig_perf, fig_sev, fig_hist

    @app.callback(
        Output("v2-peer-group", "options"),
        Output("v2-peer-group", "value"),
        Input("v2-peer-asset", "value"),
        Input("v2-peer-universe", "value"),
        State("v2-peer-group", "value"),
    )
    def peer_group_options(asset, universe, current):
        x = mem.copy()
        if asset:
            x = x[x["rf_level1"] == asset]
        if universe and "universe_name" in x.columns:
            x = x[x["universe_name"] == universe]
        vals = sorted(x.get("rf_level3", pd.Series(dtype=str)).dropna().astype(str).unique().tolist())
        return [{"label": v, "value": v} for v in vals], current if current in vals else (vals[0] if vals else None)

    @app.callback(
        Output("v2-peer-date-map", "data"),
        Output("v2-peer-date-slider", "min"),
        Output("v2-peer-date-slider", "max"),
        Output("v2-peer-date-slider", "value"),
        Output("v2-peer-date-slider", "marks"),
        Input("v2-peer-asset", "value"),
        Input("v2-peer-universe", "value"),
        Input("v2-peer-group", "value"),
        Input("v2-peer-range", "start_date"),
        Input("v2-peer-range", "end_date"),
        State("v2-store", "data"),
    )
    def peer_date_slider(asset, universe, group, start_date, end_date, state):
        x = mem.copy()
        if asset:
            x = x[x["rf_level1"] == asset]
        if universe and "universe_name" in x.columns:
            x = x[x["universe_name"] == universe]
        if group:
            x = x[x["rf_level3"] == group]
        ids = x["risk_factor_id"].astype(str).unique().tolist()
        ts_view = _filtered_ts(state)
        t = ts_view[ts_view["risk_factor_id"].isin(ids)]
        if start_date:
            t = t[t["date_norm"] >= pd.to_datetime(start_date).normalize()]
        if end_date:
            t = t[t["date_norm"] <= pd.to_datetime(end_date).normalize()]
        dates = sorted(pd.to_datetime(t.get("date_norm", pd.Series(dtype="datetime64[ns]")), errors="coerce").dropna().dt.normalize().unique().tolist())
        dmap = [str(pd.Timestamp(d).date()) for d in dates]
        if not dmap:
            return [], 0, 0, 0, {0: "N/A"}
        marks = {0: dmap[0], len(dmap) // 2: dmap[len(dmap) // 2], len(dmap) - 1: dmap[-1]}
        return dmap, 0, len(dmap) - 1, len(dmap) - 1, marks

    @app.callback(
        Output("v2-peer-multiline", "figure"),
        Output("v2-peer-cross", "figure"),
        Output("v2-peer-corr", "figure"),
        Output("v2-peer-health", "rowData"),
        Output("v2-factor-vs-peer", "figure"),
        Input("v2-peer-asset", "value"),
        Input("v2-peer-universe", "value"),
        Input("v2-peer-group", "value"),
        Input("v2-peer-range", "start_date"),
        Input("v2-peer-range", "end_date"),
        Input("v2-peer-date-map", "data"),
        Input("v2-peer-date-slider", "value"),
        Input("v2-peer-health", "selectedRows"),
        State("v2-store", "data"),
    )
    def refresh_peer(asset, universe, group, start_date, end_date, date_map, slider_idx, peer_rows, state):
        x = mem.copy()
        if asset:
            x = x[x["rf_level1"] == asset]
        if universe and "universe_name" in x.columns:
            x = x[x["universe_name"] == universe]
        gf = x.copy()
        if group:
            gf = gf[gf["rf_level3"] == group]

        ids = sorted(gf["risk_factor_id"].astype(str).unique().tolist())[:200]
        if not ids:
            return _empty_fig("Peer multiline"), _empty_fig("Cross-section"), _empty_fig("Peer correlation"), [], _empty_fig("Factor vs peer")

        ts_view = _filtered_ts(state)
        p = ts_view[ts_view["risk_factor_id"].isin(ids)].copy()
        if start_date:
            p = p[p["date_norm"] >= pd.to_datetime(start_date).normalize()]
        if end_date:
            p = p[p["date_norm"] <= pd.to_datetime(end_date).normalize()]
        if p.empty:
            return _empty_fig("Peer multiline"), _empty_fig("Cross-section"), _empty_fig("Peer correlation"), [], _empty_fig("Factor vs peer")

        p = p.sort_values(["risk_factor_id", "date_norm"])
        base = p.groupby("risk_factor_id", as_index=False)["value"].first().rename(columns={"value": "base"})
        z = p.merge(base, on="risk_factor_id", how="left")
        z["indexed"] = np.where(z["base"].abs() > 1.0e-12, 100.0 * z["value"] / z["base"], np.nan)
        fig_multi = px.line(z, x="date_norm", y="indexed", color="risk_factor_id", title="Peer group indexed series")
        med = z.groupby("date_norm", as_index=False)["indexed"].median().rename(columns={"indexed": "peer_median"})
        fig_multi.add_trace(go.Scatter(x=med["date_norm"], y=med["peer_median"], mode="lines", name="peer median", line={"width": 3, "dash": "dash"}))

        chosen = None
        if date_map and isinstance(slider_idx, (int, float)):
            ii = int(slider_idx)
            if 0 <= ii < len(date_map):
                chosen = pd.to_datetime(date_map[ii]).normalize()
        if chosen is None:
            chosen = pd.to_datetime(z["date_norm"]).max().normalize()
        snap = z[z["date_norm"] == chosen]
        fig_cross = _empty_fig("Cross-section") if snap.empty else px.scatter(snap, x="risk_factor_id", y="indexed", title=f"Cross-section at {chosen.date()}")

        piv = z.pivot_table(index="date_norm", columns="risk_factor_id", values="indexed", aggfunc="last")
        corr = piv.pct_change().corr(min_periods=20)
        fig_corr = _empty_fig("Peer correlation heatmap")
        if not corr.empty:
            c = corr.reset_index().melt(id_vars="risk_factor_id", var_name="peer", value_name="corr")
            fig_corr = px.density_heatmap(c, x="risk_factor_id", y="peer", z="corr", color_continuous_scale="RdBu", title="Peer correlation heatmap")

        latest = _latest_date(dq)
        lf = dq[(dq["flag"]) & (dq["date_norm"] == latest)]

        health = []
        for gname, gm in x.groupby("rf_level3"):
            mids = gm["risk_factor_id"].astype(str).unique().tolist()
            if not mids:
                continue
            gl = lf[lf["risk_factor_id"].isin(mids)]
            n = len(mids)
            flagged = gl["risk_factor_id"].astype(str).nunique()
            flagged_pct = 100.0 * flagged / n if n > 0 else 0.0
            sv = z[(z["risk_factor_id"].isin(mids)) & (z["date_norm"] == chosen)]["indexed"]
            disp = float((sv - sv.median()).abs().median()) if not sv.empty else np.nan
            worst = ""
            if not gl.empty:
                wm = gl.groupby("risk_factor_id", as_index=False)["norm_score"].max().sort_values("norm_score", ascending=False)
                worst = str(wm.iloc[0]["risk_factor_id"]) if not wm.empty else ""
            gp = piv[[c for c in mids if c in piv.columns]]
            avg_corr = np.nan
            corr_stability = np.nan
            if gp.shape[1] >= 2:
                cm = gp.pct_change().corr(min_periods=20).values
                if cm.size > 0:
                    up = cm[np.triu_indices_from(cm, k=1)]
                    up = up[~np.isnan(up)]
                    if up.size > 0:
                        avg_corr = float(np.mean(up))
                vals = []
                rets = gp.pct_change().dropna()
                for i in range(20, len(rets) + 1):
                    w = rets.iloc[i - 20 : i]
                    cwin = w.corr().values
                    up2 = cwin[np.triu_indices_from(cwin, k=1)]
                    up2 = up2[~np.isnan(up2)]
                    if up2.size > 0:
                        vals.append(float(np.mean(up2)))
                if vals:
                    corr_stability = float(np.std(vals))
            health.append({"peer_group": str(gname), "member_count": n, "flagged_pct": round(flagged_pct, 2), "dispersion_mad": round(disp, 4) if pd.notna(disp) else None, "worst_member": worst, "avg_corr": round(avg_corr, 4) if pd.notna(avg_corr) else None, "corr_stability": round(corr_stability, 4) if pd.notna(corr_stability) else None, "selected_factor": worst})
        health = sorted(health, key=lambda x: x.get("flagged_pct") or 0.0, reverse=True)

        sf = None
        if peer_rows:
            sf = peer_rows[0].get("selected_factor") or peer_rows[0].get("worst_member")
        if not sf:
            sf = (state or {}).get("selected_risk_factor_id")
        if not sf or sf not in ids:
            sf = ids[0]

        fig_factor = _empty_fig("Factor vs peer")
        fd = z[z["risk_factor_id"] == sf].copy()
        if not fd.empty:
            pm = z.groupby("date_norm", as_index=False)["indexed"].median().rename(columns={"indexed": "peer_median"})
            j = fd[["date_norm", "indexed"]].merge(pm, on="date_norm", how="left")
            j["factor_minus_peer"] = j["indexed"] - j["peer_median"]
            val = z.pivot_table(index="date_norm", columns="risk_factor_id", values="indexed", aggfunc="last")
            if sf in val.columns and val.shape[1] >= 2:
                cent = val.drop(columns=[sf], errors="ignore").mean(axis=1)
                rc = val[sf].rolling(60, min_periods=20).corr(cent)
            else:
                rc = pd.Series(index=j["date_norm"], dtype=float)
            fig_factor = go.Figure()
            fig_factor.add_trace(go.Scatter(x=j["date_norm"], y=j["indexed"], mode="lines", name=f"{sf} indexed"))
            fig_factor.add_trace(go.Scatter(x=j["date_norm"], y=j["peer_median"], mode="lines", name="peer median", line={"dash": "dash"}))
            fig_factor.add_trace(go.Scatter(x=j["date_norm"], y=j["factor_minus_peer"], mode="lines", name="factor - peer", yaxis="y2"))
            fig_factor.add_trace(go.Scatter(x=rc.index, y=rc.values, mode="lines", name="rolling corr(60)", yaxis="y2"))
            fig_factor.update_layout(title=f"Factor vs Peer: {sf}", yaxis={"title": "Indexed"}, yaxis2={"overlaying": "y", "side": "right", "title": "Spread / Corr"}, template="plotly_white")

        return fig_multi, fig_cross, fig_corr, health, fig_factor

    return app


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run Dash UI v2 for Advanced DQ Checks on RF.")
    parser.add_argument("--results-path", default=str(PROJECT_ROOT / "data" / "processed" / "dq_results"))
    parser.add_argument("--raw-path", default=str(PROJECT_ROOT / "data" / "raw" / "timeseries_raw"))
    parser.add_argument("--membership-path", default=str(PROJECT_ROOT / "data" / "processed" / "universe_membership"))
    parser.add_argument("--config-path", default=str(PROJECT_ROOT / "configs" / "model_catalog.yaml"))
    parser.add_argument("--triage-path", default=str(PROJECT_ROOT / "data" / "processed" / "triage_labels" / "triage_labels.parquet"))
    parser.add_argument("--business-date", default="", help="Optional business_date filter (YYYY-MM-DD) applied at load time.")
    parser.add_argument("--analyst-id", default=os.getenv("USERNAME", "analyst"))
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8061)
    parser.add_argument("--debug", action="store_true")
    return parser.parse_args()

def parse_args_test() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run Dash UI v2 for Advanced DQ Checks on RF.")
    parser.add_argument("--results-path", default=str(PROJECT_ROOT / "data" / "demo_ui_full" / "processed" / "dq_results"))
    parser.add_argument("--raw-path", default=str(PROJECT_ROOT / "data" / "demo_ui_full" / "raw" / "timeseries_raw"))
    parser.add_argument("--membership-path", default=str(PROJECT_ROOT / "data" / "demo_ui_full" / "processed" / "universe_membership"))
    parser.add_argument("--config-path", default=str(PROJECT_ROOT / "configs" / "demo_ui_full" / "model_catalog_ui_full.yaml"))
    parser.add_argument("--triage-path", default=str(PROJECT_ROOT / "data" / "processed" / "triage_labels" / "triage_labels.parquet"))
    parser.add_argument("--business-date", default="2026-01-31", help="Optional business_date filter (YYYY-MM-DD) applied at load time.")
    parser.add_argument("--analyst-id", default=os.getenv("USERNAME", "analyst"))
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8061)
    parser.add_argument("--debug", action="store_true")
    return parser.parse_args()

def main() -> None:
    args = parse_args_test()
    data = load_data(
        args.results_path,
        args.raw_path,
        args.membership_path,
        business_date=args.business_date or None,
    )
    app = create_app(data, config_path=args.config_path, triage_path=args.triage_path, analyst_id=args.analyst_id)
    app.run(host=args.host, port=args.port, debug=args.debug)


if __name__ == "__main__":
    main()

