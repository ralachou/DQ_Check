from __future__ import annotations

import json
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd


@dataclass
class CalibrationArtifact:
    run_id: str
    check_id: str
    strategy: str
    backend: str
    reference_start: str
    reference_end: str
    business_date: str = ""
    params: dict[str, Any] = field(default_factory=dict)
    stats: dict[str, Any] = field(default_factory=dict)
    config_hash: str = ""
    model_version: str = ""


class ScoreNormalizer:
    """Normalize heterogeneous anomaly raw scores into comparable norm_score."""

    def __init__(self, eps: float = 1.0e-9) -> None:
        self.eps = eps

    @staticmethod
    def _sigmoid(x: np.ndarray) -> np.ndarray:
        return 1.0 / (1.0 + np.exp(-x))

    @staticmethod
    def _ecdf_map(values: np.ndarray, ref_sorted: np.ndarray) -> np.ndarray:
        if len(ref_sorted) == 0:
            return np.zeros_like(values, dtype=float)
        idx = np.searchsorted(ref_sorted, values, side="right")
        return idx / len(ref_sorted)

    def fit(
        self,
        raw_scores: pd.Series,
        strategy: str,
        strategy_params: dict[str, Any] | None = None,
        backend: str = "local",
    ) -> dict[str, Any]:
        strategy_params = strategy_params or {}
        raw = pd.to_numeric(raw_scores, errors="coerce").fillna(0.0).to_numpy(dtype=float)

        if strategy == "backend_aware":
            if backend == "merlion" and strategy_params.get("use_merlion_calibrator", True):
                # MVP Merlion calibrator proxy: z-score style calibration.
                mu = float(np.nanmean(raw))
                sigma = float(np.nanstd(raw) + self.eps)
                return {
                    "strategy": "backend_aware",
                    "backend": backend,
                    "calibrator": {"mu": mu, "sigma": sigma},
                    "fallback_strategy": strategy_params.get("fallback_strategy", "ecdf"),
                    "fallback_state": self.fit(raw_scores, strategy_params.get("fallback_strategy", "ecdf"), strategy_params, backend),
                }
            return self.fit(raw_scores, strategy_params.get("fallback_strategy", "ecdf"), strategy_params, backend)

        if strategy == "robust_zscore":
            median = float(np.nanmedian(raw))
            mad = float(np.nanmedian(np.abs(raw - median)))
            return {"strategy": strategy, "median": median, "mad": mad}

        if strategy == "quantile":
            bins = strategy_params.get("quantile_bins", [0.90, 0.97, 0.99, 0.999])
            cutoffs = {str(q): float(np.nanquantile(raw, q)) for q in bins}
            return {"strategy": strategy, "quantiles": cutoffs}

        # default ECDF normalization.
        ref_sorted = np.sort(raw)
        return {"strategy": "ecdf", "reference_sorted": ref_sorted.tolist()}

    def transform(self, raw_scores: pd.Series, state: dict[str, Any]) -> pd.Series:
        raw = pd.to_numeric(raw_scores, errors="coerce").fillna(0.0).to_numpy(dtype=float)
        strategy = state.get("strategy", "ecdf")

        if strategy == "backend_aware":
            calibrator = state.get("calibrator", {})
            mu = float(calibrator.get("mu", 0.0))
            sigma = float(calibrator.get("sigma", 1.0))
            z_like = (raw - mu) / (sigma + self.eps)
            calibrated = self._sigmoid(z_like)
            fallback = self.transform(pd.Series(raw), state.get("fallback_state", {"strategy": "ecdf", "reference_sorted": raw.tolist()}))
            return pd.Series(np.maximum(calibrated, fallback.to_numpy()), index=raw_scores.index)

        if strategy == "robust_zscore":
            median = float(state.get("median", 0.0))
            mad = float(state.get("mad", 1.0))
            z = (raw - median) / (1.4826 * mad + self.eps)
            return pd.Series(self._sigmoid(z), index=raw_scores.index)

        if strategy == "quantile":
            quantiles = {float(k): float(v) for k, v in state.get("quantiles", {}).items()}
            ordered = sorted(quantiles.items(), key=lambda kv: kv[0])
            out = np.zeros_like(raw)
            for q, cutoff in ordered:
                out = np.where(raw >= cutoff, q, out)
            return pd.Series(out, index=raw_scores.index).clip(0.0, 1.0)

        ref_sorted = np.array(state.get("reference_sorted", []), dtype=float)
        return pd.Series(self._ecdf_map(raw, ref_sorted), index=raw_scores.index)

    def fit_transform(
        self,
        raw_scores: pd.Series,
        strategy: str,
        strategy_params: dict[str, Any] | None = None,
        backend: str = "local",
    ) -> tuple[pd.Series, dict[str, Any]]:
        state = self.fit(raw_scores=raw_scores, strategy=strategy, strategy_params=strategy_params, backend=backend)
        return self.transform(raw_scores, state), state

    @staticmethod
    def persist_artifact(artifact: CalibrationArtifact, state: dict[str, Any], artifact_root: str | Path) -> Path:
        root = Path(artifact_root)
        if artifact.business_date:
            root = root / f"business_date={artifact.business_date}"
        root = root / f"check_id={artifact.check_id}" / f"run_id={artifact.run_id}"
        root.mkdir(parents=True, exist_ok=True)
        payload = asdict(artifact)
        payload["state"] = state
        out_path = root / "artifact.json"
        out_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
        pd.DataFrame([payload]).to_parquet(root / "artifact.parquet", index=False)
        return out_path


class SeverityMapper:
    """Maps normalized scores to severity with fixed or quantile thresholds."""

    def __init__(self, fixed_thresholds: dict[str, float] | None = None) -> None:
        self.fixed_thresholds = fixed_thresholds or {
            "low": 0.80,
            "med": 0.92,
            "high": 0.975,
            "critical": 0.995,
        }

    def map_severity(
        self,
        norm_scores: pd.Series,
        mode: str = "fixed",
        quantile_thresholds: dict[str, float] | None = None,
    ) -> tuple[pd.Series, pd.Series, pd.Series]:
        s = pd.to_numeric(norm_scores, errors="coerce").fillna(0.0).clip(0.0, 1.0)
        if mode == "quantile":
            q = quantile_thresholds or {"low": 0.90, "med": 0.97, "high": 0.99, "critical": 0.999}
            cuts = {k: float(np.nanquantile(s, v)) for k, v in q.items()}
        else:
            cuts = self.fixed_thresholds
        sev = pd.Series("Low", index=s.index)
        sev.loc[s >= cuts["med"]] = "Med"
        sev.loc[s >= cuts["high"]] = "High"
        sev.loc[s >= cuts["critical"]] = "Critical"
        threshold_series = pd.Series(cuts["med"], index=s.index)
        flag = s >= cuts["med"]
        return sev, flag, threshold_series


def normalize_results(
    results_df: pd.DataFrame,
    check_profiles: dict[str, dict[str, Any]],
    run_id: str,
    config_hash: str,
    business_date: str | None = None,
    artifact_root: str | Path = "data/artifacts/normalization",
) -> pd.DataFrame:
    """
    Normalize scores by check_id and persist calibration artifacts.

    check_profiles format:
      {
        "check_id": {
          "normalization_strategy": "ecdf",
          "normalization_params": {...},
          "backend": "local",
          "severity_mode": "fixed|quantile",
          "severity_thresholds": {...},
          "model_version": "1.0.0:check_id"
        }
      }
    """
    if results_df.empty:
        return results_df
    normalizer = ScoreNormalizer()
    out_parts = []

    for check_id, part in results_df.groupby("check_id", sort=False):
        profile = check_profiles.get(check_id, {})
        strategy = profile.get("normalization_strategy", "ecdf")
        params = profile.get("normalization_params", {})
        backend = profile.get("backend", "local")
        norm_scores, state = normalizer.fit_transform(
            raw_scores=part["raw_score"],
            strategy=strategy,
            strategy_params=params,
            backend=backend,
        )
        mapper = SeverityMapper(fixed_thresholds=profile.get("fixed_thresholds"))
        severity, flag, threshold = mapper.map_severity(
            norm_scores=norm_scores,
            mode=profile.get("severity_mode", "fixed"),
            quantile_thresholds=profile.get("severity_thresholds"),
        )
        part_out = part.copy()
        part_out["norm_score"] = norm_scores
        part_out["severity"] = severity
        part_out["flag"] = flag
        part_out["threshold"] = threshold
        out_parts.append(part_out)

        artifact = CalibrationArtifact(
            run_id=run_id,
            check_id=check_id,
            business_date=str(business_date or ""),
            strategy=strategy,
            backend=backend,
            reference_start=str(pd.to_datetime(part["date"]).min().date()),
            reference_end=str(pd.to_datetime(part["date"]).max().date()),
            params=params,
            stats={k: v for k, v in state.items() if k != "reference_sorted"},
            config_hash=config_hash,
            model_version=profile.get("model_version", ""),
        )
        ScoreNormalizer.persist_artifact(artifact=artifact, state=state, artifact_root=artifact_root)

    return pd.concat(out_parts, ignore_index=True)
