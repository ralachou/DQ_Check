from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable

from dq_checks.adapters import ADTKAdapterCheck, MerlionAdapterCheck, PyODAdapterCheck
from dq_checks.base import DQCheck
from dq_checks.ensemble import EnsembleCheck
from dq_checks.local_checks import (
    CUSUMDriftCheck,
    JumpSpikeCheck,
    MeanStdShift4SigmaCheck,
    MissingGapsCheck,
    QuantileBandCheck,
    RollingKSCheck,
    RollingZScoreCheck,
    RobustZScoreCheck,
    StaleNoChangeCheck,
)


@dataclass
class ModelSpec:
    id: str
    backend: str
    model_name: str
    family: str
    fit_policy: str
    params: dict[str, Any] = field(default_factory=dict)
    normalization_profile: str = "ecdf_profile"
    severity_profile: str = "default"
    enabled: bool = True
    version_tag: str = "1.0.0"


class ModelRegistry:
    def __init__(self) -> None:
        self._registry: dict[str, Callable[..., DQCheck]] = {}
        self._required_params: dict[str, set[str]] = {}
        self._register_defaults()

    def register(self, key: str, ctor: Callable[..., DQCheck], required_params: set[str] | None = None) -> None:
        self._registry[key] = ctor
        self._required_params[key] = required_params or set()

    def _register_defaults(self) -> None:
        self.register("mean_std_shift_4sigma", MeanStdShift4SigmaCheck, {"window", "threshold"})
        self.register("legacy_4sigma_shift", MeanStdShift4SigmaCheck, {"window", "threshold"})
        self.register("robust_zscore", RobustZScoreCheck, {"window", "threshold"})
        self.register("rolling_zscore", RollingZScoreCheck, {"window", "threshold"})
        self.register("quantile_band", QuantileBandCheck, {"window"})
        self.register("jump_spike", JumpSpikeCheck, {"window", "threshold"})
        self.register("cusum_drift", CUSUMDriftCheck, {"threshold"})
        self.register("rolling_ks", RollingKSCheck, {"window", "reference", "threshold"})
        self.register("stale_values", StaleNoChangeCheck, {"stale_days"})
        self.register("missing_gaps", MissingGapsCheck, set())

    def validate(self, spec: ModelSpec) -> None:
        key = spec.model_name
        if spec.backend == "local" and key != "ensemble":
            if key not in self._registry:
                raise ValueError(f"Unknown local model_name '{key}' for model '{spec.id}'.")
            required = self._required_params.get(key, set())
            missing = sorted(required - set(spec.params.keys()))
            if missing:
                raise ValueError(f"Model '{spec.id}' missing required params: {missing}")

    def build_from_spec(self, spec: ModelSpec, check_lookup: dict[str, DQCheck] | None = None) -> DQCheck:
        self.validate(spec)
        if spec.backend == "local":
            if spec.model_name == "ensemble":
                children_ids = spec.params.get("children", [])
                children = [check_lookup[c] for c in children_ids if c in (check_lookup or {})]
                return EnsembleCheck(
                    children=children,
                    method=spec.params.get("strategy", spec.params.get("method", "weighted_avg")),
                    weights=spec.params.get("weights"),
                    threshold=spec.params.get("threshold", 0.95),
                    fit_policy=spec.fit_policy,
                )
            ctor = self._registry[spec.model_name]
            check = ctor(**spec.params)
            check.fit_policy = spec.fit_policy
            return check
        if spec.backend == "pyod":
            return PyODAdapterCheck(model_name=spec.model_name, fit_policy=spec.fit_policy, **spec.params)
        if spec.backend == "adtk":
            return ADTKAdapterCheck(model_name=spec.model_name, fit_policy=spec.fit_policy, **spec.params)
        if spec.backend == "merlion":
            return MerlionAdapterCheck(model_name=spec.model_name, fit_policy=spec.fit_policy, **spec.params)
        raise ValueError(f"Unsupported backend '{spec.backend}' for model '{spec.id}'.")

    def load_universe_specs(self, catalog: dict[str, Any], universe_name: str) -> list[ModelSpec]:
        uni = catalog.get("universes", {}).get(universe_name, {})
        checks = uni.get("checks", [])
        version = str(catalog.get("globals", {}).get("version", "1.0.0"))
        specs: list[ModelSpec] = []
        for c in checks:
            specs.append(
                ModelSpec(
                    id=c["id"],
                    backend=c["backend"],
                    model_name=c["model_name"],
                    family=c["family"],
                    fit_policy=c.get("fit_policy", "per_series"),
                    params=c.get("params", {}),
                    normalization_profile=c.get("normalization_profile", "ecdf_profile"),
                    severity_profile=c.get("severity_profile", "default"),
                    enabled=bool(c.get("enabled", True)),
                    version_tag=f"{version}:{c['id']}",
                )
            )
        return specs
