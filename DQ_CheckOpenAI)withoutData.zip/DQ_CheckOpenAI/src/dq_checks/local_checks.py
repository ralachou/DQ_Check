from __future__ import annotations

import json
from typing import Any

import numpy as np
import pandas as pd

from dq_checks.base import DQCheck, severity_from_ratio


def _finalize_output(
    df: pd.DataFrame,
    raw_score: pd.Series,
    threshold: float,
    reason_code: str,
    explain: str,
    artifacts: dict[str, Any] | None = None,
) -> pd.DataFrame:
    out = df[["risk_factor_id", "date"]].copy()
    out["raw_score"] = raw_score.astype(float).fillna(0.0)
    out["threshold"] = float(threshold)
    out["flag"] = out["raw_score"] >= threshold
    ratio = out["raw_score"] / (threshold + 1.0e-12)
    out["severity"] = severity_from_ratio(ratio)
    out.loc[~out["flag"], "severity"] = "Low"
    out["reason_code"] = np.where(out["flag"], reason_code, "OK")
    out["explain"] = np.where(out["flag"], explain, "No issue")
    out["artifacts_json"] = json.dumps(artifacts or {})
    return out


class RobustZScoreCheck(DQCheck):
    def __init__(self, **params: Any) -> None:
        super().__init__(
            name="robust_zscore",
            family="stat_univariate",
            scope="per_series",
            fit_policy="per_series",
            **params,
        )

    def score(self, df: pd.DataFrame, context: dict[str, Any], model_state: dict[str, Any] | None = None) -> pd.DataFrame:
        del context, model_state
        window = int(self.params.get("window", 260))
        min_periods = int(self.params.get("min_periods", min(20, window)))
        threshold = float(self.params.get("threshold", 6.0))
        s = df["value"].astype(float)
        med = s.rolling(window=window, min_periods=min_periods).median()
        mad = (s - med).abs().rolling(window=window, min_periods=min_periods).median()
        robust_z = ((s - med).abs()) / (1.4826 * mad + 1.0e-9)
        return _finalize_output(
            df=df,
            raw_score=robust_z,
            threshold=threshold,
            reason_code="ROBUST_ZSCORE",
            explain=f"Absolute robust z-score exceeds threshold {threshold}",
            artifacts={"window": window},
        )


class RollingZScoreCheck(DQCheck):
    """Classical rolling mean/std z-score on level values (benchmark detector)."""

    def __init__(self, **params: Any) -> None:
        super().__init__(
            name="rolling_zscore",
            family="stat_univariate",
            scope="per_series",
            fit_policy="per_series",
            **params,
        )

    def score(self, df: pd.DataFrame, context: dict[str, Any], model_state: dict[str, Any] | None = None) -> pd.DataFrame:
        del context, model_state
        window = int(self.params.get("window", 260))
        min_periods = int(self.params.get("min_periods", min(20, window)))
        threshold = float(self.params.get("threshold", 4.0))
        s = df["value"].astype(float)
        mu = s.rolling(window=window, min_periods=min_periods).mean()
        sigma = s.rolling(window=window, min_periods=min_periods).std(ddof=0)
        z = ((s - mu).abs()) / (sigma + 1.0e-9)
        return _finalize_output(
            df=df,
            raw_score=z,
            threshold=threshold,
            reason_code="ROLLING_ZSCORE",
            explain=f"Absolute rolling z-score exceeds threshold {threshold}",
            artifacts={"window": window},
        )


class MeanStdShift4SigmaCheck(DQCheck):
    """
    Mean/std detector on shifted series moves.

    This mirrors the legacy control:
      |shift - rolling_mean(shift)| / rolling_std(shift) >= k
    with default k=4.0.
    """

    def __init__(self, **params: Any) -> None:
        super().__init__(
            name="mean_std_shift_4sigma",
            family="stat_univariate",
            scope="per_series",
            fit_policy="per_series",
            **params,
        )

    def score(self, df: pd.DataFrame, context: dict[str, Any], model_state: dict[str, Any] | None = None) -> pd.DataFrame:
        del context, model_state
        window = int(self.params.get("window", 252))
        shift_lag = int(self.params.get("shift_lag", 1))
        min_periods = int(self.params.get("min_periods", min(20, window)))
        threshold = float(self.params.get("threshold", 4.0))
        s = df["value"].astype(float)
        shift = s.diff(shift_lag).fillna(0.0)
        mu = shift.rolling(window=window, min_periods=min_periods).mean()
        sigma = shift.rolling(window=window, min_periods=min_periods).std(ddof=0)
        z = ((shift - mu).abs()) / (sigma + 1.0e-9)
        return _finalize_output(
            df=df,
            raw_score=z,
            threshold=threshold,
            reason_code="MEAN_STD_SHIFT_4SIGMA",
            explain=f"Absolute shift z-score exceeds {threshold} sigma",
            artifacts={"window": window, "shift_lag": shift_lag},
        )


class QuantileBandCheck(DQCheck):
    def __init__(self, **params: Any) -> None:
        super().__init__(
            name="quantile_band",
            family="stat_univariate",
            scope="per_series",
            fit_policy="per_series",
            **params,
        )

    def score(self, df: pd.DataFrame, context: dict[str, Any], model_state: dict[str, Any] | None = None) -> pd.DataFrame:
        del context, model_state
        window = int(self.params.get("window", 260))
        high_q = float(self.params.get("high_q", 0.995))
        low_q = float(self.params.get("low_q", 0.005))
        s = df["value"].astype(float)
        q_hi = s.rolling(window, min_periods=max(20, window // 4)).quantile(high_q)
        q_lo = s.rolling(window, min_periods=max(20, window // 4)).quantile(low_q)
        raw = np.maximum((s - q_hi).clip(lower=0.0), (q_lo - s).clip(lower=0.0))
        band = (q_hi - q_lo).replace(0, np.nan)
        score = (raw / (band + 1.0e-9)).fillna(0.0)
        return _finalize_output(
            df=df,
            raw_score=score,
            threshold=float(self.params.get("threshold", 0.2)),
            reason_code="QUANTILE_BAND",
            explain="Value outside rolling quantile band",
            artifacts={"window": window, "high_q": high_q, "low_q": low_q},
        )


class StaleNoChangeCheck(DQCheck):
    def __init__(self, **params: Any) -> None:
        super().__init__(
            name="stale_values",
            family="integrity",
            scope="per_series",
            fit_policy="per_series",
            **params,
        )

    def score(self, df: pd.DataFrame, context: dict[str, Any], model_state: dict[str, Any] | None = None) -> pd.DataFrame:
        del context, model_state
        stale_days = int(self.params.get("stale_days", 5))
        change = df["value"].diff().abs().fillna(0.0)
        no_change = (change <= 1.0e-12).astype(int)
        run = no_change.groupby((no_change == 0).cumsum()).cumsum()
        return _finalize_output(
            df=df,
            raw_score=run,
            threshold=float(stale_days),
            reason_code="STALE_VALUES",
            explain=f"{stale_days}+ consecutive unchanged values",
            artifacts={"stale_days": stale_days},
        )


class MissingGapsCheck(DQCheck):
    def __init__(self, **params: Any) -> None:
        super().__init__(
            name="missing_gaps",
            family="integrity",
            scope="per_series",
            fit_policy="per_series",
            **params,
        )

    def score(self, df: pd.DataFrame, context: dict[str, Any], model_state: dict[str, Any] | None = None) -> pd.DataFrame:
        del context, model_state
        if df.empty:
            return self.empty_result(df, "No rows in input.")
        rf_id = str(df["risk_factor_id"].iloc[0])
        date_index = pd.to_datetime(df["date"])
        full_range = pd.date_range(date_index.min(), date_index.max(), freq="B")
        missing_dates = full_range.difference(pd.DatetimeIndex(date_index))
        missing_df = pd.DataFrame({"risk_factor_id": rf_id, "date": missing_dates, "value": np.nan})
        combined = pd.concat([df[["risk_factor_id", "date", "value"]], missing_df], ignore_index=True).sort_values("date")
        is_missing = combined["value"].isna().astype(float)
        out = _finalize_output(
            df=combined,
            raw_score=is_missing,
            threshold=0.5,
            reason_code="MISSING_BUSINESS_DATE",
            explain="Expected business date missing",
            artifacts={"calendar": "business_day"},
        )
        return out[out["flag"]].reset_index(drop=True)


class JumpSpikeCheck(DQCheck):
    def __init__(self, **params: Any) -> None:
        super().__init__(
            name="jump_spike",
            family="stat_univariate",
            scope="per_series",
            fit_policy="per_series",
            **params,
        )

    def score(self, df: pd.DataFrame, context: dict[str, Any], model_state: dict[str, Any] | None = None) -> pd.DataFrame:
        del context, model_state
        window = int(self.params.get("window", 60))
        threshold = float(self.params.get("threshold", 5.0))
        returns = df["value"].astype(float).diff().fillna(0.0)
        med = returns.rolling(window=window, min_periods=max(10, window // 4)).median()
        mad = (returns - med).abs().rolling(window=window, min_periods=max(10, window // 4)).median()
        score = (returns - med).abs() / (1.4826 * mad + 1.0e-9)
        return _finalize_output(
            df=df,
            raw_score=score,
            threshold=threshold,
            reason_code="RETURN_SPIKE",
            explain="Jump/spike detected from robust return statistics",
            artifacts={"window": window},
        )


class CUSUMDriftCheck(DQCheck):
    def __init__(self, **params: Any) -> None:
        super().__init__(
            name="cusum_drift",
            family="changepoint",
            scope="per_series",
            fit_policy="per_series",
            **params,
        )

    def score(self, df: pd.DataFrame, context: dict[str, Any], model_state: dict[str, Any] | None = None) -> pd.DataFrame:
        del context, model_state
        drift = float(self.params.get("drift", 0.0))
        threshold = float(self.params.get("threshold", 6.0))
        x = df["value"].astype(float).diff().fillna(0.0)
        std = x.rolling(window=60, min_periods=20).std(ddof=0).fillna(x.std(ddof=0) + 1.0e-9)
        z = (x - drift) / (std + 1.0e-9)
        pos = z.clip(lower=0).cumsum()
        neg = (-z).clip(lower=0).cumsum()
        score = np.maximum(pos, neg)
        return _finalize_output(
            df=df,
            raw_score=score,
            threshold=threshold,
            reason_code="CUSUM_DRIFT",
            explain="CUSUM drift indicates structural mean shift",
            artifacts={"drift": drift},
        )


def _ks_statistic_sample(a: np.ndarray, b: np.ndarray) -> float:
    if len(a) == 0 or len(b) == 0:
        return 0.0
    grid = np.unique(np.concatenate([a, b]))
    cdf_a = np.searchsorted(np.sort(a), grid, side="right") / len(a)
    cdf_b = np.searchsorted(np.sort(b), grid, side="right") / len(b)
    return float(np.max(np.abs(cdf_a - cdf_b)))


class RollingKSCheck(DQCheck):
    def __init__(self, **params: Any) -> None:
        super().__init__(
            name="rolling_ks",
            family="changepoint",
            scope="per_series",
            fit_policy="per_series",
            **params,
        )

    def score(self, df: pd.DataFrame, context: dict[str, Any], model_state: dict[str, Any] | None = None) -> pd.DataFrame:
        del context, model_state
        window = int(self.params.get("window", 120))
        ref = int(self.params.get("reference", 260))
        threshold = float(self.params.get("threshold", 0.35))
        values = df["value"].astype(float).to_numpy()
        scores = np.zeros(len(values), dtype=float)
        for i in range(len(values)):
            cur_start = max(0, i - window + 1)
            ref_end = cur_start
            ref_start = max(0, ref_end - ref)
            cur = values[cur_start : i + 1]
            baseline = values[ref_start:ref_end]
            if len(cur) >= max(20, window // 3) and len(baseline) >= max(20, ref // 3):
                scores[i] = _ks_statistic_sample(cur, baseline)
        return _finalize_output(
            df=df,
            raw_score=pd.Series(scores, index=df.index),
            threshold=threshold,
            reason_code="ROLLING_KS_SHIFT",
            explain="Rolling KS indicates distribution shift",
            artifacts={"window": window, "reference": ref},
        )
