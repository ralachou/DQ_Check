from __future__ import annotations

import concurrent.futures
from dataclasses import dataclass
from typing import Any

import numpy as np
import pandas as pd


@dataclass
class FeatureCacheItem:
    key: tuple[str, pd.Timestamp, int]
    frame: pd.DataFrame


class FeatureBuilder:
    """Windowed feature generation for anomaly models."""

    def __init__(self) -> None:
        self._cache: dict[tuple[str, pd.Timestamp, int], FeatureCacheItem] = {}

    def _cache_key(self, df: pd.DataFrame) -> tuple[str, pd.Timestamp, int]:
        rf_id = str(df["risk_factor_id"].iloc[0])
        last_date = pd.to_datetime(df["date"]).max()
        return rf_id, last_date, len(df)

    def build_features(
        self,
        df: pd.DataFrame,
        peer_df: pd.DataFrame | None = None,
        windows: tuple[int, int, int] = (20, 60, 252),
    ) -> pd.DataFrame:
        if df.empty:
            return df.copy()
        key = self._cache_key(df)
        if key in self._cache:
            return self._cache[key].frame.copy()
        w_short, w_mid, w_long = windows
        out = df.sort_values("date").copy()
        v = out["value"].astype(float)
        out["ret_1d"] = v.pct_change()
        out["ret_5d"] = v.pct_change(5)
        out["ret_10d"] = v.pct_change(10)
        out["rolling_mean_20"] = v.rolling(w_short, min_periods=5).mean()
        out["rolling_std_20"] = v.rolling(w_short, min_periods=5).std(ddof=0)
        med_20 = v.rolling(w_short, min_periods=5).median()
        out["rolling_mad_20"] = (v - med_20).abs().rolling(w_short, min_periods=5).median()
        out["rolling_q05_60"] = v.rolling(w_mid, min_periods=10).quantile(0.05)
        out["rolling_q95_60"] = v.rolling(w_mid, min_periods=10).quantile(0.95)
        out["rolling_skew_60"] = v.rolling(w_mid, min_periods=10).skew()
        out["rolling_kurt_60"] = v.rolling(w_mid, min_periods=10).kurt()
        out["rolling_vol_20"] = out["ret_1d"].rolling(w_short, min_periods=5).std(ddof=0)
        vol_med = out["rolling_vol_20"].rolling(w_mid, min_periods=10).median()
        vol_mad = (out["rolling_vol_20"] - vol_med).abs().rolling(w_mid, min_periods=10).median()
        out["vol_zscore_60"] = (out["rolling_vol_20"] - vol_med) / (1.4826 * vol_mad + 1.0e-9)
        out["drawdown_252"] = (v / v.rolling(w_long, min_periods=20).max()) - 1.0

        if peer_df is not None and not peer_df.empty:
            peer = peer_df.copy()
            peer["date"] = pd.to_datetime(peer["date"])
            peer_stats = (
                peer.groupby("date", as_index=False)["value"]
                .agg(peer_median="median", peer_q25=lambda x: x.quantile(0.25), peer_q75=lambda x: x.quantile(0.75))
            )
            out = out.merge(peer_stats, on="date", how="left")
            iqr = out["peer_q75"] - out["peer_q25"]
            out["peer_minus_median"] = out["value"] - out["peer_median"]
            out["peer_zscore"] = out["peer_minus_median"] / (iqr / 1.349 + 1.0e-9)
            out["peer_dispersion"] = iqr
            out["peer_percentile"] = out["value"].rank(pct=True)
        else:
            for col in ["peer_minus_median", "peer_zscore", "peer_percentile", "peer_dispersion"]:
                out[col] = np.nan

        out = out.replace([np.inf, -np.inf], np.nan)
        self._cache[key] = FeatureCacheItem(key=key, frame=out)
        return out.copy()

    def build_batch(
        self,
        df: pd.DataFrame,
        peer_groups: dict[str, pd.DataFrame] | None = None,
        max_workers: int = 4,
    ) -> pd.DataFrame:
        if df.empty:
            return df.copy()
        pieces = []
        groups = list(df.groupby("risk_factor_id"))

        def _build_one(item: tuple[str, pd.DataFrame]) -> pd.DataFrame:
            rf_id, part = item
            peer = (peer_groups or {}).get(rf_id)
            return self.build_features(part, peer_df=peer)

        with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as ex:
            for result in ex.map(_build_one, groups):
                pieces.append(result)
        return pd.concat(pieces, ignore_index=True)

