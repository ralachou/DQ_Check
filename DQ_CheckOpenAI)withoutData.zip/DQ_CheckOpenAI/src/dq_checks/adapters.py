from __future__ import annotations

import importlib
import json
import warnings
from typing import Any

import numpy as np
import pandas as pd
from sklearn.ensemble import IsolationForest
from sklearn.neighbors import LocalOutlierFactor

from dq_checks.base import DQCheck, severity_from_ratio


def _is_available(module_name: str) -> bool:
    try:
        importlib.import_module(module_name)
        return True
    except Exception:  # pragma: no cover - optional dependency
        return False


PYOD_AVAILABLE = _is_available("pyod")
ADTK_AVAILABLE = _is_available("adtk")
MERLION_AVAILABLE = _is_available("merlion")


def _optional_class(module_name: str, class_name: str):
    try:
        module = importlib.import_module(module_name)
        return getattr(module, class_name)
    except Exception:  # pragma: no cover - optional dependency
        return None


def _to_feature_matrix(df: pd.DataFrame) -> np.ndarray:
    feature_cols = [c for c in df.columns if c not in {"risk_factor_id", "date", "value"}]
    numeric_cols = [c for c in feature_cols if pd.api.types.is_numeric_dtype(df[c])]
    if not numeric_cols:
        x = pd.DataFrame(
            {
                "value": df["value"].astype(float),
                "ret_1d": df["value"].astype(float).pct_change().fillna(0.0),
                "ret_5d": df["value"].astype(float).pct_change(5).fillna(0.0),
                "ret_10d": df["value"].astype(float).pct_change(10).fillna(0.0),
            }
        )
    else:
        x = df[numeric_cols]
    return x.replace([np.inf, -np.inf], np.nan).fillna(0.0).to_numpy(dtype=float)


def _normalize_01(raw: np.ndarray) -> np.ndarray:
    raw = np.asarray(raw, dtype=float)
    lo = float(np.nanmin(raw)) if len(raw) else 0.0
    hi = float(np.nanmax(raw)) if len(raw) else 1.0
    return (raw - lo) / (hi - lo + 1.0e-12)


def _emit_output(
    df: pd.DataFrame,
    raw_score: np.ndarray | pd.Series,
    threshold: float,
    reason_code: str,
    explain: str,
    artifacts: dict[str, Any],
) -> pd.DataFrame:
    out = df[["risk_factor_id", "date"]].copy()
    out["raw_score"] = pd.Series(raw_score, index=df.index).astype(float).fillna(0.0)
    out["threshold"] = float(threshold)
    out["flag"] = out["raw_score"] >= out["threshold"]
    out["severity"] = severity_from_ratio(out["raw_score"] / (out["threshold"] + 1.0e-12))
    out.loc[~out["flag"], "severity"] = "Low"
    out["reason_code"] = np.where(out["flag"], reason_code, "OK")
    out["explain"] = np.where(out["flag"], explain, "No issue")
    out["artifacts_json"] = json.dumps(artifacts)
    return out


class PyODAdapterCheck(DQCheck):
    """
    PyOD/feature-matrix adapter.

    Supported model names (case-insensitive):
      - iforest, lof, ecod, hbos, knn, copod, pca
      - autoencoder (optional deep model)
      - deep_svdd (optional deep model)
    """

    MODEL_DESCRIPTIONS = {
        "iforest": "IsolationForest: tree isolation depth based anomaly scoring.",
        "lof": "LOF: local density deviation anomaly scoring.",
        "ecod": "ECOD: empirical CDF tail extremity anomaly scoring.",
        "hbos": "HBOS: histogram-density based outlier scoring.",
        "knn": "kNN: distance-to-neighbors anomaly scoring.",
        "copod": "COPOD: copula-based tail probability scoring.",
        "pca": "PCA: reconstruction/projection error based outlier scoring.",
        "autoencoder": "Deep AutoEncoder: neural reconstruction error scoring.",
        "deep_svdd": "Deep SVDD: one-class deep support region scoring.",
    }

    def __init__(self, model_name: str = "iforest", **params: Any) -> None:
        super().__init__(
            name=f"pyod_{model_name.lower()}",
            family="ml_unsupervised",
            scope="per_peer_group",
            fit_policy=params.pop("fit_policy", "per_peer_group"),
            **params,
        )
        self.model_name = model_name.lower()

    def _build_model(self):
        contamination = float(self.params.get("contamination", 0.002))
        n_neighbors = int(self.params.get("n_neighbors", 25))
        n_estimators = int(self.params.get("n_estimators", 200))

        if PYOD_AVAILABLE:
            pyod_map = {
                "iforest": ("pyod.models.iforest", "IForest", {"contamination": contamination}),
                "lof": ("pyod.models.lof", "LOF", {"contamination": contamination, "n_neighbors": n_neighbors}),
                "ecod": ("pyod.models.ecod", "ECOD", {"contamination": contamination}),
                "hbos": ("pyod.models.hbos", "HBOS", {"contamination": contamination}),
                "knn": ("pyod.models.knn", "KNN", {"contamination": contamination, "n_neighbors": n_neighbors}),
                "copod": ("pyod.models.copod", "COPOD", {"contamination": contamination}),
                "pca": ("pyod.models.pca", "PCA", {"contamination": contamination}),
                "autoencoder": ("pyod.models.auto_encoder", "AutoEncoder", {"contamination": contamination}),
                "deep_svdd": ("pyod.models.deep_svdd", "DeepSVDD", {"contamination": contamination}),
            }
            spec = pyod_map.get(self.model_name)
            if spec is None:
                raise ValueError(f"Unsupported PyOD model: {self.model_name}")
            cls = _optional_class(spec[0], spec[1])
            if cls is None:
                warnings.warn(f"PyOD model '{self.model_name}' not available in installed version; using fallback.")
            else:
                try:
                    kwargs = spec[2].copy()
                    kwargs.update({k: v for k, v in self.params.items() if k not in {"fit_policy", "threshold", "retrain_window"}})
                    return cls(**kwargs)
                except Exception as exc:
                    warnings.warn(f"PyOD model init failed for '{self.model_name}': {exc}; using fallback.")

        # sklearn fallback where possible
        if self.model_name == "iforest":
            return IsolationForest(contamination=contamination, random_state=42, n_estimators=n_estimators)
        if self.model_name == "lof":
            return LocalOutlierFactor(contamination=contamination, n_neighbors=n_neighbors, novelty=True)
        if self.model_name == "pca":
            from sklearn.decomposition import PCA

            n_comp = self.params.get("n_components", 0.95)
            return PCA(n_components=n_comp, svd_solver="full")
        warnings.warn(f"No fallback model available for PyOD model '{self.model_name}'.")
        return None

    def fit(self, df: pd.DataFrame, context: dict[str, Any]) -> dict[str, Any] | None:
        del context
        if df.empty:
            return None
        x = _to_feature_matrix(df)
        retrain_window = int(self.params.get("retrain_window", 0))
        if retrain_window > 0 and len(x) > retrain_window:
            x = x[-retrain_window:]
        model = self._build_model()
        if model is None:
            return {"model": None}
        # sklearn PCA fallback does not expose outlier scoring by default, no fit errors should propagate.
        model.fit(x)
        return {"model": model}

    def score(self, df: pd.DataFrame, context: dict[str, Any], model_state: dict[str, Any] | None = None) -> pd.DataFrame:
        del context
        if df.empty:
            return self.empty_result(df, "No data for PyOD scoring.")
        x = _to_feature_matrix(df)
        state = model_state or self.fit(df, {}) or {}
        model = state.get("model")
        if model is None:
            return self.empty_result(df, f"PyOD model '{self.model_name}' unavailable.")

        if hasattr(model, "decision_function"):
            raw = np.asarray(model.decision_function(x), dtype=float)
            # PyOD often returns high outlier score. If opposite convention, normalization still stabilizes.
        elif hasattr(model, "score_samples"):
            raw = -np.asarray(model.score_samples(x), dtype=float)
        elif model.__class__.__name__ == "PCA":
            # PCA fallback proxy: reconstruction error.
            x_proj = model.inverse_transform(model.transform(x))
            raw = np.linalg.norm(x - x_proj, axis=1)
        else:
            pred = np.asarray(model.predict(x))
            raw = np.where(pred < 0, 1.0, 0.0)

        raw01 = _normalize_01(raw)
        threshold = float(self.params.get("threshold", 0.98))
        return _emit_output(
            df=df,
            raw_score=raw01,
            threshold=threshold,
            reason_code="PYOD_ANOMALY",
            explain=f"PyOD model '{self.model_name}' exceeded threshold.",
            artifacts={
                "backend": "pyod",
                "model_name": self.model_name,
                "description": self.MODEL_DESCRIPTIONS.get(self.model_name, ""),
                "pyod_available": PYOD_AVAILABLE,
            },
        )


class ADTKAdapterCheck(DQCheck):
    """
    ADTK adapter for time-series-native detectors.

    Supported model names:
      - QuantileAD, SeasonalAD, LevelShiftAD,
      - PersistAD, InterQuartileRangeAD, AutoregressionAD
    """

    MODEL_DESCRIPTIONS = {
        "quantilead": "QuantileAD: flag observations outside learned quantile bands.",
        "seasonalad": "SeasonalAD: seasonality-aware anomaly detector.",
        "levelshiftad": "LevelShiftAD: abrupt level-shift detector.",
        "persistad": "PersistAD: persistent shift/deviation detector.",
        "interquartilerangead": "InterQuartileRangeAD: robust IQR range detector.",
        "autoregressionad": "AutoregressionAD: AR residual anomaly detector.",
    }

    def __init__(self, model_name: str = "LevelShiftAD", **params: Any) -> None:
        super().__init__(
            name=f"adtk_{model_name.lower()}",
            family="changepoint",
            scope="per_series",
            fit_policy=params.pop("fit_policy", "per_series"),
            **params,
        )
        self.model_name = model_name

    def _adtk_detect(self, df: pd.DataFrame) -> tuple[np.ndarray, dict[str, Any]]:
        if not ADTK_AVAILABLE:
            return np.array([]), {"mode": "fallback", "adtk_available": False}

        from adtk.data import validate_series

        detect_cls = _optional_class("adtk.detector", self.model_name)
        if detect_cls is None:
            return np.array([]), {"mode": "fallback", "adtk_available": True, "error": "detector_not_found"}

        s = df.sort_values("date").set_index("date")["value"].astype(float)
        s = validate_series(s)
        try:
            detector = detect_cls(**{k: v for k, v in self.params.items() if k not in {"fit_policy", "threshold"}})
            detected = detector.fit_detect(s)
            raw = detected.astype(float).to_numpy()
            return raw, {"mode": "adtk", "adtk_available": True}
        except Exception as exc:
            return np.array([]), {"mode": "fallback", "adtk_available": True, "error": str(exc)}

    def _fallback_detect(self, df: pd.DataFrame) -> np.ndarray:
        s = df["value"].astype(float)
        name = self.model_name.lower()
        if name == "quantilead":
            q_hi = s.rolling(60, min_periods=20).quantile(0.995)
            q_lo = s.rolling(60, min_periods=20).quantile(0.005)
            return ((s > q_hi) | (s < q_lo)).astype(float).to_numpy()
        if name == "seasonalad":
            seasonal = s.shift(5).rolling(20, min_periods=10).mean()
            resid = (s - seasonal).abs()
            sigma = resid.rolling(60, min_periods=20).std(ddof=0)
            return _normalize_01((resid / (sigma + 1.0e-9)).to_numpy())
        if name == "persistad":
            baseline = s.rolling(30, min_periods=10).mean()
            drift = (s - baseline).abs()
            sigma = drift.rolling(30, min_periods=10).std(ddof=0)
            return _normalize_01((drift / (sigma + 1.0e-9)).to_numpy())
        if name == "interquartilerangead":
            q75 = s.rolling(60, min_periods=20).quantile(0.75)
            q25 = s.rolling(60, min_periods=20).quantile(0.25)
            iqr = (q75 - q25).replace(0, np.nan)
            center = s.rolling(60, min_periods=20).median()
            return _normalize_01(((s - center).abs() / (iqr + 1.0e-9)).fillna(0.0).to_numpy())
        if name == "autoregressionad":
            pred = s.shift(1).rolling(20, min_periods=5).mean()
            resid = (s - pred).abs().fillna(0.0)
            sigma = resid.rolling(30, min_periods=10).std(ddof=0)
            return _normalize_01((resid / (sigma + 1.0e-9)).to_numpy())
        # LevelShiftAD default fallback
        level_shift = (s - s.rolling(30, min_periods=10).mean()).abs()
        mad = (s - s.rolling(30, min_periods=10).median()).abs().rolling(30, min_periods=10).median()
        return _normalize_01((level_shift / (1.4826 * mad + 1.0e-9)).fillna(0.0).to_numpy())

    def score(self, df: pd.DataFrame, context: dict[str, Any], model_state: dict[str, Any] | None = None) -> pd.DataFrame:
        del context, model_state
        if df.empty:
            return self.empty_result(df, "No rows for ADTK scoring.")

        raw, meta = self._adtk_detect(df)
        if len(raw) == 0:
            raw = self._fallback_detect(df)

        raw01 = _normalize_01(raw)
        threshold = float(self.params.get("threshold", 0.9))
        return _emit_output(
            df=df,
            raw_score=raw01,
            threshold=threshold,
            reason_code="ADTK_ANOMALY",
            explain=f"ADTK model '{self.model_name}' exceeded threshold.",
            artifacts={
                "backend": "adtk",
                "model_name": self.model_name,
                "description": self.MODEL_DESCRIPTIONS.get(self.model_name.lower(), ""),
                **meta,
            },
        )


class MerlionAdapterCheck(DQCheck):
    """
    Merlion adapter with runtime-safe fallbacks.

    Supported model names:
      - stl
      - prophet
      - iforest / isolationforest
      - changepoint
      - bocpd
    """

    MODEL_DESCRIPTIONS = {
        "stl": "STL residual anomaly detector.",
        "prophet": "Forecast residual anomaly detector using Prophet-style decomposition.",
        "iforest": "IsolationForest-based anomaly detector in Merlion family.",
        "isolationforest": "IsolationForest-based anomaly detector in Merlion family.",
        "changepoint": "Generic change-point detector.",
        "bocpd": "Bayesian online change-point detector (BOCPD).",
    }

    def __init__(self, model_name: str = "stl", **params: Any) -> None:
        super().__init__(
            name=f"merlion_{model_name.lower()}",
            family="changepoint",
            scope="per_series",
            fit_policy=params.pop("fit_policy", "per_series"),
            **params,
        )
        self.model_name = model_name.lower()

    def _fallback_score(self, df: pd.DataFrame) -> np.ndarray:
        s = df["value"].astype(float)
        if self.model_name in {"stl", "prophet"}:
            trend = s.rolling(252, min_periods=40).mean()
            resid = (s - trend).abs()
            sigma = resid.rolling(60, min_periods=20).std(ddof=0)
            return _normalize_01((resid / (sigma + 1.0e-9)).fillna(0.0).to_numpy())
        if self.model_name in {"iforest", "isolationforest"}:
            x = pd.DataFrame({"v": s, "ret": s.pct_change().fillna(0.0)}).fillna(0.0).to_numpy()
            model = IsolationForest(contamination=float(self.params.get("contamination", 0.002)), random_state=42)
            model.fit(x)
            return _normalize_01(-model.score_samples(x))
        # changepoint/bocpd default proxy
        x = s.diff().fillna(0.0)
        std = x.rolling(60, min_periods=20).std(ddof=0).fillna(x.std(ddof=0) + 1.0e-9)
        z = (x / (std + 1.0e-9)).abs()
        return _normalize_01(z.to_numpy())

    def _try_merlion_native(self, df: pd.DataFrame) -> tuple[np.ndarray, dict[str, Any]]:
        if not MERLION_AVAILABLE:
            return np.array([]), {"mode": "fallback", "merlion_available": False}
        # Keep native path defensive; fall back if model API/version differs.
        try:
            from merlion.utils import TimeSeries

            ts_df = df.sort_values("date")[["date", "value"]].copy()
            ts_df.columns = ["time", "value"]
            ts = TimeSeries.from_pd(ts_df.set_index("time"))

            model = None
            if self.model_name == "stl":
                cls = _optional_class("merlion.models.anomaly.forecast_based.mses", "MSESDetector")
                model = cls() if cls is not None else None
            elif self.model_name == "prophet":
                cls = _optional_class("merlion.models.anomaly.forecast_based.prophet", "ProphetDetector")
                model = cls() if cls is not None else None
            elif self.model_name in {"iforest", "isolationforest"}:
                cls = _optional_class("merlion.models.anomaly.isolation_forest", "IsolationForest")
                model = cls() if cls is not None else None
            elif self.model_name == "bocpd":
                cls = _optional_class("merlion.models.anomaly.change_point.bocpd", "BOCPD")
                model = cls() if cls is not None else None
            elif self.model_name == "changepoint":
                cls = _optional_class("merlion.models.anomaly.change_point.bocpd", "BOCPD")
                model = cls() if cls is not None else None

            if model is None:
                return np.array([]), {"mode": "fallback", "merlion_available": True, "error": "model_not_found"}
            model.train(ts)
            scores = model.get_anomaly_score(ts).to_pd().iloc[:, 0].astype(float).to_numpy()
            return _normalize_01(scores), {"mode": "merlion", "merlion_available": True}
        except Exception as exc:
            return np.array([]), {"mode": "fallback", "merlion_available": True, "error": str(exc)}

    def score(self, df: pd.DataFrame, context: dict[str, Any], model_state: dict[str, Any] | None = None) -> pd.DataFrame:
        del context, model_state
        if df.empty:
            return self.empty_result(df, "No rows for Merlion scoring.")
        raw, meta = self._try_merlion_native(df)
        if len(raw) == 0:
            raw = self._fallback_score(df)

        threshold = float(self.params.get("threshold", 0.9))
        return _emit_output(
            df=df,
            raw_score=raw,
            threshold=threshold,
            reason_code="MERLION_ANOMALY",
            explain=f"Merlion model '{self.model_name}' exceeded threshold.",
            artifacts={
                "backend": "merlion",
                "model_name": self.model_name,
                "description": self.MODEL_DESCRIPTIONS.get(self.model_name, ""),
                **meta,
            },
        )
