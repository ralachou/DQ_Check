from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any

import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, confusion_matrix, precision_score, recall_score, roc_auc_score
from sklearn.model_selection import train_test_split

try:
    from xgboost import XGBClassifier

    XGBOOST_AVAILABLE = True
except Exception:  # pragma: no cover - optional dependency
    XGBOOST_AVAILABLE = False

try:
    from lightgbm import LGBMClassifier

    LIGHTGBM_AVAILABLE = True
except Exception:  # pragma: no cover - optional dependency
    LIGHTGBM_AVAILABLE = False

PEER_KEYS_DEFAULT = ["rf_level1", "rf_level2", "rf_level3", "rf_level4", "rf_level5"]
STRESS_TAGS_DEFAULT = {"high_vol", "stress"}


def _severity_to_rank(s: pd.Series) -> pd.Series:
    return s.map({"Low": 0, "Med": 1, "High": 2, "Critical": 3}).fillna(0).astype(int)


def _rank_to_severity(rank: pd.Series) -> pd.Series:
    mapping = {0: "Low", 1: "Med", 2: "High", 3: "Critical"}
    return rank.clip(0, 3).map(mapping).fillna("Low")


@dataclass
class TriageModelInfo:
    enabled: bool
    model_name: str
    auc: float | None
    accuracy: float | None = None
    precision: float | None = None
    recall: float | None = None
    confusion_matrix: list[list[int]] = field(default_factory=list)
    features: list[str] = field(default_factory=list)
    candidates_tried: list[str] = field(default_factory=list)
    details: dict[str, Any] = field(default_factory=dict)


class FalseAlarmReducer:
    def __init__(
        self,
        regime_windows: list[dict[str, Any]] | None = None,
        peer_keys: list[str] | None = None,
        event_calendar: pd.DataFrame | None = None,
        event_window_days: int = 1,
        min_peer_group_size: int = 5,
        peer_confirm_ratio: float = 0.60,
        stress_tags: set[str] | None = None,
        stress_threshold_multiplier: float = 1.5,
        supervised_candidates: list[str] | None = None,
    ) -> None:
        self.regime_windows = regime_windows or []
        self.peer_keys = peer_keys or PEER_KEYS_DEFAULT
        self.event_calendar = event_calendar.copy() if event_calendar is not None else pd.DataFrame()
        self.event_window_days = int(event_window_days)
        self.min_peer_group_size = int(min_peer_group_size)
        self.peer_confirm_ratio = float(peer_confirm_ratio)
        self.stress_tags = stress_tags or STRESS_TAGS_DEFAULT
        self.stress_threshold_multiplier = float(stress_threshold_multiplier)
        self.supervised_candidates = supervised_candidates or [
            "xgboost",
            "lightgbm",
            "random_forest",
            "logistic_regression",
        ]

    def tag_regime(self, dates: pd.Series, as_of_date: pd.Timestamp | None = None) -> pd.Series:
        as_of_date = as_of_date or pd.Timestamp.today().normalize()
        tags = pd.Series("normal", index=dates.index, dtype="object")
        d = pd.to_datetime(dates)
        for rw in self.regime_windows:
            tag = rw.get("regime_tag", "regime")
            if "relative_window_days" in rw:
                days = int(rw["relative_window_days"])
                start = as_of_date - pd.Timedelta(days=days)
                end = as_of_date
            else:
                start = pd.to_datetime(rw.get("start_date"))
                end = pd.to_datetime(rw.get("end_date"))
            mask = (d >= start) & (d <= end)
            tags.loc[mask] = tag
        return tags

    def _event_proximate(self, dates: pd.Series) -> pd.Series:
        if self.event_calendar.empty:
            return pd.Series(False, index=dates.index, dtype=bool)
        ec = self.event_calendar.copy()
        if "event_date" not in ec.columns:
            return pd.Series(False, index=dates.index, dtype=bool)
        ev_dates = pd.to_datetime(ec["event_date"]).dropna().dt.normalize().unique()
        d = pd.to_datetime(dates).dt.normalize()
        out = pd.Series(False, index=dates.index, dtype=bool)
        for ev in ev_dates:
            mask = (d >= ev - pd.Timedelta(days=self.event_window_days)) & (d <= ev + pd.Timedelta(days=self.event_window_days))
            out = out | mask
        return out

    def _peer_move_frame(self, raw_df: pd.DataFrame, membership: pd.DataFrame) -> pd.DataFrame:
        needed = ["risk_factor_id", "date", "value"]
        raw = raw_df[needed].copy()
        raw["date"] = pd.to_datetime(raw["date"])
        raw = raw.sort_values(["risk_factor_id", "date"]).drop_duplicates(["risk_factor_id", "date"], keep="last")
        m = membership[["risk_factor_id"] + self.peer_keys].drop_duplicates(["risk_factor_id"], keep="last")
        base = raw.merge(m, on="risk_factor_id", how="left")
        base["series_move"] = base.groupby("risk_factor_id")["value"].diff()
        group_cols = self.peer_keys + ["date"]
        peer = (
            base.groupby(group_cols, as_index=False)
            .agg(
                peer_median_move=("series_move", "median"),
                peer_q25=("series_move", lambda x: x.quantile(0.25)),
                peer_q75=("series_move", lambda x: x.quantile(0.75)),
                peer_median_value=("value", "median"),
                peer_group_size=("risk_factor_id", "nunique"),
            )
        )
        peer["peer_iqr_move"] = peer["peer_q75"] - peer["peer_q25"]
        merged = base.merge(peer[group_cols + ["peer_median_move", "peer_iqr_move", "peer_median_value", "peer_group_size"]], on=group_cols, how="left")
        merged = merged.sort_values(["risk_factor_id", "date"]).reset_index(drop=False).rename(columns={"index": "_orig_idx"})
        corr_parts: list[pd.Series] = []
        for _, grp in merged.groupby("risk_factor_id", sort=False):
            corr = grp["value"].rolling(60, min_periods=20).corr(grp["peer_median_value"])
            corr_parts.append(pd.Series(corr.values, index=grp.index))
        if corr_parts:
            corr_series = pd.concat(corr_parts).sort_index()
            merged["peer_corr_60d"] = corr_series.values
        else:
            merged["peer_corr_60d"] = np.nan
        merged = merged.sort_values("_orig_idx").drop(columns=["_orig_idx"]).reset_index(drop=True)
        return merged

    def peer_consistency(
        self,
        alerts_df: pd.DataFrame,
        raw_df: pd.DataFrame,
        membership: pd.DataFrame,
    ) -> pd.DataFrame:
        if alerts_df.empty:
            return alerts_df.copy()
        peer_frame = self._peer_move_frame(raw_df=raw_df, membership=membership)
        join_cols = ["risk_factor_id", "date"]
        merge_cols = [
            "risk_factor_id",
            "date",
            "series_move",
            "peer_median_move",
            "peer_iqr_move",
            "peer_group_size",
            "peer_corr_60d",
        ]
        out = alerts_df.merge(peer_frame[merge_cols], on=join_cols, how="left")

        # Peer flagged ratio on same group/date.
        out_groups = out.copy()
        group_cols = [k for k in self.peer_keys if k in out_groups.columns] + ["date"]
        if group_cols and "flag" in out_groups.columns:
            grp = (
                out_groups.groupby(group_cols, as_index=False)
                .agg(
                    peer_flagged_count=("flag", "sum"),
                    peer_rows=("risk_factor_id", "nunique"),
                )
            )
            grp["peer_flag_ratio"] = grp["peer_flagged_count"] / (grp["peer_rows"] + 1.0e-9)
            out = out.merge(grp[group_cols + ["peer_flag_ratio"]], on=group_cols, how="left")
        else:
            out["peer_flag_ratio"] = 0.0

        align = np.sign(out["series_move"].fillna(0.0)) == np.sign(out["peer_median_move"].fillna(0.0))
        spread = out["peer_iqr_move"].abs().fillna(0.0)
        support = out["peer_median_move"].abs().fillna(0.0) / (spread + 1.0e-9)
        base_conf = np.where(align, support, 0.0)
        group_size = pd.to_numeric(out["peer_group_size"], errors="coerce").fillna(1.0)
        size_factor = np.clip(group_size / max(1.0, float(self.min_peer_group_size)), 0.2, 1.0)
        out["peer_support_score"] = base_conf
        out["peer_confidence"] = np.clip(base_conf * size_factor, 0.0, 1.0)
        ratio_ok = pd.to_numeric(out["peer_flag_ratio"], errors="coerce").fillna(0.0) >= self.peer_confirm_ratio
        support_ok = out["peer_confidence"] >= 0.5
        out["peer_confirmed"] = (ratio_ok | support_ok) & align
        return out

    def _apply_event_and_regime_adjustments(self, df: pd.DataFrame) -> pd.DataFrame:
        out = df.copy()
        out["event_proximate"] = self._event_proximate(out["date"])
        sev_rank = _severity_to_rank(out["severity"])
        integrity = out["reason_code"].str.contains("MISSING|STALE|INTEGRITY|GAP", case=False, na=False)
        downgrade = out["event_proximate"] & ~integrity
        # Event-proximate alerts are downgraded by one severity level.
        sev_rank = np.where(downgrade, np.maximum(sev_rank - 1, 0), sev_rank)
        # During stress/high-vol regimes, downgrade one level for non-integrity outliers.
        stress = out["regime_tag"].isin(self.stress_tags) & ~integrity
        sev_rank = np.where(stress, np.maximum(sev_rank - 1, 0), sev_rank)
        out["severity"] = _rank_to_severity(pd.Series(sev_rank, index=out.index))
        return out

    def triage_heuristic(self, df: pd.DataFrame) -> pd.DataFrame:
        out = self._apply_event_and_regime_adjustments(df)
        out["confidence_estimate"] = 0.50
        out["recommended_action"] = "NEEDS_REVIEW"

        integrity_issue = out["reason_code"].str.contains("MISSING|STALE|INTEGRITY|GAP", case=False, na=False)
        stress_regime = out["regime_tag"].isin(self.stress_tags)
        accept_mask = out["peer_confirmed"] & stress_regime
        bad_mask = (~out["peer_confirmed"]) & integrity_issue
        hard_bad = (~out["peer_confirmed"]) & out["severity"].isin(["High", "Critical"]) & (~out["event_proximate"])

        out.loc[accept_mask, "recommended_action"] = "ACCEPT_MOVE"
        out.loc[accept_mask, "confidence_estimate"] = 0.85
        out.loc[bad_mask | hard_bad, "recommended_action"] = "CONFIRM_BAD_DATA"
        out.loc[bad_mask | hard_bad, "confidence_estimate"] = 0.90
        out.loc[out["recommended_action"] == "NEEDS_REVIEW", "confidence_estimate"] = 0.60
        return out

    def _build_supervised_xy(self, df: pd.DataFrame, label_col: str) -> tuple[pd.DataFrame, pd.Series, list[str], pd.DataFrame]:
        tmp = df.reset_index().rename(columns={"index": "_row_id"}).copy()
        tmp["peer_confirmed"] = tmp["peer_confirmed"].astype(int)
        tmp["severity_num"] = _severity_to_rank(tmp["severity"])
        tmp["event_proximate"] = tmp.get("event_proximate", False).astype(int)
        features = [
            "raw_score",
            "norm_score",
            "peer_confidence",
            "peer_confirmed",
            "severity_num",
            "event_proximate",
        ]
        for col in ["rf_level1", "family", "regime_tag", "vendor", "recommended_action", "check_id"]:
            if col in tmp.columns:
                dummies = pd.get_dummies(tmp[col].fillna("UNK"), prefix=col)
                tmp = pd.concat([tmp, dummies], axis=1)
                features.extend(list(dummies.columns))
        tmp = tmp.dropna(subset=[label_col])
        x = tmp[features].fillna(0.0)
        y = tmp[label_col].astype(int)
        return x, y, features, tmp

    def _fit_candidate(self, name: str):
        lname = name.lower()
        if lname == "xgboost":
            if not XGBOOST_AVAILABLE:
                raise RuntimeError("xgboost_not_available")
            return XGBClassifier(
                n_estimators=300,
                max_depth=4,
                learning_rate=0.05,
                subsample=0.9,
                colsample_bytree=0.9,
                objective="binary:logistic",
                eval_metric="logloss",
                random_state=42,
            )
        if lname == "lightgbm":
            if not LIGHTGBM_AVAILABLE:
                raise RuntimeError("lightgbm_not_available")
            return LGBMClassifier(
                n_estimators=400,
                learning_rate=0.05,
                num_leaves=31,
                subsample=0.9,
                colsample_bytree=0.9,
                random_state=42,
            )
        if lname == "logistic_regression":
            return LogisticRegression(max_iter=1000, random_state=42)
        if lname == "random_forest":
            return RandomForestClassifier(n_estimators=300, random_state=42)
        raise RuntimeError(f"unsupported_candidate:{name}")

    def triage_supervised(
        self,
        df: pd.DataFrame,
        label_col: str = "is_false_alarm",
    ) -> tuple[pd.DataFrame, TriageModelInfo]:
        out = df.copy().reset_index(drop=True)
        if label_col not in out.columns or out[label_col].isna().all():
            out["false_alarm_probability"] = np.nan
            return out, TriageModelInfo(enabled=False, model_name="", auc=None)

        x, y, features, tmp = self._build_supervised_xy(out, label_col=label_col)
        if tmp.empty or len(np.unique(y)) < 2:
            out["false_alarm_probability"] = np.nan
            return out, TriageModelInfo(enabled=False, model_name="", auc=None, features=features)

        x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.25, random_state=42, stratify=y)
        candidates_tried: list[str] = []
        model = None
        chosen = ""
        details: dict[str, Any] = {}
        for cand in self.supervised_candidates:
            try:
                candidates_tried.append(cand)
                m = self._fit_candidate(cand)
                m.fit(x_train, y_train)
                model = m
                chosen = cand
                break
            except Exception as exc:
                details[f"{cand}_error"] = str(exc)
                continue

        if model is None:
            out["false_alarm_probability"] = np.nan
            return out, TriageModelInfo(
                enabled=False,
                model_name="",
                auc=None,
                features=features,
                candidates_tried=candidates_tried,
                details=details,
            )

        if hasattr(model, "predict_proba"):
            prob_all = model.predict_proba(x)[:, 1]
            prob_test = model.predict_proba(x_test)[:, 1]
        else:
            # defensive fallback for models without probability API
            scores_all = model.decision_function(x)  # type: ignore[attr-defined]
            scores_test = model.decision_function(x_test)  # type: ignore[attr-defined]
            prob_all = 1.0 / (1.0 + np.exp(-scores_all))
            prob_test = 1.0 / (1.0 + np.exp(-scores_test))

        pred_test = (prob_test >= 0.5).astype(int)
        auc = float(roc_auc_score(y_test, prob_test))
        acc = float(accuracy_score(y_test, pred_test))
        prec = float(precision_score(y_test, pred_test, zero_division=0))
        rec = float(recall_score(y_test, pred_test, zero_division=0))
        cm = confusion_matrix(y_test, pred_test).astype(int).tolist()

        out["false_alarm_probability"] = np.nan
        out.loc[tmp["_row_id"], "false_alarm_probability"] = prob_all
        model_info = TriageModelInfo(
            enabled=True,
            model_name=chosen,
            auc=auc,
            accuracy=acc,
            precision=prec,
            recall=rec,
            confusion_matrix=cm,
            features=features,
            candidates_tried=candidates_tried,
            details=details,
        )
        return out, model_info

    def run(
        self,
        alerts_df: pd.DataFrame,
        raw_df: pd.DataFrame,
        membership: pd.DataFrame,
        with_supervised: bool = False,
        label_col: str = "is_false_alarm",
    ) -> tuple[pd.DataFrame, dict[str, Any]]:
        if alerts_df.empty:
            return alerts_df.copy(), {"triage_model": {"enabled": False}}
        enriched = self.peer_consistency(alerts_df=alerts_df, raw_df=raw_df, membership=membership)
        enriched["regime_tag"] = self.tag_regime(enriched["date"])
        triaged = self.triage_heuristic(enriched)

        model_info = TriageModelInfo(enabled=False, model_name="", auc=None)
        if with_supervised:
            triaged, model_info = self.triage_supervised(triaged, label_col=label_col)
        triaged["triage_artifacts_json"] = json.dumps(
            {
                "peer_keys": self.peer_keys,
                "regime_windows_count": len(self.regime_windows),
                "supervised_enabled": model_info.enabled,
                "event_calendar_rows": int(len(self.event_calendar)),
                "min_peer_group_size": self.min_peer_group_size,
                "peer_confirm_ratio": self.peer_confirm_ratio,
                "stress_threshold_multiplier": self.stress_threshold_multiplier,
            }
        )
        audit = {"triage_model": model_info.__dict__}
        return triaged, audit
