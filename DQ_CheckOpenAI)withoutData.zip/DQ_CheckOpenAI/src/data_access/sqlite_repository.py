from __future__ import annotations

import sqlite3
from pathlib import Path
from typing import Any

import pandas as pd

from common.schemas import ensure_timeseries_schema
from data_access.base import TimeSeriesRepository


class SQLiteTimeSeriesRepository(TimeSeriesRepository):
    """SQLite-backed repository for local development and audits."""

    def __init__(self, db_path: str | Path) -> None:
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)

    def _connect(self) -> sqlite3.Connection:
        return sqlite3.connect(self.db_path)

    def get_series(
        self,
        risk_factor_ids: list[str] | None,
        start_date: str | pd.Timestamp,
        end_date: str | pd.Timestamp,
        business_date: str | pd.Timestamp | None = None,
    ) -> pd.DataFrame:
        with self._connect() as con:
            cols = pd.read_sql_query("PRAGMA table_info(timeseries_raw)", con)["name"].tolist()
            has_business_date = "business_date" in cols

            selected_cols = "business_date, risk_factor_id, date, value" if has_business_date else "risk_factor_id, date, value"
            query = f"""
            SELECT {selected_cols}
            FROM timeseries_raw
            WHERE date BETWEEN ? AND ?
            """
            params: list[Any] = [str(pd.to_datetime(start_date).date()), str(pd.to_datetime(end_date).date())]
            if has_business_date and business_date is not None:
                query += " AND business_date = ?"
                params.append(str(pd.to_datetime(business_date).date()))
            if risk_factor_ids:
                placeholders = ",".join(["?"] * len(risk_factor_ids))
                query += f" AND risk_factor_id IN ({placeholders})"
                params.extend(risk_factor_ids)
            df = pd.read_sql_query(query, con, params=params)

        default_business_date = business_date if business_date is not None else end_date
        if df.empty:
            return df
        return ensure_timeseries_schema(df, default_business_date=default_business_date)

    def list_risk_factors(self, filters: dict[str, Any] | None = None) -> pd.DataFrame:
        query = "SELECT * FROM risk_factors"
        params: list[Any] = []
        clauses = []
        for k, v in (filters or {}).items():
            if isinstance(v, list):
                placeholders = ",".join(["?"] * len(v))
                clauses.append(f"{k} IN ({placeholders})")
                params.extend(v)
            else:
                clauses.append(f"{k} = ?")
                params.append(v)
        if clauses:
            query += " WHERE " + " AND ".join(clauses)
        with self._connect() as con:
            return pd.read_sql_query(query, con, params=params)

    def write_results(
        self,
        df: pd.DataFrame,
        table_name: str,
        partition_cols: list[str] | None = None,
    ) -> None:
        del partition_cols
        with self._connect() as con:
            df.to_sql(table_name, con, if_exists="append", index=False)
