from __future__ import annotations

from typing import Any

import pandas as pd

from data_access.base import TimeSeriesRepository


class RestTimeSeriesRepositoryStub(TimeSeriesRepository):
    """Placeholder for future REST backend integration."""

    def __init__(self, base_url: str, timeout_seconds: int = 30) -> None:
        self.base_url = base_url
        self.timeout_seconds = timeout_seconds

    def get_series(
        self,
        risk_factor_ids: list[str] | None,
        start_date: str | pd.Timestamp,
        end_date: str | pd.Timestamp,
        business_date: str | pd.Timestamp | None = None,
    ) -> pd.DataFrame:
        del risk_factor_ids, start_date, end_date, business_date
        raise NotImplementedError("REST repository is a stub in this MVP.")

    def list_risk_factors(self, filters: dict[str, Any] | None = None) -> pd.DataFrame:
        del filters
        raise NotImplementedError("REST repository is a stub in this MVP.")

    def write_results(
        self,
        df: pd.DataFrame,
        table_name: str,
        partition_cols: list[str] | None = None,
    ) -> None:
        del df, table_name, partition_cols
        raise NotImplementedError("REST repository is a stub in this MVP.")
