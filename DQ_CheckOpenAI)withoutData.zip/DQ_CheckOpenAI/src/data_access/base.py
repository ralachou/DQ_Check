from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

import pandas as pd


class TimeSeriesRepository(ABC):
    """Abstract data access for raw time series and metadata."""

    @abstractmethod
    def get_series(
        self,
        risk_factor_ids: list[str] | None,
        start_date: str | pd.Timestamp,
        end_date: str | pd.Timestamp,
        business_date: str | pd.Timestamp | None = None,
    ) -> pd.DataFrame:
        raise NotImplementedError

    @abstractmethod
    def list_risk_factors(self, filters: dict[str, Any] | None = None) -> pd.DataFrame:
        raise NotImplementedError

    @abstractmethod
    def write_results(
        self,
        df: pd.DataFrame,
        table_name: str,
        partition_cols: list[str] | None = None,
    ) -> None:
        raise NotImplementedError
