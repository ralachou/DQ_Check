# DQ Health Control Tower

Production-minded MVP for financial market risk-factor time-series quality management.
Covers ~50,000 risk factors across all major asset classes (2007–present).

---

## Architecture Overview

```
Layer 1  ─ Data Access        src/data_access/      Parquet · SQLite · REST stub
Layer 2  ─ Universe           src/universe/         UniverseDefinition + Builder
Layer 3  ─ DQ Checks          src/checks/           Statistical · ADTK · Merlion · PyOD · Ensemble
Layer 4  ─ Config & Mapping   src/config/ + configs/ YAML model catalog + loaders
Layer 5  ─ Run Engine         src/engine/           Orchestrator · caching · parallel
Layer 6  ─ False Alarm        src/false_alarm/      Peer consistency · regime tagging · triage scoring
         ─ Normalization      src/normalization/    ECDF · robust-z · quantile · severity mapping
         ─ UI                 src/ui/               Dash 3-tab: Summary · Drilldown · Model Comparison
```

---

## Quick Start

### 1. Install dependencies

```bash
pip install -r requirements.txt

# Optional backends (install as needed):
pip install pyod          # ML anomaly detection
pip install adtk          # Time-series native detectors
pip install salesforce-merlion  # Advanced TS intelligence
pip install xgboost        # Supervised false-alarm classifier
```

### 2. Generate synthetic demo data

```bash
python scripts/generate_synthetic_data.py \
    --n-series 200 \
    --start 2018-01-01 \
    --end 2024-12-31 \
    --output data/
```

This creates:
- `data/raw/combined.parquet` — synthetic time series (~200 risk factors, ~7 years)
- `data/universe/rf_metadata.parquet` — risk factor metadata with rf_level1..5 taxonomy

### 3. Run DQ checks

```bash
# Run all checks for the US equity universe
python scripts/run_dq.py \
    --universe EQ_PRICE_US \
    --config configs/model_catalog.yaml \
    --data-root data/

# Run multiple universes
python scripts/run_dq.py \
    --universe EQ_PRICE_US IR_RATE_USD CP_RATE_CORP \
    --start 2022-01-01 \
    --end 2024-12-31

# Parallel execution
python scripts/run_dq.py --universe EQ_PRICE_US --jobs 4
```

Output written to `data/results/dq_results_enriched/`

### 4. Launch the Dash UI

```bash
python scripts/run_ui.py --data-root data --port 8050
```

Open browser at **http://localhost:8050**

---

## Project Structure

```
DQ_Checls/
├── configs/
│   ├── model_catalog.yaml          # Full model catalog (all asset classes)
│   └── universes/                  # Per-universe YAML overrides
│
├── src/
│   ├── data_access/
│   │   ├── base.py                 # TimeSeriesRepository ABC
│   │   ├── parquet_repo.py         # Parquet backend
│   │   ├── sqlite_repo.py          # SQLite backend
│   │   └── rest_stub.py            # REST API placeholder
│   │
│   ├── universe/
│   │   ├── definition.py           # UniverseDefinition + FilterRule
│   │   └── builder.py              # UniverseBuilder
│   │
│   ├── checks/
│   │   ├── base.py                 # DQCheck ABC (name, family, scope, fit, score)
│   │   ├── registry.py             # ModelRegistry (register, create, auto-register)
│   │   ├── features.py             # FeatureBuilder (4 feature families)
│   │   ├── ensemble.py             # EnsembleCheck (max/weighted/rank/vote)
│   │   ├── statistical/
│   │   │   ├── robust_zscore.py    # Rolling MAD-based z-score (primary detector)
│   │   │   ├── zscore.py           # Classic rolling z-score (benchmark)
│   │   │   ├── stale.py            # Consecutive no-change detector
│   │   │   ├── gaps.py             # Missing business date detector
│   │   │   ├── spike.py            # Return spike (MAD on returns)
│   │   │   ├── cusum.py            # CUSUM drift detector
│   │   │   ├── ks_statistic.py     # Two-sample KS distribution shift
│   │   │   └── quantile_band.py    # Rolling quantile band
│   │   └── adapters/
│   │       ├── pyod_adapter.py     # PyOD (IForest, LOF, ECOD, HBOS, …)
│   │       ├── adtk_adapter.py     # ADTK (LevelShift, Quantile, Persist, …)
│   │       └── merlion_adapter.py  # Merlion (STL, ZMS, changepoint, …)
│   │
│   ├── config/
│   │   ├── loader.py               # DQConfig: YAML → typed config + config hash
│   │   └── schema.py               # Pydantic/dataclass config schemas
│   │
│   ├── engine/
│   │   ├── runner.py               # RunEngine: orchestrator (parallel, incremental)
│   │   └── cache.py                # ModelStateCache (disk-backed)
│   │
│   ├── false_alarm/
│   │   ├── peer_consistency.py     # PeerConsistencyChecker
│   │   ├── regime_tagger.py        # RegimeTagger (GFC/COVID/etc.)
│   │   └── triage_scorer.py        # TriageScorer (heuristic + optional XGBoost)
│   │
│   ├── normalization/
│   │   ├── normalizer.py           # ScoreNormalizer (ECDF / robust-z / quantile)
│   │   └── severity_mapper.py      # SeverityMapper (norm_score → Critical/High/Med/Low)
│   │
│   └── ui/
│       └── app.py                  # Dash app (3 tabs)
│
├── scripts/
│   ├── generate_synthetic_data.py  # Synthetic risk-factor data generator
│   ├── run_dq.py                   # CLI: run DQ engine
│   └── run_ui.py                   # CLI: launch Dash UI
│
├── tests/
│   ├── test_checks.py              # Unit tests for DQ checks
│   └── test_normalizer.py          # Unit tests for normalization
│
├── data/                           # Created at runtime
│   ├── raw/                        # Raw time series (Parquet)
│   ├── results/                    # DQ results (partitioned Parquet)
│   ├── artifacts/normalization/    # Normalization artifacts
│   └── universe/                   # Universe membership + metadata
│
├── requirements.txt
└── README.md
```

---

## Risk Factor Taxonomy

Risk factors use a consistent 5-level hierarchy:

| Level | Name | Example |
|-------|------|---------|
| rf_level1 | Asset Class | `EQ_PRICE`, `IR_RATE`, `FX_VOL`, `CP_RATE` |
| rf_level2 | Currency | `USD`, `EUR`, `GBP` |
| rf_level3 | Product / Underlying | `SPX`, `TREASURY`, `CORP`, `CDX` |
| rf_level4 | Sub-type / Style | `SPOT`, `ForwardRate`, `IG`, `ATM` |
| rf_level5 | Tenor / Bucket | `NA`, `M01`, `Y05`, `Coupon4.5` |

---

## DQ Check Families

| Family | Models | Description |
|--------|--------|-------------|
| `integrity` | gaps_check, stale_check | Missing dates, frozen data |
| `stat_univariate` | robust_zscore, classic_zscore, spike_check, quantile_band | Univariate statistical detectors |
| `changepoint` | cusum_check, ks_statistic, adtk_levelshift, merlion_stl | Regime breaks, level shifts |
| `ml_unsupervised` | pyod_iforest, pyod_lof, pyod_ecod, pyod_hbos | Feature-matrix ML anomaly detection |
| `peer` | peer_consistency (Layer 6) | Cross-sectional peer validation |
| `ensemble` | EnsembleCheck | Aggregated score (max/weighted/rank/vote) |

---

## Output Schema

Every check produces this canonical output:

| Column | Type | Description |
|--------|------|-------------|
| `risk_factor_id` | str | Unique RF identifier |
| `date` | datetime | Observation date |
| `raw_score` | float | Native model score |
| `norm_score` | float | Normalized score in [0, 1] |
| `threshold` | float | Decision threshold |
| `flag` | bool | Anomaly flag |
| `severity` | str | Critical / High / Med / Low / OK |
| `reason_code` | str | Machine-readable reason |
| `explain` | str | Human-readable explanation |
| `artifacts_json` | str | Model metadata (JSON) |
| `check_id` | str | Model ID |
| `check_family` | str | Model family |
| `run_id` | str | DQ run identifier |
| `peer_confirmed` | bool | Flag confirmed by peers (Layer 6) |
| `regime_tag` | str | Applicable regime window |
| `recommended_action` | str | ACCEPT_MOVE / CONFIRM_BAD_DATA / NEEDS_REVIEW |
| `false_alarm_prob` | float | Estimated false-alarm probability |

---

## UI Tabs

**Tab 1 — Summary**
KPI cards (total series, alerts by severity) · alerts-over-time chart with regime overlays · severity pie · asset_class×currency heatmap · check-family breakdown

**Tab 2 — Hierarchy Drilldown**
AG Grid tree (asset_class → currency → product → subtype → tenor → rf_id) · click leaf → time-series plot with flagged points + issues table

**Tab 3 — Model Comparison**
Ranked table of most anomalous RFs by model · flags-per-model bar chart · severity distribution per model · click-through to Tab 2

---

## Configuration

All behavior is driven by `configs/model_catalog.yaml`:

```yaml
globals:
  regime_windows: [...]
  severity_defaults:
    Critical: 0.995
    High: 0.980

asset_class_defaults:
  EQ_PRICE:
    default_models:
      - id: eq_price_robust_z
        backend: local
        model_name: robust_zscore
        params: {window: 252, threshold: 6.0}

universes:
  EQ_PRICE_US:
    asset_class: EQ_PRICE
    models: [...]   # override asset-class defaults
```

---

## Running Tests

```bash
pytest tests/ -v
pytest tests/ --cov=src --cov-report=html
```

---

## Extending

**Add a new check:**
1. Create `src/checks/statistical/my_check.py` extending `DQCheck`
2. Register: `ModelRegistry.register("my_check", MyCheck)`
3. Add to `configs/model_catalog.yaml` under the relevant universe

**Add a new backend:**
1. Create `src/checks/adapters/my_adapter.py` extending `DQCheck`
2. Handle `model_state` from `fit()` in `score()`
3. Gracefully handle `ImportError` if the library isn't installed

---

## Design Principles

- **Auditable**: raw series never overwritten; results stored separately with run_id + config hash
- **Scalable**: joblib parallelism; partitioned Parquet output; model state cache
- **Config-driven**: all thresholds, windows, models in YAML
- **Graceful degradation**: PyOD/ADTK/Merlion are optional; local statistical checks always run
- **False-alarm aware**: peer consistency + regime tagging + heuristic/ML triage scoring
