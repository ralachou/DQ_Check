"""Unit tests for DQ checks."""
import numpy as np
import pandas as pd
from src.checks.statistical.robust_zscore import RobustZScoreCheck
from src.checks.statistical.stale import StaleCheck


def _make_series(n=500, inject_spike_at=None):
    rng = np.random.default_rng(42)
    dates = pd.bdate_range("2020-01-01", periods=n)
    vals = np.cumsum(rng.normal(0, 0.01, n)) + 100.0
    if inject_spike_at is not None:
        vals[inject_spike_at] += 5.0
    return pd.DataFrame({"risk_factor_id": "TEST", "date": dates, "value": vals})


def test_robust_zscore_returns_correct_cols():
    df = _make_series()
    check = RobustZScoreCheck(params={"window": 252, "threshold": 6.0})
    result = check.score(df)
    assert "flag" in result.columns
    assert "raw_score" in result.columns
    assert "severity" in result.columns


def test_spike_is_flagged():
    df = _make_series(inject_spike_at=300)
    check = RobustZScoreCheck(params={"window": 252, "threshold": 4.0, "min_periods": 50})
    result = check.score(df)
    assert result.iloc[300]["flag"] == True, "Spike should be flagged"


def test_no_false_positives_on_clean():
    rng = np.random.default_rng(123)
    dates = pd.bdate_range("2020-01-01", periods=1000)
    vals = np.cumsum(rng.normal(0, 0.005, 1000)) + 100.0
    df = pd.DataFrame({"risk_factor_id": "CLEAN", "date": dates, "value": vals})
    check = RobustZScoreCheck(params={"window": 252, "threshold": 8.0, "min_periods": 100})
    result = check.score(df)
    flag_rate = result["flag"].mean()
    assert flag_rate < 0.02, f"Too many false positives: {flag_rate:.2%}"
