"""Unit tests for score normalization."""
import numpy as np
import pandas as pd
from src.normalization.normalizer import ScoreNormalizer


def _make_results(n=1000):
    rng = np.random.default_rng(42)
    raw_scores = np.abs(rng.normal(0, 3.0, n))
    return pd.DataFrame({
        "risk_factor_id": [f"RF_{i % 20}" for i in range(n)],
        "date": pd.bdate_range("2020-01-01", periods=n),
        "check_id": ["robust_zscore"] * n,
        "raw_score": raw_scores,
        "flag": raw_scores > 4.0,
    })


def test_norm_score_range():
    df = _make_results()
    norm = ScoreNormalizer(strategy="ecdf")
    result = norm.fit_transform(df)
    assert "norm_score" in result.columns
    valid = result["norm_score"].dropna()
    assert (valid >= 0.0).all() and (valid <= 1.0).all()


def test_monotonicity():
    df = _make_results()
    norm = ScoreNormalizer(strategy="ecdf")
    result = norm.fit_transform(df)
    result = result.dropna(subset=["norm_score"])
    corr = result["raw_score"].corr(result["norm_score"])
    assert corr > 0.9, f"Expected high correlation, got {corr:.3f}"
