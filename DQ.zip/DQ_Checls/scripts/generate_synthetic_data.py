#!/usr/bin/env python3
"""Generate synthetic risk-factor time-series data."""
from __future__ import annotations

import argparse
import logging
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq

sys.path.insert(0, str(Path(__file__).parent.parent))

logging.basicConfig(level=logging.INFO)
log = logging.getLogger(__name__)

RF_SPECS = [
    ("EQ_PRICE", "USD", "SPX", "SPOT", "NA", 20, 4000.0, 0.015, 0.00005),
    ("EQ_PRICE", "USD", "AMZN", "SPOT", "NA", 5, 150.0, 0.020, 0.00008),
    ("IR_RATE", "USD", "TREASURY", "ForwardRate", "Y05", 5, 0.04, 0.002, 0.0),
    ("FX_RATE", "USD", "EUR", "SPOT", "NA", 5, 1.10, 0.006, 0.0),
    ("CP_RATE", "USD", "CORP", "IG", "Y05", 10, 0.012, 0.001, 0.0),
]


def _generate_series(rf_id, dates, base_val, daily_vol, drift, inject_anomalies=True, rng=None):
    rng = rng or np.random.default_rng()
    n = len(dates)
    returns = rng.normal(drift, daily_vol, n)
    if inject_anomalies and n > 500:
        spike_idx = rng.integers(200, n - 100)
        returns[spike_idx] += rng.choice([-1, 1]) * daily_vol * 15
        stale_idx = rng.integers(100, n - 20)
        returns[stale_idx:stale_idx + 5] = 0.0
    values = np.exp(np.cumsum(returns)) * base_val
    return pd.Series(values, index=dates, name=rf_id)


def generate_all(n_series, start_date, end_date, output_dir, seed=42):
    output_dir = Path(output_dir)
    (output_dir / "raw").mkdir(parents=True, exist_ok=True)
    (output_dir / "universe").mkdir(parents=True, exist_ok=True)

    dates = pd.bdate_range(start_date, end_date)
    rng = np.random.default_rng(seed)
    records, meta_rows = [], []
    total = 0

    for l1, l2, l3, l4, l5, n_spec, base, vol, drift in RF_SPECS:
        n_this = min(n_spec, max(1, n_series - total))
        for i in range(n_this):
            suffix = f"_{i:03d}" if n_this > 1 else ""
            rf_id = f"{l1}/{l2}/{l3}/{l4}/{l5}{suffix}"
            series = _generate_series(rf_id, dates, base, vol, drift, True, rng)
            for dt, val in series.items():
                records.append({"risk_factor_id": rf_id, "date": dt, "value": float(val)})
            meta_rows.append({
                "risk_factor_id": rf_id, "rf_level1": l1, "rf_level2": l2,
                "rf_level3": l3, "rf_level4": l4, "rf_level5": l5,
                "vendor": "SYNTHETIC",
            })
            total += 1
            if total >= n_series:
                break
        if total >= n_series:
            break

    ts_df = pd.DataFrame(records)
    ts_df["date"] = pd.to_datetime(ts_df["date"])
    pq.write_table(pa.Table.from_pandas(ts_df, preserve_index=False),
                   str(output_dir / "raw" / "combined.parquet"))
    log.info("Written: %s", output_dir / "raw" / "combined.parquet")

    meta_df = pd.DataFrame(meta_rows)
    pq.write_table(pa.Table.from_pandas(meta_df, preserve_index=False),
                   str(output_dir / "universe" / "rf_metadata.parquet"))
    log.info("Written: %s", output_dir / "universe" / "rf_metadata.parquet")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--n-series", type=int, default=100)
    parser.add_argument("--start", default="2018-01-01")
    parser.add_argument("--end", default="2024-12-31")
    parser.add_argument("--output", default="data")
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()
    generate_all(args.n_series, args.start, args.end, args.output, args.seed)


if __name__ == "__main__":
    main()
