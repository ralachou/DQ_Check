

import argparse
import logging
import sys
from datetime import date
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from src.config.loader import DQConfig
from src.data_access.parquet_repo import ParquetRepository
from src.engine.runner import RunEngine
from src.false_alarm.peer_consistency import PeerConsistencyChecker
from src.false_alarm.regime_tagger import RegimeTagger
from src.false_alarm.triage_scorer import TriageScorer
from src.normalization.normalizer import ScoreNormalizer
from src.normalization.severity_mapper import SeverityMapper

logging.basicConfig(level=logging.INFO)
log = logging.getLogger(__name__)


def run(args):
    config = DQConfig.from_file(args.config)
    repo = ParquetRepository(args.data_root)
    engine = RunEngine(repo, config, args.data_root, n_jobs=args.jobs)

    start = date.fromisoformat(args.start) if args.start else None
    end = date.fromisoformat(args.end) if args.end else None

    results = engine.run(args.universe, start, end, args.run_id)
    if results.empty:
        log.warning("No results.")
        return

    normalizer = ScoreNormalizer(strategy="ecdf")
    results = normalizer.fit_transform(results)
    results = SeverityMapper().map(results)

    if not args.skip_false_alarm:
        results = RegimeTagger(config.get_regime_windows()).tag(results)
        meta = repo.list_risk_factors()
        ts_df = repo.get_series(results["risk_factor_id"].unique().tolist(), start, end)
        results = PeerConsistencyChecker().enrich(results, ts_df, meta)
        results = TriageScorer().score(results)

    repo.write_results(results, "dq_results_enriched", ["universe_name"], "overwrite")
    log.info("Done. %d results, %d flagged", len(results), int(results["flag"].sum()))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--universe", nargs="+", required=True)
    parser.add_argument("--config", default="configs/model_catalog.yaml")
    parser.add_argument("--data-root", default="data")
    parser.add_argument("--start", default=None)
    parser.add_argument("--end", default=None)
    parser.add_argument("--run-id", default=None)
    parser.add_argument("--jobs", type=int, default=1)
    parser.add_argument("--skip-false-alarm", action="store_true")
    run(parser.parse_args())


if __name__ == "__main__":
    main()
