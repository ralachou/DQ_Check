#!/usr/bin/env python3
"""Launch the DQ Health Control Tower Dash UI."""
import argparse
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-root", default="data")
    parser.add_argument("--port", type=int, default=8050)
    parser.add_argument("--no-debug", action="store_true")
    args = parser.parse_args()

    os.environ["DQ_DATA_ROOT"] = str(Path(args.data_root).resolve())
    from src.ui.app import run_server
    run_server(data_root=args.data_root, port=args.port, debug=not args.no_debug)


if __name__ == "__main__":
    main()
