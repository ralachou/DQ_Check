"""Layer 2 — Universe Layer: UniverseDefinition model."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


@dataclass
class FilterRule:
    """Single filter condition applied to rf_metadata columns."""
    column: str
    operator: str       # in | eq | startswith | regex
    value: Any


@dataclass
class UniverseDefinition:
    """Describes a named set of risk factors (the DQ universe).

    A universe is the control-plane object that groups risk factors for a
    DQ run.  Membership is resolved at build-time from a repository.
    """
    name: str
    description: str = ""
    filter_rules: List[FilterRule] = field(default_factory=list)
    explicit_includes: List[str] = field(default_factory=list)
    explicit_excludes: List[str] = field(default_factory=list)
    tags: Dict[str, str] = field(default_factory=dict)

    # Resolved at build-time — use object.__setattr__ to bypass frozen check
    _member_ids: Optional[List[str]] = field(default=None, repr=False, compare=False)

    @property
    def member_ids(self) -> List[str]:
        if self._member_ids is None:
            raise RuntimeError(
                f"Universe '{self.name}' has not been built yet. "
                "Call UniverseBuilder.build() first."
            )
        return self._member_ids

    @classmethod
    def from_dict(cls, d: Dict) -> "UniverseDefinition":
        rules = [FilterRule(**r) for r in d.get("filter_rules", [])]
        return cls(
            name=d["name"],
            description=d.get("description", ""),
            filter_rules=rules,
            explicit_includes=d.get("explicit_includes", []),
            explicit_excludes=d.get("explicit_excludes", []),
            tags=d.get("tags", {}),
        )
