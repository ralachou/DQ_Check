"""Layer 2 — UniverseBuilder: resolves membership from a repository."""
from __future__ import annotations

import logging
from typing import Optional

import pandas as pd

from .definition import FilterRule, UniverseDefinition

log = logging.getLogger(__name__)

RF_LEVEL_COLS = ["rf_level1", "rf_level2", "rf_level3", "rf_level4", "rf_level5"]


class UniverseBuilder:
    """Resolves UniverseDefinition membership against a TimeSeriesRepository."""

    def __init__(self, repo):
        self._repo = repo
        self._membership_df: Optional[pd.DataFrame] = None

    def build(self, definition: UniverseDefinition) -> UniverseDefinition:
        log.info("Building universe '%s' ...", definition.name)

        meta = self._repo.list_risk_factors()
        self._ensure_rf_levels(meta)

        mask = pd.Series([True] * len(meta), index=meta.index)
        for rule in definition.filter_rules:
            mask &= self._apply_rule(meta, rule)
        filtered = meta[mask].copy()

        if definition.explicit_includes:
            extra = meta[meta["risk_factor_id"].isin(definition.explicit_includes)]
            filtered = pd.concat([filtered, extra]).drop_duplicates("risk_factor_id")

        if definition.explicit_excludes:
            filtered = filtered[~filtered["risk_factor_id"].isin(definition.explicit_excludes)]

        dupes = filtered[filtered.duplicated("risk_factor_id")]
        if not dupes.empty:
            log.warning("Duplicate risk_factor_ids removed: %d", len(dupes))
            filtered = filtered.drop_duplicates("risk_factor_id")

        empty_ids = filtered["risk_factor_id"].isna() | (filtered["risk_factor_id"] == "")
        if empty_ids.any():
            filtered = filtered[~empty_ids]

        filtered = filtered.reset_index(drop=True)
        filtered["universe_name"] = definition.name

        self._membership_df = filtered
        object.__setattr__(definition, "_member_ids", filtered["risk_factor_id"].tolist())

        log.info("Universe '%s' resolved to %d members.", definition.name, len(filtered))
        return definition

    def get_membership_df(self) -> pd.DataFrame:
        if self._membership_df is None:
            raise RuntimeError("Call build() first.")
        return self._membership_df

    @staticmethod
    def _ensure_rf_levels(meta: pd.DataFrame) -> None:
        for col in RF_LEVEL_COLS:
            if col not in meta.columns:
                meta[col] = "UNKNOWN"

    @staticmethod
    def _apply_rule(meta: pd.DataFrame, rule: FilterRule) -> pd.Series:
        col = rule.column
        if col not in meta.columns:
            log.warning("Filter column '%s' not in metadata; rule skipped.", col)
            return pd.Series([True] * len(meta), index=meta.index)

        op, val = rule.operator, rule.value
        if op == "eq":
            return meta[col] == val
        elif op == "in":
            return meta[col].isin(val if isinstance(val, list) else [val])
        elif op == "startswith":
            return meta[col].astype(str).str.startswith(str(val))
        elif op == "regex":
            return meta[col].astype(str).str.match(str(val))
        else:
            raise ValueError(f"Unknown filter operator '{op}'")
