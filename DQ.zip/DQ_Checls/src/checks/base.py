"""Layer 3 — DQ Check base interface."""
from __future__ import annotations

import abc
from typing import Any, Dict, Optional, Set

import pandas as pd

DQ_RESULT_COLS = [
    "risk_factor_id", "date", "raw_score", "norm_score",
    "threshold", "flag", "severity", "reason_code", "explain", "artifacts_json",
    "check_id", "check_family", "run_id",
]

SEVERITY_LEVELS = ["Critical", "High", "Med", "Low", "OK"]


class DQCheck(abc.ABC):
    """Abstract base for every DQ detector.

    Subclasses must implement ``score``.  ``fit`` is optional (stateless checks
    can leave it as a no-op returning None).
    """

    name: str = "base"
    family: str = "base"        # stat_univariate | integrity | changepoint | ml_unsupervised | peer | llm_assisted
    scope: str = "per_series"   # per_series | per_peer_group | global
    required_inputs: Set[str] = frozenset({"value"})
    version: str = "1.0"

    fit_policy: str = "per_series"
    min_training_points: int = 60
    min_peer_group_size: int = 5
    supports_partial_fit: bool = False

    def __init__(self, params: Optional[Dict[str, Any]] = None):
        self.params: Dict[str, Any] = params or {}
        self._model_state: Any = None

    @abc.abstractmethod
    def score(
        self,
        df: pd.DataFrame,
        context: Optional[Dict[str, Any]] = None,
        model_state: Any = None,
    ) -> pd.DataFrame:
        """Compute anomaly flags for the supplied time-series.

        Returns DataFrame with all DQ_RESULT_COLS (NaN-filled where not applicable).
        """

    def fit(
        self,
        df: pd.DataFrame,
        context: Optional[Dict[str, Any]] = None,
    ) -> Any:
        """Optional training step.  Default is no-op."""
        return None

    @staticmethod
    def empty_result(risk_factor_id: str, dates: pd.Series) -> pd.DataFrame:
        df = pd.DataFrame({"date": dates})
        df["risk_factor_id"] = risk_factor_id
        df["raw_score"] = 0.0
        df["norm_score"] = 0.0
        df["threshold"] = float("nan")
        df["flag"] = False
        df["severity"] = "OK"
        df["reason_code"] = ""
        df["explain"] = ""
        df["artifacts_json"] = "{}"
        df["check_id"] = ""
        df["check_family"] = ""
        df["run_id"] = ""
        return df

    @staticmethod
    def enforce_output_schema(df: pd.DataFrame) -> pd.DataFrame:
        for col in DQ_RESULT_COLS:
            if col not in df.columns:
                df[col] = None
        return df[DQ_RESULT_COLS + [c for c in df.columns if c not in DQ_RESULT_COLS]]
