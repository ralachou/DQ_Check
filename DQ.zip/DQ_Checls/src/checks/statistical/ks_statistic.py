"""Rolling KS statistic for distribution shift detection."""
from __future__ import annotations

from typing import Any, Dict, Optional

import numpy as np
import pandas as pd
from scipy.stats import ks_2samp

from ..base import DQCheck


class KSStatisticCheck(DQCheck):
    """Two-sample KS test between reference and recent windows."""

    name = "ks_statistic"
    family = "changepoint"
    scope = "per_series"

    def score(
        self,
        df: pd.DataFrame,
        context: Optional[Dict[str, Any]] = None,
        model_state: Any = None,
    ) -> pd.DataFrame:
        ref_window = int(self.params.get("ref_window", 252))
        test_window = int(self.params.get("test_window", 63))
        step = int(self.params.get("step", 21))
        threshold = float(self.params.get("threshold", 0.3))

        rf_id = df["risk_factor_id"].iloc[0] if "risk_factor_id" in df.columns else "unknown"
        df = df.sort_values("date").copy().reset_index(drop=True)
        series = df["value"].values
        n = len(series)

        ks_stats = np.zeros(n)
        min_start = ref_window + test_window
        if n >= min_start:
            for i in range(min_start, n, step):
                ref = series[max(0, i - ref_window - test_window) : i - test_window]
                test = series[i - test_window : i]
                if len(ref) > 5 and len(test) > 5:
                    stat, _ = ks_2samp(ref, test)
                    end = min(i + step, n)
                    ks_stats[i:end] = stat

        flag = ks_stats > threshold

        result = df[["date"]].copy()
        result["risk_factor_id"] = rf_id
        result["raw_score"] = ks_stats
        result["norm_score"] = np.nan
        result["threshold"] = threshold
        result["flag"] = flag
        result["severity"] = pd.Series(ks_stats).apply(
            lambda v: "Critical" if v > threshold * 1.5 else ("High" if v > threshold else "OK")
        ).values
        result["reason_code"] = pd.Series(flag).map({True: "KS_DIST_SHIFT", False: ""}).values
        result["explain"] = pd.Series(flag).map(
            {True: f"KS statistic {threshold:.2f} exceeded — distribution shift", False: ""}
        ).values
        result["artifacts_json"] = "{}"
        result["check_id"] = self.params.get("id", self.name)
        result["check_family"] = self.family
        result["run_id"] = (context or {}).get("run_id", "")
        return self.enforce_output_schema(result)
