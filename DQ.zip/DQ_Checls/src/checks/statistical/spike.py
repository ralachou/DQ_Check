"""Jump / spike detector on returns using robust statistics."""
from __future__ import annotations

from typing import Any, Dict, Optional

import numpy as np
import pandas as pd

from ..base import DQCheck

MAD_SCALE = 1.4826


def _severity(score: float, k: float) -> str:
    if score > k * 2:
        return "Critical"
    elif score > k * 1.5:
        return "High"
    elif score > k:
        return "Med"
    return "OK"


class SpikeCheck(DQCheck):
    """Detects abnormal return spikes using rolling MAD on 1-day returns."""

    name = "spike_check"
    family = "stat_univariate"
    scope = "per_series"

    def score(
        self,
        df: pd.DataFrame,
        context: Optional[Dict[str, Any]] = None,
        model_state: Any = None,
    ) -> pd.DataFrame:
        window = int(self.params.get("window", 252))
        k = float(self.params.get("threshold", 6.0))
        use_pct = bool(self.params.get("use_pct_change", True))
        min_periods = int(self.params.get("min_periods", max(30, window // 4)))

        rf_id = df["risk_factor_id"].iloc[0] if "risk_factor_id" in df.columns else "unknown"
        df = df.sort_values("date").copy()
        series = df["value"]

        returns = series.pct_change() if use_pct else series.diff()

        roll_med = returns.rolling(window, min_periods=min_periods).median()
        roll_mad = returns.rolling(window, min_periods=min_periods).apply(
            lambda x: np.median(np.abs(x - np.median(x))), raw=True
        )
        spike_z = (returns - roll_med).abs() / (MAD_SCALE * roll_mad + 1e-8)

        result = df[["date"]].copy()
        result["risk_factor_id"] = rf_id
        result["raw_score"] = spike_z.values
        result["norm_score"] = np.nan
        result["threshold"] = k
        result["flag"] = (spike_z > k).values
        result["severity"] = spike_z.apply(lambda v: _severity(v, k))
        result["reason_code"] = result["flag"].map({True: "SPIKE_FLAG", False: ""})
        result["explain"] = result.apply(
            lambda r: f"Return spike z={r['raw_score']:.2f} > {k}" if r["flag"] else "", axis=1
        )
        result["artifacts_json"] = "{}"
        result["check_id"] = self.params.get("id", self.name)
        result["check_family"] = self.family
        result["run_id"] = (context or {}).get("run_id", "")
        return self.enforce_output_schema(result)
