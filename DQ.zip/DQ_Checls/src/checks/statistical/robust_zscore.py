"""Rolling robust z-score (median/MAD) — primary detector."""
from __future__ import annotations

from typing import Any, Dict, Optional

import numpy as np
import pandas as pd

from ..base import DQCheck

MAD_SCALE = 1.4826  # Makes MAD consistent with std for Gaussian data


def _mad_apply(x: np.ndarray) -> float:
    return float(np.median(np.abs(x - np.median(x))))


def _severity(score: float, k: float) -> str:
    if score > k * 2.0:
        return "Critical"
    elif score > k * 1.5:
        return "High"
    elif score > k:
        return "Med"
    elif score > k * 0.75:
        return "Low"
    return "OK"


class RobustZScoreCheck(DQCheck):
    """Robust z-score using rolling median and MAD.

    Advantages over classic z-score:
    - Resistant to historical outliers distorting the baseline.
    - Configurable window per risk factor.
    """

    name = "robust_zscore"
    family = "stat_univariate"
    scope = "per_series"

    def score(
        self,
        df: pd.DataFrame,
        context: Optional[Dict[str, Any]] = None,
        model_state: Any = None,
    ) -> pd.DataFrame:
        window = int(self.params.get("window", 252))
        k = float(self.params.get("threshold", 6.0))
        min_periods = int(self.params.get("min_periods", max(30, window // 4)))

        rf_id = df["risk_factor_id"].iloc[0] if "risk_factor_id" in df.columns else "unknown"
        df = df.sort_values("date").copy()
        series = df["value"]

        roll_med = series.rolling(window, min_periods=min_periods).median()
        roll_mad = series.rolling(window, min_periods=min_periods).apply(_mad_apply, raw=True)
        robust_z = (series - roll_med).abs() / (MAD_SCALE * roll_mad + 1e-8)

        result = df[["date"]].copy()
        result["risk_factor_id"] = rf_id
        result["raw_score"] = robust_z.values
        result["norm_score"] = np.nan
        result["threshold"] = k
        result["flag"] = robust_z > k
        result["severity"] = robust_z.apply(lambda v: _severity(v, k))
        result["reason_code"] = result["flag"].map({True: "ROBUST_ZSCORE_FLAG", False: ""})
        result["explain"] = result.apply(
            lambda r: f"robust_z={r['raw_score']:.2f} > threshold {k}" if r["flag"] else "", axis=1
        )
        result["artifacts_json"] = "{}"
        result["check_id"] = self.params.get("id", self.name)
        result["check_family"] = self.family
        result["run_id"] = (context or {}).get("run_id", "")
        return self.enforce_output_schema(result)
