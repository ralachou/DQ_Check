"""Stale / no-change detector."""
from __future__ import annotations

from typing import Any, Dict, Optional

import numpy as np
import pandas as pd

from ..base import DQCheck


class StaleCheck(DQCheck):
    """Flags N consecutive identical values (stale/frozen data)."""

    name = "stale_check"
    family = "integrity"
    scope = "per_series"

    def score(
        self,
        df: pd.DataFrame,
        context: Optional[Dict[str, Any]] = None,
        model_state: Any = None,
    ) -> pd.DataFrame:
        n = int(self.params.get("n_consecutive", 5))
        tol = float(self.params.get("tolerance", 1e-9))

        rf_id = df["risk_factor_id"].iloc[0] if "risk_factor_id" in df.columns else "unknown"
        df = df.sort_values("date").copy()
        series = df["value"]

        changed = series.diff().abs() > tol
        changed.iloc[0] = True  # first point never stale

        # Cumulative streak counter
        streak = changed.groupby((changed != changed.shift()).cumsum()).cumcount()
        streak = streak.where(~changed, 0)

        flag = streak >= (n - 1)

        result = df[["date"]].copy()
        result["risk_factor_id"] = rf_id
        result["raw_score"] = streak.astype(float).values
        result["norm_score"] = np.nan
        result["threshold"] = float(n - 1)
        result["flag"] = flag.values
        result["severity"] = flag.map({True: "High", False: "OK"})
        result["reason_code"] = flag.map({True: "STALE_DATA", False: ""})
        result["explain"] = result.apply(
            lambda r: f"{int(r['raw_score'])+1} consecutive unchanged values" if r["flag"] else "", axis=1
        )
        result["artifacts_json"] = "{}"
        result["check_id"] = self.params.get("id", self.name)
        result["check_family"] = self.family
        result["run_id"] = (context or {}).get("run_id", "")
        return self.enforce_output_schema(result)
