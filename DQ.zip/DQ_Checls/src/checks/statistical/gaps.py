"""Missing / gaps detector — missing business dates."""
from __future__ import annotations

from typing import Any, Dict, Optional

import numpy as np
import pandas as pd

from ..base import DQCheck


class GapsCheck(DQCheck):
    """Detects missing business dates in a time-series."""

    name = "gaps_check"
    family = "integrity"
    scope = "per_series"

    def score(
        self,
        df: pd.DataFrame,
        context: Optional[Dict[str, Any]] = None,
        model_state: Any = None,
    ) -> pd.DataFrame:
        max_gap = int(self.params.get("max_gap_days", 1))
        calendar = self.params.get("calendar", "business")

        rf_id = df["risk_factor_id"].iloc[0] if "risk_factor_id" in df.columns else "unknown"
        df = df.sort_values("date").copy()
        df["date"] = pd.to_datetime(df["date"])

        df["gap_calendar"] = df["date"].diff().dt.days.fillna(0)

        if calendar == "business":
            # Approximate: subtract weekends
            def bday_gap(g: float) -> float:
                if g <= 1:
                    return 0.0
                # rough business day estimate
                weeks = g // 7
                remainder = g % 7
                return max(0.0, g - weeks * 2 - max(0, remainder - 5))
            df["effective_gap"] = df["gap_calendar"].apply(bday_gap)
        else:
            df["effective_gap"] = df["gap_calendar"]

        flag = df["effective_gap"] > max_gap

        result = df[["date"]].copy()
        result["risk_factor_id"] = rf_id
        result["raw_score"] = df["effective_gap"].values
        result["norm_score"] = np.nan
        result["threshold"] = float(max_gap)
        result["flag"] = flag.values
        result["severity"] = df["effective_gap"].apply(
            lambda v: "Critical" if v > 5 else ("High" if v > max_gap else "OK")
        )
        result["reason_code"] = flag.map({True: "MISSING_DATES", False: ""})
        result["explain"] = result.apply(
            lambda r: f"Gap of {int(r['raw_score'])} business days" if r["flag"] else "", axis=1
        )
        result["artifacts_json"] = "{}"
        result["check_id"] = self.params.get("id", self.name)
        result["check_family"] = self.family
        result["run_id"] = (context or {}).get("run_id", "")
        return self.enforce_output_schema(result)
