"""CUSUM drift detection."""
from __future__ import annotations

from typing import Any, Dict, Optional

import numpy as np
import pandas as pd

from ..base import DQCheck


def _severity(v: float, h: float) -> str:
    if v > h * 2:
        return "Critical"
    elif v > h * 1.5:
        return "High"
    elif v > h:
        return "Med"
    return "OK"


class CUSUMCheck(DQCheck):
    """Detects persistent drift / structural shifts via CUSUM statistic."""

    name = "cusum_check"
    family = "changepoint"
    scope = "per_series"

    def score(
        self,
        df: pd.DataFrame,
        context: Optional[Dict[str, Any]] = None,
        model_state: Any = None,
    ) -> pd.DataFrame:
        window = int(self.params.get("window", 252))
        k = float(self.params.get("slack", 0.5))
        h = float(self.params.get("threshold", 5.0))
        min_periods = int(self.params.get("min_periods", max(30, window // 4)))

        rf_id = df["risk_factor_id"].iloc[0] if "risk_factor_id" in df.columns else "unknown"
        df = df.sort_values("date").copy()
        series = df["value"]

        returns = series.diff().fillna(0.0)
        roll_std = returns.rolling(window, min_periods=min_periods).std().fillna(1.0)
        s = returns / (roll_std + 1e-8)

        cusum_pos = np.zeros(len(s))
        cusum_neg = np.zeros(len(s))
        for i in range(1, len(s)):
            cusum_pos[i] = max(0.0, cusum_pos[i - 1] + s.iloc[i] - k)
            cusum_neg[i] = max(0.0, cusum_neg[i - 1] - s.iloc[i] - k)

        cusum = np.maximum(cusum_pos, cusum_neg)
        flag = cusum > h

        result = df[["date"]].copy()
        result["risk_factor_id"] = rf_id
        result["raw_score"] = cusum
        result["norm_score"] = np.nan
        result["threshold"] = h
        result["flag"] = flag
        result["severity"] = pd.Series(cusum).apply(lambda v: _severity(v, h)).values
        result["reason_code"] = pd.Series(flag).map({True: "CUSUM_DRIFT", False: ""}).values
        result["explain"] = pd.Series(flag).map(
            {True: f"CUSUM statistic exceeds threshold {h}", False: ""}
        ).values
        result["artifacts_json"] = "{}"
        result["check_id"] = self.params.get("id", self.name)
        result["check_family"] = self.family
        result["run_id"] = (context or {}).get("run_id", "")
        return self.enforce_output_schema(result)
