"""Classic rolling z-score check (benchmark / current production method)."""
from __future__ import annotations

from typing import Any, Dict, Optional

import numpy as np
import pandas as pd

from ..base import DQCheck


def _severity(score: float, k: float) -> str:
    if score > k * 1.5:
        return "Critical"
    elif score > k * 1.2:
        return "High"
    elif score > k:
        return "Med"
    elif score > k * 0.8:
        return "Low"
    return "OK"


class ClassicZScoreCheck(DQCheck):
    """Replicates the current production approach: mean ± k*std on rolling window."""

    name = "classic_zscore"
    family = "stat_univariate"
    scope = "per_series"

    def score(
        self,
        df: pd.DataFrame,
        context: Optional[Dict[str, Any]] = None,
        model_state: Any = None,
    ) -> pd.DataFrame:
        window = int(self.params.get("window", 252))
        k = float(self.params.get("threshold", 4.0))
        min_periods = int(self.params.get("min_periods", window // 2))

        rf_id = df["risk_factor_id"].iloc[0] if "risk_factor_id" in df.columns else "unknown"
        df = df.sort_values("date").copy()
        series = df["value"]

        roll_mean = series.rolling(window, min_periods=min_periods).mean()
        roll_std = series.rolling(window, min_periods=min_periods).std()
        abs_z = ((series - roll_mean) / (roll_std + 1e-8)).abs()

        result = df[["date"]].copy()
        result["risk_factor_id"] = rf_id
        result["raw_score"] = abs_z.values
        result["norm_score"] = np.nan
        result["threshold"] = k
        result["flag"] = abs_z > k
        result["severity"] = abs_z.apply(lambda v: _severity(v, k))
        result["reason_code"] = result["flag"].map({True: "CLASSIC_ZSCORE_FLAG", False: ""})
        result["explain"] = result.apply(
            lambda r: f"z={r['raw_score']:.2f} > {k}" if r["flag"] else "", axis=1
        )
        result["artifacts_json"] = "{}"
        result["check_id"] = self.params.get("id", self.name)
        result["check_family"] = self.family
        result["run_id"] = (context or {}).get("run_id", "")
        return self.enforce_output_schema(result)
