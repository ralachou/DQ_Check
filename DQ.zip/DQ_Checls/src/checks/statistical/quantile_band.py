"""Quantile band detector."""
from __future__ import annotations

from typing import Any, Dict, Optional

import numpy as np
import pandas as pd

from ..base import DQCheck


class QuantileBandCheck(DQCheck):
    """Flag values outside rolling quantile bands."""

    name = "quantile_band"
    family = "stat_univariate"
    scope = "per_series"

    def score(
        self,
        df: pd.DataFrame,
        context: Optional[Dict[str, Any]] = None,
        model_state: Any = None,
    ) -> pd.DataFrame:
        window = int(self.params.get("window", 252))
        lower_q = float(self.params.get("lower_q", 0.005))
        upper_q = float(self.params.get("upper_q", 0.995))
        min_periods = int(self.params.get("min_periods", max(30, window // 4)))

        rf_id = df["risk_factor_id"].iloc[0] if "risk_factor_id" in df.columns else "unknown"
        df = df.sort_values("date").copy()
        series = df["value"]

        roll_lo = series.rolling(window, min_periods=min_periods).quantile(lower_q)
        roll_hi = series.rolling(window, min_periods=min_periods).quantile(upper_q)

        below = series < roll_lo
        above = series > roll_hi
        flag = below | above

        band_width = (roll_hi - roll_lo).abs() + 1e-8
        raw_score = np.where(
            above, (series - roll_hi) / band_width,
            np.where(below, (roll_lo - series) / band_width, 0.0)
        )
        raw_score = np.maximum(raw_score, 0.0)

        result = df[["date"]].copy()
        result["risk_factor_id"] = rf_id
        result["raw_score"] = raw_score
        result["norm_score"] = np.nan
        result["threshold"] = 0.0
        result["flag"] = flag.values
        result["severity"] = pd.Series(raw_score).apply(
            lambda v: "Critical" if v > 0.5 else ("High" if v > 0.2 else ("Med" if v > 0 else "OK"))
        ).values
        result["reason_code"] = flag.map({True: "QUANTILE_BAND_FLAG", False: ""})
        result["explain"] = flag.map(
            {True: f"Value outside [{lower_q:.3f}, {upper_q:.3f}] quantile band", False: ""}
        )
        result["artifacts_json"] = "{}"
        result["check_id"] = self.params.get("id", self.name)
        result["check_family"] = self.family
        result["run_id"] = (context or {}).get("run_id", "")
        return self.enforce_output_schema(result)
