"""Ensemble DQ check — aggregates scores from multiple child checks."""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

import numpy as np
import pandas as pd

from .base import DQCheck

log = logging.getLogger(__name__)


class EnsembleCheck(DQCheck):
    """Combines scores from multiple child DQCheck instances.

    Supported aggregation: max | weighted_avg | rank_agg | majority_vote
    """

    name = "ensemble"
    family = "ensemble"
    scope = "per_series"

    def __init__(self, params: Optional[Dict[str, Any]] = None):
        super().__init__(params)
        self._children: List[DQCheck] = []

    def add_child(self, check: DQCheck) -> None:
        self._children.append(check)

    def fit(self, df: pd.DataFrame, context: Optional[Dict[str, Any]] = None) -> Any:
        states = {}
        for child in self._children:
            try:
                states[child.name] = child.fit(df, context)
            except Exception as e:
                log.debug("Child fit failed %s: %s", child.name, e)
        return states

    def score(
        self,
        df: pd.DataFrame,
        context: Optional[Dict[str, Any]] = None,
        model_state: Any = None,
    ) -> pd.DataFrame:
        rf_id = df["risk_factor_id"].iloc[0] if "risk_factor_id" in df.columns else "unknown"

        if not self._children:
            return self.empty_result(rf_id, df["date"])

        method = self.params.get("aggregation", "max")
        weights = self.params.get("weights", {})
        threshold = float(self.params.get("threshold", 0.5))

        child_scores: List[np.ndarray] = []
        child_flags: List[np.ndarray] = []

        states = model_state or {}
        for child in self._children:
            try:
                res = child.score(df, context, states.get(child.name))
                raw = res["raw_score"].values.astype(float)
                rng = raw.max() - raw.min()
                norm = (raw - raw.min()) / (rng + 1e-8) if rng > 0 else np.zeros_like(raw)
                child_scores.append(norm)
                child_flags.append(res["flag"].values.astype(bool))
            except Exception as e:
                log.warning("Child check %s failed: %s", child.name, e)

        if not child_scores:
            return self.empty_result(rf_id, df["date"])

        score_matrix = np.vstack(child_scores)  # shape (n_checks, n_dates)

        if method == "max":
            agg_score = score_matrix.max(axis=0)
        elif method == "weighted_avg":
            w = np.array([weights.get(c.name, 1.0) for c in self._children[:len(child_scores)]])
            w = w / w.sum()
            agg_score = (score_matrix * w[:, None]).sum(axis=0)
        elif method == "rank_agg":
            ranks = np.argsort(np.argsort(score_matrix, axis=1), axis=1).astype(float)
            agg_score = ranks.mean(axis=0) / score_matrix.shape[1]
        elif method == "majority_vote":
            flag_matrix = np.vstack(child_flags)
            agg_score = flag_matrix.mean(axis=0)
        else:
            agg_score = score_matrix.max(axis=0)

        flag = agg_score > threshold
        df_sorted = df.sort_values("date").copy()

        result = df_sorted[["date"]].copy()
        result["risk_factor_id"] = rf_id
        result["raw_score"] = agg_score
        result["norm_score"] = agg_score
        result["threshold"] = threshold
        result["flag"] = flag
        result["severity"] = pd.Series(agg_score).apply(
            lambda v: "Critical" if v > 0.9 else ("High" if v > 0.75 else ("Med" if v > threshold else "OK"))
        ).values
        result["reason_code"] = pd.Series(flag).map(
            {True: f"ENSEMBLE_{method.upper()}_FLAG", False: ""}
        ).values
        result["explain"] = pd.Series(flag).map(
            {True: f"Ensemble ({method}) score {threshold} exceeded", False: ""}
        ).values
        result["artifacts_json"] = "{}"
        result["check_id"] = self.params.get("id", self.name)
        result["check_family"] = self.family
        result["run_id"] = (context or {}).get("run_id", "")
        return self.enforce_output_schema(result)
