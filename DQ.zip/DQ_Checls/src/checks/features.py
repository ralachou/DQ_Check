"""Layer 3 — FeatureBuilder: windowed feature engineering for ML models."""
from __future__ import annotations

import logging
from typing import Dict, List, Optional

import numpy as np
import pandas as pd

log = logging.getLogger(__name__)


class FeatureBuilder:
    """Transform a time-series into a feature matrix for ML anomaly detectors.

    Four feature families:
    1. Basic TS — returns, rolling stats
    2. Volatility & Regime — vol, drawdown
    3. Peer-based — deviations from peer group
    4. Curve features — derivatives (for rates/credit)
    """

    def __init__(
        self,
        windows: Optional[List[int]] = None,
        feature_set: str = "default_market_features",
        n_jobs: int = 1,
    ):
        self.windows = windows or [5, 21, 63, 252]
        self.feature_set = feature_set
        self.n_jobs = n_jobs

    def build(
        self,
        df: pd.DataFrame,
        peer_df: Optional[pd.DataFrame] = None,
    ) -> pd.DataFrame:
        """Build feature matrix for a single series.

        Parameters
        ----------
        df : DataFrame with columns [date, value] sorted by date.
        peer_df : Optional wide DataFrame (dates x risk_factor_ids) for peer features.
        """
        df = df.sort_values("date").copy()
        series = df.set_index("date")["value"]
        feats = pd.DataFrame(index=series.index)
        feats["value"] = series

        # 1) Basic TS features
        feats["ret_1d"] = series.pct_change(1)
        feats["ret_5d"] = series.pct_change(5)
        feats["ret_10d"] = series.pct_change(10)

        for w in self.windows:
            min_p = max(1, w // 2)
            feats[f"roll_mean_{w}"] = series.rolling(w, min_periods=min_p).mean()
            feats[f"roll_std_{w}"] = series.rolling(w, min_periods=min_p).std()
            feats[f"roll_mad_{w}"] = series.rolling(w, min_periods=min_p).apply(
                lambda x: float(np.median(np.abs(x - np.median(x)))), raw=True
            )
            feats[f"roll_q10_{w}"] = series.rolling(w, min_periods=min_p).quantile(0.10)
            feats[f"roll_q90_{w}"] = series.rolling(w, min_periods=min_p).quantile(0.90)

        w_long = max(self.windows)
        feats[f"roll_skew_{w_long}"] = series.rolling(w_long, min_periods=w_long // 2).skew()
        feats[f"roll_kurt_{w_long}"] = series.rolling(w_long, min_periods=w_long // 2).kurt()

        # 2) Volatility & Regime
        feats["roll_vol_21"] = feats["ret_1d"].rolling(21, min_periods=5).std() * np.sqrt(252)
        feats["roll_vol_63"] = feats["ret_1d"].rolling(63, min_periods=10).std() * np.sqrt(252)
        vol_mean = feats["roll_vol_21"].rolling(252, min_periods=63).mean()
        vol_std = feats["roll_vol_21"].rolling(252, min_periods=63).std()
        feats["vol_zscore"] = (feats["roll_vol_21"] - vol_mean) / (vol_std + 1e-8)
        roll_max = series.rolling(252, min_periods=1).max()
        feats["drawdown"] = (series - roll_max) / (roll_max.abs() + 1e-8)

        # 3) Peer-based
        if peer_df is not None and not peer_df.empty:
            peer_df = peer_df.reindex(series.index)
            peer_median = peer_df.median(axis=1)
            peer_std = peer_df.std(axis=1)
            feats["peer_diff"] = series - peer_median
            feats["peer_zscore"] = feats["peer_diff"] / (peer_std + 1e-8)
            feats["group_dispersion"] = peer_std / (peer_median.abs() + 1e-8)

        # 4) Curve features
        feats["d1"] = series.diff(1)
        feats["d2"] = feats["d1"].diff(1)

        return feats.reset_index()
