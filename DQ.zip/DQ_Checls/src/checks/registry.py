"""Layer 3 — ModelRegistry: dynamic registration + instantiation."""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional, Type

from .base import DQCheck

log = logging.getLogger(__name__)


class ModelRegistry:
    """Central registry mapping string model IDs to DQCheck classes."""

    _registry: Dict[str, Dict[str, Any]] = {}

    @classmethod
    def register(
        cls,
        model_id: str,
        check_class: Type[DQCheck],
        version: str = "1.0",
        description: str = "",
    ) -> None:
        cls._registry[model_id] = {
            "class": check_class,
            "version": version,
            "description": description,
        }
        log.debug("Registered model: %s (v%s)", model_id, version)

    @classmethod
    def create(cls, model_id: str, params: Optional[Dict[str, Any]] = None) -> DQCheck:
        if model_id not in cls._registry:
            raise KeyError(
                f"Model '{model_id}' not registered.  Available: {cls.list_models()}"
            )
        return cls._registry[model_id]["class"](params=params or {})

    @classmethod
    def create_from_config(cls, config: Dict[str, Any]) -> DQCheck:
        model_id = config.get("id") or config.get("name", "")
        params = dict(config.get("params", {}))
        params["id"] = model_id  # pass id into params for check_id tagging
        return cls.create(model_id, params)

    @classmethod
    def list_models(cls) -> List[str]:
        return list(cls._registry.keys())

    @classmethod
    def get_meta(cls, model_id: str) -> Dict[str, Any]:
        return cls._registry.get(model_id, {})


def _auto_register() -> None:
    """Auto-register all built-in checks on import."""
    from .statistical.zscore import ClassicZScoreCheck
    from .statistical.robust_zscore import RobustZScoreCheck
    from .statistical.stale import StaleCheck
    from .statistical.gaps import GapsCheck
    from .statistical.spike import SpikeCheck
    from .statistical.cusum import CUSUMCheck
    from .statistical.ks_statistic import KSStatisticCheck
    from .statistical.quantile_band import QuantileBandCheck

    ModelRegistry.register("classic_zscore", ClassicZScoreCheck, description="Rolling classical z-score")
    ModelRegistry.register("robust_zscore", RobustZScoreCheck, description="Rolling robust z-score (MAD)")
    ModelRegistry.register("stale_check", StaleCheck, description="Stale / no-change detector")
    ModelRegistry.register("gaps_check", GapsCheck, description="Missing business date detector")
    ModelRegistry.register("spike_check", SpikeCheck, description="Jump/spike on returns")
    ModelRegistry.register("cusum_check", CUSUMCheck, description="CUSUM drift detector")
    ModelRegistry.register("ks_statistic", KSStatisticCheck, description="Rolling KS distribution shift")
    ModelRegistry.register("quantile_band", QuantileBandCheck, description="Quantile band detector")

    try:
        from .adapters.pyod_adapter import PyODAdapter
        for mid in ("pyod_iforest", "pyod_lof", "pyod_ecod", "pyod_hbos", "pyod_knn", "pyod_copod"):
            ModelRegistry.register(mid, PyODAdapter, description=f"PyOD {mid.split('_', 1)[1]}")
    except ImportError:
        log.info("PyOD not installed — pyod_* models unavailable.")

    try:
        from .adapters.adtk_adapter import ADTKAdapter
        for mid in ("adtk_quantile", "adtk_levelshift", "adtk_persist", "adtk_seasonal", "adtk_iqr"):
            ModelRegistry.register(mid, ADTKAdapter, description=f"ADTK {mid.split('_', 1)[1]}")
    except ImportError:
        log.info("ADTK not installed — adtk_* models unavailable.")

    try:
        from .adapters.merlion_adapter import MerlionAdapter
        for mid in ("merlion_stl", "merlion_changepoint", "merlion_zms"):
            ModelRegistry.register(mid, MerlionAdapter, description=f"Merlion {mid.split('_', 1)[1]}")
    except ImportError:
        log.info("Merlion not installed — merlion_* models unavailable.")

    from .ensemble import EnsembleCheck
    ModelRegistry.register("ensemble", EnsembleCheck, description="Configurable ensemble")


_auto_register()
