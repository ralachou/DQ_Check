"""PyOD adapter — wraps any PyOD model behind the DQCheck interface."""
from __future__ import annotations

import json
import logging
from typing import Any, Dict, Optional

import numpy as np
import pandas as pd

from ..base import DQCheck
from ..features import FeatureBuilder

log = logging.getLogger(__name__)

try:
    import pyod  # noqa: F401
    PYOD_AVAILABLE = True
except ImportError:
    PYOD_AVAILABLE = False

_PYOD_MODEL_MAP = {
    "iforest": ("pyod.models.iforest", "IForest"),
    "lof": ("pyod.models.lof", "LOF"),
    "ecod": ("pyod.models.ecod", "ECOD"),
    "hbos": ("pyod.models.hbos", "HBOS"),
    "knn": ("pyod.models.knn", "KNN"),
    "copod": ("pyod.models.copod", "COPOD"),
    "pca": ("pyod.models.pca", "PCA"),
}


def _get_pyod_class(model_name: str):
    import importlib
    key = model_name.lower()
    if key not in _PYOD_MODEL_MAP:
        raise ValueError(f"Unknown PyOD model: {model_name}. Available: {list(_PYOD_MODEL_MAP)}")
    module_path, class_name = _PYOD_MODEL_MAP[key]
    return getattr(importlib.import_module(module_path), class_name)


class PyODAdapter(DQCheck):
    """Wraps PyOD models using engineered features.

    Raw score = PyOD decision_function() then ECDF-normalized.
    """

    name = "pyod_adapter"
    family = "ml_unsupervised"
    scope = "per_series"
    fit_policy = "per_peer_group"
    min_training_points = 60
    min_peer_group_size = 10

    def __init__(self, params: Optional[Dict[str, Any]] = None):
        super().__init__(params)
        self._feature_builder = FeatureBuilder(
            windows=(params or {}).get("windows", [21, 63, 252])
        )

    def fit(self, df: pd.DataFrame, context: Optional[Dict[str, Any]] = None) -> Any:
        if not PYOD_AVAILABLE:
            log.warning("PyOD not installed — PyODAdapter.fit() skipped.")
            return None

        model_name = self.params.get("model_name", "iforest")
        contamination = float(self.params.get("contamination", 0.01))
        PyODClass = _get_pyod_class(model_name)

        try:
            model = PyODClass(contamination=contamination)
        except TypeError:
            model = PyODClass()

        feats = self._build_feature_matrix(df, context)
        if feats is None or len(feats) < self.min_training_points:
            log.warning("Insufficient data for PyOD fit (%d rows)", len(feats) if feats is not None else 0)
            return None

        model.fit(feats)
        return {"model": model, "model_name": model_name, "n_train": len(feats)}

    def score(
        self,
        df: pd.DataFrame,
        context: Optional[Dict[str, Any]] = None,
        model_state: Any = None,
    ) -> pd.DataFrame:
        rf_id = df["risk_factor_id"].iloc[0] if "risk_factor_id" in df.columns else "unknown"
        df = df.sort_values("date").copy()

        if not PYOD_AVAILABLE or model_state is None:
            result = self.empty_result(rf_id, df["date"])
            result["check_id"] = self.params.get("id", self.name)
            result["check_family"] = self.family
            result["run_id"] = (context or {}).get("run_id", "")
            return self.enforce_output_schema(result)

        model = model_state["model"]
        feats = self._build_feature_matrix(df, context)
        threshold = float(self.params.get("threshold", 0.5))

        if feats is None or len(feats) == 0:
            result = self.empty_result(rf_id, df["date"])
            result["check_id"] = self.params.get("id", self.name)
            result["check_family"] = self.family
            result["run_id"] = (context or {}).get("run_id", "")
            return self.enforce_output_schema(result)

        raw_scores = model.decision_function(feats)
        raw_min, raw_max = raw_scores.min(), raw_scores.max()
        norm = (raw_scores - raw_min) / (raw_max - raw_min + 1e-8)
        flag = norm > threshold

        result = df[["date"]].copy()
        result["risk_factor_id"] = rf_id
        result["raw_score"] = raw_scores
        result["norm_score"] = norm
        result["threshold"] = threshold
        result["flag"] = flag
        result["severity"] = pd.Series(norm).apply(
            lambda v: "Critical" if v > 0.9 else ("High" if v > 0.75 else ("Med" if v > threshold else "OK"))
        ).values
        result["reason_code"] = pd.Series(flag).map({True: "PYOD_ANOMALY", False: ""}).values
        result["explain"] = pd.Series(flag).map(
            {True: f"PyOD score {threshold:.2f} exceeded", False: ""}
        ).values
        result["artifacts_json"] = json.dumps({
            "model_name": model_state.get("model_name", ""),
            "n_train": model_state.get("n_train", 0),
        })
        result["check_id"] = self.params.get("id", self.name)
        result["check_family"] = self.family
        result["run_id"] = (context or {}).get("run_id", "")
        return self.enforce_output_schema(result)

    def _build_feature_matrix(self, df: pd.DataFrame, context: Optional[Dict]) -> Optional[np.ndarray]:
        peer_df = (context or {}).get("peer_wide_df")
        feats_df = self._feature_builder.build(df, peer_df)
        drop_cols = {"date", "risk_factor_id"}
        feat_cols = [c for c in feats_df.columns if c not in drop_cols]
        mat = feats_df[feat_cols].select_dtypes(include=[np.number]).dropna()
        return mat.values if not mat.empty else None
