"""ADTK adapter — wraps ADTK detectors behind the DQCheck interface."""
from __future__ import annotations

import json
import logging
from typing import Any, Dict, Optional

import numpy as np
import pandas as pd

from ..base import DQCheck

log = logging.getLogger(__name__)

try:
    import adtk  # noqa: F401
    ADTK_AVAILABLE = True
except ImportError:
    ADTK_AVAILABLE = False

_ADTK_MODEL_MAP = {
    "quantile": ("adtk.detector", "QuantileAD"),
    "levelshift": ("adtk.detector", "LevelShiftAD"),
    "persist": ("adtk.detector", "PersistAD"),
    "seasonal": ("adtk.detector", "SeasonalAD"),
    "iqr": ("adtk.detector", "InterQuartileRangeAD"),
    "autoregression": ("adtk.detector", "AutoregressionAD"),
}


def _get_adtk_class(model_name: str):
    import importlib
    key = model_name.lower()
    if key not in _ADTK_MODEL_MAP:
        raise ValueError(f"Unknown ADTK model: {model_name}")
    module_path, class_name = _ADTK_MODEL_MAP[key]
    return getattr(importlib.import_module(module_path), class_name)


class ADTKAdapter(DQCheck):
    """Wraps ADTK anomaly detectors."""

    name = "adtk_adapter"
    family = "changepoint"
    scope = "per_series"
    fit_policy = "per_series"

    def fit(self, df: pd.DataFrame, context: Optional[Dict[str, Any]] = None) -> Any:
        return None  # Most ADTK detectors are stateless (fit during detect)

    def score(
        self,
        df: pd.DataFrame,
        context: Optional[Dict[str, Any]] = None,
        model_state: Any = None,
    ) -> pd.DataFrame:
        rf_id = df["risk_factor_id"].iloc[0] if "risk_factor_id" in df.columns else "unknown"
        df = df.sort_values("date").copy()

        if not ADTK_AVAILABLE:
            result = self.empty_result(rf_id, df["date"])
            result["check_id"] = self.params.get("id", self.name)
            result["check_family"] = self.family
            result["run_id"] = (context or {}).get("run_id", "")
            return self.enforce_output_schema(result)

        from adtk.data import validate_series

        model_name = self.params.get("model_name", "quantile")
        ADTKClass = _get_adtk_class(model_name)

        series = df.set_index("date")["value"]
        series.index = pd.DatetimeIndex(series.index)
        inferred_freq = pd.infer_freq(series.index)
        if inferred_freq:
            series.index.freq = inferred_freq

        try:
            series = validate_series(series)
            detector_params = {
                k: v for k, v in self.params.items()
                if k not in ("model_name", "id", "backend", "enabled")
            }
            detector = ADTKClass(**detector_params)
            anomalies = detector.fit_detect(series)
        except Exception as e:
            log.warning("ADTK detection failed for %s: %s", rf_id, e)
            result = self.empty_result(rf_id, df["date"])
            result["check_id"] = self.params.get("id", self.name)
            result["check_family"] = self.family
            result["run_id"] = (context or {}).get("run_id", "")
            return self.enforce_output_schema(result)

        if isinstance(anomalies, pd.DataFrame):
            flag_series = anomalies.any(axis=1)
        else:
            flag_series = anomalies.fillna(False).astype(bool)

        flag_series = flag_series.reindex(series.index, fill_value=False)

        result = df[["date"]].copy()
        result["risk_factor_id"] = rf_id
        result["raw_score"] = flag_series.values.astype(float)
        result["norm_score"] = np.nan
        result["threshold"] = 0.5
        result["flag"] = flag_series.values
        result["severity"] = pd.Series(flag_series.values).map({True: "High", False: "OK"}).values
        result["reason_code"] = pd.Series(flag_series.values).map(
            {True: f"ADTK_{model_name.upper()}_FLAG", False: ""}
        ).values
        result["explain"] = pd.Series(flag_series.values).map(
            {True: f"ADTK {model_name} detected anomaly", False: ""}
        ).values
        result["artifacts_json"] = json.dumps({"adtk_model": model_name})
        result["check_id"] = self.params.get("id", self.name)
        result["check_family"] = self.family
        result["run_id"] = (context or {}).get("run_id", "")
        return self.enforce_output_schema(result)
