"""Merlion adapter — wraps Salesforce Merlion behind DQCheck interface."""
from __future__ import annotations

import json
import logging
from typing import Any, Dict, Optional

import numpy as np
import pandas as pd

from ..base import DQCheck

log = logging.getLogger(__name__)

try:
    import merlion  # noqa: F401
    MERLION_AVAILABLE = True
except ImportError:
    MERLION_AVAILABLE = False


class MerlionAdapter(DQCheck):
    """Wraps Merlion anomaly detectors (ZMS, IsolationForest, WindStats)."""

    name = "merlion_adapter"
    family = "changepoint"
    scope = "per_series"
    fit_policy = "per_series"
    min_training_points = 252

    def fit(self, df: pd.DataFrame, context: Optional[Dict[str, Any]] = None) -> Any:
        if not MERLION_AVAILABLE:
            log.warning("Merlion not installed — MerlionAdapter.fit() skipped.")
            return None

        model_type = self.params.get("model_type", "ZMS")
        train_ts = self._to_merlion_ts(df)

        try:
            model = self._build_model(model_type)
            model.train(train_ts)
            return {"model": model, "model_type": model_type}
        except Exception as e:
            log.warning("Merlion fit failed for model %s: %s", model_type, e)
            return None

    def score(
        self,
        df: pd.DataFrame,
        context: Optional[Dict[str, Any]] = None,
        model_state: Any = None,
    ) -> pd.DataFrame:
        rf_id = df["risk_factor_id"].iloc[0] if "risk_factor_id" in df.columns else "unknown"
        df = df.sort_values("date").copy()

        if not MERLION_AVAILABLE or model_state is None:
            result = self.empty_result(rf_id, df["date"])
            result["check_id"] = self.params.get("id", self.name)
            result["check_family"] = self.family
            result["run_id"] = (context or {}).get("run_id", "")
            return self.enforce_output_schema(result)

        model = model_state["model"]
        test_ts = self._to_merlion_ts(df)
        threshold_val = float(self.params.get("threshold", 3.0))

        try:
            score_ts = model.get_anomaly_score(test_ts)
            scores = score_ts.to_pd().iloc[:, 0]
            scores = scores.reindex(pd.DatetimeIndex(df["date"]), method="nearest").fillna(0.0)
        except Exception as e:
            log.warning("Merlion scoring failed: %s", e)
            result = self.empty_result(rf_id, df["date"])
            result["check_id"] = self.params.get("id", self.name)
            result["check_family"] = self.family
            result["run_id"] = (context or {}).get("run_id", "")
            return self.enforce_output_schema(result)

        flag = scores.abs() > threshold_val

        result = df[["date"]].copy()
        result["risk_factor_id"] = rf_id
        result["raw_score"] = scores.values
        result["norm_score"] = np.nan
        result["threshold"] = threshold_val
        result["flag"] = flag.values
        result["severity"] = scores.abs().apply(
            lambda v: "Critical" if v > threshold_val * 2 else
                      ("High" if v > threshold_val * 1.5 else
                       ("Med" if v > threshold_val else "OK"))
        ).values
        result["reason_code"] = pd.Series(flag.values).map({True: "MERLION_ANOMALY", False: ""}).values
        result["explain"] = pd.Series(flag.values).map(
            {True: f"Merlion score exceeded threshold {threshold_val}", False: ""}
        ).values
        result["artifacts_json"] = json.dumps({"merlion_model": model_state.get("model_type", "")})
        result["check_id"] = self.params.get("id", self.name)
        result["check_family"] = self.family
        result["run_id"] = (context or {}).get("run_id", "")
        return self.enforce_output_schema(result)

    @staticmethod
    def _to_merlion_ts(df: pd.DataFrame):
        from merlion.utils import TimeSeries as MerlionTS, UnivariateTimeSeries
        series = df.set_index("date")["value"]
        series.index = pd.DatetimeIndex(series.index)
        return MerlionTS(UnivariateTimeSeries(series.index, series.values, "value"))

    @staticmethod
    def _build_model(model_type: str):
        import importlib
        model_map = {
            "ZMS": ("merlion.models.anomaly.zms", "ZMS"),
            "IsolationForest": ("merlion.models.anomaly.isolation_forest", "IsolationForest"),
            "WindStats": ("merlion.models.anomaly.windstats", "WindStats"),
        }
        if model_type not in model_map:
            raise ValueError(f"Unknown Merlion model type: {model_type}")
        mod_path, cls_name = model_map[model_type]
        cls = getattr(importlib.import_module(mod_path), cls_name)
        return cls(cls.config_class()())
