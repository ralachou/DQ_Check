"""Severity mapper — maps norm_score [0,1] to Critical/High/Med/Low/OK."""
from __future__ import annotations

from typing import Dict, Optional

import pandas as pd

DEFAULT_THRESHOLDS = {
    "Critical": 0.995,
    "High":     0.980,
    "Med":      0.950,
    "Low":      0.900,
}


class SeverityMapper:
    """Maps norm_score (0-1) to severity labels.

    Thresholds configurable per asset_class.
    Ensures consistent severity labels regardless of model backend.
    """

    def __init__(
        self,
        default_thresholds: Optional[Dict[str, float]] = None,
        asset_class_overrides: Optional[Dict[str, Dict[str, float]]] = None,
    ):
        self.default_thresholds = default_thresholds or DEFAULT_THRESHOLDS
        self.asset_class_overrides = asset_class_overrides or {}

    def map(self, results_df: pd.DataFrame) -> pd.DataFrame:
        results_df = results_df.copy()
        if "norm_score" not in results_df.columns:
            return results_df

        if "rf_level1" in results_df.columns:
            results_df["severity"] = results_df.apply(self._row_severity, axis=1)
        else:
            results_df["severity"] = results_df["norm_score"].apply(
                lambda s: self._score_to_severity(s, self.default_thresholds)
            )
        return results_df

    def _row_severity(self, row: pd.Series) -> str:
        thresholds = self.asset_class_overrides.get(
            row.get("rf_level1", ""), self.default_thresholds
        )
        score = row.get("norm_score", 0.0)
        return self._score_to_severity(float(score) if pd.notna(score) else 0.0, thresholds)

    @staticmethod
    def _score_to_severity(score: float, thresholds: Dict[str, float]) -> str:
        if score >= thresholds.get("Critical", 0.995):
            return "Critical"
        elif score >= thresholds.get("High", 0.980):
            return "High"
        elif score >= thresholds.get("Med", 0.950):
            return "Med"
        elif score >= thresholds.get("Low", 0.900):
            return "Low"
        return "OK"
