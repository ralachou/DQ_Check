"""Score normalization framework — makes 20+ heterogeneous model scores comparable."""
from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd
from scipy.interpolate import interp1d

log = logging.getLogger(__name__)

EPS = 1e-8
MAD_SCALE = 1.4826


class ScoreNormalizer:
    """Normalizes raw anomaly scores to a common [0, 1] scale.

    Supported strategies:
    - ecdf: empirical CDF on reference window (recommended — makes cross-model scores comparable)
    - robust_zscore: rolling median/MAD -> logistic CDF
    - quantile: map to within-group percentile rank
    """

    def __init__(
        self,
        strategy: str = "ecdf",
        reference_period: Optional[Tuple[str, str]] = None,
        n_bins: int = 1000,
    ):
        self.strategy = strategy
        self.reference_period = reference_period
        self.n_bins = n_bins

        self._ecdf_map: Dict[str, interp1d] = {}
        self._robust_stats: Dict[str, Tuple[float, float]] = {}

    def fit(
        self,
        results_df: pd.DataFrame,
        group_cols: Optional[List[str]] = None,
    ) -> "ScoreNormalizer":
        group_cols = group_cols or ["check_id"]

        for group_key, group in results_df.groupby(group_cols):
            raw = group["raw_score"].dropna().values
            if len(raw) < 10:
                continue
            key = str(group_key)
            if self.strategy == "ecdf":
                self._fit_ecdf(key, raw)
            elif self.strategy == "robust_zscore":
                self._fit_robust(key, raw)
        return self

    def _fit_ecdf(self, key: str, raw: np.ndarray) -> None:
        sorted_raw = np.sort(raw)
        n = len(sorted_raw)
        ecdf_y = np.arange(1, n + 1) / n
        x = np.concatenate([[-1e12], sorted_raw, [1e12]])
        y = np.concatenate([[0.0], ecdf_y, [1.0]])
        self._ecdf_map[key] = interp1d(x, y, bounds_error=False, fill_value=(0.0, 1.0))

    def _fit_robust(self, key: str, raw: np.ndarray) -> None:
        med = float(np.median(raw))
        mad = float(np.median(np.abs(raw - med)))
        self._robust_stats[key] = (med, mad)

    def transform(
        self,
        results_df: pd.DataFrame,
        group_cols: Optional[List[str]] = None,
    ) -> pd.DataFrame:
        group_cols = group_cols or ["check_id"]
        results_df = results_df.copy()

        if self.strategy == "quantile":
            results_df["norm_score"] = results_df.groupby(group_cols)["raw_score"].rank(pct=True)
            return results_df

        norm_scores = np.full(len(results_df), np.nan)

        for group_key, group in results_df.groupby(group_cols):
            key = str(group_key)
            raw = group["raw_score"].values.astype(float)
            loc = results_df.index.get_indexer(group.index)

            if self.strategy == "ecdf" and key in self._ecdf_map:
                norm_scores[loc] = self._ecdf_map[key](raw)
            elif self.strategy == "robust_zscore" and key in self._robust_stats:
                med, mad = self._robust_stats[key]
                z = (raw - med) / (MAD_SCALE * mad + EPS)
                norm_scores[loc] = 1.0 / (1.0 + np.exp(-z))
            else:
                # Fallback: min-max within group
                rng = raw.max() - raw.min()
                norm_scores[loc] = (raw - raw.min()) / (rng + EPS) if rng > EPS else np.zeros_like(raw)

        results_df["norm_score"] = norm_scores
        return results_df

    def fit_transform(
        self,
        results_df: pd.DataFrame,
        group_cols: Optional[List[str]] = None,
    ) -> pd.DataFrame:
        return self.fit(results_df, group_cols).transform(results_df, group_cols)

    def save_artifacts(self, out_dir: str | Path, run_id: str = "") -> None:
        out_dir = Path(out_dir)
        out_dir.mkdir(parents=True, exist_ok=True)
        artifacts = {
            "strategy": self.strategy,
            "run_id": run_id,
            "reference_period": self.reference_period,
            "ecdf_keys": list(self._ecdf_map.keys()),
            "robust_stats": {k: list(v) for k, v in self._robust_stats.items()},
        }
        fname = out_dir / f"norm_artifacts_{run_id or 'latest'}.json"
        with open(fname, "w") as f:
            json.dump(artifacts, f, indent=2, default=str)
        log.info("Normalization artifacts saved to %s", fname)
