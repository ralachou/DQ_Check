"""DQ Health Control Tower — Dash UI."""
from __future__ import annotations

import logging
import os
from pathlib import Path

import dash
from dash import Input, Output, callback, dcc, html
import plotly.express as px
import plotly.graph_objects as go
import pandas as pd

log = logging.getLogger(__name__)

DATA_ROOT = Path(os.environ.get("DQ_DATA_ROOT", "data"))
_CACHE = {}


def _load(name: str) -> pd.DataFrame:
    if name in _CACHE:
        return _CACHE[name]
    if name == "dq_results":
        try:
            import pyarrow.parquet as pq
            df = pq.read_table(str(DATA_ROOT / "results" / "dq_results_enriched")).to_pandas()
            df["date"] = pd.to_datetime(df["date"])
        except Exception:
            df = pd.DataFrame()
    elif name == "ts_raw":
        try:
            df = pd.read_parquet(DATA_ROOT / "raw" / "combined.parquet")
            df["date"] = pd.to_datetime(df["date"])
        except Exception:
            df = pd.DataFrame()
    elif name == "universe":
        try:
            df = pd.read_parquet(DATA_ROOT / "universe" / "rf_metadata.parquet")
        except Exception:
            df = pd.DataFrame()
    else:
        df = pd.DataFrame()
    _CACHE[name] = df
    return df


def invalidate_cache():
    _CACHE.clear()


SEVERITY_COLORS = {
    "Critical": "#d62728", "High": "#ff7f0e", "Med": "#ffdd57",
    "Low": "#aec7e8", "OK": "#98df8a",
}

app = dash.Dash(__name__, title="DQ Health Control Tower", suppress_callback_exceptions=True)

app.layout = html.Div([
    html.Div([
        html.H2("DQ Health Control Tower", style={"margin": "0", "color": "#fff"}),
        html.Span("Risk-Factor Time-Series Quality", style={"color": "#aaa", "marginLeft": "16px"}),
        html.Button("Refresh", id="btn-refresh", n_clicks=0,
                    style={"marginLeft": "auto", "padding": "6px 16px"}),
    ], style={"background": "#1a1a2e", "padding": "12px 24px",
              "display": "flex", "alignItems": "center"}),

    dcc.Store(id="store-refresh", data=0),

    dcc.Tabs(id="tabs-main", value="tab-summary", children=[
        dcc.Tab(label="Summary", value="tab-summary"),
        dcc.Tab(label="Drilldown", value="tab-drilldown"),
        dcc.Tab(label="Model Comparison", value="tab-comparison"),
    ]),

    html.Div(id="tab-content", style={"padding": "16px"}),
], style={"fontFamily": "Arial, sans-serif", "background": "#f4f6fa", "minHeight": "100vh"})


@app.callback(Output("tab-content", "children"), Input("tabs-main", "value"))
def render_tab(tab):
    if tab == "tab-summary":
        return _layout_summary()
    elif tab == "tab-drilldown":
        return _layout_drilldown()
    elif tab == "tab-comparison":
        return _layout_comparison()
    return html.Div("Unknown tab")


@app.callback(Output("store-refresh", "data"), Input("btn-refresh", "n_clicks"))
def refresh_data(n):
    invalidate_cache()
    return (n or 0) + 1


def _layout_summary():
    dq = _load("dq_results")
    if dq.empty:
        return html.Div("No data. Run DQ checks first.", style={"padding": "20px"})

    flagged = dq[dq.get("flag", False) == True]
    n_series = dq["risk_factor_id"].nunique() if "risk_factor_id" in dq.columns else 0
    n_flags = len(flagged)
    n_critical = (flagged["severity"] == "Critical").sum() if "severity" in flagged.columns else 0

    fig_time = go.Figure()
    if not flagged.empty and "date" in flagged.columns and "severity" in flagged.columns:
        daily = flagged.groupby(["date", "severity"]).size().reset_index(name="count")
        fig_time = px.area(daily, x="date", y="count", color="severity",
                          color_discrete_map=SEVERITY_COLORS, title="Alerts Over Time")
    else:
        fig_time.update_layout(title="No alerts to display")

    fig_sev = go.Figure()
    if not flagged.empty and "severity" in flagged.columns:
        sev = flagged["severity"].value_counts().reset_index()
        sev.columns = ["severity", "count"]
        fig_sev = px.pie(sev, names="severity", values="count",
                        color="severity", color_discrete_map=SEVERITY_COLORS,
                        title="Severity Breakdown")

    return html.Div([
        html.H3("Summary"),
        html.Div([
            _kpi_card("Total Series", n_series, "#2196F3"),
            _kpi_card("Total Alerts", n_flags, "#ff7f0e"),
            _kpi_card("Critical", n_critical, "#d62728"),
        ], style={"display": "flex", "gap": "12px", "marginBottom": "16px"}),
        dcc.Graph(figure=fig_time),
        dcc.Graph(figure=fig_sev),
    ])


def _kpi_card(label, value, color):
    return html.Div([
        html.Div(str(value), style={"fontSize": "2em", "fontWeight": "bold", "color": color}),
        html.Div(label, style={"fontSize": "0.85em", "color": "#555"}),
    ], style={"background": "#fff", "borderRadius": "8px", "padding": "16px 24px",
              "minWidth": "130px", "boxShadow": "0 1px 4px rgba(0,0,0,0.08)",
              "borderLeft": f"4px solid {color}"})


def _layout_drilldown():
    dq = _load("dq_results")
    if dq.empty:
        return html.Div("No data available", style={"padding": "20px"})

    flagged = dq[dq.get("flag", False) == True]
    if flagged.empty:
        return html.Div([html.H3("Hierarchy Drilldown"),
                        html.P("No alerts found")])

    summary = flagged.groupby("risk_factor_id").agg({
        "flag": "sum",
        "date": "max",
        "severity": lambda x: (x == "Critical").sum(),
    }).reset_index()
    summary.columns = ["risk_factor_id", "total_flags", "latest_date", "critical_count"]

    return html.Div([
        html.H3("Risk Factors with Alerts"),
        html.Table([
            html.Thead(html.Tr([html.Th(col) for col in summary.columns])),
            html.Tbody([
                html.Tr([html.Td(summary.iloc[i][col]) for col in summary.columns])
                for i in range(min(50, len(summary)))
            ])
        ], style={"width": "100%", "borderCollapse": "collapse"}),
    ])


def _layout_comparison():
    dq = _load("dq_results")
    if dq.empty:
        return html.Div("No data available", style={"padding": "20px"})

    return html.Div([
        html.H3("Model Comparison"),
        html.P("Compare anomaly detection models across the portfolio"),
    ])


def run_server(data_root=None, port=8050, debug=True):
    global DATA_ROOT
    if data_root:
        DATA_ROOT = Path(data_root)
    app.run(debug=debug, port=port)


if __name__ == "__main__":
    run_server()
