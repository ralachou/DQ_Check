"""Layer 1 - SQLite-backed TimeSeriesRepository."""
from __future__ import annotations

import sqlite3
from datetime import date
from pathlib import Path
from typing import List, Optional

import pandas as pd

from .base import TimeSeriesRepository


class SQLiteRepository(TimeSeriesRepository):
    """Read/write time-series from a local SQLite database.

    Schema:
        time_series(risk_factor_id TEXT, date TEXT, value REAL)
        rf_metadata(risk_factor_id TEXT PRIMARY KEY, rf_level1..5 TEXT, ...)
    """

    def __init__(self, db_path: str | Path):
        self.db_path = str(db_path)
        self._init_db()

    def _conn(self) -> sqlite3.Connection:
        return sqlite3.connect(self.db_path)

    def _init_db(self) -> None:
        with self._conn() as con:
            con.execute(
                """CREATE TABLE IF NOT EXISTS time_series (
                    risk_factor_id TEXT NOT NULL,
                    date TEXT NOT NULL,
                    value REAL,
                    PRIMARY KEY (risk_factor_id, date)
                )"""
            )
            con.execute(
                """CREATE TABLE IF NOT EXISTS rf_metadata (
                    risk_factor_id TEXT PRIMARY KEY,
                    rf_level1 TEXT, rf_level2 TEXT, rf_level3 TEXT,
                    rf_level4 TEXT, rf_level5 TEXT,
                    vendor TEXT, description TEXT
                )"""
            )
            con.commit()

    def get_series(
        self,
        risk_factor_ids: List[str],
        start_date: Optional[date] = None,
        end_date: Optional[date] = None,
    ) -> pd.DataFrame:
        placeholders = ",".join("?" * len(risk_factor_ids))
        query = f"SELECT risk_factor_id, date, value FROM time_series WHERE risk_factor_id IN ({placeholders})"
        params: list = list(risk_factor_ids)
        if start_date:
            query += " AND date >= ?"
            params.append(str(start_date))
        if end_date:
            query += " AND date <= ?"
            params.append(str(end_date))

        with self._conn() as con:
            df = pd.read_sql_query(query, con, params=params)
        if df.empty:
            return pd.DataFrame(columns=["risk_factor_id", "date", "value"])
        return self.validate_schema(df)

    def list_risk_factors(self, filters: Optional[dict] = None) -> pd.DataFrame:
        query = "SELECT * FROM rf_metadata"
        conditions, params = [], []
        if filters:
            for col, val in filters.items():
                if isinstance(val, (list, tuple)):
                    placeholders = ",".join("?" * len(val))
                    conditions.append(f"{col} IN ({placeholders})")
                    params.extend(val)
                else:
                    conditions.append(f"{col} = ?")
                    params.append(val)
        if conditions:
            query += " WHERE " + " AND ".join(conditions)
        with self._conn() as con:
            df = pd.read_sql_query(query, con, params=params)
        return df

    def write_results(
        self,
        df: pd.DataFrame,
        table_name: str,
        partition_cols: Optional[List[str]] = None,
        mode: str = "append",
    ) -> None:
        if_exists = "replace" if mode == "overwrite" else "append"
        with self._conn() as con:
            df.to_sql(table_name, con, if_exists=if_exists, index=False)

    def upsert_raw_series(self, df: pd.DataFrame) -> None:
        """Insert or replace raw time-series rows."""
        df = self.validate_schema(df)
        df["date"] = df["date"].dt.strftime("%Y-%m-%d")
        with self._conn() as con:
            df.to_sql("time_series", con, if_exists="append", index=False, method="multi")
