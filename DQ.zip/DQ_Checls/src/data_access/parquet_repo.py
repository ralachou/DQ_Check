"""Layer 1 - Parquet-backed TimeSeriesRepository."""
from __future__ import annotations

import os
from datetime import date
from pathlib import Path
from typing import List, Optional

import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq

from .base import TimeSeriesRepository


class ParquetRepository(TimeSeriesRepository):
    """Read/write time-series and results from a local Parquet directory tree.

    Expected raw layout:
        data_root/raw/<risk_factor_id>.parquet   - one file per RF, OR
        data_root/raw/combined.parquet            - single combined file
    """

    def __init__(self, data_root: str | Path):
        self.data_root = Path(data_root)
        self._raw_dir = self.data_root / "raw"
        self._results_dir = self.data_root / "results"
        self._raw_dir.mkdir(parents=True, exist_ok=True)
        self._results_dir.mkdir(parents=True, exist_ok=True)

        # Lazy-loaded combined cache
        self._combined: Optional[pd.DataFrame] = None

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _load_combined(self) -> pd.DataFrame:
        """Load all parquet files under raw/ into a single DataFrame (cached)."""
        if self._combined is not None:
            return self._combined

        files = list(self._raw_dir.rglob("*.parquet"))
        if not files:
            self._combined = pd.DataFrame(columns=["risk_factor_id", "date", "value"])
            return self._combined

        frames = []
        for f in files:
            df = pd.read_parquet(f)
            # If single-RF file, inject risk_factor_id from filename
            if "risk_factor_id" not in df.columns:
                df["risk_factor_id"] = f.stem
            frames.append(df)

        self._combined = pd.concat(frames, ignore_index=True)
        self._combined = self.validate_schema(self._combined)
        return self._combined

    def invalidate_cache(self) -> None:
        self._combined = None

    # ------------------------------------------------------------------
    # TimeSeriesRepository implementation
    # ------------------------------------------------------------------

    def get_series(
        self,
        risk_factor_ids: List[str],
        start_date: Optional[date] = None,
        end_date: Optional[date] = None,
    ) -> pd.DataFrame:
        df = self._load_combined()
        mask = df["risk_factor_id"].isin(risk_factor_ids)
        if start_date:
            mask &= df["date"] >= pd.Timestamp(start_date)
        if end_date:
            mask &= df["date"] <= pd.Timestamp(end_date)
        return df[mask].copy().reset_index(drop=True)

    def list_risk_factors(self, filters: Optional[dict] = None) -> pd.DataFrame:
        df = self._load_combined()
        meta = df[["risk_factor_id"]].drop_duplicates().copy()
        # If a metadata sidecar exists, merge it
        meta_path = self.data_root / "universe" / "rf_metadata.parquet"
        if meta_path.exists():
            meta_df = pd.read_parquet(meta_path)
            meta = meta.merge(meta_df, on="risk_factor_id", how="left")
        if filters:
            for col, val in filters.items():
                if col in meta.columns:
                    if isinstance(val, (list, tuple)):
                        meta = meta[meta[col].isin(val)]
                    else:
                        meta = meta[meta[col] == val]
        return meta.reset_index(drop=True)

    def write_results(
        self,
        df: pd.DataFrame,
        table_name: str,
        partition_cols: Optional[List[str]] = None,
        mode: str = "append",
    ) -> None:
        out_dir = self._results_dir / table_name
        out_dir.mkdir(parents=True, exist_ok=True)

        table = pa.Table.from_pandas(df, preserve_index=False)

        if partition_cols and all(c in df.columns for c in partition_cols):
            pq.write_to_dataset(
                table,
                root_path=str(out_dir),
                partition_cols=partition_cols,
                existing_data_behavior="overwrite_or_ignore" if mode == "overwrite" else "delete_matching",
            )
        else:
            # Single file with timestamp suffix for append
            import time
            fname = out_dir / f"part_{int(time.time_ns())}.parquet"
            pq.write_table(table, str(fname))

    def write_raw_series(self, df: pd.DataFrame) -> None:
        """Persist raw time-series. Creates one combined.parquet."""
        df = self.validate_schema(df)
        out = self._raw_dir / "combined.parquet"
        table = pa.Table.from_pandas(df, preserve_index=False)
        pq.write_table(table, str(out))
        self.invalidate_cache()
