"""Layer 1 - Data Access Layer: abstract repository interface."""
from __future__ import annotations

import abc
from datetime import date
from typing import List, Optional

import pandas as pd


# Canonical column names enforced across all backends
SCHEMA_COLS = {"risk_factor_id": "str", "date": "datetime64[ns]", "value": "float64"}


class TimeSeriesRepository(abc.ABC):
    """Uniform access to time-series + metadata from multiple backends."""

    # ------------------------------------------------------------------
    # Read side
    # ------------------------------------------------------------------

    @abc.abstractmethod
    def get_series(
        self,
        risk_factor_ids: List[str],
        start_date: Optional[date] = None,
        end_date: Optional[date] = None,
    ) -> pd.DataFrame:
        """Return a tidy DataFrame with columns: risk_factor_id, date, value.

        Returned dates are inclusive on both ends when provided.
        """

    @abc.abstractmethod
    def list_risk_factors(self, filters: Optional[dict] = None) -> pd.DataFrame:
        """Return metadata DataFrame.  Must include risk_factor_id + rf_level1..5."""

    # ------------------------------------------------------------------
    # Write side
    # ------------------------------------------------------------------

    @abc.abstractmethod
    def write_results(
        self,
        df: pd.DataFrame,
        table_name: str,
        partition_cols: Optional[List[str]] = None,
        mode: str = "append",
    ) -> None:
        """Persist results (never overwrites raw series)."""

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def validate_schema(df: pd.DataFrame) -> pd.DataFrame:
        """Enforce canonical schema; cast dtypes; raise on missing cols."""
        missing = set(SCHEMA_COLS) - set(df.columns)
        if missing:
            raise ValueError(f"DataFrame missing required columns: {missing}")
        df = df.copy()
        df["date"] = pd.to_datetime(df["date"])
        df["value"] = df["value"].astype("float64")
        df["risk_factor_id"] = df["risk_factor_id"].astype(str)
        return df
