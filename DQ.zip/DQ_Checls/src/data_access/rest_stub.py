"""Layer 1 - REST API stub (placeholder for future live data integration)."""
from __future__ import annotations

import warnings
from datetime import date
from typing import List, Optional

import pandas as pd

from .base import TimeSeriesRepository


class RestApiRepository(TimeSeriesRepository):
    """Stub implementation targeting a REST API endpoint.

    Replace _fetch_series / _fetch_metadata with real HTTP calls.
    """

    def __init__(self, base_url: str, api_key: str = "", timeout: int = 30):
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.timeout = timeout
        warnings.warn(
            "RestApiRepository is a stub - data calls will return empty frames.",
            UserWarning,
            stacklevel=2,
        )

    def _headers(self) -> dict:
        return {"Authorization": f"Bearer {self.api_key}"} if self.api_key else {}

    def get_series(
        self,
        risk_factor_ids: List[str],
        start_date: Optional[date] = None,
        end_date: Optional[date] = None,
    ) -> pd.DataFrame:
        # TODO: implement real HTTP call, e.g.:
        # resp = requests.post(f"{self.base_url}/timeseries", json={...}, headers=self._headers())
        warnings.warn("RestApiRepository.get_series: stub returning empty DataFrame.", UserWarning)
        return pd.DataFrame(columns=["risk_factor_id", "date", "value"])

    def list_risk_factors(self, filters: Optional[dict] = None) -> pd.DataFrame:
        warnings.warn("RestApiRepository.list_risk_factors: stub returning empty DataFrame.", UserWarning)
        return pd.DataFrame(columns=["risk_factor_id", "rf_level1", "rf_level2", "rf_level3", "rf_level4", "rf_level5"])

    def write_results(self, df, table_name, partition_cols=None, mode="append"):
        warnings.warn("RestApiRepository.write_results: stub - data NOT written.", UserWarning)
