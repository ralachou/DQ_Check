"""Model state cache — disk-backed, avoids unnecessary re-fitting."""
from __future__ import annotations

import hashlib
import logging
import pickle
from pathlib import Path
from typing import Any, Optional

log = logging.getLogger(__name__)


class ModelStateCache:
    """Simple disk-backed cache for fitted model states."""

    def __init__(self, cache_dir: str | Path, max_entries: int = 10_000):
        self.cache_dir = Path(cache_dir)
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self.max_entries = max_entries
        self._memory: dict = {}

    def _key_path(self, key: str) -> Path:
        h = hashlib.md5(key.encode()).hexdigest()
        return self.cache_dir / f"{h}.pkl"

    def get(self, key: str) -> Optional[Any]:
        if key in self._memory:
            return self._memory[key]
        p = self._key_path(key)
        if p.exists():
            try:
                with open(p, "rb") as f:
                    state = pickle.load(f)
                self._memory[key] = state
                return state
            except Exception as e:
                log.debug("Cache load failed for %s: %s", key, e)
        return None

    def set(self, key: str, value: Any) -> None:
        self._memory[key] = value
        try:
            with open(self._key_path(key), "wb") as f:
                pickle.dump(value, f)
        except Exception as e:
            log.debug("Cache write failed for %s: %s", key, e)

    def clear(self) -> None:
        self._memory.clear()
        for f in self.cache_dir.glob("*.pkl"):
            f.unlink(missing_ok=True)
