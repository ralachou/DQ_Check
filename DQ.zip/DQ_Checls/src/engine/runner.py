"""Layer 5 — Run Engine / Orchestrator."""
from __future__ import annotations

import logging
import time
import uuid
from datetime import date, datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

import pandas as pd

from src.checks.registry import ModelRegistry
from src.config.loader import DQConfig
from src.data_access.base import TimeSeriesRepository

log = logging.getLogger(__name__)


class RunEngine:
    """Orchestrates full DQ run: load universe -> run checks -> write results.

    Features:
    - Parallelism via joblib (optional, n_jobs > 1)
    - Model state caching (avoid unnecessary re-fit)
    - Incremental re-runs (only new dates)
    - Deterministic: same inputs/config -> same results
    """

    def __init__(
        self,
        repo: TimeSeriesRepository,
        config: DQConfig,
        output_dir: str | Path,
        n_jobs: int = 1,
        incremental: bool = False,
    ):
        self.repo = repo
        self.config = config
        self.output_dir = Path(output_dir)
        self.n_jobs = n_jobs
        self.incremental = incremental
        self._model_state_cache: Dict[str, Any] = {}

    def run(
        self,
        universe_names: List[str],
        start_date: Optional[date] = None,
        end_date: Optional[date] = None,
        run_id: Optional[str] = None,
    ) -> pd.DataFrame:
        run_id = run_id or f"run_{datetime.utcnow().strftime('%Y%m%dT%H%M%S')}_{uuid.uuid4().hex[:6]}"
        t0 = time.time()
        log.info("=== DQ Run %s started ===", run_id)

        all_results = []
        for universe_name in universe_names:
            log.info("Processing universe: %s", universe_name)
            try:
                results = self._run_universe(universe_name, run_id, start_date, end_date)
                if results is not None and not results.empty:
                    all_results.append(results)
            except Exception as e:
                log.error("Universe %s failed: %s", universe_name, e, exc_info=True)

        if not all_results:
            log.warning("No results produced.")
            return pd.DataFrame()

        combined = pd.concat(all_results, ignore_index=True)
        self._write_results(combined, run_id)

        elapsed = time.time() - t0
        n_flags = int(combined["flag"].sum()) if "flag" in combined.columns else 0
        log.info("=== DQ Run %s done in %.1fs — %d results, %d flags ===",
                 run_id, elapsed, len(combined), n_flags)
        return combined

    def _run_universe(
        self,
        universe_name: str,
        run_id: str,
        start_date: Optional[date],
        end_date: Optional[date],
    ) -> Optional[pd.DataFrame]:
        model_configs = self.config.get_models_for_universe(universe_name)
        enabled_models = [m for m in model_configs if m.get("enabled", True)]

        if not enabled_models:
            log.warning("No enabled models for universe %s", universe_name)
            return None

        membership = self.repo.list_risk_factors()
        if membership.empty:
            log.warning("No risk factors found.")
            return None

        rf_ids = membership["risk_factor_id"].tolist()

        log.info("Loading %d series for universe %s ...", len(rf_ids), universe_name)
        ts_df = self.repo.get_series(rf_ids, start_date, end_date)

        if ts_df.empty:
            log.warning("No time-series data for universe %s", universe_name)
            return None

        if self.incremental:
            ts_df = self._filter_incremental(ts_df, universe_name)

        peer_wide_df = self._build_peer_wide(ts_df)
        context_base = {
            "run_id": run_id,
            "universe_name": universe_name,
            "config_hash": self.config.hash,
            "regime_windows": self.config.get_regime_windows(),
            "peer_wide_df": peer_wide_df,
        }

        results = []
        if self.n_jobs == 1:
            for rf_id, group in ts_df.groupby("risk_factor_id"):
                for model_conf in enabled_models:
                    r = self._score_one(str(rf_id), group, model_conf, context_base)
                    if r is not None:
                        results.append(r)
        else:
            results = self._run_parallel(ts_df, enabled_models, context_base)

        if not results:
            return None

        df = pd.concat(results, ignore_index=True)
        df["universe_name"] = universe_name
        return df

    def _score_one(
        self,
        rf_id: str,
        group: pd.DataFrame,
        model_conf: Dict[str, Any],
        context: Dict[str, Any],
    ) -> Optional[pd.DataFrame]:
        model_id = model_conf.get("id") or model_conf.get("name", "")
        if not model_id:
            return None

        # Map YAML model IDs to registered names
        registered_name = self._resolve_model_name(model_conf)

        try:
            check = ModelRegistry.create(registered_name, params=dict(model_conf.get("params", {})))
            check.params["id"] = model_id
        except KeyError as e:
            log.debug("Model not registered: %s (conf id=%s)", e, model_id)
            return None

        cache_key = f"{rf_id}::{model_id}::{self.config.hash}"
        model_state = self._model_state_cache.get(cache_key)

        if model_state is None:
            try:
                model_state = check.fit(group, context)
                self._model_state_cache[cache_key] = model_state
            except Exception as e:
                log.debug("Fit failed for %s / %s: %s", rf_id, model_id, e)

        try:
            result = check.score(group, context, model_state)
            result["model_id"] = model_id
            return result
        except Exception as e:
            log.warning("Score failed for %s / %s: %s", rf_id, model_id, e)
            return None

    @staticmethod
    def _resolve_model_name(model_conf: Dict[str, Any]) -> str:
        """Map YAML model entry to registry key."""
        model_id = model_conf.get("id", "")
        model_name = model_conf.get("model_name", "")
        backend = model_conf.get("backend", "local")

        # If model_name is explicitly set, prefer it
        if model_name:
            return model_name

        # If backend is non-local, use pattern
        if backend == "pyod":
            pyod_name = model_conf.get("params", {}).get("model_name", "iforest")
            return f"pyod_{pyod_name}"
        elif backend == "adtk":
            adtk_name = model_conf.get("params", {}).get("model_name", "quantile")
            return f"adtk_{adtk_name}"
        elif backend == "merlion":
            return "merlion_zms"

        return model_id

    def _run_parallel(
        self,
        ts_df: pd.DataFrame,
        model_configs: List[Dict[str, Any]],
        context: Dict[str, Any],
    ) -> List[pd.DataFrame]:
        try:
            from joblib import Parallel, delayed
        except ImportError:
            log.warning("joblib not installed — falling back to sequential.")
            results = []
            for rf_id, group in ts_df.groupby("risk_factor_id"):
                for mc in model_configs:
                    r = self._score_one(str(rf_id), group, mc, context)
                    if r is not None:
                        results.append(r)
            return results

        tasks = [
            (str(rf_id), group.copy(), mc)
            for rf_id, group in ts_df.groupby("risk_factor_id")
            for mc in model_configs
        ]

        def _task(rf_id, group, mc):
            return self._score_one(rf_id, group, mc, context)

        out = Parallel(n_jobs=self.n_jobs)(
            delayed(_task)(rf_id, group, mc) for rf_id, group, mc in tasks
        )
        return [r for r in out if r is not None]

    @staticmethod
    def _build_peer_wide(ts_df: pd.DataFrame) -> pd.DataFrame:
        if ts_df.empty:
            return pd.DataFrame()
        try:
            return ts_df.pivot_table(index="date", columns="risk_factor_id", values="value")
        except Exception:
            return pd.DataFrame()

    def _filter_incremental(self, ts_df: pd.DataFrame, universe_name: str) -> pd.DataFrame:
        result_path = self.output_dir / "results" / "dq_results"
        if not result_path.exists():
            return ts_df
        try:
            import pyarrow.parquet as pq
            existing = pq.read_table(str(result_path)).to_pandas()
            if existing.empty or "date" not in existing.columns:
                return ts_df
            scored_dates = existing[
                existing.get("universe_name", pd.Series()) == universe_name
            ]["date"].unique()
            return ts_df[~ts_df["date"].isin(scored_dates)]
        except Exception:
            return ts_df

    def _write_results(self, df: pd.DataFrame, run_id: str) -> None:
        self.repo.write_results(
            df,
            table_name="dq_results",
            partition_cols=["universe_name", "check_family"],
            mode="append",
        )
        log.info("Results written for run %s", run_id)
