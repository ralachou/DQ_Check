"""Layer 4 — Configuration loader: YAML -> typed config objects."""
from __future__ import annotations

import hashlib
import json
import logging
from pathlib import Path
from typing import Any, Dict, List, Optional

import yaml

log = logging.getLogger(__name__)


def load_yaml(path: str | Path) -> Dict[str, Any]:
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f) or {}


def config_hash(config: Dict[str, Any]) -> str:
    canonical = json.dumps(config, sort_keys=True, default=str)
    return hashlib.sha256(canonical.encode()).hexdigest()[:16]


class DQConfig:
    """Parsed and validated DQ configuration."""

    def __init__(self, raw: Dict[str, Any], config_path: Optional[str] = None):
        self._raw = raw
        self.config_path = config_path
        self.hash = config_hash(raw)

        self.globals: Dict[str, Any] = raw.get("globals", {})
        self.feature_sets: Dict[str, Any] = raw.get("feature_sets", {})
        self.normalization: Dict[str, Any] = raw.get("normalization", {})
        self.asset_class_defaults: Dict[str, Any] = raw.get("asset_class_defaults", {})
        self.universes: Dict[str, Any] = raw.get("universes", {})

    @classmethod
    def from_file(cls, path: str | Path) -> "DQConfig":
        return cls(load_yaml(path), config_path=str(path))

    def get_universe_config(self, universe_name: str) -> Dict[str, Any]:
        u_conf = self.universes.get(universe_name, {})
        asset_class = u_conf.get("asset_class") or universe_name.split("_")[0]
        ac_defaults = self.asset_class_defaults.get(asset_class, {})
        merged = {}
        merged.update(self.globals)
        merged.update(ac_defaults)
        merged.update(u_conf)
        return merged

    def get_models_for_universe(self, universe_name: str) -> List[Dict[str, Any]]:
        u_conf = self.universes.get(universe_name, {})
        if "models" in u_conf:
            return u_conf["models"]
        asset_class = u_conf.get("asset_class") or universe_name.split("_")[0]
        ac = self.asset_class_defaults.get(asset_class, {})
        return ac.get("default_models", [])

    def get_regime_windows(self) -> List[Dict[str, Any]]:
        return self.globals.get("regime_windows", [])

    def raw(self) -> Dict[str, Any]:
        return self._raw
