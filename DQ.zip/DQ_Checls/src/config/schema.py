"""Layer 4 — Config schemas (Pydantic v2 with dataclass fallback)."""
from __future__ import annotations

from typing import Any, Dict, List, Optional

try:
    from pydantic import BaseModel, Field

    class RegimeWindow(BaseModel):
        name: str
        start: str
        end: str
        high_vol: bool = False
        label: str = ""

    class ModelConfig(BaseModel):
        id: str
        backend: str = "local"
        model_name: Optional[str] = None
        family: str = "stat_univariate"
        fit_policy: str = "per_series"
        params: Dict[str, Any] = Field(default_factory=dict)
        normalization_profile: str = "ecdf"
        severity_profile: str = "default"
        enabled: bool = True

    class UniverseConfig(BaseModel):
        name: str
        description: str = ""
        asset_class: str = ""
        peer_group_keys: List[str] = Field(default_factory=list)
        models: List[ModelConfig] = Field(default_factory=list)
        tags: Dict[str, str] = Field(default_factory=dict)

    PYDANTIC_AVAILABLE = True

except ImportError:
    PYDANTIC_AVAILABLE = False
    from dataclasses import dataclass, field

    @dataclass
    class RegimeWindow:
        name: str
        start: str
        end: str
        high_vol: bool = False
        label: str = ""

    @dataclass
    class ModelConfig:
        id: str
        backend: str = "local"
        model_name: str = ""
        family: str = "stat_univariate"
        fit_policy: str = "per_series"
        params: dict = field(default_factory=dict)
        normalization_profile: str = "ecdf"
        severity_profile: str = "default"
        enabled: bool = True

    @dataclass
    class UniverseConfig:
        name: str
        description: str = ""
        asset_class: str = ""
        peer_group_keys: list = field(default_factory=list)
        models: list = field(default_factory=list)
        tags: dict = field(default_factory=dict)
