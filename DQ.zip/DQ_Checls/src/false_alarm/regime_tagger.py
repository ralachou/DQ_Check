"""Layer 6 — Regime tagger: annotate results with market regime context."""
from __future__ import annotations

from typing import Any, Dict, List, Optional

import pandas as pd

_DEFAULT_REGIMES = [
    {"name": "GFC_2008", "start": "2008-09-01", "end": "2009-06-30", "high_vol": True},
    {"name": "EURO_DEBT_2010", "start": "2010-04-01", "end": "2012-09-30", "high_vol": True},
    {"name": "COVID_2020", "start": "2020-02-15", "end": "2020-06-30", "high_vol": True},
    {"name": "RATE_HIKE_2022", "start": "2022-01-01", "end": "2023-06-30", "high_vol": True},
]


class RegimeTagger:
    """Tags each result row with the applicable market regime window."""

    def __init__(self, regime_windows: Optional[List[Dict[str, Any]]] = None):
        self.regime_windows = regime_windows or _DEFAULT_REGIMES

    def tag(self, results_df: pd.DataFrame) -> pd.DataFrame:
        results_df = results_df.copy()
        results_df["date"] = pd.to_datetime(results_df["date"])
        results_df["regime_tag"] = "NORMAL"
        results_df["regime_high_vol"] = False

        now = pd.Timestamp.now()

        for regime in self.regime_windows:
            name = regime.get("name", "REGIME")
            start_str = regime.get("start", "")
            end_str = regime.get("end", "now")
            high_vol = regime.get("high_vol", False)

            # Handle "last_1y" / "now" as dynamic values
            if start_str == "last_1y":
                start = now - pd.DateOffset(years=1)
            else:
                start = pd.Timestamp(start_str)

            end = now if end_str in ("now", "last_1y") else pd.Timestamp(end_str)

            mask = (results_df["date"] >= start) & (results_df["date"] <= end)
            results_df.loc[mask, "regime_tag"] = name
            if high_vol:
                results_df.loc[mask, "regime_high_vol"] = True

        return results_df
