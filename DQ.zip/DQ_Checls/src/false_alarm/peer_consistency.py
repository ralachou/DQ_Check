"""Layer 6 — Peer consistency checker."""
from __future__ import annotations

import logging
from typing import List, Optional

import numpy as np
import pandas as pd

log = logging.getLogger(__name__)

PEER_GROUP_KEYS = ["rf_level1", "rf_level2", "rf_level3"]


class PeerConsistencyChecker:
    """Checks if a flagged series moves in line with its peer group.

    A flag is "peer-confirmed" if a sufficient fraction of peer series show a
    similar direction + magnitude move on the same date.
    """

    def __init__(
        self,
        peer_group_keys: Optional[List[str]] = None,
        min_peer_size: int = 3,
        confirmation_threshold: float = 0.4,
    ):
        self.peer_group_keys = peer_group_keys or PEER_GROUP_KEYS
        self.min_peer_size = min_peer_size
        self.confirmation_threshold = confirmation_threshold

    def enrich(
        self,
        results_df: pd.DataFrame,
        ts_df: pd.DataFrame,
        metadata_df: pd.DataFrame,
    ) -> pd.DataFrame:
        """Add peer_confirmed, peer_group_size, peer_median_move columns."""
        results_df = results_df.copy()
        results_df["peer_confirmed"] = False
        results_df["peer_group_size"] = 0
        results_df["peer_median_move"] = np.nan

        if metadata_df.empty or "risk_factor_id" not in metadata_df.columns:
            return results_df

        meta = metadata_df.set_index("risk_factor_id")

        ts_df = ts_df.copy()
        ts_df["date"] = pd.to_datetime(ts_df["date"])

        try:
            returns_wide = ts_df.pivot_table(
                index="date", columns="risk_factor_id", values="value"
            ).pct_change()
        except Exception:
            return results_df

        flagged_mask = results_df.get("flag", pd.Series([False] * len(results_df))) == True
        flagged_indices = results_df[flagged_mask].index

        for idx in flagged_indices:
            row = results_df.loc[idx]
            rf_id = row["risk_factor_id"]
            dt = pd.Timestamp(row["date"])

            peer_ids = self._get_peers(rf_id, meta)
            peer_ids = [p for p in peer_ids if p != rf_id]

            results_df.at[idx, "peer_group_size"] = len(peer_ids)

            if len(peer_ids) < self.min_peer_size:
                continue

            if dt not in returns_wide.index:
                continue

            try:
                rf_ret = returns_wide.loc[dt, rf_id] if rf_id in returns_wide.columns else np.nan
                valid_peers = [p for p in peer_ids if p in returns_wide.columns]
                if not valid_peers:
                    continue
                peer_rets = returns_wide.loc[dt, valid_peers]
                peer_median = float(peer_rets.median())
                results_df.at[idx, "peer_median_move"] = peer_median

                if np.isnan(rf_ret) or np.isnan(peer_median):
                    continue

                same_sign = (rf_ret * peer_median) > 0
                frac_moving = (peer_rets.abs() > peer_rets.abs().median() * 0.5).mean()

                if same_sign and frac_moving >= self.confirmation_threshold:
                    results_df.at[idx, "peer_confirmed"] = True
            except Exception as e:
                log.debug("Peer check failed for %s: %s", rf_id, e)

        return results_df

    def _get_peers(self, rf_id: str, meta: pd.DataFrame) -> List[str]:
        if rf_id not in meta.index:
            return []
        rf_row = meta.loc[rf_id]
        mask = pd.Series([True] * len(meta), index=meta.index)
        for key in self.peer_group_keys:
            if key in meta.columns:
                mask &= meta[key] == rf_row.get(key)
        return meta[mask].index.tolist()
