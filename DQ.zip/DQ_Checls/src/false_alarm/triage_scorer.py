"""Layer 6 — Triage scorer: heuristic + optional ML false-alarm classifier."""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

import numpy as np
import pandas as pd

log = logging.getLogger(__name__)

ACCEPT_MOVE = "ACCEPT_MOVE"
CONFIRM_BAD_DATA = "CONFIRM_BAD_DATA"
NEEDS_REVIEW = "NEEDS_REVIEW"


class TriageScorer:
    """Assigns a confidence estimate and recommended action to each flagged result.

    Two modes:
    1. Heuristic (always available): rule-based confidence + action.
    2. Supervised ML (optional): train on historical labels.
    """

    def __init__(self, use_ml: bool = False, model_params: Optional[Dict] = None):
        self.use_ml = use_ml
        self.model_params = model_params or {}
        self._classifier = None
        self._feature_cols: List[str] = []

    def score(self, results_df: pd.DataFrame) -> pd.DataFrame:
        results_df = results_df.copy()
        results_df = self._heuristic_score(results_df)
        if self.use_ml and self._classifier is not None:
            results_df = self._ml_score(results_df)
        return results_df

    def _heuristic_score(self, df: pd.DataFrame) -> pd.DataFrame:
        flag = df.get("flag", pd.Series([False] * len(df), index=df.index))
        peer_confirmed = df.get("peer_confirmed", pd.Series([False] * len(df), index=df.index))
        regime_high_vol = df.get("regime_high_vol", pd.Series([False] * len(df), index=df.index))
        integrity_flag = df.get("check_family", pd.Series([""] * len(df), index=df.index)) == "integrity"
        severity_critical = df.get("severity", pd.Series(["OK"] * len(df), index=df.index)) == "Critical"

        confidence = pd.Series(0.5, index=df.index)
        action = pd.Series(NEEDS_REVIEW, index=df.index)

        # Rule 1: peer-confirmed + high-vol -> likely real market move
        cond_accept = flag & peer_confirmed & regime_high_vol
        confidence = confidence.where(~cond_accept, 0.85)
        action = action.where(~cond_accept, ACCEPT_MOVE)

        # Rule 2: not peer-confirmed + integrity issue -> bad data
        cond_bad = flag & ~peer_confirmed & integrity_flag
        confidence = confidence.where(~cond_bad, 0.90)
        action = action.where(~cond_bad, CONFIRM_BAD_DATA)

        # Rule 3: critical + not peer-confirmed -> likely bad data
        cond_critical = flag & ~peer_confirmed & severity_critical & ~integrity_flag
        confidence = confidence.where(~cond_critical, 0.75)
        action = action.where(~cond_critical, CONFIRM_BAD_DATA)

        df["confidence_estimate"] = confidence.values
        df["recommended_action"] = action.values
        df["false_alarm_prob"] = (1.0 - confidence).where(flag, 0.0).values
        return df

    def train(self, labeled_df: pd.DataFrame, label_col: str = "is_false_alarm") -> Dict[str, Any]:
        feature_cols = [
            "raw_score", "norm_score", "peer_confirmed", "regime_high_vol",
            "peer_group_size", "peer_median_move",
        ]
        cat_cols = ["check_family", "severity", "rf_level1"]
        for col in cat_cols:
            if col in labeled_df.columns:
                dummies = pd.get_dummies(labeled_df[col], prefix=col, drop_first=True)
                labeled_df = pd.concat([labeled_df, dummies], axis=1)
                feature_cols.extend(dummies.columns.tolist())

        available_cols = [c for c in feature_cols if c in labeled_df.columns]
        X = labeled_df[available_cols].fillna(0).values
        y = labeled_df[label_col].astype(int).values
        self._feature_cols = available_cols

        try:
            from xgboost import XGBClassifier
            clf = XGBClassifier(n_estimators=100, max_depth=4, eval_metric="logloss")
        except ImportError:
            try:
                from lightgbm import LGBMClassifier
                clf = LGBMClassifier(n_estimators=100, max_depth=4, verbose=-1)
            except ImportError:
                from sklearn.ensemble import GradientBoostingClassifier
                clf = GradientBoostingClassifier(n_estimators=100, max_depth=3)

        clf.fit(X, y)
        self._classifier = clf

        try:
            from sklearn.metrics import roc_auc_score
            proba = clf.predict_proba(X)[:, 1]
            auc = roc_auc_score(y, proba)
            log.info("False-alarm classifier trained: AUC=%.3f on %d samples", auc, len(y))
            return {"auc_train": auc, "n_samples": len(y), "features": available_cols}
        except Exception:
            return {"n_samples": len(y), "features": available_cols}

    def _ml_score(self, df: pd.DataFrame) -> pd.DataFrame:
        available = [c for c in self._feature_cols if c in df.columns]
        X = df[available].fillna(0).values
        try:
            proba = self._classifier.predict_proba(X)[:, 1]
            df["false_alarm_prob"] = proba
            df["confidence_estimate"] = 1.0 - proba
        except Exception as e:
            log.warning("ML scoring failed: %s", e)
        return df
