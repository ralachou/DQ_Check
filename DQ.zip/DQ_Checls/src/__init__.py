"""DQ Health Control Tower - financial risk-factor time-series quality engine."""
__version__ = "0.1.0"
