from __future__ import annotations

from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

ASSET_CLASS_TEMPLATES: dict[str, list[tuple[str, str, str, str]]] = {
    "EQ_PRICE": [("USD", "SPX", "SPOT", "NA"), ("USD", "AMZN", "SPOT", "NA"), ("USD", "AAPL", "SPOT", "NA")],
    "EQ_VOL": [("USD", "SPX", "ATM", "M01"), ("USD", "SPX", "ATM", "M03")],
    "IR_RATE": [("USD", "Treasury", "ForwardRate", "M01"), ("USD", "Treasury", "ForwardRate", "Y05")],
    "IR_VOL": [("USD", "Swaption", "ATM", "Y01"), ("USD", "Swaption", "ATM", "Y05")],
    "FX_RATE": [("USD", "EUR", "SPOT", "NA"), ("USD", "JPY", "SPOT", "NA")],
    "FX_VOL": [("USD", "EURUSD", "ATM", "M01"), ("USD", "USDJPY", "ATM", "M01")],
    "COMM_PRICE": [("USD", "GOLD", "FUTURE", "M01"), ("USD", "SILVER", "FUTURE", "M01")],
    "COMM_VOL": [("USD", "GOLD", "ATM", "M01"), ("USD", "WTI", "ATM", "M01")],
    "CP_RATE": [("USD", "CORP", "BBB", "Y05"), ("USD", "CDX", "IG", "Y05"), ("USD", "RMBS", "TBA", "Coupon4.5")],
    "CP_VOL": [("USD", "CDX", "VOL", "Y05"), ("USD", "CORP", "VOL", "Y05")],
}


def _sample_rf_rows(num_factors: int, seed: int = 42) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    rows: list[dict[str, Any]] = []
    classes = list(ASSET_CLASS_TEMPLATES.keys())
    for i in range(num_factors):
        ac = classes[i % len(classes)]
        cur, prod, subtype, quote = ASSET_CLASS_TEMPLATES[ac][rng.integers(0, len(ASSET_CLASS_TEMPLATES[ac]))]
        rf_id = f"RF_{ac}_{i:06d}"
        rows.append(
            {
                "risk_factor_id": rf_id,
                "rf_level1": ac,
                "rf_level2": cur,
                "rf_level3": prod,
                "rf_level4": subtype,
                "rf_level5": quote,
                "tenor_bucket": quote if quote != "NA" else "SPOT",
                "vendor": rng.choice(["VENDOR_A", "VENDOR_B", "VENDOR_C"], p=[0.6, 0.3, 0.1]),
                "rating": rng.choice(["AAA", "AA", "A", "BBB", "BB"], p=[0.1, 0.2, 0.25, 0.25, 0.2]),
            }
        )
    return pd.DataFrame(rows)


def _regime_vol(date: pd.Timestamp) -> float:
    if pd.Timestamp("2008-09-01") <= date <= pd.Timestamp("2009-06-30"):
        return 3.5
    if pd.Timestamp("2020-02-15") <= date <= pd.Timestamp("2020-06-30"):
        return 2.8
    return 1.0


def _inject_anomalies(values: np.ndarray, rng: np.random.Generator) -> np.ndarray:
    out = values.copy()
    n = len(out)
    if n < 40:
        return out
    # Spikes
    for _ in range(max(1, n // 500)):
        idx = int(rng.integers(20, n - 1))
        out[idx] += rng.normal(0.0, np.std(out) * 8.0)
    # Stale patches
    for _ in range(max(1, n // 900)):
        start = int(rng.integers(10, n - 10))
        length = int(rng.integers(3, 7))
        out[start : start + length] = out[start]
    return out


def generate_synthetic_market_data(
    start_date: str = "2019-01-01",
    end_date: str = "2024-12-31",
    num_factors: int = 500,
    seed: int = 42,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    rng = np.random.default_rng(seed)
    risk_factors = _sample_rf_rows(num_factors=num_factors, seed=seed)
    dates = pd.bdate_range(start_date, end_date)
    ts_parts = []
    for _, row in risk_factors.iterrows():
        base = 100.0 + rng.normal(0, 10)
        drift = rng.normal(0.0, 0.02)
        vol = rng.uniform(0.6, 2.0)
        shocks = []
        for d in dates:
            shocks.append(rng.normal(drift, vol * _regime_vol(d)))
        path = base + np.cumsum(np.array(shocks))
        path = _inject_anomalies(path, rng=rng)
        # Introduce random missing dates
        keep_mask = rng.random(len(dates)) > 0.005
        df = pd.DataFrame(
            {
                "risk_factor_id": row["risk_factor_id"],
                "date": dates[keep_mask],
                "value": path[keep_mask],
            }
        )
        ts_parts.append(df)
    timeseries = pd.concat(ts_parts, ignore_index=True)
    timeseries["date"] = pd.to_datetime(timeseries["date"])
    return risk_factors, timeseries.sort_values(["risk_factor_id", "date"]).reset_index(drop=True)


def write_demo_datasets(
    raw_path: str | Path = "data/raw",
    processed_path: str | Path = "data/processed",
    start_date: str = "2019-01-01",
    end_date: str = "2024-12-31",
    num_factors: int = 500,
    seed: int = 42,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    raw_root = Path(raw_path)
    proc_root = Path(processed_path)
    raw_root.mkdir(parents=True, exist_ok=True)
    proc_root.mkdir(parents=True, exist_ok=True)
    risk_factors, timeseries = generate_synthetic_market_data(
        start_date=start_date,
        end_date=end_date,
        num_factors=num_factors,
        seed=seed,
    )
    (raw_root / "risk_factors").mkdir(parents=True, exist_ok=True)
    (raw_root / "timeseries_raw").mkdir(parents=True, exist_ok=True)
    risk_factors.to_parquet(raw_root / "risk_factors" / "part-000.parquet", index=False)
    timeseries.to_parquet(raw_root / "timeseries_raw" / "part-000.parquet", index=False)
    return risk_factors, timeseries

