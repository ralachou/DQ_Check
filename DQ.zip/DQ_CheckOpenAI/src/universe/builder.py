from __future__ import annotations

from dataclasses import asdict

import pandas as pd

from data_access.base import TimeSeriesRepository
from universe.definitions import UniverseDefinition

RF_LEVELS = ["rf_level1", "rf_level2", "rf_level3", "rf_level4", "rf_level5"]


class UniverseBuilder:
    """Loads and validates universe membership from metadata repository."""

    def __init__(self, repository: TimeSeriesRepository) -> None:
        self.repository = repository

    def build(self, definition: UniverseDefinition) -> pd.DataFrame:
        df = self.repository.list_risk_factors(definition.filter_rules)
        if df.empty:
            return df
        out = df.copy()
        for level in RF_LEVELS:
            if level not in out.columns:
                out[level] = "NA"
            out[level] = out[level].fillna("NA").astype(str)
        if definition.include_ids:
            include_df = df[df["risk_factor_id"].isin(definition.include_ids)]
            out = pd.concat([out, include_df], ignore_index=True)
        if definition.exclude_ids:
            out = out[~out["risk_factor_id"].isin(definition.exclude_ids)]
        out = out.drop_duplicates(subset=["risk_factor_id"])
        required = ["risk_factor_id"] + RF_LEVELS
        missing_cols = [c for c in required if c not in out.columns]
        if missing_cols:
            raise ValueError(f"Universe membership missing columns: {missing_cols}")
        out["universe_name"] = definition.name
        out["universe_description"] = definition.description
        out["definition_json"] = str(asdict(definition))
        return out.reset_index(drop=True)

