from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import pandas as pd
import yaml

TIMESERIES_COLUMNS = ("risk_factor_id", "date", "value")
RESULT_COLUMNS = (
    "run_id",
    "universe_name",
    "risk_factor_id",
    "date",
    "check_id",
    "backend",
    "family",
    "raw_score",
    "norm_score",
    "threshold",
    "flag",
    "severity",
    "reason_code",
    "explain",
    "artifacts_json",
)


@dataclass(frozen=True)
class RunContext:
    run_id: str
    universe_name: str
    start_date: pd.Timestamp
    end_date: pd.Timestamp
    config_hash: str


def ensure_timeseries_schema(df: pd.DataFrame) -> pd.DataFrame:
    missing = [col for col in TIMESERIES_COLUMNS if col not in df.columns]
    if missing:
        raise ValueError(f"Missing required time-series columns: {missing}")
    out = df.copy()
    out["risk_factor_id"] = out["risk_factor_id"].astype(str)
    out["date"] = pd.to_datetime(out["date"], utc=False).dt.tz_localize(None)
    out["value"] = pd.to_numeric(out["value"], errors="coerce")
    return out[list(TIMESERIES_COLUMNS)]


def load_yaml(path: str | Path) -> dict[str, Any]:
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f) or {}


def config_hash(config: dict[str, Any]) -> str:
    payload = json.dumps(config, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()

