from __future__ import annotations

from pathlib import Path
from typing import Any

import pandas as pd

from common.schemas import ensure_timeseries_schema
from data_access.base import TimeSeriesRepository


class ParquetTimeSeriesRepository(TimeSeriesRepository):
    """Parquet-backed repository with table directories under a base path."""

    def __init__(self, base_path: str | Path, write_base_path: str | Path | None = None) -> None:
        self.base_path = Path(base_path)
        self.write_base_path = Path(write_base_path) if write_base_path else self.base_path
        self.base_path.mkdir(parents=True, exist_ok=True)
        self.write_base_path.mkdir(parents=True, exist_ok=True)

    def _table_path(self, table_name: str) -> Path:
        return self.base_path / table_name

    def _write_table_path(self, table_name: str) -> Path:
        return self.write_base_path / table_name

    def _read_parquet_dir(self, table_name: str) -> pd.DataFrame:
        path = self._table_path(table_name)
        if not path.exists():
            return pd.DataFrame()
        parquet_files = list(path.rglob("*.parquet"))
        if not parquet_files:
            return pd.DataFrame()
        return pd.concat((pd.read_parquet(p) for p in parquet_files), ignore_index=True)

    def get_series(
        self,
        risk_factor_ids: list[str] | None,
        start_date: str | pd.Timestamp,
        end_date: str | pd.Timestamp,
    ) -> pd.DataFrame:
        df = self._read_parquet_dir("timeseries_raw")
        if df.empty:
            return df
        df = ensure_timeseries_schema(df)
        start_ts = pd.to_datetime(start_date)
        end_ts = pd.to_datetime(end_date)
        mask = (df["date"] >= start_ts) & (df["date"] <= end_ts)
        if risk_factor_ids:
            mask &= df["risk_factor_id"].isin(risk_factor_ids)
        return df.loc[mask].sort_values(["risk_factor_id", "date"]).reset_index(drop=True)

    def list_risk_factors(self, filters: dict[str, Any] | None = None) -> pd.DataFrame:
        df = self._read_parquet_dir("risk_factors")
        if df.empty:
            return df
        out = df.copy()
        for k, v in (filters or {}).items():
            if k not in out.columns:
                continue
            if isinstance(v, list):
                out = out[out[k].isin(v)]
            else:
                out = out[out[k] == v]
        return out.reset_index(drop=True)

    def write_results(
        self,
        df: pd.DataFrame,
        table_name: str,
        partition_cols: list[str] | None = None,
    ) -> None:
        path = self._write_table_path(table_name)
        path.mkdir(parents=True, exist_ok=True)
        partition_cols = partition_cols or []
        df.to_parquet(
            path,
            engine="pyarrow",
            index=False,
            partition_cols=partition_cols if partition_cols else None,
        )
