"""Pipeline entry points."""

