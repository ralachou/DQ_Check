from __future__ import annotations

import argparse
from datetime import UTC, datetime

from data.synthetic import write_demo_datasets
from data_access.parquet_repository import ParquetTimeSeriesRepository
from engine.run_engine import RunEngine, RunRequest


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run DQ Health Control Tower demo pipeline.")
    parser.add_argument("--start-date", default="2019-01-01")
    parser.add_argument("--end-date", default="2024-12-31")
    parser.add_argument("--num-factors", type=int, default=400)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--raw-path", default="data/raw")
    parser.add_argument("--processed-path", default="data/processed")
    parser.add_argument("--config-path", default="configs/model_catalog.yaml")
    parser.add_argument("--universe-name", default="CP_RATE_CORP")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    write_demo_datasets(
        raw_path=args.raw_path,
        processed_path=args.processed_path,
        start_date=args.start_date,
        end_date=args.end_date,
        num_factors=args.num_factors,
        seed=args.seed,
    )
    repo = ParquetTimeSeriesRepository(base_path=args.raw_path, write_base_path=args.processed_path)
    engine = RunEngine(repository=repo, artifact_root="data/artifacts/normalization")
    run_id = f"demo_{datetime.now(UTC).strftime('%Y%m%d_%H%M%S')}"
    result = engine.run(
        RunRequest(
            run_id=run_id,
            universe_name=args.universe_name,
            start_date=args.start_date,
            end_date=args.end_date,
            config_path=args.config_path,
            incremental=False,
        )
    )
    print(f"Run completed: run_id={run_id}")
    print(result["audit_log"].to_string(index=False))


if __name__ == "__main__":
    main()
