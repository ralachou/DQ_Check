from __future__ import annotations

import json
from typing import Any

import numpy as np
import pandas as pd

from dq_checks.base import DQCheck, severity_from_ratio


class EnsembleCheck(DQCheck):
    def __init__(self, children: list[DQCheck], method: str = "weighted_average", weights: list[float] | None = None, **params: Any) -> None:
        super().__init__(
            name="ensemble",
            family="ensemble",
            scope="per_series",
            fit_policy=params.pop("fit_policy", "per_series"),
            **params,
        )
        self.children = children
        self.method = method
        self.weights = weights or [1.0 / max(1, len(children))] * len(children)

    @staticmethod
    def _normalize(series: pd.Series) -> pd.Series:
        lo, hi = series.min(), series.max()
        return (series - lo) / (hi - lo + 1.0e-12)

    def score(self, df: pd.DataFrame, context: dict[str, Any], model_state: dict[str, Any] | None = None) -> pd.DataFrame:
        del model_state
        if not self.children:
            return self.empty_result(df, "No child checks configured.")
        outputs = []
        for child in self.children:
            child_state = child.fit(df, context)
            child_out = child.score(df, context, child_state)
            child_out = child_out.rename(columns={"raw_score": f"{child.name}_score"})
            outputs.append(child_out[["risk_factor_id", "date", f"{child.name}_score"]])
        merged = outputs[0]
        for part in outputs[1:]:
            merged = merged.merge(part, on=["risk_factor_id", "date"], how="outer")
        score_cols = [c for c in merged.columns if c.endswith("_score")]
        score_mat = merged[score_cols].fillna(0.0).apply(self._normalize, axis=0)

        if self.method == "max":
            agg = score_mat.max(axis=1)
        elif self.method == "majority_vote":
            agg = (score_mat >= 0.9).sum(axis=1) / max(1, score_mat.shape[1])
        elif self.method == "rank_aggregation":
            ranks = score_mat.rank(axis=0, pct=True)
            agg = ranks.mean(axis=1)
        else:
            w = np.array(self.weights, dtype=float)
            w = w / (w.sum() + 1.0e-12)
            agg = score_mat.to_numpy() @ w
            agg = pd.Series(agg, index=merged.index)

        threshold = float(self.params.get("threshold", 0.95))
        out = merged[["risk_factor_id", "date"]].copy()
        out["raw_score"] = agg.astype(float)
        out["threshold"] = threshold
        out["flag"] = out["raw_score"] >= threshold
        out["severity"] = severity_from_ratio(out["raw_score"] / (threshold + 1.0e-12))
        out.loc[~out["flag"], "severity"] = "Low"
        out["reason_code"] = np.where(out["flag"], "ENSEMBLE_ALERT", "OK")
        out["explain"] = np.where(out["flag"], f"Ensemble method={self.method} exceeded threshold", "No issue")
        out["artifacts_json"] = json.dumps({"method": self.method, "children": [c.name for c in self.children]})
        return out

