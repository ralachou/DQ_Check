from __future__ import annotations

import json
import warnings
from typing import Any

import numpy as np
import pandas as pd
from sklearn.ensemble import IsolationForest
from sklearn.neighbors import LocalOutlierFactor

from dq_checks.base import DQCheck, severity_from_ratio

try:
    from pyod.models.copod import COPOD
    from pyod.models.ecod import ECOD
    from pyod.models.hbos import HBOS
    from pyod.models.iforest import IForest
    from pyod.models.knn import KNN
    from pyod.models.lof import LOF

    PYOD_AVAILABLE = True
except Exception:  # pragma: no cover - optional dependency
    PYOD_AVAILABLE = False

try:
    import adtk  # noqa: F401

    ADTK_AVAILABLE = True
except Exception:  # pragma: no cover - optional dependency
    ADTK_AVAILABLE = False

try:
    import merlion  # noqa: F401

    MERLION_AVAILABLE = True
except Exception:  # pragma: no cover - optional dependency
    MERLION_AVAILABLE = False


def _to_feature_matrix(df: pd.DataFrame) -> np.ndarray:
    feature_cols = [c for c in df.columns if c not in {"risk_factor_id", "date", "value"}]
    numeric_cols = [c for c in feature_cols if pd.api.types.is_numeric_dtype(df[c])]
    if not numeric_cols:
        x = pd.DataFrame(
            {
                "value": df["value"].astype(float),
                "ret_1d": df["value"].astype(float).pct_change().fillna(0.0),
                "ret_5d": df["value"].astype(float).pct_change(5).fillna(0.0),
            }
        )
    else:
        x = df[numeric_cols]
    x = x.replace([np.inf, -np.inf], np.nan).fillna(0.0)
    return x.to_numpy(dtype=float)


class PyODAdapterCheck(DQCheck):
    def __init__(self, model_name: str = "iforest", **params: Any) -> None:
        super().__init__(
            name=f"pyod_{model_name}",
            family="ml_unsupervised",
            scope="per_peer_group",
            fit_policy=params.pop("fit_policy", "per_peer_group"),
            **params,
        )
        self.model_name = model_name.lower()

    def _build_model(self):
        contamination = float(self.params.get("contamination", 0.002))
        if PYOD_AVAILABLE:
            mapping = {
                "iforest": IForest(contamination=contamination),
                "lof": LOF(contamination=contamination),
                "ecod": ECOD(contamination=contamination),
                "hbos": HBOS(contamination=contamination),
                "knn": KNN(contamination=contamination),
                "copod": COPOD(contamination=contamination),
            }
            model = mapping.get(self.model_name)
            if model is None:
                raise ValueError(f"Unsupported PyOD model: {self.model_name}")
            return model
        warnings.warn("PyOD not installed, using sklearn fallback where possible.")
        if self.model_name == "iforest":
            return IsolationForest(
                contamination=contamination,
                random_state=42,
                n_estimators=int(self.params.get("n_estimators", 200)),
            )
        if self.model_name == "lof":
            return LocalOutlierFactor(
                contamination=contamination,
                n_neighbors=int(self.params.get("n_neighbors", 25)),
                novelty=True,
            )
        warnings.warn(f"PyOD unavailable and no sklearn fallback for '{self.model_name}'. Check disabled.")
        return None

    def fit(self, df: pd.DataFrame, context: dict[str, Any]) -> dict[str, Any] | None:
        del context
        if df.empty:
            return None
        x = _to_feature_matrix(df)
        model = self._build_model()
        if model is None:
            return {"model": None, "disabled": True}
        model.fit(x)
        return {"model": model}

    def score(self, df: pd.DataFrame, context: dict[str, Any], model_state: dict[str, Any] | None = None) -> pd.DataFrame:
        del context
        if df.empty:
            return self.empty_result(df, "No data for PyOD scoring.")
        try:
            model = model_state["model"] if model_state else self.fit(df, {})["model"]  # type: ignore[index]
        except Exception as exc:
            warnings.warn(f"PyOD check disabled: {exc}")
            return self.empty_result(df, f"PyOD unavailable: {exc}")
        if model is None:
            return self.empty_result(df, f"PyOD model {self.model_name} unavailable.")
        x = _to_feature_matrix(df)
        if hasattr(model, "decision_function"):
            raw = model.decision_function(x)
        elif hasattr(model, "score_samples"):
            raw = -model.score_samples(x)
        else:
            pred = model.predict(x)
            raw = np.where(pred < 0, 1.0, 0.0)
        raw = np.asarray(raw, dtype=float)
        raw = (raw - np.nanmin(raw)) / (np.nanmax(raw) - np.nanmin(raw) + 1.0e-12)
        threshold = float(self.params.get("threshold", 0.98))
        out = df[["risk_factor_id", "date"]].copy()
        out["raw_score"] = raw
        out["threshold"] = threshold
        out["flag"] = out["raw_score"] >= threshold
        out["severity"] = severity_from_ratio(out["raw_score"] / (threshold + 1.0e-12))
        out.loc[~out["flag"], "severity"] = "Low"
        out["reason_code"] = np.where(out["flag"], "PYOD_ANOMALY", "OK")
        out["explain"] = np.where(out["flag"], f"PyOD {self.model_name} anomaly score exceeded threshold", "No issue")
        out["artifacts_json"] = json.dumps({"model_name": self.model_name, "pyod_available": PYOD_AVAILABLE})
        return out


class ADTKAdapterCheck(DQCheck):
    def __init__(self, model_name: str = "LevelShiftAD", **params: Any) -> None:
        super().__init__(
            name=f"adtk_{model_name.lower()}",
            family="changepoint",
            scope="per_series",
            fit_policy=params.pop("fit_policy", "per_series"),
            **params,
        )
        self.model_name = model_name

    def score(self, df: pd.DataFrame, context: dict[str, Any], model_state: dict[str, Any] | None = None) -> pd.DataFrame:
        del context, model_state
        if not ADTK_AVAILABLE:
            warnings.warn("ADTK not installed, ADTK checks are disabled.")
            return self.empty_result(df, "ADTK unavailable.")
        s = df["value"].astype(float)
        level_shift = (s - s.rolling(30, min_periods=10).mean()).abs()
        mad = (s - s.rolling(30, min_periods=10).median()).abs().rolling(30, min_periods=10).median()
        raw = level_shift / (1.4826 * mad + 1.0e-9)
        threshold = float(self.params.get("threshold", 5.0))
        out = df[["risk_factor_id", "date"]].copy()
        out["raw_score"] = raw.fillna(0.0)
        out["threshold"] = threshold
        out["flag"] = out["raw_score"] >= threshold
        out["severity"] = severity_from_ratio(out["raw_score"] / (threshold + 1.0e-12))
        out.loc[~out["flag"], "severity"] = "Low"
        out["reason_code"] = np.where(out["flag"], "ADTK_LEVEL_SHIFT", "OK")
        out["explain"] = np.where(out["flag"], f"ADTK-style {self.model_name} level shift signal", "No issue")
        out["artifacts_json"] = json.dumps({"model_name": self.model_name})
        return out


class MerlionAdapterCheck(DQCheck):
    def __init__(self, model_name: str = "stl", **params: Any) -> None:
        super().__init__(
            name=f"merlion_{model_name.lower()}",
            family="changepoint",
            scope="per_series",
            fit_policy=params.pop("fit_policy", "per_series"),
            **params,
        )
        self.model_name = model_name

    def score(self, df: pd.DataFrame, context: dict[str, Any], model_state: dict[str, Any] | None = None) -> pd.DataFrame:
        del context, model_state
        if not MERLION_AVAILABLE:
            warnings.warn("Merlion not installed, Merlion checks are disabled.")
            return self.empty_result(df, "Merlion unavailable.")
        s = df["value"].astype(float)
        trend = s.rolling(252, min_periods=40).mean()
        resid = (s - trend).abs()
        sigma = resid.rolling(60, min_periods=20).std(ddof=0)
        raw = resid / (sigma + 1.0e-9)
        threshold = float(self.params.get("threshold", 4.5))
        out = df[["risk_factor_id", "date"]].copy()
        out["raw_score"] = raw.fillna(0.0)
        out["threshold"] = threshold
        out["flag"] = out["raw_score"] >= threshold
        out["severity"] = severity_from_ratio(out["raw_score"] / (threshold + 1.0e-12))
        out.loc[~out["flag"], "severity"] = "Low"
        out["reason_code"] = np.where(out["flag"], "MERLION_ANOMALY", "OK")
        out["explain"] = np.where(out["flag"], f"Merlion-style {self.model_name} residual anomaly", "No issue")
        out["artifacts_json"] = json.dumps({"model_name": self.model_name, "calibrated": True})
        return out
