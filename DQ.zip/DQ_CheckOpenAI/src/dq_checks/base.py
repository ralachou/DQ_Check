from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

import pandas as pd


class DQCheck(ABC):
    name: str
    family: str
    scope: str
    required_inputs: set[str]
    fit_policy: str

    def __init__(
        self,
        name: str,
        family: str,
        scope: str,
        required_inputs: set[str] | None = None,
        fit_policy: str = "per_series",
        **params: Any,
    ) -> None:
        self.name = name
        self.family = family
        self.scope = scope
        self.required_inputs = required_inputs or {"risk_factor_id", "date", "value"}
        self.fit_policy = fit_policy
        self.params = params

    def fit(self, df: pd.DataFrame, context: dict[str, Any]) -> dict[str, Any] | None:
        del df, context
        return None

    @abstractmethod
    def score(
        self,
        df: pd.DataFrame,
        context: dict[str, Any],
        model_state: dict[str, Any] | None = None,
    ) -> pd.DataFrame:
        raise NotImplementedError

    @staticmethod
    def empty_result(df: pd.DataFrame, reason: str) -> pd.DataFrame:
        if df.empty:
            return pd.DataFrame(
                columns=[
                    "risk_factor_id",
                    "date",
                    "raw_score",
                    "threshold",
                    "flag",
                    "severity",
                    "reason_code",
                    "explain",
                    "artifacts_json",
                ]
            )
        out = df[["risk_factor_id", "date"]].copy()
        out["raw_score"] = 0.0
        out["threshold"] = 1.0
        out["flag"] = False
        out["severity"] = "Low"
        out["reason_code"] = "CHECK_SKIPPED"
        out["explain"] = reason
        out["artifacts_json"] = "{}"
        return out


def severity_from_ratio(ratio: pd.Series) -> pd.Series:
    levels = pd.Series("Low", index=ratio.index)
    levels.loc[ratio >= 1.0] = "Med"
    levels.loc[ratio >= 1.5] = "High"
    levels.loc[ratio >= 2.0] = "Critical"
    return levels

