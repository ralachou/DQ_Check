from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any

import numpy as np
import pandas as pd
from sklearn.ensemble import GradientBoostingClassifier, RandomForestClassifier
from sklearn.metrics import roc_auc_score
from sklearn.model_selection import train_test_split

PEER_KEYS_DEFAULT = ["rf_level1", "rf_level2", "rf_level3", "rf_level4", "rf_level5"]


@dataclass
class TriageModelInfo:
    enabled: bool
    model_name: str
    auc: float | None
    features: list[str]


class FalseAlarmReducer:
    def __init__(self, regime_windows: list[dict[str, Any]] | None = None, peer_keys: list[str] | None = None) -> None:
        self.regime_windows = regime_windows or []
        self.peer_keys = peer_keys or PEER_KEYS_DEFAULT

    def tag_regime(self, dates: pd.Series, as_of_date: pd.Timestamp | None = None) -> pd.Series:
        as_of_date = as_of_date or pd.Timestamp.today().normalize()
        tags = pd.Series("normal", index=dates.index, dtype="object")
        d = pd.to_datetime(dates)
        for rw in self.regime_windows:
            tag = rw.get("regime_tag", "regime")
            if "relative_window_days" in rw:
                days = int(rw["relative_window_days"])
                start = as_of_date - pd.Timedelta(days=days)
                end = as_of_date
            else:
                start = pd.to_datetime(rw.get("start_date"))
                end = pd.to_datetime(rw.get("end_date"))
            mask = (d >= start) & (d <= end)
            tags.loc[mask] = tag
        return tags

    def _peer_move_frame(self, raw_df: pd.DataFrame, membership: pd.DataFrame) -> pd.DataFrame:
        needed = ["risk_factor_id", "date", "value"]
        base = raw_df[needed].merge(membership[["risk_factor_id"] + self.peer_keys], on="risk_factor_id", how="left")
        base["series_move"] = base.groupby("risk_factor_id")["value"].diff()
        group_cols = self.peer_keys + ["date"]
        peer = (
            base.groupby(group_cols, as_index=False)["series_move"]
            .agg(peer_median_move="median", peer_q25=lambda x: x.quantile(0.25), peer_q75=lambda x: x.quantile(0.75))
        )
        peer["peer_iqr_move"] = peer["peer_q75"] - peer["peer_q25"]
        return base.merge(peer[group_cols + ["peer_median_move", "peer_iqr_move"]], on=group_cols, how="left")

    def peer_consistency(
        self,
        alerts_df: pd.DataFrame,
        raw_df: pd.DataFrame,
        membership: pd.DataFrame,
    ) -> pd.DataFrame:
        if alerts_df.empty:
            return alerts_df.copy()
        peer_frame = self._peer_move_frame(raw_df=raw_df, membership=membership)
        join_cols = ["risk_factor_id", "date"]
        out = alerts_df.merge(
            peer_frame[
                [
                    "risk_factor_id",
                    "date",
                    "series_move",
                    "peer_median_move",
                    "peer_iqr_move",
                ]
            ],
            on=join_cols,
            how="left",
        )
        align = np.sign(out["series_move"].fillna(0.0)) == np.sign(out["peer_median_move"].fillna(0.0))
        spread = out["peer_iqr_move"].abs().fillna(0.0)
        support = out["peer_median_move"].abs().fillna(0.0) / (spread + 1.0e-9)
        out["peer_support_score"] = np.where(align, support, 0.0)
        out["peer_confirmed"] = out["peer_support_score"] >= 0.5
        out["peer_confidence"] = np.clip(out["peer_support_score"], 0.0, 1.0)
        return out

    def triage_heuristic(self, df: pd.DataFrame) -> pd.DataFrame:
        out = df.copy()
        out["confidence_estimate"] = 0.50
        out["recommended_action"] = "NEEDS_REVIEW"

        accept_mask = (out["peer_confirmed"]) & (out["regime_tag"] == "high_vol")
        bad_mask = (~out["peer_confirmed"]) & out["reason_code"].str.contains("MISSING|STALE|INTEGRITY", na=False)
        hard_bad = (~out["peer_confirmed"]) & (out["severity"].isin(["High", "Critical"]))

        out.loc[accept_mask, "recommended_action"] = "ACCEPT_MOVE"
        out.loc[accept_mask, "confidence_estimate"] = 0.85
        out.loc[bad_mask | hard_bad, "recommended_action"] = "CONFIRM_BAD_DATA"
        out.loc[bad_mask | hard_bad, "confidence_estimate"] = 0.90
        out.loc[out["recommended_action"] == "NEEDS_REVIEW", "confidence_estimate"] = 0.60
        return out

    def triage_supervised(
        self,
        df: pd.DataFrame,
        label_col: str = "is_false_alarm",
    ) -> tuple[pd.DataFrame, TriageModelInfo]:
        out = df.copy()
        if label_col not in out.columns or out[label_col].isna().all():
            out["false_alarm_probability"] = np.nan
            return out, TriageModelInfo(enabled=False, model_name="", auc=None, features=[])
        features = [
            "raw_score",
            "norm_score",
            "peer_confidence",
            "peer_confirmed",
        ]
        tmp = out.copy()
        tmp["peer_confirmed"] = tmp["peer_confirmed"].astype(int)
        tmp["severity_num"] = tmp["severity"].map({"Low": 0, "Med": 1, "High": 2, "Critical": 3}).fillna(0)
        features.append("severity_num")
        for col in ["rf_level1", "family", "regime_tag", "vendor"]:
            if col in tmp.columns:
                dummies = pd.get_dummies(tmp[col].fillna("UNK"), prefix=col)
                tmp = pd.concat([tmp, dummies], axis=1)
                features.extend(list(dummies.columns))
        tmp = tmp.dropna(subset=[label_col])
        if tmp.empty:
            out["false_alarm_probability"] = np.nan
            return out, TriageModelInfo(enabled=False, model_name="", auc=None, features=[])
        x = tmp[features].fillna(0.0)
        y = tmp[label_col].astype(int)
        if len(np.unique(y)) < 2:
            out["false_alarm_probability"] = np.nan
            return out, TriageModelInfo(enabled=False, model_name="", auc=None, features=features)
        x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.25, random_state=42, stratify=y)
        try:
            model = GradientBoostingClassifier(random_state=42)
            model.fit(x_train, y_train)
            prob = model.predict_proba(x)[:, 1]
            auc = roc_auc_score(y_test, model.predict_proba(x_test)[:, 1])
            model_name = "GradientBoostingClassifier"
        except Exception:
            model = RandomForestClassifier(n_estimators=300, random_state=42)
            model.fit(x_train, y_train)
            prob = model.predict_proba(x)[:, 1]
            auc = roc_auc_score(y_test, model.predict_proba(x_test)[:, 1])
            model_name = "RandomForestClassifier"
        tmp["false_alarm_probability"] = prob
        out = out.merge(tmp[["risk_factor_id", "date", "check_id", "false_alarm_probability"]], on=["risk_factor_id", "date", "check_id"], how="left")
        return out, TriageModelInfo(enabled=True, model_name=model_name, auc=float(auc), features=features)

    def run(
        self,
        alerts_df: pd.DataFrame,
        raw_df: pd.DataFrame,
        membership: pd.DataFrame,
        with_supervised: bool = False,
        label_col: str = "is_false_alarm",
    ) -> tuple[pd.DataFrame, dict[str, Any]]:
        if alerts_df.empty:
            return alerts_df.copy(), {"triage_model": {"enabled": False}}
        enriched = self.peer_consistency(alerts_df=alerts_df, raw_df=raw_df, membership=membership)
        enriched["regime_tag"] = self.tag_regime(enriched["date"])
        triaged = self.triage_heuristic(enriched)

        model_info = TriageModelInfo(enabled=False, model_name="", auc=None, features=[])
        if with_supervised:
            triaged, model_info = self.triage_supervised(triaged, label_col=label_col)
        triaged["triage_artifacts_json"] = json.dumps(
            {
                "peer_keys": self.peer_keys,
                "regime_windows_count": len(self.regime_windows),
                "supervised_enabled": model_info.enabled,
            }
        )
        audit = {"triage_model": model_info.__dict__}
        return triaged, audit

