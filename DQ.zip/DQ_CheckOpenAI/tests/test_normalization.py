from __future__ import annotations

import numpy as np
import pandas as pd

from normalization.normalizer import SeverityMapper, ScoreNormalizer


def test_monotonicity_ecdf_normalization() -> None:
    raw = pd.Series(np.linspace(-5.0, 5.0, 500))
    normalizer = ScoreNormalizer()
    norm, _ = normalizer.fit_transform(raw_scores=raw, strategy="ecdf")
    diffs = np.diff(norm.to_numpy())
    assert (diffs >= -1.0e-12).all()
    assert norm.min() >= 0.0
    assert norm.max() <= 1.0


def test_percentile_consistency_across_models() -> None:
    rng = np.random.default_rng(42)
    raw_a = pd.Series(rng.normal(0.0, 1.0, 1000))
    raw_b = pd.Series(rng.gamma(shape=2.0, scale=1.5, size=1000))
    normalizer = ScoreNormalizer()
    norm_a, _ = normalizer.fit_transform(raw_a, strategy="ecdf")
    norm_b, _ = normalizer.fit_transform(raw_b, strategy="ecdf")

    mapper = SeverityMapper()
    sev_a, _, _ = mapper.map_severity(norm_a, mode="fixed")
    sev_b, _, _ = mapper.map_severity(norm_b, mode="fixed")

    top_a = sev_a[norm_a >= 0.995]
    top_b = sev_b[norm_b >= 0.995]
    assert (top_a == "Critical").all()
    assert (top_b == "Critical").all()

