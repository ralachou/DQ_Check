import { useState } from "react";

const categories = [
  {
    id: "rf-identification",
    title: "1. Risk Factor Identification & Classification",
    icon: "🔬",
    priority: "Critical",
    summary: "Identify, map, and classify every risk factor as modellable, Type A NMRF, or Type B NMRF via qualitative and quantitative tests.",
    items: [
      {
        action: "Build a comprehensive risk factor universe",
        ref: "§ __.214(a)",
        detail: "Identify an appropriate set of risk factors sufficient to represent the risks inherent in all market risk covered positions on model-eligible trading desks. Must include ALL risk factors in internal risk management models and financial reporting models, plus all risk factors specified in § __.208 for each risk class (IR, CS, EQ, COMM, FX).",
        effort: "High"
      },
      {
        action: "Implement the Risk Factor Qualitative Test",
        ref: "§ __.214(b)(2)",
        detail: "For each risk factor, verify data meets 7 standards: (i) captures idiosyncratic and systematic risk; (ii) reflects volatility and correlations; (iii) reflects observed/quoted market prices; (iv) updated at least weekly with clear backfill/gap-fill policies; (v) stress period data reflective of actual historical stress prices; (vi) proxy usage demonstrated appropriate with track record, similar volatility/correlation, and region/credit/type match; (vii) not deemed unsuitable by supervisor.",
        effort: "High"
      },
      {
        action: "Implement the Risk Factor Quantitative Test (RFET)",
        ref: "§ __.214(b)(3)",
        detail: "For each risk factor, count real price observations over prior 12 months. Must meet minimum thresholds: 24 observations if LH is 10 or 20 days, 16 otherwise. Build bucketing infrastructure (own or standard approach). Real prices include executed transactions, exchange/CCP prices, arm's-length bids/offers, or third-party-verified prices. Max one real price per day.",
        effort: "High"
      },
      {
        action: "Classify each risk factor into one of three categories",
        ref: "§ __.214(b)(1)",
        detail: "Modellable = passes both qualitative + quantitative tests → goes into IMCC. Type A NMRF = passes qualitative but fails quantitative → goes into both IMCC and SES. Type B NMRF = fails qualitative (or both) → goes into SES only with no diversification benefit.",
        effort: "Medium"
      },
      {
        action: "Establish real price observation sourcing from third-party providers",
        ref: "§ __.214(b)(3)(i)(C)",
        detail: "Third-party providers must supply minimum identifier info for mapping to risk factors. Non-government/non-exchange/non-QCCP providers must be subject to a satisfactory public audit of pricing validity. When data arrives with time lag, test period may differ from calibration period by up to one month.",
        effort: "Medium"
      },
      {
        action: "Build bucketing infrastructure for RFET",
        ref: "§ __.214(b)(3)(ii)",
        detail: "Choose between Own Bucketing (one RF per bucket, must match RTPL) or Standard Bucketing (prescribed maturity/moneyness buckets per Table 1 to § __.214). Handle maturity-rolldown: real prices may stay in original bucket or re-allocate to shorter maturity bucket. Allow real prices to map to multiple risk factors.",
        effort: "Medium"
      },
      {
        action: "Handle new issuances in RFET",
        ref: "§ __.214(b)(3)(iii)(B)",
        detail: "For newly issued instruments, the 12-month observation window starts at issuance date and the minimum real price count is prorated until 12 months after issuance.",
        effort: "Low"
      }
    ]
  },
  {
    id: "es-model",
    title: "2. Expected Shortfall (ES) Model Build",
    icon: "📐",
    priority: "Critical",
    summary: "Build and calibrate an ES-based internal model at the 97.5th percentile with liquidity horizon scaling and stress period selection.",
    items: [
      {
        action: "Develop ES-based measure at 97.5% confidence, 10-day base horizon",
        ref: "§ __.215(b)(1)–(3)",
        detail: "Compute daily at trading desk level, aggregate level, and per-risk-class aggregate. Apply liquidity horizon scaling from base 10-day ES using the prescribed LH buckets (10, 20, 40, 60, 120 days). Use overlapping 10-day return windows; cannot scale up from shorter horizon.",
        effort: "High"
      },
      {
        action: "Assign liquidity horizons to all risk factors",
        ref: "§ __.215(b)(11), Table 2",
        detail: "Map each risk factor to prescribed LH categories (IR, EQ, FX, COMM, CS) with minimum LHs per Table 2. Shorter instrument maturity → next longer LH. Multi-underlying indices use weighted average of constituent LHs. Update mapping at least quarterly.",
        effort: "High"
      },
      {
        action: "Select and maintain 12-month stress period",
        ref: "§ __.215(b)(5)",
        detail: "Identify the 12-month period (going back to at least 2007) in which model-eligible positions would experience the largest loss. Can use full or reduced set of risk factors. If reduced set, must explain ≥75% of variation of full ES. Equal-weight observations. Update at least quarterly or upon material portfolio changes.",
        effort: "High"
      },
      {
        action: "Choose Direct vs. Indirect calibration approach",
        ref: "§ __.215(b)(6)",
        detail: "Direct: use full risk factor set with stress period data (proxies allowed for gaps). Indirect: compute current-period ES with full factors, stress-period ES with reduced factors, and scale: ES = ES_R,S × (ES_F,C / ES_R,C). Both require data meeting qualitative test.",
        effort: "High"
      },
      {
        action: "Model non-linearities, correlations, and basis risks",
        ref: "§ __.215(b)(8)–(10)",
        detail: "ES model must capture non-linear price characteristics (especially for options), correlation and basis risks (e.g., CDS-bond basis). For options: capture volatility surface across strike and maturity. Empirical correlations allowed within risk classes; across risk classes constrained by IMCC aggregation.",
        effort: "High"
      },
      {
        action: "Update model input data at least quarterly",
        ref: "§ __.215(b)(7)",
        detail: "Input data for ES models must be refreshed no less than quarterly. Process must be flexible enough for more frequent updates when market prices change materially.",
        effort: "Medium"
      }
    ]
  },
  {
    id: "imcc-ses",
    title: "3. IMCC & Stressed Expected Shortfall (SES) Calculation",
    icon: "⚡",
    priority: "Critical",
    summary: "Aggregate modellable and non-modellable risk factor capital charges into IMCC and SES components.",
    items: [
      {
        action: "Calculate IMCC as constrained/unconstrained weighted average",
        ref: "§ __.215(c)",
        detail: "IMCC = 0.5 × IMCC(C) + 0.5 × Σ IMCC(Ci), where C = full diversified ES across all risk classes, Ci = partial ES per risk class (IR, CS, EQ, COMM, FX) with other classes held constant. Same stress period for both. Include all modellable + Type A NMRFs in the model.",
        effort: "High"
      },
      {
        action: "Build Stressed Expected Shortfall (SES) for all NMRFs",
        ref: "§ __.215(d)",
        detail: "For each NMRF, compute a stress scenario capital measure at least as conservative as the ES-based measure. Select a common 12-month stress period per risk class for all NMRFs. LH floor of 20 days. Aggregate: Type A NMRFs get partial diversification (ρ_b = 0.36); Type B NMRFs are summed outright (no diversification). If stress scenario cannot be determined, use maximum possible loss.",
        effort: "High"
      },
      {
        action: "Compute final models-based non-default capital requirement",
        ref: "§ __.204(c)",
        detail: "IMA_G,A = max((IMCC_t-1 + SES_t-1), (mc × IMCC_avg + SES_avg)) + PLA add-on. mc (capital multiplier) starts at 1.5, can increase to 2.0 based on aggregate backtesting exceptions. NDCR = IMA_G,A + (SA_all_desks − SA_G,A).",
        effort: "High"
      }
    ]
  },
  {
    id: "desk-structure",
    title: "4. Trading Desk Structure & Model Approval",
    icon: "🏗️",
    priority: "Critical",
    summary: "Define trading desk structure, obtain supervisory approval, and maintain ongoing model governance.",
    items: [
      {
        action: "Define and document trading desk structure",
        ref: "§ __.203(b)(1)",
        detail: "Define each trading desk. Identify model-eligible vs. model-ineligible desks. Identify desks for internal risk transfers. Identify notional trading desks. Each non-notional desk needs: (i) written business strategy; (ii) trading/hedging strategy; (iii) risk/position limits; (iv) governance structure.",
        effort: "High"
      },
      {
        action: "Obtain supervisory approval for model-eligible trading desks",
        ref: "§ __.212(b)(2)",
        detail: "For each desk seeking IMA status: get internal model approved, plus provide either 250 business days of backtesting (and PLA after 3-yr transition) results, OR 125 days with demonstrated ongoing capability, OR show desk is similar to an already-approved desk, OR accept PLA add-on until 250 days are accumulated.",
        effort: "High"
      },
      {
        action: "Obtain approval for internal models and stressed ES methodologies",
        ref: "§ __.212(c)",
        detail: "Demonstrate: (i) model properly measures all material risks; (ii) properly validated; (iii) sophistication commensurate with position complexity; (iv) meets all Subpart F requirements. Any material changes require prior approval; non-material changes require prompt notification.",
        effort: "High"
      },
      {
        action: "Handle model-ineligible positions on model-eligible desks",
        ref: "§ __.212(b)(1)(ii)–(iii)",
        detail: "Model-eligible desks may hold only de minimis amounts of model-ineligible positions (securitizations, correlation trading, certain fund exposures). These must be excluded from IMCC/ES and from backtesting/PLA unless supervisor approves inclusion. Capital for these positions calculated under standardized approach.",
        effort: "Medium"
      },
      {
        action: "Establish change management for trading desk structure",
        ref: "§ __.212(b)(3)",
        detail: "Material changes to desk structure require prior supervisory approval. Non-material changes require prompt notification. Supervisor can rescind model-eligible status or impose PLA add-on if desk no longer complies.",
        effort: "Medium"
      }
    ]
  },
  {
    id: "backtesting",
    title: "5. Backtesting & PLA Testing",
    icon: "🧪",
    priority: "Critical",
    summary: "Implement desk-level and aggregate backtesting plus PLA testing to validate internal model accuracy.",
    items: [
      {
        action: "Implement desk-level backtesting at dual confidence levels",
        ref: "§ __.213(b)",
        detail: "Daily comparison of actual P&L and hypothetical P&L against VaR at both 97.5% and 99.0% one-tail confidence. Count exceptions over most recent 250 business days. Failure thresholds: >12 exceptions at 99.0% or >30 at 97.5% → desk becomes model-ineligible. Time effects must be treated consistently in hypothetical P&L.",
        effort: "High"
      },
      {
        action: "Implement aggregate trading portfolio backtesting",
        ref: "§ __.204(g)",
        detail: "Quarterly: compare aggregate actual P&L and aggregate hypothetical P&L vs. aggregate VaR (99.0%, 1-day). Count exceptions over 250 days. Overall exceptions = max(actual exceptions, hypothetical exceptions). Drives capital multiplier mc (1.5 to 2.0 per Table 1 to § __.204).",
        effort: "High"
      },
      {
        action: "Implement PLA testing (Kolmogorov-Smirnov metric)",
        ref: "§ __.213(c)",
        detail: "Compare 250 days of hypothetical P&L vs. risk-theoretical P&L (from internal risk management models). Calculate KS metric. Zone classification: Green (KS ≤ threshold) = no add-on; Amber = PLA add-on applied; Red = desk becomes model-ineligible. 3-year transition: no automatic consequences during transition period, but must report results.",
        effort: "High"
      },
      {
        action: "Build hypothetical P&L and risk-theoretical P&L generation",
        ref: "§ __.202 definitions, § __.213(c)(1)",
        detail: "Hypothetical P&L: value change due to market data changes with end-of-previous-day positions held constant. Exclude: fees, commissions, reserves, net interest income, intraday trading. Risk-theoretical P&L: generated by internal risk management models, must include all risk factors including NMRFs. Data alignment between HPL and RTPL is permitted with documentation.",
        effort: "High"
      },
      {
        action: "Calculate PLA add-on when applicable",
        ref: "§ __.213(c)(4)",
        detail: "PLA add-on = max(0, Σ SA_i (amber desks) + Σ SA_i (all model-eligible desks) − IMA_G,A) formula components. Applies to amber-zone desks after 3-year transition period.",
        effort: "Medium"
      },
      {
        action: "Handle exception overrides",
        ref: "§ __.204(g)(1)(iii), § __.213(b)(1)(iii)",
        detail: "With supervisor approval, exceptions may be disregarded if: (a) caused by unrelated technical issues; (b) caused by NMRFs where attributable SES exceeds the VaR breach amount; (c) caused by model-ineligible positions where attributable SA capital exceeds the breach amount.",
        effort: "Medium"
      }
    ]
  },
  {
    id: "data-infra",
    title: "6. Data Infrastructure & Sourcing",
    icon: "🗄️",
    priority: "High",
    summary: "Build the market data pipelines, proxy frameworks, and data quality processes needed to support RFET, ES calibration, and ongoing model operations.",
    items: [
      {
        action: "Establish real price observation data pipelines",
        ref: "§ __.214(b)(3)(i)",
        detail: "Source real prices from: (1) own executed transactions; (2) regulated exchanges, QCCPs, sovereigns, supranationals; (3) verifiable arm's-length transactions/bids/offers from third parties. No more than one observation per day. Build mapping from real prices to risk factor buckets.",
        effort: "High"
      },
      {
        action: "Build proxy framework for risk factor calibration",
        ref: "§ __.214(b)(2)(vi), § __.214(c)",
        detail: "For modellable and Type A NMRFs, proxies are permitted if: appropriate track record, sufficiently similar volatility/correlation characteristics, appropriate for region/credit/quality/type. Document and justify each proxy relationship. For calibration of ES, may use different data than that used for RFET.",
        effort: "High"
      },
      {
        action: "Develop stress period data sourcing",
        ref: "§ __.215(b)(5)(ii)",
        detail: "Source data directly from historical stress period when possible. Empirically justify any cases where stress period prices differ from actually observed prices. For instruments that didn't exist during stress period, demonstrate price proxies match changes in similar instruments during that period.",
        effort: "High"
      },
      {
        action: "Implement data quality and gap-filling procedures",
        ref: "§ __.214(b)(2)(iv)",
        detail: "Clear policies for backfilling and gap-filling missing data. Clear policies for updating data sources. Regression-based parameter estimates must be re-estimated regularly. Minimum weekly data update frequency.",
        effort: "Medium"
      },
      {
        action: "Third-party provider audit and governance",
        ref: "§ __.214(b)(3)(i)(C)(2)",
        detail: "Non-government/non-exchange/non-QCCP third-party providers must be subject to public audit of pricing information validity. Audit must be satisfactory to supervisor; if not, data cannot be used for RFET.",
        effort: "Medium"
      }
    ]
  },
  {
    id: "documentation",
    title: "7. Documentation, Policies & Governance",
    icon: "📋",
    priority: "High",
    summary: "Document all material aspects of risk factor identification, model validation, P&L attribution, and liquidity horizon assignment.",
    items: [
      {
        action: "Document RFET processes end-to-end",
        ref: "§ __.203(i)(4)(i)",
        detail: "Document policies and procedures for risk factor qualitative and quantitative tests, including description of how real price observations are mapped to risk factors.",
        effort: "Medium"
      },
      {
        action: "Document PLA testing data alignment",
        ref: "§ __.203(i)(4)(ii)",
        detail: "Document alignment of HPL and RTPL time series used in PLA testing. Must be able to assess the effect of data alignments on RTPL. Must compare aligned vs. non-aligned RTPL when designing/changing alignment process or at supervisor request.",
        effort: "Medium"
      },
      {
        action: "Document liquidity horizon assignment process",
        ref: "§ __.203(i)(4)(iii)",
        detail: "Document the assignment of risk factors to liquidity horizons per § __.215(b)(11) and any empirical correlations recognized within risk classes.",
        effort: "Medium"
      },
      {
        action: "Document model validation framework",
        ref: "§ __.212(d)(3), § __.203(i)(3)",
        detail: "Validate internal models initially and ongoing. Independent validation covering: conceptual soundness, material risk capture, ongoing monitoring with internal/external data, outcomes analysis (backtesting + PLA at desk level), aggregate-level backtesting. Revalidate upon material model changes or significant structural market changes.",
        effort: "High"
      },
      {
        action: "Maintain internal audit coverage",
        ref: "§ __.203(e)(3)",
        detail: "Annual internal audit of: effectiveness of controls supporting market risk measurement, business trading unit and independent risk control unit activities, initial designation and re-designation of positions, compliance with policies, calculation of market risk measures including mapping of risk factors to liquidity horizons.",
        effort: "Medium"
      }
    ]
  },
  {
    id: "sa-fallback",
    title: "8. Standardized Approach Risk Factors (SA Parallel Run)",
    icon: "📊",
    priority: "High",
    summary: "Even under IMA, the SA sensitivities-based method must run in parallel for all desks — requiring full risk factor sensitivity computation per § __.208.",
    items: [
      {
        action: "Calculate SA sensitivities for all 7 risk classes",
        ref: "§ __.206–__.209",
        detail: "Compute delta, vega, curvature sensitivities per § __.207 for: (1) IR risk (curve × tenor × currency); (2) CS non-sec; (3) CS CTP; (4) CS sec non-CTP; (5) Equity (spot + repo rate); (6) Commodity (spot × location × maturity); (7) FX. Required because SA_all_desks and SA_G,A feed directly into the models-based capital formula.",
        effort: "High"
      },
      {
        action: "Map all positions to prescribed risk factor buckets",
        ref: "§ __.209",
        detail: "Assign each position's sensitivities to the correct bucket (credit quality × sector, market cap × economy × sector, etc.) with prescribed risk weights and correlation parameters. Run under 3 correlation scenarios (medium, high = ×1.25, low = adjusted formula).",
        effort: "High"
      },
      {
        action: "Build fallback capital requirement process",
        ref: "§ __.204(e)",
        detail: "For any position where SA or DRC cannot be calculated, the position falls to fallback = absolute fair value. Must identify and track all such positions. SA_all_desks calculation is needed even when using IMA.",
        effort: "Medium"
      }
    ]
  },
  {
    id: "reporting",
    title: "9. Reporting & Disclosures",
    icon: "📤",
    priority: "Medium",
    summary: "Meet quarterly public and confidential supervisory reporting requirements related to risk factors, models, and backtesting.",
    items: [
      {
        action: "Quarterly public disclosures for IMA",
        ref: "§ __.217(f)(1)",
        detail: "Disclose: (i) aggregate on/off-balance sheet securitization positions by type; (ii) soundness criteria and methodology descriptions including NMRF categories; (iii) aggregate correlation trading positions; (iv) VaR-based estimates vs. actual gains/losses for each material portfolio with outlier analysis.",
        effort: "Medium"
      },
      {
        action: "Annual public disclosures",
        ref: "§ __.217(f)(2)",
        detail: "Disclose: model characteristics for ES-based measure (general description, data update frequency, current vs. stressed observation description), trading desk structure (model-eligible vs. model-ineligible changes), validation approaches, stress testing per risk category, valuation policies.",
        effort: "Medium"
      },
      {
        action: "Confidential supervisory reporting (quarterly)",
        ref: "§ __.217(f)(4)",
        detail: "Report at aggregate level for all model-eligible desks (500 business days, ≤20 day lag): daily VaR (99.0%), daily ES (97.5%), actual P&L, hypothetical P&L, p-values. At desk level: same plus RTPL and VaR at both 97.5% and 99.0% percentiles.",
        effort: "High"
      }
    ]
  }
];

const effortColor = {
  High: { bg: "#FEE2E2", text: "#991B1B", border: "#FECACA" },
  Medium: { bg: "#FEF3C7", text: "#92400E", border: "#FDE68A" },
  Low: { bg: "#D1FAE5", text: "#065F46", border: "#A7F3D0" }
};

const priorityColor = {
  Critical: "#DC2626",
  High: "#F59E0B",
  Medium: "#3B82F6"
};

export default function FRTBRiskFactorActions() {
  const [expanded, setExpanded] = useState(new Set(["rf-identification"]));
  const [filter, setFilter] = useState("All");

  const toggle = (id) => {
    setExpanded(prev => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
  };

  const expandAll = () => setExpanded(new Set(categories.map(c => c.id)));
  const collapseAll = () => setExpanded(new Set());

  const filtered = filter === "All" ? categories : categories.filter(c => c.priority === filter);

  const totalItems = categories.reduce((s, c) => s + c.items.length, 0);
  const highItems = categories.reduce((s, c) => s + c.items.filter(i => i.effort === "High").length, 0);

  return (
    <div style={{ fontFamily: "'Segoe UI', system-ui, sans-serif", maxWidth: 900, margin: "0 auto", padding: "24px 16px", color: "#1E293B" }}>
      {/* Header */}
      <div style={{ marginBottom: 32 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 4 }}>
          <span style={{ fontSize: 28, fontWeight: 800, letterSpacing: "-0.5px" }}>FRTB IMA</span>
          <span style={{ fontSize: 13, background: "#EF4444", color: "#fff", padding: "2px 10px", borderRadius: 4, fontWeight: 600 }}>NPR Mar 2026</span>
        </div>
        <div style={{ fontSize: 16, color: "#64748B", fontWeight: 500 }}>Risk Factor — Actions, Expectations & Body of Work</div>
        <div style={{ display: "flex", gap: 16, marginTop: 16, fontSize: 13, color: "#64748B" }}>
          <span style={{ background: "#F1F5F9", padding: "4px 12px", borderRadius: 6 }}>{categories.length} categories</span>
          <span style={{ background: "#F1F5F9", padding: "4px 12px", borderRadius: 6 }}>{totalItems} action items</span>
          <span style={{ background: "#FEE2E2", padding: "4px 12px", borderRadius: 6, color: "#991B1B" }}>{highItems} high-effort</span>
        </div>
      </div>

      {/* Controls */}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
        <div style={{ display: "flex", gap: 6 }}>
          {["All", "Critical", "High", "Medium"].map(f => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              style={{
                padding: "5px 14px", borderRadius: 6, border: "1px solid #E2E8F0",
                background: filter === f ? "#1E293B" : "#fff",
                color: filter === f ? "#fff" : "#64748B",
                fontSize: 12, fontWeight: 600, cursor: "pointer"
              }}
            >{f}</button>
          ))}
        </div>
        <div style={{ display: "flex", gap: 8 }}>
          <button onClick={expandAll} style={{ fontSize: 12, color: "#3B82F6", background: "none", border: "none", cursor: "pointer", fontWeight: 600 }}>Expand All</button>
          <button onClick={collapseAll} style={{ fontSize: 12, color: "#3B82F6", background: "none", border: "none", cursor: "pointer", fontWeight: 600 }}>Collapse All</button>
        </div>
      </div>

      {/* Categories */}
      {filtered.map(cat => {
        const isOpen = expanded.has(cat.id);
        return (
          <div key={cat.id} style={{ marginBottom: 12, border: "1px solid #E2E8F0", borderRadius: 10, overflow: "hidden", background: "#fff" }}>
            <div
              onClick={() => toggle(cat.id)}
              style={{
                padding: "14px 18px", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "space-between",
                background: isOpen ? "#F8FAFC" : "#fff",
                borderBottom: isOpen ? "1px solid #E2E8F0" : "none"
              }}
            >
              <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                <span style={{ fontSize: 20 }}>{cat.icon}</span>
                <span style={{ fontWeight: 700, fontSize: 14 }}>{cat.title}</span>
                <span style={{
                  fontSize: 10, fontWeight: 700, padding: "2px 8px", borderRadius: 4,
                  background: cat.priority === "Critical" ? "#FEE2E2" : cat.priority === "High" ? "#FEF3C7" : "#DBEAFE",
                  color: priorityColor[cat.priority]
                }}>{cat.priority}</span>
                <span style={{ fontSize: 11, color: "#94A3B8", fontWeight: 500 }}>{cat.items.length} items</span>
              </div>
              <span style={{ fontSize: 18, color: "#94A3B8", transform: isOpen ? "rotate(180deg)" : "none", transition: "0.2s" }}>▾</span>
            </div>
            {isOpen && (
              <div style={{ padding: "8px 18px 14px" }}>
                <div style={{ fontSize: 13, color: "#64748B", marginBottom: 14, lineHeight: 1.5, padding: "8px 12px", background: "#F8FAFC", borderRadius: 6, borderLeft: `3px solid ${priorityColor[cat.priority]}` }}>
                  {cat.summary}
                </div>
                {cat.items.map((item, idx) => (
                  <div key={idx} style={{ padding: "12px 0", borderTop: idx > 0 ? "1px solid #F1F5F9" : "none" }}>
                    <div style={{ display: "flex", alignItems: "flex-start", gap: 10 }}>
                      <div style={{ minWidth: 20, height: 20, borderRadius: 4, border: "2px solid #CBD5E1", marginTop: 1 }} />
                      <div style={{ flex: 1 }}>
                        <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 4 }}>
                          <span style={{ fontWeight: 700, fontSize: 13 }}>{item.action}</span>
                          <span style={{
                            fontSize: 10, fontWeight: 600, padding: "1px 7px", borderRadius: 3,
                            background: effortColor[item.effort].bg,
                            color: effortColor[item.effort].text,
                            border: `1px solid ${effortColor[item.effort].border}`
                          }}>{item.effort}</span>
                        </div>
                        <div style={{ fontSize: 11, color: "#3B82F6", fontWeight: 600, marginBottom: 4, fontFamily: "monospace" }}>{item.ref}</div>
                        <div style={{ fontSize: 12, color: "#475569", lineHeight: 1.6 }}>{item.detail}</div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        );
      })}

      {/* Legend */}
      <div style={{ marginTop: 24, padding: 16, background: "#F8FAFC", borderRadius: 8, border: "1px solid #E2E8F0" }}>
        <div style={{ fontSize: 11, fontWeight: 700, color: "#94A3B8", marginBottom: 8, textTransform: "uppercase", letterSpacing: 1 }}>Legend</div>
        <div style={{ display: "flex", gap: 24, fontSize: 12, color: "#64748B", flexWrap: "wrap" }}>
          <div><strong>Priority:</strong> Critical = blocking for IMA approval, High = required for production, Medium = required for compliance</div>
          <div><strong>Effort:</strong> High = multi-month build, Medium = weeks, Low = days</div>
          <div><strong>Refs:</strong> § numbers refer to Subpart F of the common rule text (§ __.2xx series)</div>
        </div>
      </div>
    </div>
  );
}
