Prompt: Build a Python “DQ Health Control Tower” for Risk-Factor Time Series
You are an Architect + Principal Python Data Scientist building a production-minded MVP of a “DQ Health Control Tower” for financial market risk-factor time series.

For your knowledge 
0) Problem Context
We manage ~50,000 risk factors (time series) used in trading, pricing, VaR/SVaR, and risk reporting. Each risk factor has history back to 2007 ( over 4000 business date for each) 
The current DQ approach is simplistic:
•	Outliers detected using (mean ± 4 * std) on 1-year shifts per risk factor (one-size-fits-all).
•	This is fragile (past bad points distort mean/std), ignores market regimes, and creates lots of false alarms, requiring heavy SME triage.

We need an application that:
•	Runs multiple DQ checks per asset class / universe.
•	Detects outliers, missing/stale, gaps, regime breaks (vendor/method changes).
•	Implements false-alarm reduction using peer-consistency + regime awareness.
•	Produces an auditable output dataset + a Dash UI for summary, drilldown, and triage.

1)	What are the  Risk Factor Hierarchy ? (rf_level1 → rf_level5)
Risk factors are keyed by a consistent 5-level taxonomy:
•	rf_level1 = Asset Class
•	rf_level2 = Currency
•	rf_level3 = Product / Market / Underlying
•	rf_level4 = Sub-type / Structure / Style
•	rf_level5 = Tenor / Bucket / Quote
This must scale naturally to 50k+ risk factors.
Examples (illustrative):
•	EQ_PRICE / USD / SPX / SPOT / NA
•	EQ_PRICE / USD / AMZN / SPOT / NA
•	EQ_VOL / USD / SPX / ATM / M01
•	IR_RATE / USD / Treasury / ForwardRate / M01
•	FX_RATE / USD / EUR / SPOT / NA
•	COMM_PRICE / USD / GOLD / FUTURE / M01
•	CP_RATE / USD / CDX / IG / Y05
•	CP_RATE / USD / RMBS / TBA / Coupon4.5
•	CP_RATE / USD / CORP / BBB / FWD_M01 (or similar normalized representation)






Architecture Requirements (Layered)
Implement the following layers as Python packages/modules (not a single script). Provide a clean folder structure.
Layer 1 — Data Access Layer
Layer 2 — Universe Layer (time series control plane)
Layer 3 — Advanced DQ Model & Method Library
Layer 4 — Configuration & Mapping Layer
Layer 5 — Run Engine / Orchestrator
Layer 6 — False Alarm Reduction + Triage Scorer (Must Implement)




Layer 1 — Data Access Layer
Goal: uniform access to time series + metadata from multiple backends.
•	Implement interfaces for:
o	Parquet (local)
o	SQLite (local)
o	optional stub for REST API (placeholder)
•	Provide TimeSeriesRepository abstraction with methods like:
o	get_series(risk_factor_ids, start_date, end_date) -> DataFrame
o	list_risk_factors(filters) -> DataFrame
o	write_results(df, table_name, partition_cols=...)
•	Enforce common schema: risk_factor_id (str), date (datetime64[ns]), value (float)
Layer 2 — Universe Layer (time series control plane)
•	A Universe is a named/tagged set of risk factors, pullable from any source.
•	UniverseDefinition includes:
o	name, description, filter rules (by rf levels, vendor, etc.), explicit includes/excludes
•	UniverseBuilder:
o	loads membership
o	normalizes to canonical rf_level1..5
o	validates duplicates / missing fields
o	outputs universe_membership dataset


# Layer 3 — Advanced DQ Model & Method Library
(Statistical + ML + Time-Series Native + AI-Assisted)
This layer is the core intelligence engine of the DQ Health Control Tower.
It must support:
1.	Pure statistical time-series detectors
2.	Or Change-point detection
3.	Unsupervised ML anomaly detection
4.	Supervised ML anomaly 
5.	Deep anomaly detection (optional)
6.	Peer cross-sectional detection
7.	Supervised false-alarm classification
8.	LLM-assisted explanation layer
9.	Pluggable third-party frameworks:
o	PyOD
o	Merlion
o	ADTK
o	plus custom local models
10.	in addition to the above, It must include class implementing a common interface:
DQCheck interface:
•	name
•	required_inputs
•	fit(df, context) -> model_state (optional)
•	score(df, context, model_state) -> results_df
Where df is timeseries for 1 risk factor OR a peer group batch depending on method.

Implement MVP checks:
1.	Rolling robust z-score using median/MAD (not mean/std), configurable window.
2.	Classic rolling z-score (mean/std), configurable window (for benchmarking current method).
3.	Stale / no-change detector (N consecutive identical values).
4.	Missing / gaps detector (missing business dates; configurable calendar).
5.	Jump / spike detector using robust change statistics on returns/shifts.
6.	Optional: LOF / IsolationForest via PyOD (if available) or sklearn equivalents:
o	Should  support “fit per peer-group if enough samples, else per series sliding window”.
Each check must output:
•	date, raw_score, flag, severity, threshold, reason_code
Severity mapping rules (example):
•	Critical if score > critical_threshold
•	High/Med/Low else; all configurable per check and per asset class.


The design must be modular , and configuration-driven.
 
## 3.1 Architecture Requirements
### 3.1.1 Model Registry
Implement a ModelRegistry that dynamically registers:
•	Local statistical models
•	PyOD adapters
•	Merlion adapters
•	ADTK adapters
•	Ensemble models
ModelRegistry.register("robust_zscore", RobustZScoreCheck)
ModelRegistry.register("pyod_iforest", PyODAdapter)
ModelRegistry.register("merlion_stl", MerlionAdapter)
ModelRegistry.register("adtk_quantile", ADTKAdapter)
The registry must support:
•	Instantiating from YAML config
•	Automatic validation of required params
•	Version tagging for audit
 
## 3.2 Unified DQCheck Interface
All detectors (local or third-party) must implement:
class DQCheck:
    name: str
    family: str  # stat_univariate | integrity | changepoint | ml_unsupervised | ml_supervised | peer | llm_assisted
    scope: str   # per_series | per_peer_group | global
    required_inputs: set
def fit(self, df, context) -> model_state:
        pass
def score(self, df, context, model_state) -> pd.DataFrame:
        pass
Output schema must always include:
•	risk_factor_id
•	date
•	raw_score
•	threshold
•	flag
•	severity
•	reason_code
•	explain
•	artifacts_json
This ensures interoperability across 50+ detectors.
 
## 3.3 Feature Engineering Sub-Layer (Mandatory)
Before any ML model runs, we should  transform time-series into features.
Implement a FeatureBuilder:
Feature categories:
- 1️⃣ Basic Time-Series
•	1d return
•	5d return
•	10d return
•	rolling mean
•	rolling std
•	rolling MAD
•	rolling quantiles
•	rolling skew/kurtosis
- 2️⃣ Volatility & Regime
•	rolling vol
•	realized vol proxy
•	volatility zscore
•	drawdown
- 3️⃣ Peer-Based
•	value - peer median
•	zscore vs peer group
•	percentile rank in group
•	group dispersion index
- 4️⃣ Curve Features (for rates/credit)
•	slope
•	curvature
•	butterfly
•	first derivative
•	second derivative
FeatureBuilder must:
•	operate windowed
•	be incremental
•	cache intermediate results
•	support parallelization
 
## 3.4 Model Families (Expanded)
🟢 A) Statistical Local Models (Always Available)
Implement internally:

| #  | Check                                  | Description                                                                                        |
|----|----------------------------------------|----------------------------------------------------------------------------------------------------|
| 0  | **4 Stdv Away from the Mean of shift** | Mean/Std based, configurable window (default 252). 4 standard Deviation. Primary outlier detector. |
| 1  | **Rolling Robust Z-Score**             | Median/MAD based, configurable window (default 252). Primary outlier detector.                     |
| 2  | **Rolling Classical Z-Score**          | Mean/Std based, configurable window. For benchmarking vs robust.                                   |
| 3  | **Quantile Band Detection**            | Flag values outside rolling [1%, 99%] bands.                                                       |
| 4  | **Robust Return Spike Detector**       | Large absolute returns vs rolling MAD of returns.                                                  |
| 5  | **CUSUM Drift Detection**              | Cumulative sum of deviations to detect persistent level shifts.                                    |
| 6  | **Rolling KS Statistic**               | Kolmogorov-Smirnov test comparing recent window vs history — distribution shift.                   |
| 7  | **Stale / No-Change Detector**         | N consecutive identical values (configurable N per asset class).                                   |
| 8  | **Missing Date / Gap Detector**        | Missing business dates, configurable calendar per region/exchange.                                 |

These models must:
•	Require zero heavy dependencies
•	Run per-series
•	Be extremely fast
•	Be default fallback models
 
### 🔵 B) ADTK Integration (Time-Series Native Detectors)
Wrap ADTK models behind adapter:
Example candidates:
- `QuantileAD` — quantile-based outlier
- `SeasonalAD` — seasonality-aware anomaly
- `LevelShiftAD` — abrupt level changes
- `PersistAD` — persistence / mean-reversion anomaly
- `InterQuartileRangeAD` — IQR-based
- `AutoregressionAD` — AR model residual anomaly

ADTK Adapter must:
-Convert pandas series into ADTK format
-Run detector
-Convert anomaly output to DQ schema
-Support ensemble combination

Use ADTK primarily for:
    •	Level shifts
    •  	Seasonality-aware anomalies
    •	Persistence detection
 
### 🟡 C) Merlion Integration (Advanced TS Intelligence)
Merlion is strong for:
•	Change-point detection
•	STL-based anomaly detection
•	Forecast-based anomaly scoring
•	Multi-model ensemble

Wrap Merlion models behind `MerlionAdapter`:

Candidate models:
- STL-based anomaly detector
- Prophet-based anomaly detection
- IsolationForest (Merlion version)
- Change-point detectors (BOCPD)

Adapter must:
•	Convert series into Merlion TimeSeries
•	Fit on training window
•	Score future window
•	Handle incremental scoring

Merlion should be used for:
•	Structural breaks
•	Forecast residual anomaly
•	High-quality regime detection
 
### 🔴 D) PyOD Integration (Feature-Based ML Anomaly Detection)
PyOD is ideal for:
•	Multivariate anomaly detection on engineered features
Wrap via `PyODAdapter`. Supported model types:

- IsolationForest
- LOF (Local Outlier Factor)
- ECOD (Empirical Cumulative Distribution)
- HBOS (Histogram-Based Outlier Score)
- kNN
- COPOD (Copula-Based)
- PCA
- Deep AutoEncoder (optional)
- Deep SVDD (optional)

**Design rules:**
- Operate ONLY on feature matrices (output of FeatureBuilder)
- Must support: per-peer-group fit, per-asset-class fit, sliding-window retrain
- Must normalize raw PyOD scores to [0, 1] across models for comparability

Critical:
Raw PyOD score must be standardized across models.
 
### 🟣 E) Supervised False-Alarm Classifier
Optional mode:
Train classifier on historical triage labels.
Candidates:
- XGBoost
- LightGBM
- RandomForest
- Logistic Regression baseline


**Input features:**
- All anomaly scores from upstream checks
- peer_confirmed_flag (did peers also flag?)
- regime_tag (stress / normal / low-vol)
- check_type, asset_class, vendor
- integrity flags (stale, missing, gap, outlier)
- 
**Output:** `false_alarm_probability` (0–1)

Model version + training metrics + confusion matrix must be logged for audit.
 
#### 🟠 F) LLM-Assisted Layer (Advisory Only)

LLM is **NOT** a primary anomaly detector. Use only for:
- **Explanation:** Generate human-readable narratives for flagged anomalies
- **Context summarization:** "This risk factor moved −3σ but its CDX peer group also moved −2.5σ during a credit event"
- **Recommended remediation:** Suggest whether to override, escalate, or suppress
- **Parameter tuning suggestions:** "This series has high seasonality; consider enabling SeasonalAD"

**LLM must:** never modify raw data, never override thresholds, output structured JSON only.

 
### 3.5 Fit Policies (Critical for 50k Series)

Each model must declare:

```yaml
fit_policy: per_series | per_peer_group | global
min_training_points: 252      # minimum history required
min_peer_group_size: 5        # minimum peers for cross-sectional fit
supports_partial_fit: true    # incremental update supported?
retrain_frequency: weekly     # how often to refit
```

Engine must: avoid refitting unnecessarily, cache `model_state` (pickle or joblib), retrain only on new windows or schedule.

 
### 3.6 Ensemble Engine

```python
class EnsembleCheck(DQCheck):
    children: List[DQCheck]
    strategy: str   # max_score | weighted_avg | rank_aggregation | majority_vote
```
#### Support:
•	max score
•	weighted average
•	rank aggregation
•	majority vote

#### Ensemble must:
•	Accept arbitrary list of child checks
•	Normalize scores first
•	Output aggregated severity
 
### 3.7 Configuration-Driven Model Activation
All model selection is driven by YAML. Example:

```yaml
universe: CP_RATE_CORP
models:
  - name: robust_zscore
    params:
      window: 260
      threshold: 6

  - name: adtk_levelshift
    params:
      window: 30

  - name: pyod_iforest
    params:
      contamination: 0.002
      window: 60
      feature_set: default_market_features

  - name: merlion_stl
    params:
      seasonality: 252

  - name: ensemble_default
    children:
      - robust_zscore
      - pyod_iforest
      - adtk_levelshift
    strategy: max_score

severity_thresholds:
  critical: 8.0
  high: 6.0
  medium: 4.0
  low: 2.5
```

#### Must support:
•	per asset_class defaults
•	per universe override
•	per rf_level override



## Layer 4 — Configuration & Mapping Layer
We need a declarative configuration system:
•	YAML config files under configs/
•	Map: universe_name -> list of checks + parameters
•	Map: asset_class (rf_level1) -> default checks + defaults
•	Allow overrides by rf_level2..5 or vendor if needed.
Example mapping (illustrative):
•	universe: CP_RATE_CORP
o	rolling_zscore(window=260, k=4)
o	rolling_robust_zscore(window=260, k=6)
o	isolation_forest(contamination=0.002, window=60)
o	stale_check(days=5)
Also compute a config hash to store in audit logs.

## Layer 5 — Run Engine / Orchestrator
Implement a run engine that:
•	takes run_id, universe_name(s), date range, and config
•	loads membership + time series
•	groups series logically (per risk factor; and per peer group when needed)
•	executes checks with caching and parallelism (optional: joblib or multiprocessing)
•	writes results as partitioned Parquet:
o	partition by run_id/universe_name/check_type (or similar)
•	logs timing + counts per stage.
Must support:
•	incremental re-runs (only new dates)
•	deterministic outputs (same inputs/config -> same results)


## Layer 6 — False Alarm Reduction + Triage Scorer (Must Implement)
Implement a “false alarm reduction layer” even if heuristic-first.

### 6.1 )  Market Regime Awareness

Integrate regime indicators:
- **Equity vol:** VIX
- **Rates vol:** Trasury  index
- **Credit stress:** CDX IG / HY spreads, iTraxx
- **FX vol:** CVIX or G10 implied vol index

### 6.2  Event Calendar Integration

Suppress or re-label expected jumps around:
- FOMC dates, ECB meetings, BOJ decisions
- Earnings dates (equity names)
- Index rebalance dates
- Futures/options expiry and roll dates
- CDS roll dates (Mar/Jun/Sep/Dec 20th)
- Known data vendor maintenance windows

Implementation: maintain an event calendar table. Before flagging, check if any event overlaps within ±1 business day. If yes, tag flag as `event_proximate: true` and reduce severity by one level.

###  6.3  Peer-Based Comparison Engine

For each risk factor, define a peer group (same sector, same tenor, same rating, same curve family).

**Auto-clustering:** Use correlation-based similarity (rolling 252d Pearson) or DTW (Dynamic Time Warping) to cluster risk factors. Update clusters quarterly.

**For any flagged anomaly, compute:**
- Factor's move vs. peer group median move
- Percentile rank of factor's move within peer group
- Number of peers also flagged on same date
- Rolling correlation stability (has factor decoupled from peers?)

**Flag reduction rule:** If the factor moved AND ≥60% of its peers also moved comparably (within 1σ of peer group), downgrade severity. Only flag if the factor is an **outlier relative to its peers**.

Allow manual peer group overrides via config.

#### 6.4 ) Peer consistency checks:
•	Define peer groups using hierarchy keys:
(asset_class, currency, product/underlying, sector/rating if available, tenor_bucket)
•	For each date, compute peer median and IQR band.
•	Mark alert as peer-confirmed if series move aligns with peer move:
o	e.g., if many peers flag similar direction/magnitude.
•	For small peer groups, degrade confidence gracefully.

#### 6.5 ) Regime/Stress Period tagging:
During identified stress periods (VIX > 30, MOVE > 120, etc.):
- Automatically widen anomaly thresholds by a configurable multiplier (e.g., 1.5×)
- Tag all flags with `regime: stress` so analysts can filter
- Never suppress critical integrity checks (stale, missing) regardless of regime


- Implement regime windows configurable in YAML:
- e.g., 2008-09-01 to 2009-06-30
- 2020-02-15 to 2020-06-30
- plus “last 1 year” as default reference
- During high-vol regimes, lower the probability that an outlier is “bad data” unless peers do not confirm.

#### 6.6 ) Triage scorer:
•	If no labels exist: heuristic confidence_estimate and recommended_action:
o	ACCEPT_MOVE if peer-confirmed and regime-tagged high-vol
o	CONFIRM_BAD_DATA if not peer-confirmed + integrity issues
o	NEEDS_REVIEW otherwise
•	If labels exist (optional mode): train a simple classifier (XGBoost if installed else sklearn GradientBoosting/RandomForest) predicting false-alarm probability using features:
o	check_type, severity, raw_score, peer_confirmed, asset_class, vendor, regime_tag, missing/stale indicators, etc.
•	MLflow integration optional and OFF by default.
•	Persist model version + metrics in audit_log.


 ## 7 ) Lastly UI/Dash 
You are a senior architect + principal Python data scientist. Generate code and configuration artifacts for a “DQ Health Control Tower” specifically for financial market risk-factor time series (50k series, 2007–present). Implement three deliverables:
1.	A full YAML model catalog template for all asset classes
2.	A score normalization framework so anomaly scores from 20+ heterogeneous models are comparable and map to a common severity scale
3.	A Dash UI (Dash + Plotly + Dash AG Grid) that supports summary, model comparison, and click-through series investigation
Hard requirements
•	Support model backends: Local statistical checks, PyOD, Merlion, ADTK
•	Everything is config-driven using YAML
•	Outputs must be auditable: never overwrite raw series; store results and decisions separately
•	Must be scalable: batch scoring, caching, partitioned output
•	Provide clean module structure and typed interfaces
 




## A) Deliverable 1 — Full YAML model catalog template (all asset classes)
Create a complete YAML catalog file configs/model_catalog.yaml that defines:
1) Global defaults
•	regime windows (e.g., 2008, 2020, last_1y)
•	standard feature sets (for PyOD feature-matrix models)
•	standard normalization policy defaults (see section B)
•	default severity thresholds (Critical/High/Med/Low), configurable per asset class and per model family
2) Asset-class defaults
For each rf_level1 asset class:
•	EQ_PRICE, EQ_VOL
•	IR_RATE, IR_VOL
•	FX_RATE, FX_VOL
•	COMM_PRICE, COMM_VOL
•	CP_RATE, CP_VOL
Define:
•	peer grouping keys (rf_level1..5 + optional sector/rating/tenor_bucket)
•	which model families apply (integrity/stat/changepoint/ML)
•	default windows (e.g., 30, 60, 260)
•	default contamination for ML models (if used)
3) Universe-level overrides
Include example universes:
•	EQ_PRICE_US
•	IR_RATE_USD
•	FX_VOL_G10
•	COMM_PRICE_METALS
•	CP_RATE_CORP
•	CP_RATE_CDX
•	CP_RATE_RMBS
Each universe maps to a list of checks with parameters and the fit policy:
•	per_series
•	per_peer_group
•	global
YAML format requirements
•	Use stable schema:
o	globals
o	feature_sets
o	normalization
o	asset_class_defaults
o	universes
•	Each model entry includes:
o	id, backend (local|pyod|merlion|adtk)
o	model_name (for backend adapter)
o	family (integrity|stat_univariate|changepoint|ml_unsupervised|peer|ensemble)
o	fit_policy
o	params
o	normalization_profile
o	severity_profile
o	enabled: true/false
Generate a filled template with sensible starter models per asset class:
•	Always include local integrity + robust stats
•	Add ADTK for level shifts / seasonal patterns
•	Add Merlion for change-point / STL or forecast residual anomalies
•	Add PyOD for feature-based multivariate detectors (e.g., IsolationForest, LOF) using a feature set
Notes:
•	PyOD detectors must be treated as feature-matrix models using decision_function() for raw scores. (PyOD)
•	Merlion provides calibration tools that can calibrate model scores to be interpretable like z-scores; include normalization option to use Merlion calibrator when backend=merlion. (Salesforce Open Source)
•	ADTK encourages composing detectors + transformers + aggregators; include an ensemble/aggregator example in YAML. (Anomaly Detection Toolkit)
 
## B) Deliverable 2 — Score normalization framework (20+ models comparable)
Implement a module src/normalization/normalizer.py that defines:
B1) Standard normalized score
Define a standard normalized score norm_score in [0, 1] or z-like units.
Support multiple normalization strategies, selectable in YAML:
1.	Robust z-score normalization
•	For each check, compute rolling (or reference-window) median and MAD of raw_score
•	norm_z = (raw_score - median) / (1.4826*MAD + eps)
•	Then convert to [0,1] via logistic or CDF mapping
2.	Empirical CDF normalization (recommended for heterogenous models)
•	For each (asset_class, check_id) learn an ECDF mapping using a training reference period
•	norm_score = ECDF(raw_score)
•	Supports stable comparability across different score scales
3.	Quantile-to-severity normalization
•	Define severity by percentile bands (e.g., top 0.1% = Critical)
•	This makes different detectors comparable by rarity
4.	Backend-aware calibration
•	If backend=merlion and calibrator is enabled, apply Merlion score calibration (z-score interpretability) before other mappings. (Salesforce Open Source)
•	If backend=pyod: use raw decision_function() scores, then apply ECDF/quantile mapping. (PyOD)
### B2) Severity mapping
Implement SeverityMapper with:
•	configurable thresholds either:
o	fixed thresholds on norm_score, or
o	quantile thresholds (per asset class and model)
•	output: Critical/High/Med/Low
### B3) Calibration artifacts and versioning
For each (run_id, check_id):
•	persist normalization artifacts:
o	reference period
o	ECDF bins or quantile cutoffs
o	fitted robust statistics
o	model + config hashes
Store to data/artifacts/normalization/ partitioned by check_id.
### B4) Comparable outputs across models
Define a unified output schema:
•	raw_score (native)
•	norm_score (comparable)
•	severity
•	flag (boolean)
•	threshold used (in normalized units)
•	reason_code
Provide unit tests verifying:
•	monotonicity: higher raw_score -> higher norm_score (within tolerance)
•	consistency: same percentile band yields same severity across models
 
# C) Deliverable 3 — Dash UI (summary + comparison + click series)
Build a Dash app src/ui/app.py with 3 tabs:
## TAB 1 — Summary
•	KPIs: total series, alerts by severity, alerts over time
•	filter controls:
o	asset_class, universe, date range, model family, severity
•	charts:
o	alerts over time (with regime window overlays)
o	breakdown by asset class + check family
o	heatmap by (asset_class x currency)
## TAB 2 — Hierarchy Drilldown (Tree)
Use Dash AG Grid tree data with a hierarchy path:
asset_class → currency → underlying/product → subtype → tenor → risk_factor_id
Implement tree using getDataPath so each row provides a list path. (Dash Documentation)
On click leaf risk_factor_id:
•	show time series plot with flagged points
•	show table of issues: (date, check_id, raw_score, norm_score, severity, reason_code)
•	show model comparison view:
o	overlay anomaly flags from multiple checks for the same series
o	optional: “score ribbons” per model for the selected time window
## TAB 3 — Model Comparison & Outliers Explorer
•	pick a universe + a date window
•	show a ranked table: risk_factor_id with the largest norm_score per model
•	allow selecting multiple models and compare:
o	overlap between model flags
o	disagreement report (model A flags, model B doesn’t)
o	severity distribution per model
•	clickable rows navigate back to TAB 2 and load that series


Data sources for UI
UI reads:
•	dq_results dataset (parquet)
•	timeseries_raw dataset (parquet)
•	universe_membership dataset
Optionally cache in memory for performance.
Callback requirements
•	Central store pattern:
o	dcc.Store for selected universe, filters, selected risk_factor_id
•	Callbacks must be well-documented and linked to layout components.
 
### D) Implementation details
Generate:
1.	configs/model_catalog.yaml (complete template)
2.	src/normalization/ (normalizer + severity mapper + artifact persistence)
3.	src/ui/app.py (Dash UI with 3 tabs)
4.	sample loader + small synthetic dataset generator for demo
5.	README instructions to run:
o	generate synthetic data
o	compute dq_results with normalization
o	run Dash UI
Use these libraries:
•	pandas, numpy, pyarrow
•	dash, plotly, dash-ag-grid
•	pydantic (optional)
•	pyod (optional but supported)
•	merlion (optional but supported)
•	adtk (optional but supported)
Make sure code handles missing optional deps gracefully:
•	if PyOD not installed, disable pyod models with a clear warning
•	same for Merlion and ADTK
Now produce the full artifacts (YAML + python modules + Dash app) with file boundaries.



# Deliverable 4  new verion of App
 keep the existing  rc/ui/app.py and lets build new ui:  rc/ui/app_v2.py)
Build a Dash app `src/ui/app.py` with 4 tabs. The dashboard must handle 50k risk factors
across 60+ asset classes and feel responsive at scale.

---

## TAB 1 — War Room (Executive Summary)

**Purpose:** In 5 seconds, tell a risk manager where the problems are today.

### Top Banner
- Current regime indicator: show VIX, MOVE, CDX IG level with color-coded status
  (normal / elevated / stress). This contextualizes everything below.
- KPI bar: total series monitored | total flagged today | new flags (not flagged yesterday) |
  critical count | 7-day trend arrow (↑ improving / ↓ degrading)

### Primary Visual — DQ Health Heatmap Matrix
- Rows: asset classes (EQ_STOCK, CORP_RATE, CDX, FX_VOL, TREASURY, CMBS, ABS, MUNI, ...)
- Columns: check families (integrity, stat_univariate, changepoint, ml_unsupervised, peer)
- Cell color: worst severity in that (asset_class × check_family) combination
- Cell tooltip: count of flags, top reason_code
- Click any cell → jump to TAB 2 pre-filtered to that asset_class + check_family

### Secondary Visuals
- Alerts over time (line chart, 30d rolling, with regime window overlays as shaded bands)
- Breakdown by asset class (bar chart, stacked by severity)
- "New vs. Persisting" donut: split today's flags into first-time flags vs. flags firing ≥N days
- Top 10 worst risk factors globally (ranked table with composite anomaly score,
  clickable → jumps to TAB 2 leaf)

### Filter Controls
- asset_class (multi-select)
- universe (multi-select, cascading from asset_class)
- date range (date picker)
- model family (multi-select: integrity, stat, ML, peer)
- severity (multi-select: critical, high, medium, low)
- regime (normal / elevated / stress / all)
- show_only: new_today | persisting | all

---

## TAB 2 — Hierarchy Drilldown (Tree + Detail Panel)

**Purpose:** Navigate from asset class down to individual risk factor, with useful
aggregated info at every intermediate level.

### Left Panel — AG Grid Tree
Use Dash AG Grid tree data with `getDataPath`.

**Hierarchy path** (configurable per asset class via YAML):
```
Default:  asset_class → universe → risk_factor_id
Rates:    asset_class → currency → curve_family → tenor → risk_factor_id
Credit:   asset_class → rating_bucket → series → risk_factor_id
Equity:   asset_class → sector → region → risk_factor_id
FX:       asset_class → currency_pair → tenor → risk_factor_id
```

**Columns visible at every tree level (aggregated for non-leaf rows):**
| Column | Description |
|---|---|
| Name | Node label |
| Total Factors | Count of leaf factors under this node |
| Flagged | Count currently flagged |
| Critical | Count of critical severity |
| Worst Severity | Worst severity badge (colored chip) |
| Flag Rate | % of factors flagged (= Flagged / Total) |
| Trend (30d) | Inline sparkline of daily flag count for this branch |
| Peer Health | % of peer group also flagged (universe level and below) |

**Non-leaf row click:** Update right panel to show aggregated summary for that branch
(mini heatmap of check families, top offenders list, alerts-over-time chart for branch).

**Leaf row click (risk_factor_id):** Load full detail panel (see below).

### Right Panel — Risk Factor Detail (on leaf click)

#### Section A: Time Series Chart
- Full history line chart with anomaly flags overlaid as colored markers (by severity)
- Toggle overlays:
  - Peer group median ± 1σ band
  - Rolling Bollinger bands
  - Regime shading (stress windows)
  - Event markers (FOMC, roll dates, etc.)

#### Section B: Flag Table
- Table of all active + recent flags for this factor:
  (date, check_name, check_family, raw_score, norm_score, threshold, severity,
   reason_code, explain, peer_confirmed, event_proximate, false_alarm_prob)
- Sortable by date, severity, score

#### Section C: Model Comparison View
- Overlay anomaly flags from all active checks for this series on a shared timeline
- "Score ribbons": per-model anomaly score plotted as semi-transparent bands over time
  (each model gets a different color)
- Disagreement highlights: dates where models disagree on flag/no-flag

#### Section D: Context Sidebar
- Current regime tag + regime indicators
- Nearest calendar event (type + days until/since)
- Peer group confirmation: "X of Y peers also flagged on this date"
- False alarm probability (if supervised classifier is active)
- Vendor + data source info

#### Section E: Triage Actions
- Buttons: ✅ Confirm Issue | ❌ Dismiss (False Alarm) | ⚠️ Known/Expected | 🔍 Needs Investigation
- On action: store label to `triage_labels` table with timestamp, analyst_id, flag_id
- Historical triage: show past flags on this same factor and their resolution

---

## TAB 3 — Model Comparison & Outliers Explorer

**Purpose:** Power-user tab for comparing model behavior, tuning, and calibration.

### Controls
- Select universe (dropdown) + date window (range picker)
- Select 2-4 models to compare (multi-select)

### Views

#### Ranked Outlier Table
- risk_factor_id ranked by largest norm_score, per selected model
- Columns: factor name, asset_class, each model's norm_score, each model's flag (✓/✗),
  consensus (how many models agree), peer_confirmed
- Clickable rows → navigate to TAB 2 and load that series

#### Model Agreement Analysis
- **Venn/Upset diagram**: For selected models, show overlap of flagged factors
  (how many flagged by all, by exactly 2, by exactly 1)
- **"Solo flags" filter**: Toggle to see factors flagged by exactly one model only —
  these are the most interesting for calibration
- **Disagreement report table**: Rows where Model A flags but Model B doesn't,
  with both scores shown

#### Score Correlation
- Scatter plot: Model A score (x) vs Model B score (y) for all factors in selected universe
- Color points by severity or by whether analyst confirmed/dismissed
- Identify systematic biases (e.g., IsolationForest consistently scores higher than Z-Score)

#### Model Performance (requires triage labels)
- Per-model precision, recall, false-alarm rate (based on accumulated analyst labels)
- Confusion matrix per model
- Trend of model precision over time (are models improving as labels accumulate?)

#### Secondary
- Severity distribution per model (collapsible)
- Score histogram per model (collapsible)

---

## TAB 4 — Peer Group Explorer

**Purpose:** Dedicated view for peer-based analysis — answering "is this factor broken,
or did the whole market move?"

### Controls
- Select peer group (by universe, or by asset_class + sub_category)
- Date range

### Views

#### Multi-Line Time Series
- All factors in the peer group plotted together (indexed to 100 or as returns)
- The flagged/outlier factor highlighted in a distinct color
- Peer median shown as thick dashed line

#### Cross-Sectional Scatter (single-date)
- Slider to pick a date. On that date, plot all peer group members as dots (x = factor,
  y = value or return). Flagged factors shown as red dots with labels.
- Shows the cross-sectional distribution and where the outlier sits.

#### Peer Correlation Heatmap
- NxN heatmap of rolling correlations between all group members
- Highlight cells where correlation has dropped below historical average by >2σ
  (leading indicator of decoupling / data issue)

#### Peer Group Health Table
- For each peer group: member count, % flagged, group dispersion (MAD),
  worst member (by score), group avg correlation, correlation stability (rolling σ of avg corr)
- Sortable — surface the most distressed peer groups first

#### Factor vs. Peer Comparison Panel
- On clicking any factor in the peer group:
  - factor return vs. peer median return (dual axis or indexed)
  - factor z-score within peer group over time
  - rolling correlation to peer centroid

---

## Cross-Tab Navigation Rules
- TAB 1 heatmap cell click → TAB 2 pre-filtered to that asset_class + check_family
- TAB 1 top-10 row click → TAB 2 with that risk_factor_id selected
- TAB 2 leaf click → loads detail panel in TAB 2 (same tab)
- TAB 3 row click → TAB 2 with that risk_factor_id selected
- TAB 4 factor click → TAB 2 with that risk_factor_id selected
- All navigation preserves active date range filter

---

## Performance Requirements for 50k Factors
- TAB 1 aggregations must be pre-computed (not calculated on page load)
- TAB 2 tree must use server-side row model or virtual scrolling (AG Grid infinite row model)
- TAB 2 detail panel loads data on-demand (only when leaf clicked)
- TAB 4 peer group limited to max ~200 factors per group for charting performance
- All heavy queries go through a pre-aggregated results table, not raw time series