# Layer 3 Taxonomy And Common Checks Context

This document captures the full change set implemented for Layer 3 taxonomy cleanup, model expansion, and UI/model-level comparison support.

## Scope

- Clean family taxonomy aligned to `docs/features/family_Models_Mapping.MD`.
- Additional Layer 3 checks (statistical, rule-based, forecast, peer).
- Common checks configurable once and applied per universe.
- Model-level comparison support (`check_id`/`model_id`) in outputs and UI.
- Backward-compatible behavior where possible.

## Taxonomy Standard

Canonical family names now used:
- `STATISTICAL_BASIC`
- `STATISTICAL_ROBUST`
- `RULE_BASED`
- `ML_UNSUPERVISED`
- `ML_FORECAST_BASED`
- `PEER_CROSS_GROUP`
- `ENSEMBLE`

Implementation:
- `src/dq_checks/taxonomy.py`

Notes:
- Legacy families (`stat_univariate`, `integrity`, `changepoint`, `peer`, `ensemble`) are mapped to canonical names.
- Backend-aware defaults are applied (`pyod -> ML_UNSUPERVISED`, `adtk/merlion -> ML_FORECAST_BASED`).

## New/Updated Layer 3 Checks

Implemented in:
- `src/dq_checks/local_checks.py`

Added/updated models:
- Statistical basic:
  - `mean_std_shift_4` (alias to 4-sigma shift)
  - `zscore_mean_std`
  - `rolling_zscore`
- Statistical robust:
  - `robust_zscore_median_mad` (alias to robust z)
  - `robust_zscore_mean_std`
  - `quantile_band`
  - `iqr`
  - `jump_spike`
  - `rolling_ks`
  - `cusum_drift`
- Rule based:
  - `rule_abs_shift_gt`
  - `stale_values`
  - `missing_gaps`
- Forecast based:
  - `arima_residual` (statsmodels when available, fallback rolling baseline)
- Peer cross-group:
  - `peer_median_dev`
  - `peer_mad`
  - `peer_robust_z`
  - `peer_percentile`

Adapters:
- `src/dq_checks/adapters.py`
  - Added PyOD `iqr` support with safe fallback.
  - Updated adapter families to canonical taxonomy.

Ensemble:
- `src/dq_checks/ensemble.py`
  - Family set to canonical `ENSEMBLE`.

## Registry And Common Checks

Implemented in:
- `src/dq_checks/registry.py`

Key behavior:
- Registers all added checks/aliases.
- Canonicalizes family at spec load time.
- Supports `common_checks` block in YAML.
- Universe-specific checks override common checks when `id` matches.

Common check selector:
- Primary selector: `apply_to_universes` (list of universe names).
- Backward-compatible fallback: `apply_to_rf_level1` if present.

## Config Updates

Updated:
- `configs/model_catalog.yaml`

What changed:
- Added `common_checks` section with a full baseline set.
- Added `EQ_VOL_USD` universe for EQ volatility defaults.
- Updated family names to canonical taxonomy across asset defaults and universes.
- Common checks now target explicit universes using `apply_to_universes`.

## Output Schema / Engine Changes

Added explicit model identifier in results:
- `model_id` column (currently mirrors `check_id`).

Updated files:
- `src/engine/run_engine.py`
- `src/pipeline/run_demo_layer3_dqChecks.py`
- `src/pipeline/run_demo_layer6_false_alarm.py`
- `src/common/schemas.py`

Purpose:
- Model-level comparison and model-specific triage features without relying only on family.

## UI Changes

Updated files:
- `src/ui/app.py`
- `src/ui/app_v2.py`

Changes:
- Added check/model ID filter in UI v1 and UI v2.
- Preserved family filters.
- UI v2 model comparison continues using selected check IDs.
- Added defensive handling for missing columns (`date`, `regime_tag`, etc.) to avoid load-time failures.

## Layer 6 / Triage Feature Extension

Updated:
- `src/triage/false_alarm.py`

Change:
- Supervised feature builder now includes one-hot features from `model_id` when present.

## Validation Performed

- Python compile checks on all modified modules.
- YAML parse validation for `configs/model_catalog.yaml`.
- Layer 3 demo run with canonical families and newly added checks.
- Layer 6 demo run after output serialization fix for nested objects.
- App v2 initialization sanity check with data load and app creation.

## Follow-up Guidance

- Keep common checks lightweight for default runs; enable heavier forecast checks selectively per universe.
- Use `check_id`/`model_id` selectors in UI for model-by-model calibration and disagreement review.
- For production, consider adding explicit model metadata table (`model_id -> feature family, backend, fit policy`) for downstream XGBoost feature engineering.



### completed
Implemented. I read `docs/features/family_Models_Mapping.MD` and applied the taxonomy + model updates in Layer 3 and UI.

**What changed**
- Added canonical family taxonomy and mapper:
  - `src/dq_checks/taxonomy.py:6`
  - `src/dq_checks/taxonomy.py:86`
- Implemented/renamed missing Layer 3 checks:
  - `zscore_mean_std`: `src/dq_checks/local_checks.py:101`
  - `robust_zscore_mean_std`: `src/dq_checks/local_checks.py:145`
  - `iqr`: `src/dq_checks/local_checks.py:207`
  - `rule_abs_shift_gt` (for `abs(shift) > threshold`): `src/dq_checks/local_checks.py:237`
  - `arima_residual`: `src/dq_checks/local_checks.py:422`
  - Peer checks:
    - `peer_median_dev`: `src/dq_checks/local_checks.py:482`
    - `peer_mad`: `src/dq_checks/local_checks.py:509`
    - `peer_robust_z`: `src/dq_checks/local_checks.py:535`
    - `peer_percentile`: `src/dq_checks/local_checks.py:561`
- Extended PyOD adapter with `iqr` and updated families:
  - `src/dq_checks/adapters.py:100`
- Updated ensemble family taxonomy:
  - `src/dq_checks/ensemble.py`
- Registry now:
  - Registers new model names/aliases
  - Canonicalizes family names
  - Supports default common checks per universe (with universe override by same `id`)
  - `src/dq_checks/registry.py:56`
  - `src/dq_checks/registry.py:136`
- Added common default checks in catalog (enabled by default), plus `EQ_VOL_USD` universe:
  - `configs/model_catalog.yaml:154`
  - `configs/model_catalog.yaml:416`
- Updated config families to clean taxonomy names (`STATISTICAL_BASIC`, `STATISTICAL_ROBUST`, `RULE_BASED`, `ML_UNSUPERVISED`, `ML_FORECAST_BASED`, `PEER_CROSS_GROUP`, `ENSEMBLE`).
- Added model-level column in outputs (`model_id = check_id`) for false-alarm features/UI:
  - `src/engine/run_engine.py:77`
  - `src/common/schemas.py:20`
  - `src/pipeline/run_demo_layer3_dqChecks.py:75`
  - `src/pipeline/run_demo_layer6_false_alarm.py:117`
- False-alarm supervised feature builder now includes `model_id` when present:
  - `src/triage/false_alarm.py`
- UI model/check-level filtering added:
  - App v2 check/model filter dropdown: `src/ui/app_v2.py:449`
  - App v2 filter state includes `check_id`: `src/ui/app_v2.py:432`
  - App v2 applies check_id filter: `src/ui/app_v2.py:637`
  - App v1 also now has `filter-check-id`: `src/ui/app.py:142`
- Fixed `app_v2` robustness for missing columns (`date`, `regime_tag`) to avoid `NoneType/.dt` errors:
  - `src/ui/app_v2.py`

**Behavior you asked for**
- Common detectors can run by default per universe, and you can still override/customize by `check_id` and params in universe checks.
- UI now supports exact model/check selection, not only family-level filtering.
- Outputs include explicit model-level id (`model_id`) for downstream false-alarm reduction features.

**Validated**
- `py_compile` passed for all changed modules.
- `model_catalog.yaml` parses successfully.
- Layer 3 demo runs with new checks/families.
- Layer 6 demo runs with parquet output (fixed prior struct/parquet issue in `triage_model` output).
- `app_v2` app object creation succeeds after robustness fixes.

If you want, next I can add a short `docs/features/FAMILY_TAXONOMY_USAGE.md` with exact examples for:
1. overriding one common check per universe,
2. disabling common checks for one universe,
3. selecting exact check IDs in UI for side-by-side comparison.

### Completed.

1. Added requested taxonomy usage file with all 3 examples  
- `docs/features/Family_Taxanomoy_usage.MF`  
- Includes:
  - Override a common check in one universe (same `id` override)
  - Disable common checks for one universe (`use_common_checks: false`)
  - Compare exact `check_id`/`model_id` in UI (not just family)

2. Added one consolidated context MD for all recent changes  
- `docs/LAYER3_TAXONOMY_AND_COMMON_CHECKS_CONTEXT.md`  
- Covers taxonomy, new checks, registry changes, config changes, UI changes, output schema updates, and validation.

3. Switched common-check targeting from `rf_level1` to explicit universe lists  
- Registry logic updated:
  - `src/dq_checks/registry.py`
  - Now uses `apply_to_universes` as primary selector.
  - `apply_to_rf_level1` remains only as backward-compatible fallback.
- Config updated:
  - `configs/model_catalog.yaml`
  - All common checks now use:
    `apply_to_universes: [CP_RATE_CORP, CP_RATE_CDX, CP_RATE_RMBS, EQ_VOL_USD, IR_RATE_USD]`

Validation run:
- YAML parses successfully.
- Registry/spec loading confirms expected behavior:
  - `EQ_PRICE_US` gets only its own checks.
  - `CP_RATE_CORP`, `IR_RATE_USD`, `EQ_VOL_USD` get common checks as configured.