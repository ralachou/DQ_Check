# Session Context Handoff

Date: 2026-03-02
Project: Advanced DQ Checks on RF
Repository: DQ_CheckOpenAI

## Scope
This file captures key implementation context and operational notes from the current build-out, so work can continue on another machine/session without losing continuity.

## Architecture Summary
Layered system implemented in `src/`:
- Layer 1 Data Access: repository abstraction and parquet/sqlite/rest backends.
- Layer 2 Universe Layer: config-driven universe membership and hierarchy normalization.
- Layer 3 DQ Model Library: local statistical checks + adapters (PyOD/ADTK/Merlion) + ensemble.
- Layer 4 Config Layer: YAML-driven model catalog and activation.
- Layer 5 Run Engine: orchestrates membership, loading, checks, normalization, persistence.
- Layer 6 False Alarm/Triage: peer consistency, regime/event awareness, supervised option.
- Layer 7 UI: Dash dashboards (`ui.app`, `ui.app_v2`) for summary/drilldown/comparison/peer analysis.

## Key Data Contracts
Time-series canonical schema:
- `business_date`, `risk_factor_id`, `date`, `value`

DQ result core schema includes:
- `run_id`, `universe_name`, `business_date`, `risk_factor_id`, `date`, `check_id`,
- `backend`, `family`, `raw_score`, `norm_score`, `threshold`, `flag`, `severity`,
- `reason_code`, `explain`, `artifacts_json`

## Major Enhancements Implemented
1. Business-date-first processing
- Data loading and storage are business-date partition aware.
- `ui.app` and `ui.app_v2` support load-time business-date filtering.

2. UI v2 filter support
- Added UI business-date selector in `app_v2`.
- Store/filter state includes `business_date`.
- Compare/peer/drilldown paths apply business-date filtering.

3. Large demo generation and scaling controls
- Full hierarchy demo runner supports per-asset-class cap:
  - `--max-factors-per-asset-class`
- Dedicated `demo_ui_full` raw/processed/artifact roots.

4. Integration pathway for external manual dataset
- Added integration demo script:
  - `src/pipeline/run_demo_integrate_with_Mar.py`
- Added validation notebook:
  - `tests/validate_integration_withMar.ipynb`
- Supports staging manual `.csv/.xlsx` into existing raw table layout.

5. Multi-universe run support in integration demo
- Added:
  - `--universe-names`
  - `--run-all-compatible-universes`
- Engine can run all compatible universes inferred from staged metadata.

6. Layer 6 supervised triage improvements
- Added XGBoost/LightGBM/RF/LogReg candidate pipeline in false-alarm reducer.
- Added supervised probability calibration (`sigmoid`/`isotonic`/`none`).
- Added CLI controls:
  - `--supervised-candidates`
  - `--calibration-method`

## Important Runtime Notes
1. Module import resolution
- On new machines, missing `ui` module usually means `src` not on `PYTHONPATH` or package not installed.
- Recommended setup:
  - `pip install -r requirements.txt`
  - `pip install -e .`

2. Version consistency
- UI compare-tab issues were observed with outdated pandas.
- Ensure environment matches repo constraints (`requirements.txt` / `pyproject.toml`).

3. Business-date behavior
- Use `--business-date` explicitly when launching UI to avoid loading unintended partitions.

## High-Value Commands
1. Launch app_v2 with explicit paths and business date
```cmd
python -m ui.app_v2 --results-path data/demo_ui_full/processed/dq_results --raw-path data/demo_ui_full/raw/timeseries_raw --membership-path data/demo_ui_full/processed/universe_membership --config-path data/demo_ui_full/processed/ui_full_demo/model_catalog_ui_full.yaml --business-date 2026-01-31 --port 8060
```

2. Debug Dash callback behavior
```cmd
python -m pipeline.run_demo_layer7_dash_ui --app-version v2 --results-path data/demo_ui_full/processed/dq_results --raw-path data/demo_ui_full/raw/timeseries_raw --membership-path data/demo_ui_full/processed/universe_membership --run-callback refresh_compare --sample-args --no-print-layout-tree --no-print-callbacks --no-validate-callback-ids
```

3. Integrate manual dataset and run all compatible universes
```cmd
python -m pipeline.run_demo_integrate_with_Mar --source-path data/incoming/manual_dataset.xlsx --raw-path data/raw_manual --processed-path data/processed_manual --config-path configs/model_catalog.yaml --business-date 2026-01-31 --run-engine --run-all-compatible-universes
```

4. Layer 6 supervised demo forcing XGBoost + calibration
```cmd
python -m pipeline.run_demo_layer6_false_alarm --universe-name CP_RATE_CORP --start-date 2024-01-01 --end-date 2024-12-31 --business-date 2024-12-31 --with-supervised --generate-demo-labels --label-rate 0.2 --supervised-candidates xgboost --calibration-method sigmoid --output-format parquet
```

## Rehydration Prompt (for new AI session)
Use this to rebuild context in a fresh session:
- Read AGENTS.md.
- Read README.md and numbered docs under `docs/`.
- Read:
  - `src/common/schemas.py`
  - `src/data_access/base.py`
  - `src/data_access/parquet_repository.py`
  - `src/engine/run_engine.py`
  - `src/ui/app.py`
  - `src/ui/app_v2.py`
  - `src/pipeline/run_demo_*.py` (all key demo runners)
  - `src/pipeline/run_demo_integrate_with_Mar.py`
  - `tests/validate_integration_withMar.ipynb`
- Then summarize architecture, implemented enhancements, run commands, open risks, and ask for next step.

## Current Open Risks/Watch Items
- Optional dependency availability differs by machine (pyod/adtk/merlion/xgboost/lightgbm).
- Dash/AG Grid/pandas version drift can impact callback behavior.
- For manual integration, ensure source columns map correctly and date/value coercions are validated before engine run.

