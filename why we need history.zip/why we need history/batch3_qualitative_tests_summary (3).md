# Batch 3 — The Six Qualitative Data Standards

**Sources:** US NPR §\_\_.214(b)(2)(i)–(vi) (operative text) and preamble; Basel MAR31 Principles 1–7; cross-references to §\_\_.215(b)(5) (stress period) and MAR33.5(2)(b) (reduced set / 75%).

**Citation architecture — confirmed.** Test (v) cross-references "§\_\_.215(b)(5)" for the stress period. The qualitative data standards sit in **§\_\_.214(b)(2)**; §\_\_.215 carries the stress period specification and RFET. Internal test numbering #1–#6 maps one-to-one onto (i)–(vi).

---

## 1. The framing question

Basel 2.5 asked: *do we have a time series?*
FRTB IMA asks: **is the data used for this risk factor suitable for the ES measure?**

Two consequences.

**Scope.** These are standards for the data used to calculate the ES-based measure. They are not conditioned on RFET outcome. A risk factor that passes RFET remains subject to all six. *"It passed RFET" is not responsive to any of them.*

**Sufficiency is not self-certified.** The data must satisfy **each applicable standard** — and the rule separately empowers the supervisor to deem data unsuitable **even where the listed requirements are met**. Compliance with (i)–(vi) is necessary, not conclusive. This is the seventh, meta layer.

> **RFET pass ≠ ES data-quality pass.**
> **History exists ≠ history is appropriate.**

---

## 2. The six standards and their Basel counterparts

| # | US §\_\_.214(b)(2) | Basel MAR31 | Core question |
|---|---|---|---|
| 1 | (i) idiosyncratic and systematic risk | Principle 2 | Are all material components of the risk represented? |
| 2 | (ii) volatility and correlation | Principle 3 | Does the history preserve the actual behaviour of the risk factor? |
| 3 | (iii) observed/quoted prices | Principle 4 | Is the history grounded in market observations? |
| 4 | (iv) frequency, backfill, gap-fill | Principle 5 | Is the series maintained and documented appropriately? |
| 5 | (v) stress-period prices | Principle 6 | Does the history actually represent the stress period? |
| 6 | (vi) proxies | Principle 7 | If substituted, is the substitute empirically appropriate? |

Basel adds **Principle 1** (combinations, interpolation, compression, derived parameters, extrapolation), which has no direct US counterpart in this list and matters for SABR parameters, par→forward transformations, PCA and interpolation. See §9.

---

## 3. Divergences between US and Basel text

A deck that attributes Basel language to the NPR will be corrected.

| Point | US NPR | Basel MAR31 |
|---|---|---|
| **Update frequency** | minimum **weekly** | minimum **monthly**, preferably daily; regressions no less than every two weeks; pricing-model calibration ideally as frequent as front office |
| **Proxy criteria** | region, **credit spread**, quality, instrument type | region, quality, instrument type |
| **Reconciliation** | (iii) states the standard | Principle 4 requires periodic reconciliation of risk-model prices against real price observations and front/back office prices, plus documentation of derivation |
| **Uncaptured components** | (i) states the standard | Principle 2: apply an **NMRF charge for those aspects** not adequately captured |
| **Failure of the stress-period standard** | (v) states the requirement; **no omission mechanic** | Principle 6: omit the risk factor from the stressed period and meet the 75% reduced-set requirement |

**The US floor on update frequency is stricter than Basel's.** Worth stating, because it counters a general impression that the NPR is the lighter text.

---

## 4. Test #5 / Principle 6 — the cornerstone

**US operative text (v):**

> "The data to determine the liquidity horizon-adjusted ES-based measure must be reflective of market prices observed or quoted in the period of stress specified in § \_\_.215(b)(5). The data **should be sourced directly from the historical period whenever possible**. The [BANKING ORGANIZATION] must **empirically justify** any instances where the market prices used in the period of stress are different from the market prices actually observed during that period. In cases where market risk covered positions that are currently traded **did not exist** during a period of significant financial stress, the [BANKING ORGANIZATION] must demonstrate that the prices used **match changes in prices or spreads of similar instruments** during the stress period."

### The hierarchy the text establishes

```
Actual stress-period observations available?
        │
       YES ──> use them  ("sourced directly ... whenever possible")
        │
        NO
        ▼
Use alternative / reconstructed / similar-instrument data
        │
        ▼
EMPIRICALLY JUSTIFY the deviation
        │
        ▼
If the instrument did not exist in the stress period:
demonstrate the prices used MATCH changes in prices or
spreads of similar instruments that DID trade then
```

What the text does **not** establish:

```
No target history  ──>  use whatever history we hold  ──>  done
```

The preference for direct sourcing is explicit, and the burden of demonstrating that direct sourcing was not possible sits with the bank.

### Correction: do not transplant Basel's omission mechanic into the US direct approach

Basel Principle 6's second paragraph provides that where use of current market data cannot be sufficiently justified, the bank must **omit the risk factor for the stressed period** and still meet MAR33.5(2)(b) — the reduced set explaining **75%** of the fully specified ES model. It further presumes that idiosyncratic components of name-specific factors unavailable in the stress period are **not** in the reduced set, and requires exposures outside the reduced set to be **mapped to the most suitable risk factor** within it.

**That mechanic belongs to Basel's ES_R,S reduced-set architecture.** The US direct approach instead requires the **full set of risk factors** across the stress period, and permits **proxies** to fill missing risk-factor data subject to the (vi) standards.

**Do not state:** "the US direct approach permits missing risk factors to be omitted." It does not.

**The correct — and stronger — reading:**

| Route | What it requires | Effect of unjustifiable stress-period data |
|---|---|---|
| **US direct approach** | Full set of risk factors across the stress period; proxies permitted subject to (vi)(A)–(C) | **No omission route exists.** Either the data are there, or a proxy satisfying (vi) is demonstrated. There is no third option. |
| **US indirect / reduced set** | Reduced set must explain **75%** of the fully specified ES model | Portfolio-level statistical threshold absorbs the gap — but it is a hard numeric test, and the only numeric threshold anywhere in this framework. |

Under the direct approach the absence of data is not self-resolving. It converts directly into a proxy that must be evidenced under (vi).

**Use Basel Principle 6 for regulatory intent and interpretation. Do not present its omission mechanic as US law.**

---

## 5. Test #2 / Principle 3 — behaviour preservation

Principle 3 is unusually explicit and names proxies by mechanism:

> "Banks must ensure that they do not understate the volatility of an asset (eg by using inappropriate averaging of data **or proxies**)."

> "banks must ensure that they accurately reflect the correlation of asset prices, rates across yield curves **and/or volatilities within volatility surfaces**."

> "Different data sources can provide **dramatically different** volatility and correlation estimates."

> "any **transformations** must not understate the volatility arising from risk factors and must accurately reflect the correlations."

Three testable conditions: data representative of real price observations; volatility **not understated** by the choice of data; correlations a **reasonable approximation** of correlations among real price observations.

*Transformations* covers scaling, averaging, interpolation and proxy mapping. Each is subject to the non-understatement condition.

### Application

Where several risk factors share a single driver with no scaling, the stress-period shock is identical across them:

```
USD Swaption shock   = +20%
EUR Swaption         = +20%
GBP Swaption         = +20%
Inflation Vol        = +20%
Bond Future Vol      = +20%
```

Volatility level and correlation both fail. Introducing scale factors fixes the first and not the second: under positive deterministic scaling, pairwise correlation among all derived factors is **identically 1**, for any scale factors. Correlation structure cannot be created from one driver — it is excluded by the construction, not merely unestimated.

*Precision:* correlation is exactly 1 only for a positive scalar transform of the same series. Where different tenor slices or added residuals are involved, correlation is below 1 but far above observed levels. Describe the construction as it actually is.

**Correlation within volatility surfaces is named explicitly in the text.** Scope is not an inference.

---

## 6. Test #3 / Principle 4 — lineage, not observability

**The rule:** data must reflect prices observed or quoted in the market. Where not derived from real price observations, the bank must demonstrate the data are **reasonably representative** of real price observations.

**Basel adds the mechanism:** risk-model prices must be **periodically reconciled** against real price observations and against front and back office prices, and banks must **document their approaches to deriving risk factors from market prices**.

### The distinction that matters for a volatility stack

The rule does **not** require every risk factor to be directly observable. Principle 1 expressly permits parameters derived from observations of modellable risk factors, including stochastic implied-volatility parameters.

> **SABR parameters are not inherently a problem.**

The problem is lineage. Where the stored history is:

```
STORED:      SABR alpha, rho, nu  (calibrated output)

NOT STORED:  option quotes, strikes, expiries,
             underlying forwards, observed implied vols,
             market source
```

then the parameter series cannot be reconciled against real price observations for the stress period, because the observations it was derived from no longer exist. Principle 4's reconciliation requirement has nothing to reconcile against.

**The failure is not that the risk factor is derived. It is that the derivation cannot be evidenced.**

Possible remediation routes: preserved calibration inputs elsewhere; vendor archives; Totem; independent observed option data; reconstruction and recalibration. Where none exist, validation becomes materially harder and the disposition moves toward Build or Accept.

---

## 7. Test #1 / Principle 2 — component-level failure

> "If the data used in the model do not reflect either idiosyncratic or general market risk, the bank must apply an **NMRF charge for those aspects** that are not adequately captured in its model."

The charge attaches to the **uncaptured aspect**, not necessarily the whole risk factor. A proxy capturing the systematic component but not the idiosyncratic one is partially charged rather than wholly disqualified.

Where several distinct risk factors are compressed into one common source, a generic proxy may capture systematic rate-volatility risk while stripping out currency basis, market-specific volatility, instrument-specific volatility and idiosyncratic behaviour.

**The question:** where is the basis behaviour — EUR vs USD, inflation vs nominal, bond-future option vs OTC swaption — and if it is not in the history, where is it capitalised?

---

## 8. Test #4 / Principle 5 — governance, not regeneration

Requires minimum weekly updating (US), regular re-estimation of regression parameters, and clear policies for backfilling, gap-filling and updating data sources.

This standard does **not** support a regeneration argument, and the deck is more credible for saying so. Its relevance to legacy history is **lineage and control**:

```
2007 ────── 2012 ────── 2016 ────── 2019 ────── 2026
      gaps        proxy change      source change
```

The question is not *can we fill the gaps* but: what was the gap-filling method, what source was used, when did it change, and can we show those transformations preserved the required behaviour?

**Disposition: Prove.** Documentation and lineage evidence, not rebuild.

---

## 9. Principle 1 — the strongest argument for retention, and its limits

An informed counterparty will use this, so it belongs in the deck.

Principle 1 permits: **combinations** of modellable risk factors; **interpolation**; dimensional **compression** (e.g. principal components); **derived model parameters**, including stochastic implied volatility; and limited **extrapolation**. Risk factors derived through **multifactor beta models** whose inputs and calibrations rest solely on modellable risk factors can be classified as modellable.

> **The regulator is not against transformations.**

The correct position is therefore **not** "historical data must look like today's raw market data." It is:

> **Transformation, derivation, proxying and reconstruction are all permitted. The resulting risk-factor history must still satisfy the data-quality standards.**

### The textual limits

| Constraint | Source |
|---|---|
| Betas must be **empirically based and not determined by judgment**; judgment-set coefficients "generally should be considered as NMRFs" | Principle 7(a) |
| Multifactor model must have **significant explanatory power** and **provide an assessment of the uncertainty** due to the proxy | Principle 7(a) |
| Remaining idiosyncratic risk must be **demonstrably uncorrelated** across issuers | Principle 7(a) |
| A factor derived from modellable factors mapped to **distinct buckets** of a curve or surface is modellable **only if it also passes RFET** | Principle 1 |
| Interpolation must be **consistent with PLA mappings**, not based on broader bucketing | Principle 1(a) |
| Extrapolation requires **supervisory approval**, must not rely solely on the closest modellable factor, and must be reflected in RTPL | Principle 1(b) |

**The dialectic:** Principle 1 says a derived factor can be modellable. Principle 7(a) says the derivation must be an empirically calibrated model, not an assignment. The distance between *a calibrated multifactor model with measured explanatory power and quantified uncertainty* and *a one-to-many mapping with no scaling* is the distance between compliance and NMRF.

---

## 10. Test #6 / Principle 7 — proxy appropriateness in context

Standards (A) track record, (B) similar volatility level and correlations, (C) appropriate region, credit spread, quality and instrument type.

**Tests #5 and #6 are distinct hurdles and are strongest together.**

| Today's risk factor | Legacy stress history | |
|---|---|---|
| EUR Swaption 5Y×10Y | USD Swaption 5Y×10Y | |
| **Test #5 asks** | Does the USD series represent how a similar EUR instrument changed during the stress period? | |
| **Test #6 asks** | Is USD an appropriate proxy for EUR on volatility, correlation, region and instrument type? | |

Passing one does not answer the other.

**Principle 7(b) — the PLA consequence.** Where risk factors are represented by proxy data in the current-period ES model, **the proxy representation — not the risk factor itself — must be used in RTPL**, unless the bank identifies the basis between proxy and actual and properly capitalises it (in the ES model if modellable, or as an NMRF). RTPL is then built on either the proxy plus basis, or the actual factor.

RTPL uses the proxy; HPL reflects actual pricing. The proxy-to-target basis surfaces directly as RTPL/HPL divergence — the quantity the KS statistic measures. The escape requires measuring the basis, which requires target-factor observations.

**Why this matters for audience:** SES is a risk-owned capital number. PLA outcomes are **desk eligibility** — amber attracts an add-on, red moves the desk to standardised. This is the version of the argument that is legible to front office.

*Caveat: Principle 7(b) is Basel text. Confirm US RTPL treatment in §\_\_.213 before presenting it as a US requirement.*

---

## 11. The funnel

```
                    IMA HISTORICAL DATA
                            │
                            ▼
            ┌───────────────────────────────┐
            │ #1  Capture actual risks      │
            │     systematic + idiosyncratic│
            └───────────────┬───────────────┘
                            ▼
            ┌───────────────────────────────┐
            │ #2  Preserve behaviour        │
            │     volatility + correlation  │
            └───────────────┬───────────────┘
                            ▼
            ┌───────────────────────────────┐
            │ #3  Ground in market prices   │
            │     (lineage / reconciliation)│
            └───────────────┬───────────────┘
                            ▼
            ┌───────────────────────────────┐
            │ #4  Maintain / document       │
            └───────────────┬───────────────┘
                            ▼
       ╔════════════════════════════════════════╗
       ║ #5  REPRESENT THE STRESS PERIOD        ║
       ║     Prefer actual historical data      ║
       ║     Alternatives require evidence      ║
       ╚═══════════════════╤════════════════════╝
                           ▼
            ┌───────────────────────────────┐
            │ #6  If proxy → prove the      │
            │     proxy is appropriate      │
            └───────────────┬───────────────┘
                            ▼
              Supervisory assessment may still
              deem the data unsuitable
```

---

## 12. Consequence map

| Standard failed | Stated consequence | Source |
|---|---|---|
| #1 idiosyncratic / systematic | NMRF charge for the uncaptured **aspects** | Principle 2 |
| #2 volatility / correlation | No separate consequence stated; feeds capital understatement and supervisory challenge | Principle 3 |
| #3 observability / lineage | Data not demonstrably representative; falls back to (vi) or supervisory challenge | Principle 4 |
| #4 frequency / gap-fill | Governance finding; control and documentation deficiency | Principle 5 |
| #5 stress period (US direct) | **No omission route.** Requires a proxy satisfying (vi), or the data | §\_\_.214(b)(2)(v) |
| #5 stress period (Basel ES_R,S) | Omit from stressed period; reduced set must still explain 75%; exposures remapped | Principle 6 |
| #6 proxy — appropriateness | Proxy not accepted | (vi)(A)–(C) |
| #6 proxy — judgment coefficients | Generally treated as NMRF | Principle 7(a) |
| #6 proxy — basis not capitalised | Proxy must be used in RTPL; basis surfaces as RTPL/HPL divergence | Principle 7(b) |
| **Any / all met** | Supervisor may still deem data unsuitable | §\_\_.214(b)(2) |

Failure does not carry one price. It carries several, landing in capital, model architecture, desk eligibility and supervisory standing.

---

## 13. Disposition framework

For each risk-factor family, six questions:

| Question | Existing history acceptable if… | Remediation trigger |
|---|---|---|
| 1. Risk capture | Material systematic and idiosyncratic components remain represented | Material basis or idiosyncratic risk has disappeared |
| 2. Volatility / correlation | Transformations preserve realistic volatility and correlation | Proxy or compression distorts them |
| 3. Market observability | History can be traced or validated against market observations | Relation to market prices cannot be substantiated |
| 4. Data process | Gaps and source changes documented and controlled | Unexplained gaps or source changes |
| 5. Stress representativeness | History reflects the stress period | Today's risk factor represented by unrelated or current data |
| 6. Proxy appropriateness | Proxy relationship empirically demonstrable | Proxy exists but cannot be defended |

Mapped to the standing triage:

| Disposition | Condition | Work |
|---|---|---|
| **Prove** | History exists and is appropriate; or an existing proxy can be demonstrated | Evidence, validation, documentation. No rebuild. |
| **Remediate** | History exists but was built incorrectly, at inadequate granularity, or needs empirical calibration | Recalibrate betas/scaling; rebuild the risk-factor representation from surviving market inputs; fix gap-filling; add explicit basis. |
| **Build** | Underlying observations do not exist in retrievable form | New historical sourcing, or new capture process going forward. |
| **Accept** | No suitable history and no defensible proxy | NMRF classification and SES; or standardised treatment. A legitimate outcome, chosen deliberately rather than by default. |

**Scope is set by the proxies and representations retained, not by the size of the risk-factor inventory.**

---

## 14. Framing for stakeholders

Avoid: *"Why aren't we regenerating history?"* — that asks people to defend a past implementation decision.

Use:

> **For each material IMA risk factor, can the existing historical representation demonstrate compliance with the qualitative data requirements — particularly stress-period representativeness, volatility and correlation preservation, and proxy appropriateness?**
>
> If yes → retain it.
> If partially → remediate it.
> If no → reconstruct, or establish an alternative defensible treatment.

Anchored in the requirements rather than in anyone's judgment, this is difficult to characterise as an attack.

### Airtime priority, if all six cannot be covered

1. **#5 — stress-period representativeness.** *Does our GFC history represent what happened in the GFC?*
2. **#2 — volatility and correlation.** *Does our construction preserve how the risk factor behaves?*
3. **#6 — proxy appropriateness.** *If we lack the target history, can we defend the substitute?*
4. **#3 — lineage.** *What actual market observations demonstrate any of the above?*

Together #2, #3, #5 and #6 are the case for **assessing** the existing history rather than grandfathering it.

---

## 15. Conclusions

1. The six standards are **ES data standards**, not RFET criteria. They apply to modellable risk factors. RFET pass does not discharge them, and the supervisor may deem data unsuitable even where all six are met.
2. Test #2 names **proxies** as a volatility-understatement mechanism and names **correlation within volatility surfaces** as in scope. Both are explicit.
3. Test #3 does not require observability — it requires **lineage**. Derived parameters are permitted; underivable ones are not.
4. Under the **US direct approach there is no omission route** for unjustifiable stress-period data. The choice is data or a demonstrated proxy.
5. Proxying carries an **RTPL consequence**; both available routes require target-factor observations.
6. Principle 1 permits derived risk factors including beta models; Principle 7(a) requires the coefficients to be empirically based. **Calibrated model versus assignment is where this is decided.**

---

*Open items: (1) US treatment where a proxy under (vi) cannot be demonstrated under the direct approach — locate the fallback; (2) confirm US RTPL treatment of proxied factors in §\_\_.213 against Principle 7(b); (3) MAR31 paragraph numbers for Principles 1–7; (4) exact wording and location of the supervisory-unsuitability provision. Note: a single Federal Register URL is a source, not clause-level verification.*
