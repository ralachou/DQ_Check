# Batch 3 — The Six Qualitative Data Standards

**Sources:** US NPR §\_\_.214(b)(2)(i)–(vi) (operative text); Basel MAR31 Principles 1–7; cross-reference to §\_\_.215(b)(5) (stress period) and MAR33.5(2)(b) (reduced set / 75%).

**Citation architecture — now confirmed.** Test (v) cross-references "§\_\_.215(b)(5)" for the stress period. The qualitative data standards therefore sit in **§\_\_.214(b)(2)**, and §\_\_.215 carries the stress period specification and RFET. Internal test numbering #1–#6 maps one-to-one onto (i)–(vi).

**Scope consequence.** These are standards for *the data used to calculate the ES-based measure*. They are not conditioned on RFET outcome. A risk factor that passes RFET is still subject to all six. "It passed RFET" is not responsive to any of them.

---

## 1. The six standards at a glance

| # | US §\_\_.214(b)(2) | Basel MAR31 | Requires |
|---|---|---|---|
| 1 | (i) idiosyncratic and systematic risk | Principle 2 | Data must let the model pick up both components |
| 2 | (ii) volatility and correlation | Principle 3 | Data must let the model reflect volatility **and** correlation of risk factors |
| 3 | (iii) reflective of observed/quoted prices | Principle 4 | Where not from real price observations, demonstrate reasonable representativeness |
| 4 | (iv) update frequency | Principle 5 | Minimum **weekly** (US); regressions re-estimated regularly; documented backfill/gap-fill policies |
| 5 | (v) stress period | Principle 6 | Data reflective of prices observed/quoted **in the stress period**; sourced directly where possible; deviations empirically justified |
| 6 | (vi) proxies | Principle 7 | Track record; similar volatility and correlation; appropriate to region, credit spread, quality, instrument type |

---

## 2. Where the US and Basel texts diverge

These differences matter because a deck that attributes Basel language to the NPR will be corrected.

| Point | US NPR | Basel MAR31 | Note |
|---|---|---|---|
| **Update frequency** | "at a minimum on a **weekly** basis" | "at a minimum on a **monthly** basis, but preferably daily"; regressions "no less frequently than every two weeks" | **The US is stricter on the floor.** Basel is more specific on regressions and on calibration frequency relative to front-office pricing models. |
| **Proxy criteria** | region, **credit spread**, quality, type of instrument | region, quality, type of instrument | US adds credit spread explicitly. |
| **Reconciliation mechanism** | (iii) states the standard only | Principle 4 requires periodic reconciliation of risk model prices against front and back office prices, and documentation of how risk factors are derived from market prices | Basel supplies the *how*. Useful as expected practice, not as US obligation. |
| **Consequence of failing the stress-period test** | (v) states the requirement; **no stated consequence** | Principle 6, second paragraph: omit the risk factor for the stressed period and meet the MAR33.5(2)(b) 75% reduced-set requirement | **Flagged for verification.** The omission mechanic must be located in the US reduced-set / direct-indirect provisions before being asserted as a US consequence. |
| **Uncaptured risk components** | (i) states the standard only | Principle 2: "the bank **must apply an NMRF charge for those aspects** that are not adequately captured" | Basel provides component-level NMRF treatment — the *aspect*, not necessarily the whole factor. |

---

## 3. Test #2 / Principle 3 — the most directly applicable to a volatility stack

Principle 3 is unusually explicit, and names proxies by mechanism:

> "Banks must ensure that they do not understate the volatility of an asset (eg by using inappropriate averaging of data **or proxies**)."

> "banks must ensure that they accurately reflect the correlation of asset prices, rates across yield curves **and/or volatilities within volatility surfaces**."

> "Different data sources can provide **dramatically different** volatility and correlation estimates."

> "any **transformations** must not understate the volatility arising from risk factors and must accurately reflect the correlations arising from risk factors."

Three obligations follow, each testable:

1. **(i)** data representative of real price observations;
2. **(ii)** price volatility **not understated** by the choice of data;
3. **(iii)** correlations are **reasonable approximations** of correlations among real price observations.

The word **transformations** is important: scaling, averaging, interpolation and proxy mapping are all transformations, and each is subject to the non-understatement condition.

**Application.** Where N distinct volatility risk factors are derived from a single series by positive deterministic scaling, pairwise correlation among them is identically 1 for any scale factors. Condition (iii) cannot be satisfied — correlations are not approximations of observed correlations, they are an artefact of the construction. Where no scaling is applied at all, condition (ii) fails as well, and volatility understatement is the easier of the two to evidence.

**Correlation within volatility surfaces is named explicitly.** This is not an inference about scope.

---

## 4. Test #5 / Principle 6 — the requirement and the real consequence

**US operative text (v):**

> "The data to determine the liquidity horizon-adjusted ES-based measure must be reflective of market prices observed or quoted in the period of stress specified in § \_\_.215(b)(5). The data **should be sourced directly from the historical period whenever possible**. The [BANKING ORGANIZATION] must **empirically justify** any instances where the market prices used in the period of stress are different from the market prices actually observed during that period. In cases where market risk covered positions that are currently traded **did not exist** during a period of significant financial stress, the [BANKING ORGANIZATION] must demonstrate that the prices used **match changes in prices or spreads of similar instruments** during the stress period."

Four distinct obligations: reflective of stress-period prices; sourced directly where possible; deviations empirically justified; and, for instruments that did not exist, matched to similar instruments that did trade.

**The consequence chain — Basel Principle 6, second paragraph:**

> "In cases where banks do not sufficiently justify the use of current market data for products whose characteristics have changed since the stress period, the bank must **omit the risk factor for the stressed period** and meet the requirement of MAR33.5(2)(b) that the **reduced set of risk factors explain 75%** of the fully specified ES model."

> "if **name-specific** risk factors are used to calculate the ES in the actual period and these names were not available in the stressed period, there is a **presumption that the idiosyncratic part of these risk factors are not in the reduced set**."

> "Exposures for risk factors that are included in the current set but not in the reduced set need to be **mapped to the most suitable risk factor of the reduced set**."

### Why this matters more than an NMRF charge

Failing the stress-period standard does not produce a tidy factor-level add-on. It produces **exclusion from the stressed set**, and that lands on the ES architecture:

| Route | Requirement | Effect of unjustified stress-period data |
|---|---|---|
| **Direct approach** | ES computed on the **full** current risk-factor set across the stress period | The full set is precisely what cannot be evidenced. The route is unavailable for the affected factors. |
| **Indirect approach** | Reduced set must explain **75%** of the fully specified ES model | Affected factors are omitted from the reduced set. Exposures must be mapped to the most suitable remaining factor. If a material block of factors drops out, the 75% test comes under pressure. |

The circularity is the point: the direct approach demands the missing data; the indirect approach absorbs the loss into a portfolio-level statistical test with a hard threshold. Retention does not convert cleanly into an SES number — it converts into risk to the ES model's structure and to the approach election itself.

**This is a live input to the direct-vs-indirect decision, not a downstream consequence of it.**

---

## 5. Test #6 / Principle 7 — proxying carries a PLA consequence

Beyond the three appropriateness standards already indexed, Principle 7(b) attaches a **profit-and-loss attribution** consequence:

> "If risk factors are represented by proxy data in the current period ES model, **the proxy data representation of the risk factor – not the risk factor itself – must be used in the RTPL** unless the bank has identified the basis between the proxy and the actual risk factor and properly capitalised the basis either by including the basis in the ES model (if the risk factor is modellable) or capturing the basis as a NMRF."

Where the basis is properly capitalised, the bank may then include in RTPL either the proxy plus the basis, or the actual risk factor.

### The mechanism

RTPL is built from the risk model's representation. HPL is built from actual pricing. If a risk factor is proxied in the ES model, RTPL must use the proxy — while HPL continues to reflect the target instrument's real behaviour. The proxy-to-target basis therefore appears directly as RTPL/HPL divergence, which is what the KS statistic measures.

The escape route requires **identifying and capitalising the basis** — which requires measuring the basis — which requires observations of the target risk factor. The same evidentiary requirement recurs.

### Why this changes the audience

SES is a capital number owned by risk. A PLA failure is a **desk eligibility** outcome: an amber desk attracts a PLA add-on, and a red desk moves to the standardised measure. That is a front-office P&L consequence, and it makes the proxy question relevant to stakeholders for whom an SES figure is abstract.

**Caveat:** Principle 7(b) is Basel text. Confirm the equivalent RTPL treatment in the US PLA provisions (§\_\_.213) before presenting it as a US requirement.

---

## 6. Test #1 / Principle 2 — component-level failure

> "If the data used in the model do not reflect either idiosyncratic or general market risk, the bank must apply an **NMRF charge for those aspects** that are not adequately captured in its model."

Two things follow. The charge attaches to the **uncaptured aspect**, not necessarily the entire risk factor — so a proxy that captures the systematic component but not the idiosyncratic one is not wholly disqualified, it is partially charged. And a construction in which many risk factors are derived from a single driver has, by design, no idiosyncratic component to capture.

---

## 7. The strongest argument for retention — Principle 1 — and its limit

Principle 1 is the most permissive text in this batch, and an informed counterparty will use it.

> "risk factors derived solely from a combination of modellable risk factors are generally modellable. For example, risk factors derived through **multifactor beta models** for which inputs and calibrations are based solely on modellable risk factors, can be classified as modellable and can be included within the ES model."

It further permits compression into orthogonal factors (e.g. principal components) and derivation of parameters not directly observable, such as stochastic implied volatility models.

**Read plainly: deriving risk factors from modellable ones — including by beta model — is expressly contemplated.** A proxy architecture built as a calibrated multifactor model is not prohibited. It is anticipated.

### The limits, all textual

| Constraint | Source | Effect |
|---|---|---|
| Betas must be **empirically based and must not be determined based on judgment**; judgment-set coefficients "generally should be considered as NMRFs" | Principle 7(a) | An unadjusted mapping carries an implicit coefficient of 1. If not empirically derived, it is judgment. |
| Multifactor model must have **significant explanatory power** and **provide an assessment of the uncertainty** due to the proxy | Principle 7(a) | Explanatory power must be measured; proxy uncertainty must be quantified. |
| Remaining idiosyncratic risk must be **demonstrably uncorrelated** across issuers | Principle 7(a) | Requires an idiosyncratic residual to exist and be tested. |
| Derived factor mapped to **distinct buckets** of a curve or surface is modellable **only if it also passes RFET** | Principle 1 | Derivation does not bypass RFET at bucket level. |
| Interpolation must be **consistent with PLA mappings** and not based on broader bucketing | Principle 1(a) | Risk-model and RTPL bucketing must agree. |
| Extrapolation requires **supervisory approval**, must not rely solely on the closest modellable factor, and must be reflected in RTPL | Principle 1(b) | Bounded and approval-gated. |

**The dialectic for the deck:** Principle 1 says a derived factor can be modellable. Principle 7(a) says the derivation must be an empirically calibrated model, not an assignment. The distance between a *calibrated multifactor model with measured explanatory power and quantified uncertainty* and a *one-to-many assignment with no scaling* is the distance between compliance and NMRF.

That framing concedes the retention camp's strongest point and then locates the actual question — which is where the argument should be.

---

## 8. Consequence map

| Standard failed | Stated consequence | Source |
|---|---|---|
| #1 idiosyncratic / systematic | NMRF charge for the uncaptured aspects | Principle 2 |
| #2 volatility / correlation | No separate consequence stated; feeds understatement of capital and supervisory challenge | Principle 3 |
| #5 stress period | Omit the risk factor from the stressed period; reduced set must still explain 75%; exposures remapped | Principle 6 |
| #6 proxy — appropriateness | Proxy not accepted; factor falls back to the underlying standard | (vi)(A)–(C) |
| #6 proxy — judgment coefficients | Generally treated as NMRF | Principle 7(a) |
| #6 proxy — basis not capitalised | Proxy must be used in RTPL, with the basis appearing as RTPL/HPL divergence | Principle 7(b) |

Failure does not have one price. It has four different ones, landing in capital, model architecture, and desk eligibility respectively.

---

## 9. Counter-readings to expect

| Argument | Response |
|---|---|
| "These factors passed RFET." | §\_\_.214(b)(2) governs the data used in the ES measure. It is not conditioned on RFET outcome. |
| "Principle 1 permits deriving risk factors from modellable ones." | Correct, and the strongest point available. It permits a *calibrated multifactor model*. Principle 7(a) requires empirically based betas and quantified proxy uncertainty. The question is whether the current construction is a model or an assignment. |
| "'Whenever possible' and 'if applicable' are proportionality hooks." | They are, and they are the basis of the moderate position. They condition effort, not the standard itself — and "should be sourced directly from the historical period whenever possible" places the burden on demonstrating that it was not possible. |
| "Basel Principle 6's omission consequence isn't in the US rule." | Correct as to the operative text of (v). The equivalent must be located in the US reduced-set provisions before being asserted. Flagged. |
| "Nothing here sets a numeric threshold for 'sufficiently similar'." | True — except in one place. The reduced set must explain **75%**. That threshold is numeric, and it is where retained gaps ultimately register. |

---

## 10. Conclusions from Batch 3

1. The six standards are **ES data standards**, not RFET criteria. They apply to modellable risk factors. Passing RFET does not discharge them.
2. Test #2 explicitly names **proxies** as a volatility-understatement mechanism and explicitly names **correlation within volatility surfaces** as in scope. Both are testable, not interpretive.
3. Failing test #5 routes to **omission from the stressed period**, not to SES — engaging the reduced set and the 75% requirement, and closing the direct approach for the affected factors.
4. Proxying carries an **RTPL consequence** under Principle 7(b): either the proxy is used in RTPL, or the basis is identified and capitalised. Both roads require target-factor observations.
5. Principle 1 permits derived risk factors, including beta models. Principle 7(a) requires those betas to be **empirically based**. The distinction between a calibrated model and an assignment is where this argument is actually decided.

### The question this batch produces

> Not: *is proxying permitted?* It is.
> But: **is our construction a calibrated model with measured explanatory power, quantified uncertainty and empirically derived coefficients — or an assignment?** And if the latter, which of the four consequences do we prefer to accept?

---

*Open items: (1) locate the US equivalent of Principle 6's omission-and-75% consequence within the §\_\_.214 reduced-set provisions; (2) confirm US RTPL treatment of proxied risk factors in §\_\_.213 against Principle 7(b); (3) confirm MAR31 paragraph numbers for Principles 1–7.*
