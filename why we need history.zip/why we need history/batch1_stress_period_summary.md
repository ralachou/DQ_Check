# Batch 1 — The Stress Period Governs the Capital

**Source:** US Basel III Endgame NPR (March 2026), §215 and its preamble.
Sections 1–2 are **preamble** (intent). Sections 3–4 draw on **operative rule text** — verbatim citations pending confirmation in Batch 2.

---

## 1. Where capital is measured

| Text as written | What it establishes |
|---|---|
| "IMCC and SES ... are intended to capture the potential losses arising from **changes in risk factors during a period of substantial market stress**" | Both capital legs are calibrated to stress-period risk-factor behaviour. No component of the models-based non-default charge is driven by current-period risk-factor moves. |
| "The IMCC is intended to capture the estimated losses ... arising from changes in **modellable and type A non-modellable risk factors** over a **twelve-month historical period of substantial market stress**" | Fixes the ES window as a single twelve-month stress period and places Type A NMRFs inside IMCC scope. |
| Rule text: identify a 12-month stress period; consider periods going back at least to 2007; calibrate the LH-adjusted ES to that period; **under the direct approach, use the full set of risk factors** | The obligation runs to the *full current* risk-factor set across the stress window — not to whichever factors happen to have history. |

**Precision:** the stress period is a *single twelve-month window* selected from an observation period beginning no later than 2007 — not the full run of history since 2007.

**Precision:** the current period is not irrelevant. It governs RFET eligibility, backtesting and PLA. It is simply not the input to the capital measure.

> **Current period → eligibility. Stress period → capital.**

---

## 2. Why data quality is priced, not merely documented

| Text as written | What it establishes |
|---|---|
| "risk factors for which there is **appropriate data for the twelve-month historical stress period** ... **and** a sufficient number of **real prices in the current period**" | Modellability is **conjunctive**. Two independent gates. Passing current-period RPO counts says nothing about stress-period fitness. |
| "**lower quality inputs** ... for example, limited data on the market prices **observed or quoted** during the twelve-month historical stress period" | Input quality is defined by reference to the stress period, on an evidentiary base wider than real price observations. |
| "these data limitations can increase the possibility that ... models **overstate the diversification benefits or understate price volatility** (and therefore, understate the magnitude of potential losses)" | The named harm mechanism: shared or thin stress-period history compresses basis between distinct risk factors and inflates apparent hedge offset. |
| "the conservative treatment of non-modellable risk factors that do not meet the proposed **data quality standards** would provide appropriate **incentives** ... to **enhance the quality of data inputs**" | The framework is designed to price data quality. Retaining a legacy data set is an anticipated choice carrying a defined capital consequence. |

**Inference (not text):** the framework does not grandfather historical inputs merely because they were previously used for regulatory capital. The last row does not require regeneration — but it removes the argument that prior acceptance settles the question.

---

## 3. The operative standard — Qualitative Test #5 (stress period)

The rule requires ES data to be **reflective of market prices observed or quoted in the period of stress**, and further:

- data should be **sourced directly from the historical period whenever possible**;
- **deviations from actual market prices** in that period require **empirical justification**;
- for instruments that **did not exist** in the stress period, the bank must demonstrate the prices used **behave consistently with similar instruments that actually traded** in that period.

This is where "appropriate data" acquires teeth. Availability of a series is not the standard; representativeness is.

> **History availability ≠ history suitability.**

**Read with Qualitative Test #2 (volatility and correlation):** the data must permit the model to reflect the volatility *and correlation* of the risk factors. A series that satisfies neither cannot be cured by length.

**Counter-reading to anticipate:** "whenever possible" is a proportionality hook. It is the basis of the moderate position below — and equally the strongest defence of retention. Expect it to be used both ways.

---

## 4. Proxies are permitted — and bounded — Qualitative Test #6

The NPR does not require raw historical data to exist for every current risk factor. The direct approach expressly permits proxies to fill missing risk-factor data, subject to the proxy requirements, which include:

- sufficient evidence that the proxy is appropriate;
- sufficiently similar **volatility and correlation characteristics**;
- appropriateness for the **region, spread, credit quality and instrument type** represented.

**The structural constraint:** demonstrating "sufficiently similar volatility and correlation characteristics" is a **two-sided comparison**. It requires evidence of how the *target* risk factor behaved in the stress period, not only the proxy. Where no stress-period evidence exists for the target, the demonstration cannot be performed — regardless of how well-observed the proxy is.

A proxy is therefore not a substitute for absent data. It is a claim about absent data that must itself be evidenced.

---

## 5. Scope — the moderate position

The position is **not** that everything from 2007 onward must be regenerated. The rule does not support that.

> Existing history is retained where it meets IMA requirements. Where direct history is unavailable or unrepresentative, reconstruction or proxying may be used — but the resulting representation must satisfy the applicable data-quality and proxy standards.

---

## 6. Conclusions from Batch 1

1. IMCC and SES are fundamentally calibrated to historical stress-period risk-factor behaviour.
2. The framework explicitly recognises that inadequate historical data distorts volatility, correlation, diversification and ultimately capital.
3. Stress-period inputs are subject to explicit data-quality standards. Existence of a historical time series alone is not sufficient.
4. Proxies and pragmatic reconstruction are permitted — but must be demonstrably appropriate, and that demonstration requires evidence on both sides.

### The central question

Today's IMA risk-factor set and the legacy Basel 2.5 historical infrastructure are not the same population, and were not built to answer the same question.

> **Not:** "Do we already have history?"
> **But:** "Does the history we have appropriately represent today's IMA risk factors during the required stress period?"

---

*Open items: verbatim citations for the direct-approach full-set requirement and for qualitative tests #2, #5 and #6 (Batch 2). Risk-factor population counts — current IMA set vs. legacy historical set — to be substituted for illustrative figures.*
