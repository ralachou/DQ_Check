# Batch 2 — Proxies Are Permitted, and Conditioned

**Sources:** US NPR (March 2026) §\_\_.214(b)(2) qualitative data standards and preamble; Basel MAR31 Principle 7; EBA RTS on assessment methodology §2.2.2; EBA Guidelines on use of data inputs in the IMA.
EBA is a defensible reference in the US context, not a binding one.

> **Citation note.** The proxy provision is cited here as **§\_\_.214(b)(2)(vi)** — i.e. within the ES **data standards**, not within §215 (RFET). If confirmed, the six qualitative tests bind the data used in the ES measure for **all** risk factors in the model, not only those being assessed for modellability. Passing RFET would not exempt a risk factor's history from these standards. *To be verified against verbatim clause numbering before use.*

---

## 1. The permission, and how it differs by regime

| Source | What it says about proxy usage |
|---|---|
| **US NPR** §\_\_.214(b)(2)(vi) | Proxies **may** be used if appropriateness and the specified characteristics are demonstrated to the supervisor's satisfaction |
| **Basel MAR31** Principle 7 | Proxy usage **must be limited**, and proxies must appropriately represent the target |
| **EBA** RTS §2.2.2 | Proxy used **only where data are insufficient**; must be conservative and track the actual position |

**Do not attribute the "only where data are insufficient" gate to the US rule.** That framing is European. The NPR conditions proxies; it does not restrict them to cases of unavailability. Every statement in the deck must survive challenge, and this is the easiest one to get wrong.

The regulatory equation:

> Proxy permitted **≠** any available history may be used as a proxy.
> Proxy permitted **+** empirical appropriateness demonstrated **=** potentially acceptable.

---

## 2. The three evidentiary burdens

Each burden is a **comparison**, and each requires evidence on **both** sides.

| # | Standard | Text |
|---|---|---|
| 1 | **Track record** | "sufficient evidence demonstrating the appropriateness of the proxies, such as an appropriate track record for their representation of a market risk covered position" |
| 2 | **Similar volatility and correlation** | "sufficiently similar characteristics to the transactions they represent in terms of volatility level and correlations" |
| 3 | **Fit to instrument** | "appropriate for the region, credit spread, quality and type of instrument they are intended to represent" |

A track record is observation of the proxy *against the actual*. Similar volatility and correlation is a two-sided measurement. Neither can be produced from the proxy alone.

**Consequence:** a proxy does not remove the data requirement. It relocates it — from *building the series* to *evidencing the substitute*.

---

## 3. The standard is conservatism, not similarity

| Source | Text |
|---|---|
| NPR preamble | "demonstrate, **empirically on an ongoing basis**, that the proxy data are a **conservative representation of the underlying risk under adverse market conditions**" |
| EBA, conditions for accuracy | "(a) supported by **convincing empirical evidence and objective data**; (b) accurately reflect changes in prices of similar instruments **during the identified period of financial stress**; (c) **do not underestimate risk**" |

- The demonstration is **empirical**, not reasoned. A memo explaining why a proxy is economically sensible does not satisfy it.
- The demonstration is **ongoing**, not a one-off approval artefact.
- The condition is measured **under adverse conditions / during the stress period**. Similarity established in benign conditions does not discharge it — the framework exists precisely because benign-period volatility and correlation relationships do not hold in stress.

**This is the pivot.** A proxy relationship fitted on recent data makes a claim about the stress period that recent data cannot evidence.

---

## 4. The tests work together, not in isolation

| Test | Requirement | What it forces the proxy to reproduce |
|---|---|---|
| **#1** Idiosyncratic vs systematic | Data must capture systematic **and idiosyncratic** risk where applicable | An idiosyncratic component distinct from the common driver |
| **#2** Volatility and correlation | ES data must allow the model to reflect **volatility and correlation** of the risk factors | Both moments — not volatility alone |
| **#5** Stress period | Data must be **reflective of market prices observed or quoted in the stress period**; sourced directly from that period whenever possible; departures require **empirical justification** | Behaviour *during* the stress window |
| **#6** Proxy | Appropriateness demonstrated: track record, similar volatility/correlation, fit to region and instrument type | The full appropriateness case |

The chain: **you may proxy missing history — but the proxy must still represent the actual risk factor's volatility and correlation, be appropriate for its region and type, and reproduce its stress-period behaviour.**

This is considerably stronger than arguing that proxying is restricted.

---

## 5. The structural limit: one driver cannot generate a correlation structure

Suppose several risk factors are derived from a single historical series *X* by positive deterministic scaling:

```
EUR = 1.2·X     GBP = 0.8·X     Inflation = 0.6·X
```

Then:

```
Corr(EUR, GBP) = Corr(EUR, Inflation) = Corr(GBP, Inflation) = 1
```

**identically, for any positive scale factors.**

A single driver can reproduce different **volatility levels**. It cannot reproduce independent **correlation structure, basis, or idiosyncratic risk**. Those properties are not underdetermined by the construction — they are excluded by it.

*Precision:* correlation is exactly 1 only where the mapping is a positive scalar transform of the same series. Where different tenor slices or added noise are involved, correlation falls below 1 but remains far above observed levels. State the claim to match the actual construction.

**Desk-level consequence:** basis between two factors sharing a driver is identically zero in the stress period. A book long one and short the other exhibits no P&L variance and attracts no capital for a risk it demonstrably runs.

**Regulatory consequence:** this is the mechanism the NPR names in the SES preamble — models that "overstate the diversification benefits or understate price volatility (and therefore, understate the magnitude of potential losses)." It engages Test #2 directly, Test #1 by implication, and EBA condition (c): the inputs must not underestimate risk.

**Where no scaling factor is applied at all**, volatility level fails alongside correlation — and volatility level is the easier of the two to demonstrate.

**The validation question this produces:**

> If multiple economically distinct risk factors are derived from one or two historical series, how are their distinct stress-period correlation, basis and idiosyncratic risks preserved?

---

## 6. Proxy strength is a gradient, not a verdict

The rule does not treat all proxies alike, and neither should the position. Illustrative gradation for a rates-volatility stack:

| Mapping | Shared | Differs | Assessment |
|---|---|---|---|
| EUR swaption → USD swaption | Instrument type, market convention | Currency, region, monetary regime, curve and volatility dynamics | **Potentially defensible — evidence required.** The explicit *region* criterion means this is defended, not assumed. |
| EUR cap/floor → USD cap/floor | Instrument type, closer structural match | Region, currency, volatility behaviour | **Potentially defensible.** A demonstrated stable relationship with conservative stress representation supports it. |
| Inflation vol → USD swaption vol | Optionality only | Region **and** underlying risk type — inflation expectations, real/nominal dynamics, distinct market structure | **Weak absent unusually compelling empirical evidence.** |

This gradation is what separates a proportionate position from an extreme one. The argument is not that proxies fail; it is that they must each be evidenced, and some will be harder to evidence than others.

**What is not the test:** "this is the only historical series we stored."

---

## 7. Where proxies are most exposed

**Judgment-set coefficients.** Basel Principle 7: "The coefficients (betas) of a multifactor model must be **empirically based and must not be determined based on judgment**. Instances where coefficients are set by judgment **generally should be considered as NMRFs**."

A proxy applied without a scaling or adjustment factor carries an implicit coefficient of 1. Unless empirically derived, that is a coefficient determined by judgment on the plain reading — with the stated consequence being NMRF treatment. Note the text says *generally should*, not *must*.

**Index and multifactor proxies.** Basel Principle 7 additionally requires such a model to capture the correlated risk of the assets represented; demonstrate that remaining idiosyncratic risk is **uncorrelated across different issuers**; have **significant explanatory power** for price movements; and **provide an assessment of the uncertainty in the final outcome due to the use of the proxy**. That last obligation — quantifying proxy uncertainty — is rarely discharged.

Basel's framing matters for the deck: **proxying is a model that must explain the target risk, not a data substitution technique.**

---

## 8. What a supervisor will actually do

EBA §2.2.2 sets out concrete assessment techniques:

1. verify the **correlation between proxy data and the data used to mark the risk factor** in the end-of-day value;
2. **compare the resulting volatilities** when proxy data are used and when proxy data are not used;
3. for NMRFs, assess the **rationale for proxying where at least 12 observations are available**.

Test 2 is the operative constraint. Running it requires the **un-proxied series**. Validating a proxy therefore requires the data the proxy was intended to substitute for — retention does not avoid the build, it defers it into validation.

Test 3 places a burden on proxying *in preference to* available observations: where data exist, choosing the proxy must itself be justified.

---

## 9. The question to put to stakeholders

For a historical architecture of the shape:

```
USD Swaption  ──┬──> USD Swaption Vol
                ├──> EUR / GBP / other non-USD Swaption Vol
                ├──> Inflation Vol
                ├──> Bond Future Option Vol
                └──> Listed Option Vol

USD Cap/Floor ──┬──> USD Cap/Floor Vol
                └──> Non-USD Cap/Floor Vol
```

The question is not *why was it designed this way* and not *why didn't we regenerate history*. It is:

> **For each arrow: what evidence supports sufficiently similar volatility and correlation characteristics, and appropriateness for region and instrument type, under §\_\_.214(b)(2)(vi)?**

Asked per arrow, this requires no accusation and is difficult to deflect.

---

## 10. Availability is not appropriateness

```
"We have USD history"
        │
        ▼
   Data is available
        │
        │  Does NOT establish:
        ├── Similar volatility level?
        ├── Similar correlation behaviour?
        ├── Appropriate region?
        ├── Appropriate instrument type?
        ├── Appropriate stress-period behaviour?
        └── Track record / empirical evidence?
```

Two questions are being run together. **Availability** — do we have historical data? Yes. **Representativeness** — does that history appropriately represent the target risk factor? Not established by the first.

The rule is addressed almost entirely to the second.

---

## 11. The proportionate conclusion — three dispositions

The rule does not require every risk factor to have directly observed stress-period history. It permits proxies and expects them. What it does not permit is an **unevidenced** proxy.

> **A proxy is not a replacement for data. It is a claim about data — and a claim that must be evidenced empirically, on an ongoing basis, under stress conditions.**

Mapping to the existing disposition triage:

| Disposition | Condition | Action |
|---|---|---|
| **Prove** | Target history exists and meets the data standards; or an existing proxy can be demonstrated on volatility, correlation, region, instrument type and stress representativeness | Evidence and document. No regeneration for its own sake. |
| **Remediate** | Target history is incomplete or the proxy relationship is demonstrable only in part | Reconstruct or source additional stress-period observations; improve the proxy model with empirically derived coefficients. |
| **Build** | The proxy cannot be empirically established — e.g. non-USD, inflation, listed and bond-future vols mapped to a generic USD series with no adjustment | New data capture or model change; otherwise accept NMRF classification and the SES consequence. |

**Scope is therefore set by the proxies retained, not by the size of the risk-factor inventory.** Each proxy that can be evidenced reduces the build. Each that cannot is a candidate for NMRF treatment and SES.

---

## 12. Counter-readings to expect

| Argument | Response |
|---|---|
| "Proxies are expressly permitted." | Correct, and not in dispute. Permission is conditioned in every source. The question is what evidences them. |
| "'Sufficiently similar' has no numeric threshold." | True. Absence of a threshold is not absence of a standard — it moves the outcome to supervisory discretion. |
| "It is to the supervisor's satisfaction, and supervisors may be pragmatic." | Also true. But an unevidenced proxy is not *approved* — it is *unresolved*, and resolution can land after the implementation horizon, when remediation is no longer available. |
| "EBA is not binding here." | Correct. Cited as the most developed articulation of what an examiner will look for, not as a source of obligation. |
| "These factors passed RFET." | RFET governs eligibility. If the qualitative data standards sit in §\_\_.214, they govern the ES data for all risk factors in the model regardless of RFET outcome. *Verify.* |
| "The data were accepted for capital before." | Prior acceptance was against a different risk-factor taxonomy and a different measure. It is not a track record for today's proxies. |

---

## 13. The slide sentence

> **The regulatory question is not whether a historical proxy exists; it is whether the proxy can be demonstrated to represent the target risk factor — including its volatility, correlation, region, instrument characteristics and behaviour during stress.**

Beneath it:

> **Using USD history for a non-USD or different instrument type is not inherently prohibited — but availability of USD history alone is not evidence of proxy appropriateness.**

---

*Open items: verbatim clause numbering for §\_\_.214(b)(2)(i)–(vi) and confirmation that the qualitative tests sit in §214 rather than §215; MAR31 paragraph number for Principle 7; EBA RTS article references for the §2.2.2 techniques and the (a)–(c) accuracy conditions. A single Federal Register URL is a source, not clause-level verification.*
