# Batch 2 — Proxies Are Permitted, and Conditioned

**Sources:** US NPR (March 2026) §215 qualitative test #6 and preamble; Basel MAR31 Principle 7; EBA RTS on assessment methodology, §2.2.2 and the data-accuracy conditions.
EBA is a defensible reference in the US context, not a binding one.

---

## 1. The permission

| Source | Text as written |
|---|---|
| NPR preamble | "the proposal would allow the data for risk factors to include proxies if the banking organization is able to demonstrate the appropriateness of such proxies to the satisfaction of the primary Federal supervisor" |
| NPR rule text | "The data may include proxies provided the [BANKING ORGANIZATION] can demonstrate to the satisfaction of the [AGENCY] that the proxies are appropriate and that the following standards are satisfied" |
| Basel MAR31, Principle 7 | "The use of proxies **must be limited**" |
| EBA RTS §2.2.2 | the institution "uses a proxy **only where data are insufficient**" |

Proxying is expressly available. It is framed as a fallback where data are insufficient — not as a design choice, and not without limit.

---

## 2. The three evidentiary burdens

Every source imposes the same structure. Each burden is a **comparison**, and each comparison requires evidence on **both** sides.

| # | Standard | Text |
|---|---|---|
| 1 | **Track record** | "sufficient evidence demonstrating the appropriateness of the proxies, such as an appropriate track record for their representation of a market risk covered position" |
| 2 | **Similar volatility and correlation** | "sufficiently similar characteristics to the transactions they represent in terms of volatility level and correlations" |
| 3 | **Fit to instrument** | "appropriate for the region, credit spread, quality and type of instrument they are intended to represent" |

A track record is observation of the proxy *against the actual*. Similar volatility and correlation is a two-sided measurement. Neither can be produced from the proxy alone.

**Consequence:** a proxy does not remove the data requirement. It relocates it — from *building the series* to *evidencing the substitute*.

---

## 3. The standard is conservatism, not similarity

| Source | Text |
|---|---|
| NPR preamble | "demonstrate, **empirically on an ongoing basis**, that the proxy data are a **conservative representation of the underlying risk under adverse market conditions**" |
| EBA, conditions for accuracy | "(a) supported by **convincing empirical evidence and objective data**; (b) accurately reflect changes in prices of similar instruments **during the identified period of financial stress**; (c) **do not underestimate risk**" |

Three things follow.

- The demonstration is **empirical**, not reasoned. A memo explaining why a proxy is economically sensible does not satisfy it.
- The demonstration is **ongoing**, not a one-off approval artefact.
- The condition is measured **under adverse conditions / during the stress period**. Similarity established in benign conditions does not discharge it — the framework exists precisely because benign-period volatility and correlation relationships do not hold in stress.

**This is the pivot.** A proxy relationship fitted on recent data makes a claim about the stress period that the recent data cannot evidence.

---

## 4. Where proxies are most exposed

**Judgment-set coefficients.** Basel Principle 7: "The coefficients (betas) of a multifactor model must be **empirically based and must not be determined based on judgment**. Instances where coefficients are set by judgment **generally should be considered as NMRFs**."

A proxy applied without a scaling or adjustment factor carries an implicit coefficient of 1. Unless that value is empirically derived, it is a coefficient determined by judgment on the plain reading — with the stated consequence being NMRF treatment.

**Index and multifactor proxies.** Basel Principle 7 requires that such a model:
- capture the correlated risk of the assets represented;
- demonstrate that remaining idiosyncratic risk is **uncorrelated across different issuers**;
- have **significant explanatory power** for price movements;
- **provide an assessment of the uncertainty in the final outcome due to the use of the proxy**.

The last requirement is an explicit obligation to quantify proxy uncertainty. It is rarely discharged.

**Many-to-few mappings.** Where a large set of distinct risk factors is represented by a small number of common drivers, the model sees those factors move together. Basis between them disappears and offsetting positions show suppressed variance. This is the mechanism the NPR names in the SES preamble — models that "overstate the diversification benefits or understate price volatility." It engages EBA condition (c) directly: the inputs must not underestimate risk.

---

## 5. What a supervisor will actually do

EBA §2.2.2 sets out concrete assessment techniques competent authorities will apply:

1. verify the **correlation between proxy data and the data used to mark the risk factor** in the end-of-day value;
2. **compare the resulting volatilities** when proxy data are used and when proxy data are not used;
3. for NMRFs, assess the **rationale for using proxies where at least 12 observations are available**.

Test 2 is the operative constraint. Running it requires the **un-proxied series**. Validating a proxy therefore requires the data the proxy was intended to substitute for — retention does not avoid the build, it defers it into the validation.

Test 3 places a burden on proxying *in preference to* available observations: where data exist, choosing the proxy must itself be justified.

---

## 6. Counter-readings to expect

| Argument | Response |
|---|---|
| "Proxies are expressly permitted." | Correct, and not in dispute. The question is what evidences them. Permission is conditioned in every source. |
| "'Sufficiently similar' has no numeric threshold." | True. Absence of a threshold is not absence of a standard — it moves the outcome to supervisory discretion. |
| "It is to the satisfaction of the supervisor, and supervisors may be pragmatic." | Also true. But an unevidenced proxy is not *approved* — it is *unresolved*, and resolution can land after the implementation horizon, when remediation is no longer available. |
| "EBA is not binding here." | Correct. It is cited as the most developed articulation of what an examiner will look for, not as a source of obligation. |
| "The data were accepted for capital before." | Prior acceptance was against a different risk-factor taxonomy and a different measure. It is not a track record for today's proxies. |

---

## 7. The proportionate conclusion

The rule does not require every risk factor to have directly observed stress-period history. It permits proxies, and expects them.

What it does not permit is an **unevidenced** proxy.

> **A proxy is not a replacement for data. It is a claim about data — and a claim that must be evidenced empirically, on an ongoing basis, under stress conditions.**

This sets the scope between the two extremes:

- **Not:** regenerate all history from 2007.
- **Not:** retain the existing history unchanged because it was previously used for capital.
- **But:** generate or reconstruct enough stress-period evidence to demonstrate that the proxies we intend to keep are similar in volatility and correlation, appropriate to instrument and region, and conservative under adverse conditions.

The size of the data build is therefore set by the proxies retained, not by the size of the risk-factor inventory. Each proxy we can evidence reduces the build. Each proxy we cannot evidence is a candidate for NMRF treatment and SES.

---

*Open items: verbatim §215 clause numbering for qualitative test #6; MAR31 paragraph number for Principle 7; EBA RTS article references for the §2.2.2 techniques and the (a)–(c) accuracy conditions.*
