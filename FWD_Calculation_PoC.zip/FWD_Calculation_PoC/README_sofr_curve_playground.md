# SOFR OIS Curve Playground

An interactive Streamlit PoC for experimenting with:

- SOFR OIS par quotes
- Discount factors
- Zero rates
- Forward rates
- Sequential curve bootstrapping
- Curve interpolation
- Repricing validation
- Par-to-forward Jacobians
- Quote bump scenarios

## Install

```bash
pip install -r requirements_sofr_curve_playground.txt
```

## Run

```bash
streamlit run sofr_ois_curve_playground.py
```

The app opens in your browser. Rates in the quote table are percentages, so `4.20` means `4.20%`.

This is an educational PoC and does not implement all production SOFR conventions.
