# SOFR OIS Curve Playground

An interactive Streamlit PoC for experimenting with:

- SOFR OIS par quotes
- Discount factors
- Zero rates
- Forward rates
- Sequential curve bootstrapping
- Curve interpolation
- Repricing validation
- Par-to-forward Jacobians
- Quote bump scenarios

## Install

```bash
pip install -r requirements_sofr_curve_playground.txt
```

## Run

```bash
streamlit run sofr_ois_curve_playground.py
```

The app opens in your browser. Rates in the quote table are percentages, so `4.20` means `4.20%`.

This is an educational PoC and does not implement all production SOFR conventions.

## Added F(3Y,5Y) deep-dive module

The app now includes an interactive walkthrough showing:

- Why F(3Y,5Y) directly needs P(0,3Y) and P(0,5Y)
- How annual-pay 1Y, 2Y, 3Y, 4Y and 5Y swaps bootstrap sequentially
- The full quote-to-discount-factor dependency map
- Missing 2Y and 3Y quote scenarios
- Replacing missing short-end swap quotes with illustrative quarterly SOFR futures-implied forwards
- Comparing linear-zero, log-linear-discount-factor and linear-discount-factor interpolation
- Why a single 3Y par quote creates an underdetermined system without earlier curve information
- Dense versus sparse market curves
- Reusable Python snippets for the annual bootstrap and F(3Y,5Y)
