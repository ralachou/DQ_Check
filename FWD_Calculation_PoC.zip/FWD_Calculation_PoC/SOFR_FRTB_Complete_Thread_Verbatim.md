# Complete Visible Conversation Transcript
> Scope: visible User and Assistant messages only. Hidden system/developer instructions and internal tool logs are excluded. Message bodies are preserved verbatim.

---

## Message 1 — User

Forward Rate from new bie to Expert PoC. 

Pick Sofr OIS curve. 
Act like Quant teacher who is explaining forward rate calculation 101. 
Start from scratch.
Give me all foundation knowledge to understand forward rate calculation. 
Make it easy to understand and teach to high schooler. 
What we observe in the market (instruments swap rate for example, for market prices or...)

Then go to how to bootstrap curve with 1M 3M 6M 9m 1y 2Y 3Y 4Y 5Y 10Y 20Y 30Y

Explain these two approaches
From instruments, raw market observable (i dont know zero rate, cash flow, swap rate, ...) to ....forward rate.
Give me formulas. Explain them
Give me sample of inputs
POC to compute forward rate in python


Then give me par rate to forward rate 

What is par rate. What is zero rate , what discount factor. 
 
Then how compute par to forward

About what Jacobian methodology par to forward. 

....start from beginning level to experience levet

---

## Message 2 — Assistant update

I’ll build this as a learning path: market observables → discount factors → zero rates → par swap rates → forward rates → bootstrapping → Jacobian sensitivities, with a working Python PoC.

---

## Message 3 — Assistant update

The key distinction is this: the market usually quotes **instrument prices or par rates**, not a ready-made forward curve. Bootstrapping is the translation engine that finds discount factors making every quoted instrument reprice exactly.

---

## Message 4 — Assistant

# SOFR OIS Forward Rates: From Beginner to Expert

Think of an interest-rate curve as a machine:

\[
\boxed{\text{Market quotes}}
\longrightarrow
\boxed{\text{Discount factors}}
\longrightarrow
\boxed{\text{Zero rates}}
\longrightarrow
\boxed{\text{Forward rates}}
\]

The market does **not normally hand us a complete forward curve**. It gives us tradable instrument quotes—SOFR fixings, futures prices, OIS par swap rates and similar observables. We construct the curve that reproduces those market prices.

SOFR itself is an overnight secured financing rate based on Treasury repo transactions. A SOFR OIS exchanges a fixed rate against compounded overnight SOFR. ([newyorkfed.org](https://www.newyorkfed.org/markets/reference-rates/sofr?funnelFromId=56&utm_source=chatgpt.com))

---

# 1. Start with the basic question

Suppose someone asks:

> What will the one-year interest rate be, starting two years from today?

That is not today's overnight rate. It is not necessarily the three-year swap rate either.

It is a **forward rate**:

\[
F(2Y,3Y)
\]

It represents the rate implied today for borrowing or lending between year 2 and year 3.

To calculate it, we first need the market-implied value today of:

- receiving \$1 at year 2;
- receiving \$1 at year 3.

Those values are called **discount factors**.

---

# 2. What do we observe in the market?

For a SOFR curve, possible market inputs include:

| Curve region | Typical observable | What the market quotes |
|---|---|---|
| Overnight | Published SOFR | Overnight interest rate |
| Very short term | SOFR OIS, SOFR futures | OIS fixed rate or futures price |
| Short/intermediate | SOFR futures and OIS | Futures price or par swap rate |
| Long term | SOFR OIS swaps | Par fixed swap rate |

The New York Fed publishes overnight SOFR and backward-looking compounded SOFR averages. The CME lists SOFR futures and cleared SOFR-indexed swaps. ([newyorkfed.org](https://www.newyorkfed.org/markets/reference-rates?utm_source=chatgpt.com))

For this PoC, assume that we receive these **par SOFR OIS rates**:

| Maturity | Hypothetical par OIS rate |
|---:|---:|
| 1M | 4.30% |
| 3M | 4.28% |
| 6M | 4.25% |
| 9M | 4.22% |
| 1Y | 4.20% |
| 2Y | 4.05% |
| 3Y | 3.95% |
| 4Y | 3.90% |
| 5Y | 3.88% |
| 10Y | 3.95% |
| 20Y | 4.02% |
| 30Y | 4.00% |

These are teaching inputs, not current market quotes.

---

# 3. The time value of money

## 3.1 One dollar today is worth more than one dollar later

Suppose the one-year interest rate is 5%.

If you invest \$100 today:

\[
100(1+5\%)=105
\]

Therefore:

\[
\$100\text{ today} = \$105\text{ in one year}
\]

Working backward:

\[
\$1\text{ received in one year}
=
\frac{1}{1.05}
=
\$0.95238\text{ today}
\]

The number \(0.95238\) is the one-year discount factor.

---

# 4. Discount factor

The discount factor \(P(0,T)\) means:

> The value today, at time 0, of receiving \$1 at future time \(T\).

For example:

\[
P(0,1)=0.96
\]

means:

> \$1 received one year from now is worth \$0.96 today.

Basic properties under ordinary positive-rate conditions are:

\[
P(0,0)=1
\]

and usually:

\[
P(0,T_2)<P(0,T_1), \qquad T_2>T_1
\]

because cash received further in the future is worth less today.

Discount factors are the most fundamental curve representation because every future cash flow can be valued as:

\[
PV=\sum_i CF_iP(0,t_i)
\]

where:

- \(CF_i\) is a future cash flow;
- \(P(0,t_i)\) is its discount factor;
- \(PV\) is present value.

---

# 5. Zero rate

A **zero rate**, or zero-coupon rate, is the single rate applying from today until one specific future date.

For example:

\[
z(3Y)
\]

is the rate for an investment made today and maturing in three years, with no intermediate coupons.

It is called a zero rate because it can be associated with a **zero-coupon instrument**: one payment at maturity and no payments in between.

## 5.1 Zero rate using annual compounding

\[
P(0,T)=\frac{1}{(1+z_T)^T}
\]

Therefore:

\[
z_T=P(0,T)^{-1/T}-1
\]

## 5.2 Zero rate using continuous compounding

\[
P(0,T)=e^{-z_TT}
\]

Therefore:

\[
\boxed{
z_T=-\frac{\ln P(0,T)}{T}
}
\]

Example:

\[
P(0,2)=0.92
\]

Then the continuously compounded two-year zero rate is:

\[
z_2=-\frac{\ln(0.92)}{2}
\]

\[
z_2\approx4.17\%
\]

The zero rate is therefore just another way to represent the same discount factor.

---

# 6. Forward rate

A forward rate applies between two future dates:

\[
F(T_1,T_2)
\]

For example:

\[
F(2Y,3Y)
\]

means the market-implied one-year rate beginning two years from today.

## 6.1 Forward rate from discount factors

Suppose:

\[
P(0,T_1)=P_1
\]

and:

\[
P(0,T_2)=P_2
\]

For a simple-compounded forward rate:

\[
\boxed{
F(T_1,T_2)
=
\frac{\frac{P(0,T_1)}{P(0,T_2)}-1}
{\tau(T_1,T_2)}
}
\]

where \(\tau(T_1,T_2)\) is the year fraction between the dates.

If the period is exactly one year:

\[
F(T_1,T_2)
=
\frac{P(0,T_1)}{P(0,T_2)}-1
\]

## 6.2 Example

Suppose:

\[
P(0,2)=0.925
\]

\[
P(0,3)=0.887
\]

Then:

\[
F(2,3)=\frac{0.925/0.887-1}{1}
\]

\[
F(2,3)=4.28\%
\]

This means the curve implies approximately 4.28% for the one-year period from year 2 to year 3.

---

# 7. Why does the forward formula work?

Consider two strategies.

## Strategy A

Invest \$1 directly from today until year 3.

Your future value is related to:

\[
\frac{1}{P(0,3)}
\]

## Strategy B

Invest from today until year 2, then reinvest from year 2 until year 3.

The first investment grows according to:

\[
\frac{1}{P(0,2)}
\]

The second period grows by:

\[
1+F(2,3)\tau
\]

No-arbitrage requires the two strategies to produce the same result:

\[
\frac{1}{P(0,3)}
=
\frac{1}{P(0,2)}
\left(1+F(2,3)\tau\right)
\]

Rearranging:

\[
1+F(2,3)\tau
=
\frac{P(0,2)}{P(0,3)}
\]

Therefore:

\[
F(2,3)
=
\frac{P(0,2)/P(0,3)-1}{\tau}
\]

That is the fundamental forward-rate equation.

---

# 8. Forward rate from zero rates

Suppose continuously compounded zero rates are:

\[
z(T_1)
\quad\text{and}\quad
z(T_2)
\]

Because:

\[
P(0,T)=e^{-z(T)T}
\]

the continuously compounded forward rate is:

\[
\boxed{
f(T_1,T_2)
=
\frac{z(T_2)T_2-z(T_1)T_1}
{T_2-T_1}
}
\]

Example:

\[
z(2)=4.00\%
\]

\[
z(3)=4.20\%
\]

Then:

\[
f(2,3)
=
\frac{0.042(3)-0.04(2)}{3-2}
\]

\[
f(2,3)=4.60\%
\]

Notice that the forward rate can be higher than both nearby zero rates. It represents the marginal rate for the future period, not the average rate from today.

---

# 9. What is a par rate?

A **par swap rate** is the fixed rate that makes a new swap worth zero at inception.

In a SOFR OIS:

- one side pays a fixed rate;
- the other side pays compounded overnight SOFR;
- the par rate is the fixed rate for which both legs have equal present value.

Therefore:

\[
PV_{\text{fixed}}=PV_{\text{floating}}
\]

and:

\[
PV_{\text{swap}}=0
\]

The fixed rate is known today. The floating SOFR payments are determined through the contractual overnight compounding mechanism. SOFR OIS conventions use compounded overnight SOFR for the floating leg. ([cmegroup.com](https://www.cmegroup.com/articles/2025/price-and-hedging-usd-sofr-interest-swaps-with-sofr-futures.html?utm_source=chatgpt.com))

---

# 10. Par rate is not a zero rate

This distinction is critical.

## Zero rate

One start date, one maturity date and one final cash flow:

\[
P(0,T)=e^{-z(T)T}
\]

## Par swap rate

A weighted average involving many payment dates:

\[
1Y,\ 2Y,\ 3Y,\ldots,T
\]

A five-year par swap rate therefore depends on the entire discount curve up to five years.

It is not simply the five-year zero rate.

---

# 11. The OIS par-rate formula

Consider a spot-starting OIS maturing at \(T_n\).

Let:

- \(K_n\): quoted par fixed rate;
- \(t_i\): fixed-leg payment dates;
- \(\alpha_i\): accrual fraction for payment period \(i\);
- \(P(0,t_i)\): discount factor.

The fixed-leg present value per dollar of notional is:

\[
PV_{\text{fixed}}
=
K_n\sum_{i=1}^{n}\alpha_iP(0,t_i)
\]

The quantity:

\[
A_n=\sum_{i=1}^{n}\alpha_iP(0,t_i)
\]

is called the **swap annuity** or **PV01 denominator**.

For a simplified spot-starting OIS, the floating-leg present value is:

\[
PV_{\text{float}}
=
1-P(0,T_n)
\]

At par:

\[
K_nA_n=1-P(0,T_n)
\]

Therefore:

\[
\boxed{
K_n=
\frac{1-P(0,T_n)}
{\sum_{i=1}^{n}\alpha_iP(0,t_i)}
}
\]

This is the bridge from discount factors to par rates.

---

# 12. Bootstrapping: the central idea

Bootstrapping means:

> Solve the curve one maturity at a time, starting with the shortest instrument.

We begin with the 1M quote, solve the 1M discount factor, then use that result when solving 3M, then 6M, and continue outward.

The curve is constructed sequentially:

\[
1M\rightarrow3M\rightarrow6M\rightarrow9M\rightarrow1Y
\rightarrow2Y\rightarrow\cdots\rightarrow30Y
\]

At every step, the newly solved discount factor must make the corresponding market instrument price exactly equal to its observed market quote.

---

# 13. Short maturity bootstrapping

Suppose a short OIS has only one payment at maturity \(T\).

The par equation becomes:

\[
K\alpha P(0,T)=1-P(0,T)
\]

Move the discount-factor terms together:

\[
K\alpha P(0,T)+P(0,T)=1
\]

\[
P(0,T)(1+K\alpha)=1
\]

Therefore:

\[
\boxed{
P(0,T)=\frac{1}{1+K\alpha}
}
\]

## Example: 3M OIS

Suppose:

\[
K_{3M}=4.28\%
\]

and:

\[
\alpha=0.25
\]

Then:

\[
P(0,3M)
=
\frac{1}{1+0.0428(0.25)}
\]

\[
P(0,3M)=0.989414
\]

From that discount factor, the continuously compounded zero rate is:

\[
z_{3M}
=
-\frac{\ln(0.989414)}{0.25}
\]

\[
z_{3M}\approx4.26\%
\]

---

# 14. Bootstrapping a two-year swap

Assume annual fixed payments and known:

\[
P(0,1)
\]

The two-year par swap equation is:

\[
K_2
\left[
P(0,1)+P(0,2)
\right]
=
1-P(0,2)
\]

Rearrange:

\[
K_2P(0,1)+K_2P(0,2)
=
1-P(0,2)
\]

\[
P(0,2)(1+K_2)
=
1-K_2P(0,1)
\]

Therefore:

\[
\boxed{
P(0,2)
=
\frac{1-K_2P(0,1)}
{1+K_2}
}
\]

More generally, for annual payments:

\[
\boxed{
P(0,T_n)
=
\frac{
1-K_n\sum_{i=1}^{n-1}\alpha_iP(0,t_i)
}{
1+K_n\alpha_n
}
}
\]

This formula works directly when all earlier coupon-date discount factors are already known.

---

# 15. Example: par rates to discount factors

Assume:

\[
K_1=4.20\%
\]

For a one-year, single-payment OIS:

\[
P(0,1)
=
\frac{1}{1.042}
=
0.959693
\]

Now suppose:

\[
K_2=4.05\%
\]

Then:

\[
P(0,2)
=
\frac{1-0.0405(0.959693)}
{1.0405}
\]

\[
P(0,2)\approx0.923563
\]

The implied one-year forward from year 1 to year 2 is:

\[
F(1,2)
=
\frac{P(0,1)}{P(0,2)}-1
\]

\[
F(1,2)
=
\frac{0.959693}{0.923563}-1
\]

\[
F(1,2)\approx3.91\%
\]

Although the one-year par rate is 4.20% and the two-year par rate is 4.05%, the marginal second-year rate is approximately 3.91%.

---

# 16. Bootstrapping the complete curve

For the requested maturities:

\[
1M,\ 3M,\ 6M,\ 9M,\ 1Y,\ 2Y,\ 3Y,\ 4Y,\ 5Y,\ 10Y,\ 20Y,\ 30Y
\]

the process is:

### 1M through 1Y

Treat each short OIS as a single-payment instrument in the simplified PoC:

\[
P(0,T)=\frac{1}{1+K_TT}
\]

### 2Y through 5Y

Use the swap equation with annual fixed payments:

\[
K_T\sum_i\alpha_iP(0,t_i)=1-P(0,T)
\]

### 10Y, 20Y and 30Y

There are coupon dates for which no direct market pillar exists.

For example, the 10Y swap includes fixed payments at:

\[
6Y,\ 7Y,\ 8Y,\ 9Y,\ 10Y
\]

but the input curve jumps from 5Y to 10Y.

We therefore choose an interpolation rule, such as:

- linear interpolation of zero rates;
- linear interpolation of discount factors;
- log-linear interpolation of discount factors;
- piecewise-constant instantaneous forwards;
- monotone-convex interpolation.

The PoC uses **log-linear discount-factor interpolation**:

\[
\ln P(0,t)
\]

is assumed linear between neighboring curve pillars.

Then we numerically solve the unknown 10Y discount factor so that the modeled 10Y swap rate equals the market’s 10Y par rate.

---

# 17. Why interpolation matters

Different interpolation choices can produce the same fit at the market pillars but different:

- intermediate discount factors;
- forward rates;
- sensitivities;
- hedge ratios;
- P&L behavior.

For example, both curves may exactly reproduce the 5Y and 10Y swaps, but they may imply different 7Y forward rates.

This is why a production curve definition must include:

- instruments;
- conventions;
- bootstrap method;
- interpolation method;
- extrapolation method;
- compounding convention;
- day-count convention;
- calendars and payment schedules.

---

# 18. The complete translation chain

## Approach 1: Instrument quotes to forward rates

\[
\boxed{
\text{OIS par quotes}
\rightarrow
\text{discount factors}
\rightarrow
\text{forward rates}
}
\]

Detailed steps:

1. Receive market par rates \(K_1,\ldots,K_n\).
2. Build each instrument's payment schedule.
3. Solve discount factors so each instrument has zero NPV.
4. Interpolate between curve pillars.
5. Compute forwards from discount-factor ratios.

## Approach 2: Par rates to zero rates to forward rates

\[
\boxed{
\text{Par rates}
\rightarrow
\text{discount factors}
\rightarrow
\text{zero rates}
\rightarrow
\text{forward rates}
}
\]

Once discount factors are available:

\[
z(T)=-\frac{\ln P(0,T)}{T}
\]

Then:

\[
f(T_1,T_2)
=
\frac{z(T_2)T_2-z(T_1)T_1}
{T_2-T_1}
\]

Both approaches produce the same economic curve when the conventions are internally consistent.

---

# 19. A small conceptual table

| Item | Meaning | Usually directly observed? |
|---|---|---:|
| SOFR fixing | Actual overnight secured rate | Yes |
| Futures price | Exchange-traded market price | Yes |
| OIS par rate | Fixed rate making swap NPV zero | Yes |
| Discount factor | Present value of \$1 paid later | Usually derived |
| Zero rate | Single today-to-maturity rate | Usually derived |
| Forward rate | Rate between two future dates | Usually derived |
| Instantaneous forward | Infinitesimal future rate | Derived |

---

# 20. Par rate versus forward rate

A par rate is a weighted average of forward rates.

For a standard swap:

\[
\boxed{
K_n
=
\frac{
\sum_{i=1}^{n}
\alpha_iP(0,t_i)F(t_{i-1},t_i)
}{
\sum_{i=1}^{n}
\alpha_iP(0,t_i)
}
}
\]

The weight for each forward period is:

\[
w_i
=
\frac{\alpha_iP(0,t_i)}
{\sum_j\alpha_jP(0,t_j)}
\]

Therefore:

\[
K_n=\sum_iw_iF_i
\]

with:

\[
\sum_iw_i=1
\]

This gives an intuitive interpretation:

> The par swap rate is a discount-weighted average of the forward rates covering the life of the swap.

But going backward from par rates to forwards is not just an ordinary subtraction. The weights themselves depend on discount factors, which are also being solved from the curve.

That is why bootstrapping is required.

---

# 21. Direct par-to-forward transformation

Let the vector of observed par quotes be:

\[
\mathbf q=
\begin{bmatrix}
K_{1M}\\
K_{3M}\\
K_{6M}\\
\vdots\\
K_{30Y}
\end{bmatrix}
\]

Let the resulting forward-rate vector be:

\[
\mathbf f=
\begin{bmatrix}
F(0,1M)\\
F(1M,3M)\\
F(3M,6M)\\
\vdots\\
F(20Y,30Y)
\end{bmatrix}
\]

Bootstrapping defines a nonlinear function:

\[
\boxed{
\mathbf f=g(\mathbf q)
}
\]

The par quotes are the inputs. The forwards are outputs after:

1. instrument construction;
2. curve calibration;
3. interpolation;
4. discount-factor calculation;
5. forward extraction.

---

# 22. What is the Jacobian?

The Jacobian measures how every output forward rate responds to every input par quote.

\[
\boxed{
J_{ij}
=
\frac{\partial f_i}{\partial q_j}
}
\]

For example:

\[
J_{5Y,10Y}
=
\frac{\partial F_{5Y,10Y}}
{\partial K_{10Y}}
\]

This answers:

> If the 10Y par OIS quote moves by one basis point, how much does the 5Y-to-10Y implied forward rate move?

The complete Jacobian looks like:

\[
J=
\begin{bmatrix}
\frac{\partial f_1}{\partial q_1} &
\frac{\partial f_1}{\partial q_2} &
\cdots\\
\frac{\partial f_2}{\partial q_1} &
\frac{\partial f_2}{\partial q_2} &
\cdots\\
\vdots & \vdots & \ddots
\end{bmatrix}
\]

---

# 23. Why the Jacobian matters

The Jacobian supports several important applications.

## Risk transformation

A trade may be calculated internally against forward-curve nodes, while the desk hedges using market par swaps.

The Jacobian translates risk between the two representations.

## Market-data shock transformation

A regulatory or risk system may shock:

- par swap rates;
- zero rates;
- discount factors;
- forwards.

The Jacobian maps one shock representation into another.

## Hedge ratios

Suppose a trade has forward-rate sensitivity:

\[
\frac{\partial V}{\partial \mathbf f}
\]

Because:

\[
\mathbf f=g(\mathbf q)
\]

the chain rule gives:

\[
\boxed{
\frac{\partial V}{\partial \mathbf q}
=
J^\mathsf{T}
\frac{\partial V}{\partial \mathbf f}
}
\]

This converts forward-node risk into par-quote risk.

---

# 24. Numerical Jacobian: bump and rebootstrap

The easiest robust PoC method is finite differences.

For each market quote \(q_j\):

1. Build the base curve.
2. Record all base forwards.
3. Increase quote \(q_j\) by 1 bp.
4. Rebootstrap the entire curve.
5. Recalculate every forward.
6. Measure the change.

The approximation is:

\[
\boxed{
J_{ij}
\approx
\frac{
f_i(\mathbf q+\epsilon\mathbf e_j)-f_i(\mathbf q)
}{
\epsilon
}
}
\]

where:

- \(\epsilon=1\) bp;
- \(\mathbf e_j\) means bump only quote \(j\).

This is sometimes called a **bump-and-revalue** or **bump-and-rebootstrap Jacobian**.

---

# 25. Why the Jacobian is often triangular

Because bootstrapping proceeds from shortest maturity to longest:

- the 1M discount factor generally depends only on the 1M quote;
- the 2Y discount factor depends on quotes through 2Y;
- the 10Y discount factor depends on quotes through 10Y.

Therefore, the dependency structure is usually approximately lower triangular.

But interpolation can introduce broader relationships within curve segments. A quote at one pillar can affect multiple intermediate forwards.

---

# 26. Analytical versus numerical Jacobian

## Numerical Jacobian

\[
J_{ij}
\approx
\frac{\Delta f_i}{\Delta q_j}
\]

Advantages:

- straightforward;
- works with complex pricing libraries;
- captures calendars and interpolation;
- easy to validate.

Disadvantages:

- computationally expensive;
- sensitive to bump size;
- can contain numerical noise.

## Analytical Jacobian

Differentiate the calibration equations directly.

Let:

\[
\mathbf G(\mathbf x,\mathbf q)=0
\]

where:

- \(\mathbf x\) is the vector of curve parameters, such as log discount factors;
- \(\mathbf q\) is the market quote vector;
- \(\mathbf G\) contains instrument repricing errors.

Implicit differentiation gives:

\[
\frac{\partial\mathbf G}{\partial\mathbf x}
\frac{\partial\mathbf x}{\partial\mathbf q}
+
\frac{\partial\mathbf G}{\partial\mathbf q}
=0
\]

Therefore:

\[
\boxed{
\frac{\partial\mathbf x}{\partial\mathbf q}
=
-
\left(
\frac{\partial\mathbf G}{\partial\mathbf x}
\right)^{-1}
\frac{\partial\mathbf G}{\partial\mathbf q}
}
\]

If forwards are:

\[
\mathbf f=h(\mathbf x)
\]

then:

\[
\boxed{
\frac{\partial\mathbf f}{\partial\mathbf q}
=
\frac{\partial\mathbf f}{\partial\mathbf x}
\frac{\partial\mathbf x}{\partial\mathbf q}
}
\]

That is the expert-level mathematical definition of the par-to-forward Jacobian.

---

# 27. Choosing curve parameters

A curve may be calibrated using different internal variables.

## Discount-factor parameters

\[
x_i=P(0,T_i)
\]

Potential issue: numerical optimization must preserve positivity.

## Zero-rate parameters

\[
x_i=z(T_i)
\]

Easy for humans to read, but interpolation may produce unstable forwards.

## Log-discount-factor parameters

\[
x_i=\ln P(0,T_i)
\]

This is often convenient because:

\[
P(0,T_i)=e^{x_i}>0
\]

Positive discount factors are automatically guaranteed.

## Forward-rate parameters

\[
x_i=F(T_{i-1},T_i)
\]

This directly represents marginal curve segments, but par instruments depend on accumulated earlier forwards.

The supplied PoC solves discount factors and uses log-linear interpolation.

---

# 28. Simplified PoC output

Using the hypothetical quotes, the program:

- bootstraps one discount factor per tenor;
- calculates continuously compounded zero rates;
- calculates simple and continuously compounded forwards;
- reprices every input swap;
- reports repricing errors;
- calculates the par-quote-to-forward Jacobian.

The repricing errors are effectively zero, demonstrating that the constructed curve reproduces the input par quotes.

[Download the Python SOFR OIS curve PoC](sandbox:/mnt/data/sofr_ois_forward_curve_poc.py)

[Download the bootstrapped curve results](sandbox:/mnt/data/sofr_ois_bootstrapped_curve.csv)

[Download the par-to-forward Jacobian](sandbox:/mnt/data/sofr_ois_quote_to_forward_jacobian.csv)

Run it with:

```bash id="sy9duv"
pip install numpy pandas scipy
python sofr_ois_forward_curve_poc.py
```

---

# 29. Core Python logic

The essential forward formula is:

```python id="vmtx30"
def forward_from_discount_factors(
    df_start: float,
    df_end: float,
    year_fraction: float,
) -> float:
    return (df_start / df_end - 1.0) / year_fraction
```

The OIS par-rate formula is:

```python id="7pt321"
def par_rate(payment_dfs, accruals):
    annuity = sum(
        alpha * discount_factor
        for alpha, discount_factor in zip(accruals, payment_dfs)
    )

    maturity_df = payment_dfs[-1]

    return (1.0 - maturity_df) / annuity
```

The numerical Jacobian logic is:

```python id="ehfody"
base_curve = bootstrap_quotes(market_quotes)
base_forwards = calculate_forwards(base_curve)

for quote_name in market_quotes:
    bumped_quotes = market_quotes.copy()
    bumped_quotes[quote_name] += 0.0001  # One basis point

    bumped_curve = bootstrap_quotes(bumped_quotes)
    bumped_forwards = calculate_forwards(bumped_curve)

    jacobian[:, quote_column] = (
        bumped_forwards - base_forwards
    ) / 0.0001
```

The critical point is that we do **not** merely bump the final forward. We bump a market quote and reconstruct the entire curve.

---

# 30. What the PoC simplifies

The example is deliberately transparent. A production SOFR OIS curve must also handle:

- actual dates rather than approximate year fractions;
- business-day calendars;
- holiday adjustments;
- settlement delays;
- fixed-leg payment frequency;
- Actual/360 accrual conventions;
- daily compounded SOFR;
- observation shifts, lookbacks or payment delays where applicable;
- short stubs and long stubs;
- futures convexity adjustments;
- interpolation and extrapolation governance;
- bid, offer and mid selection;
- stale or missing quotes;
- instrument weighting;
- multi-curve requirements where relevant.

USD floating-rate accruals commonly use an Actual/360-style money-market convention, while contractual swap details determine schedules and payment mechanics. ([cmegroup.com](https://www.cmegroup.com/articles/2025/price-and-hedging-usd-sofr-interest-swaps-with-sofr-futures.html?utm_source=chatgpt.com))

---

# 31. Expert interpretation of a forward curve

A forward curve is not a pure forecast.

It is more accurately:

> The set of future rates implied by current tradable prices, discounting assumptions, collateral conventions and no-arbitrage relationships.

Forward rates can contain:

- expectations about future overnight rates;
- term premiums;
- liquidity effects;
- supply and demand;
- hedging pressure;
- technical effects;
- convexity effects, especially when futures are involved.

Therefore:

\[
\text{Forward rate}
\neq
\text{guaranteed future realized SOFR}
\]

It is the market-consistent break-even rate embedded in today's curve.

---

# 32. Final mental model

Keep these six definitions together:

### Market par rate

The fixed swap rate that makes the instrument's current NPV zero.

\[
K=\frac{PV_{\text{floating}}}{\text{fixed-leg annuity}}
\]

### Discount factor

Today's value of \$1 received at \(T\).

\[
P(0,T)
\]

### Zero rate

One rate from today to one maturity.

\[
z(T)=-\frac{\ln P(0,T)}{T}
\]

### Forward rate

Rate between two future dates.

\[
F(T_1,T_2)
=
\frac{P(0,T_1)/P(0,T_2)-1}{\tau}
\]

### Bootstrap

Solve discount factors sequentially so all market instruments reprice exactly.

\[
PV_{\text{model}}=PV_{\text{market}}
\]

### Jacobian

Measure how derived forwards change when observed par quotes change.

\[
J_{ij}=\frac{\partial f_i}{\partial q_j}
\]

The entire curve-construction process can therefore be summarized as:

\[
\boxed{
\text{Raw market instruments}
\overset{\text{bootstrap}}{\longrightarrow}
P(0,T)
\longrightarrow
z(T)
\longrightarrow
F(T_1,T_2)
}
\]

and the risk transformation as:

\[
\boxed{
\text{Par quote shocks}
\overset{\text{Jacobian}}{\longrightarrow}
\text{Forward-rate shocks}
}
\]

---

## Message 5 — User

Great explanation. I need python code that let me play with all past explanation 

---

## Message 6 — Assistant update

I’ll turn the lesson into an interactive Python playground where you can edit SOFR OIS quotes, rebuild the curve, inspect discount/zero/forward rates, test individual formulas, and bump quotes to see the Jacobian.

---

## Message 7 — Assistant

I created an interactive **Streamlit SOFR OIS curve playground**.

You can:

- Edit the 1M–30Y par OIS quotes.
- Bootstrap discount factors.
- View zero, par and forward curves.
- Calculate forwards from discount factors or zero rates.
- Calculate any forward period, such as \(F(2Y,3Y)\).
- Change annual, semiannual or quarterly fixed payments.
- Bump an individual market quote and see how all forwards move.
- Generate the full par-to-forward Jacobian.
- Verify that every input instrument reprices to zero error.
- Download curve and Jacobian results as CSV files.

### Files

[Download the interactive Python app](sandbox:/mnt/data/sofr_ois_curve_playground.py)

[Download the setup instructions](sandbox:/mnt/data/README_sofr_curve_playground.md)

[Download the requirements file](sandbox:/mnt/data/requirements_sofr_curve_playground.txt)

### Run it

Place the three files in the same folder, open a terminal there, and run:

```bash id="nabfch"
pip install -r requirements_sofr_curve_playground.txt
```

Then:

```bash id="jk925o"
streamlit run sofr_ois_curve_playground.py
```

The application will open in your browser.

The main editable input looks like:

```text id="iuqd6d"
Tenor    Par Rate
1M       4.30%
3M       4.28%
6M       4.25%
...
10Y      3.95%
20Y      4.02%
30Y      4.00%
```

When you change any quote, the app immediately recalculates:

\[
\text{Par quotes}
\rightarrow
\text{Discount factors}
\rightarrow
\text{Zero rates}
\rightarrow
\text{Forward rates}
\rightarrow
\text{Jacobian}
\]

The code is heavily separated into mathematical functions and the user interface, so you can also reuse the bootstrap functions independently in another Python project.

---

## Message 8 — User

Now lets discuss one big points
the 1M discount factor generally depends only on the 1M quote;
the 3Y discount factor depends on quotes through 3Y;
the 5Y discount factor depends on quotes through 5Y.

Illustrate why I need quotes from 0 through 3Y and quotes from 0 through 5y to compute F(3Y, 5Y)

Help me understand this. 
What would happen if I miss quotes for 1Y, 2Y for example 

---

## Message 9 — Assistant update

The core issue is that \(F(3Y,5Y)\) needs two discount factors, \(P(0,3Y)\) and \(P(0,5Y)\), and each of those is itself built from earlier market information.

---

## Message 10 — Assistant

Exactly. This is one of the most important ideas in curve construction.

# 1. Start with the forward formula

To compute the two-year forward rate starting in year 3 and ending in year 5:

\[
\boxed{
F(3Y,5Y)
=
\frac{\frac{P(0,3Y)}{P(0,5Y)}-1}{2}
}
\]

So mathematically, you only need two discount factors:

\[
P(0,3Y)
\]

and

\[
P(0,5Y)
\]

But the important question is:

> How did we obtain \(P(0,3Y)\) and \(P(0,5Y)\)?

If the market gives you zero-coupon bond prices directly, you could use them immediately.

But the market usually gives you **par swap rates**, and a par swap rate depends on several earlier cash flows.

That is why the earlier quotes matter.

---

# 2. Why the 3Y discount factor needs earlier information

Assume annual swap payments.

A 3Y OIS has fixed payments at:

\[
1Y,\ 2Y,\ 3Y
\]

Its par-rate equation is:

\[
K_{3Y}
\left[
P(0,1Y)+P(0,2Y)+P(0,3Y)
\right]
=
1-P(0,3Y)
\]

The unknown is \(P(0,3Y)\).

Rearranging:

\[
\boxed{
P(0,3Y)
=
\frac{
1-K_{3Y}\left[P(0,1Y)+P(0,2Y)\right]
}{
1+K_{3Y}
}
}
\]

Notice what appears on the right-hand side:

\[
P(0,1Y)
\quad\text{and}\quad
P(0,2Y)
\]

Therefore, the 3Y swap quote alone is not normally enough to determine the 3Y discount factor.

You first need the earlier discount factors.

The dependency chain is:

\[
K_{1Y}
\rightarrow P(0,1Y)
\]

\[
K_{1Y},K_{2Y}
\rightarrow P(0,2Y)
\]

\[
K_{1Y},K_{2Y},K_{3Y}
\rightarrow P(0,3Y)
\]

This is why bootstrapping proceeds from short maturity to long maturity.

---

# 3. Numerical example through 3Y

Assume these hypothetical par OIS rates:

| Maturity | Par rate |
|---|---:|
| 1Y | 4.00% |
| 2Y | 4.20% |
| 3Y | 4.30% |

Assume annual fixed payments and unit notional.

## Step 1: Solve the 1Y discount factor

For the 1Y swap:

\[
K_{1Y}P_1=1-P_1
\]

Therefore:

\[
P_1=\frac{1}{1+K_{1Y}}
\]

Using \(K_{1Y}=4.00\%\):

\[
P_1=\frac{1}{1.04}
\]

\[
\boxed{P_1=0.961538}
\]

---

## Step 2: Solve the 2Y discount factor

The 2Y par equation is:

\[
0.042(P_1+P_2)=1-P_2
\]

Therefore:

\[
P_2=
\frac{1-0.042P_1}{1.042}
\]

Substituting \(P_1=0.961538\):

\[
\boxed{P_2\approx0.920936}
\]

---

## Step 3: Solve the 3Y discount factor

The 3Y equation is:

\[
0.043(P_1+P_2+P_3)=1-P_3
\]

Therefore:

\[
P_3=
\frac{1-0.043(P_1+P_2)}{1.043}
\]

Substituting the earlier discount factors:

\[
\boxed{P_3\approx0.881164}
\]

So the 3Y discount factor was not obtained from the 3Y quote alone.

It required:

\[
1Y \rightarrow 2Y \rightarrow 3Y
\]

---

# 4. Why the 5Y discount factor also needs earlier information

A 5Y swap with annual payments has cash flows at:

\[
1Y,\ 2Y,\ 3Y,\ 4Y,\ 5Y
\]

Its par equation is:

\[
K_{5Y}
\left[
P_1+P_2+P_3+P_4+P_5
\right]
=
1-P_5
\]

To solve for \(P_5\), you need:

\[
P_1,\ P_2,\ P_3,\ P_4
\]

Then:

\[
P_5
=
\frac{
1-K_{5Y}(P_1+P_2+P_3+P_4)
}{
1+K_{5Y}
}
\]

Therefore, the 5Y discount factor depends on the earlier curve.

Conceptually:

\[
\boxed{
P(0,5Y)
=
g(K_{1Y},K_{2Y},K_{3Y},K_{4Y},K_{5Y})
}
\]

If the 4Y quote is unavailable, the curve builder must estimate \(P_4\) using interpolation or another instrument.

That estimate will influence the solved 5Y discount factor.

---

# 5. Computing \(F(3Y,5Y)\)

Once you have:

\[
P_3=0.881164
\]

and suppose the bootstrap gives:

\[
P_5=0.801735
\]

then:

\[
F(3Y,5Y)
=
\frac{P_3/P_5-1}{2}
\]

\[
F(3Y,5Y)
=
\frac{0.881164/0.801735-1}{2}
\]

\[
\boxed{
F(3Y,5Y)\approx4.95\%
}
\]

The forward rate itself uses only \(P_3\) and \(P_5\).

However:

\[
P_3
\]

contains information from the curve through 3Y, and:

\[
P_5
\]

contains information from the curve through 5Y.

Therefore:

\[
\boxed{
F(3Y,5Y)
\text{ indirectly depends on the quotes used to build the curve through 5Y.}
}
\]

---

# 6. A useful dependency diagram

Think of it this way:

```text id="rixks4"
1Y quote ──────► P(0,1Y)
                    │
2Y quote ───────────┼──► P(0,2Y)
                    │       │
3Y quote ───────────┼───────┼──► P(0,3Y)
                    │       │       │
4Y quote/interpolation ──────┼───────┼──► P(0,4Y)
                    │       │       │       │
5Y quote ───────────┴───────┴───────┴───────┼──► P(0,5Y)
                                             │
                         P(0,3Y), P(0,5Y) ───┴──► F(3Y,5Y)
```

The dependency is cumulative because each swap contains all earlier fixed-leg coupon payments.

---

# 7. What happens if the 1Y and 2Y quotes are missing?

This depends on what other market instruments are available.

There are several cases.

---

## Case 1: Other short-dated instruments exist

Perhaps you do not have 1Y and 2Y OIS quotes, but you have:

- SOFR futures;
- 1Y forward-starting OIS;
- short-dated deposits or cash instruments;
- 18M OIS;
- 3Y OIS plus liquid futures covering the missing period.

Then you may still construct the earlier part of the curve.

The missing OIS quote does not necessarily mean the maturity is completely unobservable.

A production SOFR curve often combines multiple instrument types across maturities. CME describes SOFR futures as an important source of curve price discovery and explains that sequential forward rates can be accumulated into discount factors. ([cmegroup.com](https://www.cmegroup.com/articles/2025/price-and-hedging-usd-sofr-interest-swaps-with-sofr-futures.html?utm_source=chatgpt.com))

---

## Case 2: You interpolate across the missing quotes

Suppose you have:

- 6M quote;
- 3Y quote;
- no 1Y quote;
- no 2Y quote.

You could interpolate the curve between 6M and 3Y.

For example, you might assume:

- zero rates are linear;
- log discount factors are linear;
- instantaneous forwards are constant;
- a smooth spline applies.

Then you estimate:

\[
P(0,1Y)
\]

and:

\[
P(0,2Y)
\]

Once those are estimated, you can solve the 3Y instrument.

But now the result is not fully market-determined.

It depends on your interpolation assumption.

That means:

\[
\boxed{
\text{Missing quote}
\Rightarrow
\text{more model dependency}
}
\]

---

# 8. Why different interpolation methods produce different answers

Suppose you only know:

\[
P(0,6M)
\]

and eventually solve:

\[
P(0,3Y)
\]

There are infinitely many possible curves between 6M and 3Y.

For example:

### Method A: Linear zero rates

Assume:

\[
z(t)
\]

moves linearly between 6M and 3Y.

### Method B: Log-linear discount factors

Assume:

\[
\ln P(0,t)
\]

moves linearly.

### Method C: Flat forward rates

Assume the instantaneous forward rate is constant between the two pillars.

All three approaches can fit the same endpoint market instruments, yet give different values for:

\[
P(0,1Y),\ P(0,2Y)
\]

and therefore different forwards inside that interval.

The BIS notes that spot rates, forward rates and discount factors are different representations of the term structure, and curve estimates require a method for deriving one representation from another. ([bis.org](https://www.bis.org/publ/bppdf/bispap25.htm?utm_source=chatgpt.com))

---

# 9. Can you solve a 3Y swap with no 1Y and 2Y information?

Consider the 3Y equation:

\[
K_3(P_1+P_2+P_3)=1-P_3
\]

Suppose all you know is \(K_3\).

Unknowns are:

\[
P_1,\ P_2,\ P_3
\]

You have one equation but three unknowns.

That is an underdetermined system.

There are infinitely many combinations of \(P_1,P_2,P_3\) that make the 3Y swap price correctly.

For example, one curve might have:

\[
P_1=0.96,\quad P_2=0.92
\]

while another might have:

\[
P_1=0.95,\quad P_2=0.93
\]

Both could potentially solve to a different \(P_3\) while still repricing the same 3Y swap quote.

Therefore:

\[
\boxed{
\text{One 3Y par quote does not uniquely define the full 0–3Y curve.}
}
\]

You need either:

- additional market instruments;
- structural assumptions;
- interpolation constraints;
- parametric curve fitting.

---

# 10. Missing 1Y and 2Y quotes: impact on \(F(3Y,5Y)\)

Even though \(F(3Y,5Y)\) refers to the period after 3Y, missing earlier quotes can still affect it.

Why?

Because:

\[
F(3,5)
=
\frac{P_3/P_5-1}{2}
\]

Both \(P_3\) and \(P_5\) are affected by the earlier discount factors used in the swap annuities.

For the 3Y swap:

\[
K_3(P_1+P_2+P_3)=1-P_3
\]

For the 5Y swap:

\[
K_5(P_1+P_2+P_3+P_4+P_5)=1-P_5
\]

If you change your assumptions for \(P_1\) and \(P_2\), both \(P_3\) and \(P_5\) can change.

Sometimes part of that effect cancels in the ratio \(P_3/P_5\), but not necessarily completely.

Therefore, the 3Y–5Y forward becomes sensitive to how the missing short-end portion was reconstructed.

---

# 11. Important nuance: you do not always need every quoted tenor

You do not literally need a market quote at every date.

For example, a practical curve might have liquid quotes at:

\[
1Y,\ 2Y,\ 3Y,\ 5Y,\ 7Y,\ 10Y
\]

but no 4Y, 6Y, 8Y or 9Y quotes.

The curve engine fills the missing dates using interpolation.

So the requirement is not:

> Every maturity must have a quote.

The real requirement is:

> You need enough independent market instruments and a defined interpolation methodology to uniquely construct the curve.

If the market data are sparse, more of the result comes from interpolation.

If the market data are dense, more of the result is directly anchored to tradable quotes.

---

# 12. Dense versus sparse curve

## Dense curve

Quotes:

\[
1Y,\ 2Y,\ 3Y,\ 4Y,\ 5Y
\]

Advantages:

- each pillar is directly anchored;
- less interpolation;
- more local sensitivities;
- more transparent hedging.

## Sparse curve

Quotes:

\[
1Y,\ 3Y,\ 5Y
\]

Then:

- 2Y is interpolated;
- 4Y is interpolated;
- intermediate forwards depend strongly on interpolation;
- quote risk can be spread over wider maturity segments.

Both curves can reprice the available instruments exactly.

But their intermediate forward rates may differ.

---

# 13. A simplified Python illustration

```python id="iccmd1"
import math


def solve_one_year_df(par_rate):
    return 1.0 / (1.0 + par_rate)


def solve_swap_df(par_rate, previous_dfs):
    """
    Annual fixed payments.

    P_n = [1 - K * sum(P_1 ... P_{n-1})] / (1 + K)
    """
    return (
        1.0 - par_rate * sum(previous_dfs)
    ) / (1.0 + par_rate)


k1 = 0.0400
k2 = 0.0420
k3 = 0.0430

p1 = solve_one_year_df(k1)
p2 = solve_swap_df(k2, [p1])
p3 = solve_swap_df(k3, [p1, p2])

print("P1:", p1)
print("P2:", p2)
print("P3:", p3)
```

Output is approximately:

```text id="6e6azc"
P1 = 0.961538
P2 = 0.920936
P3 = 0.881164
```

Now observe what happens if we assume different missing values for \(P_1\) and \(P_2\):

```python id="d10135"
k3 = 0.0430

assumption_a = [0.9615, 0.9209]
assumption_b = [0.9500, 0.9300]

p3_a = solve_swap_df(k3, assumption_a)
p3_b = solve_swap_df(k3, assumption_b)

print(p3_a)
print(p3_b)
```

Both calculations use the same 3Y par quote, but produce different 3Y discount factors because the earlier curve differs.

That is the central lesson.

---

# 14. Expert interpretation

There are two different statements:

### Statement 1

\[
F(3Y,5Y)
\]

directly depends only on:

\[
P(0,3Y),P(0,5Y)
\]

This is mathematically true.

### Statement 2

Those discount factors are calibrated from par instruments whose cash flows span all earlier payment dates.

This is also true.

Therefore:

\[
\boxed{
F(3Y,5Y)
\text{ directly depends on }P_3,P_5
\text{ but indirectly depends on the entire calibrated curve through 5Y.}
}
\]

That is why the Jacobian for \(F(3Y,5Y)\) can show sensitivity not only to the 3Y and 5Y quotes, but also to earlier market quotes.

---

# 15. The one-sentence explanation

> You need the curve from today through 3Y to determine the present value at 3Y, and the curve from today through 5Y to determine the present value at 5Y; the 3Y-to-5Y forward is then the rate that bridges those two present values.

Or visually:

\[
\boxed{
0 \longrightarrow 3Y
}
\]

gives:

\[
P(0,3Y)
\]

\[
\boxed{
0 \longrightarrow 5Y
}
\]

gives:

\[
P(0,5Y)
\]

Then:

\[
\boxed{
3Y \longrightarrow 5Y
}
\]

is inferred from their ratio:

\[
F(3,5)=\frac{P(0,3)/P(0,5)-1}{2}
\]

---

## Message 11 — User

Great. Add all the above  to the stream app created earlier to illustrate F(3Y, 5Y)

Include all steps 1, 2, 3,4,5,6 : from the ideal need for  two discount factors P(0, 3Y) and P(0, 5Y)
..add example of how you used annual swap payments and how you need to solve for discount factor for  1y, 2y, 3Y 

Then add examples what if 2Y and 3Y are missing..
Bring example of sofr futures
And example of interpolation 
    Relying on short end instruments 
    Or interpolate 
    Show different interpolation gived different results using method A,B and C

And add all details you added in step 9, 10, 11, 12 ans 13


---

## Message 12 — Assistant update

I’ll extend the Streamlit app with a dedicated **F(3Y,5Y) learning module** that walks through the dependency chain, missing-tenor cases, SOFR futures substitution, and interpolation comparisons with live calculations.

---

## Message 13 — Assistant update

The new module will contrast three different meanings of “missing”: no quote but another short-end instrument exists, no quote so interpolation is used, and insufficient information where the system becomes underdetermined.

---

## Message 14 — Assistant update

The module now includes live annual-bootstrap equations and a side-by-side missing-data experiment. I’m validating the app so the teaching tabs and editable futures/interpolation inputs run cleanly.

---

## Message 15 — Assistant

The Streamlit app has been updated with a full interactive **F(3Y,5Y) deep-dive module**.

[Download the updated SOFR OIS Curve Playground](sandbox:/mnt/data/sofr_ois_curve_playground.py)

[Download the updated instructions](sandbox:/mnt/data/README_sofr_curve_playground.md)

[Download the requirements file](sandbox:/mnt/data/requirements_sofr_curve_playground.txt)

## What was added

The new section starts with:

\[
F(3Y,5Y)
=
\frac{P(0,3Y)/P(0,5Y)-1}{2}
\]

It then walks through eleven interactive tabs.

### Steps 1–6: Ideal annual bootstrap

The app shows:

1. The two discount factors directly needed:
   \[
   P(0,3Y),\quad P(0,5Y)
   \]

2. How the 1Y discount factor is solved:
   \[
   P_1=\frac{1}{1+K_1}
   \]

3. How the 2Y discount factor depends on \(P_1\):
   \[
   P_2=\frac{1-K_2P_1}{1+K_2}
   \]

4. How the 3Y discount factor depends on both \(P_1\) and \(P_2\):
   \[
   P_3=
   \frac{1-K_3(P_1+P_2)}
   {1+K_3}
   \]

5. How the 5Y discount factor depends on the full annual curve:
   \[
   P_5=
   \frac{1-K_5(P_1+P_2+P_3+P_4)}
   {1+K_5}
   \]

6. The full dependency diagram from quotes to discount factors and finally to \(F(3Y,5Y)\).

All calculations respond to the market quotes entered in the main app.

## Missing 2Y and 3Y quotes

The app now demonstrates two possible responses.

### Use short-end instruments

An editable table contains eight illustrative quarterly SOFR futures-implied rates covering 1Y through 3Y.

The discount factors are accumulated using:

\[
P(0,t+0.25)
=
\frac{P(0,t)}
{1+F(t,t+0.25)\times0.25}
\]

This produces futures-derived values for:

\[
P(0,2Y)
\quad\text{and}\quad
P(0,3Y)
\]

Three-Month SOFR futures provide market information across future quarterly periods and are commonly used for short-end SOFR curve construction and price discovery. The app identifies that a production implementation must also consider exact contract dates, settlement mechanics and possible futures-forward convexity adjustments. ([cmegroup.com](https://www.cmegroup.com/markets/interest-rates/secured-overnight-financing-rate.html?utm_source=chatgpt.com))

### Use interpolation

The app removes the direct 2Y and 3Y anchors and compares three methods between the 1Y and 4Y points:

- Linear zero rates
- Log-linear discount factors
- Linear discount factors

It calculates, for every method:

\[
P(0,2Y)
\]

\[
P(0,3Y)
\]

and:

\[
F(3Y,5Y)
\]

A chart shows that the methods share the same surrounding anchors but generate different internal curve shapes.

## Underdetermined-system example

The app demonstrates why one 3Y par quote cannot uniquely determine:

\[
P_1,\ P_2,\ P_3
\]

The equation:

\[
K_3(P_1+P_2+P_3)=1-P_3
\]

contains three unknown discount factors but only one pricing equation.

Two different assumptions for \(P_1\) and \(P_2\) produce two different values of \(P_3\), even though the same 3Y quote is used.

## Dense versus sparse curves

The app also explains the distinction between:

\[
1Y,\ 2Y,\ 3Y,\ 4Y,\ 5Y
\]

as a dense curve and:

\[
1Y,\ 3Y,\ 5Y
\]

as a sparse curve.

Both can fit their available instruments, but the sparse curve places more reliance on interpolation and creates more model-dependent intermediate forwards and risk allocations.

SOFR itself is an overnight Treasury-repo-based reference rate administered and published by the New York Fed. ([newyorkfed.org](https://www.newyorkfed.org/markets/reference-rates/sofr?funnelFromId=56&utm_source=chatgpt.com))

Run the updated app with:

```bash id="bucyzp"
pip install -r requirements_sofr_curve_playground.txt
streamlit run sofr_ois_curve_playground.py
```

---

## Message 16 — User

Now. Going back to FRTB ima and RPOs and quantitative tests. 
Lets assume that on the i have  RPOs on using swap rates for 6M, 1Y, 2Y, 3Y , 4Y and 5Y..
But assume that some buckets fail the tests. 

But because I use interpolation, i can survive.
How interpolation can simplify my RPOs counts and not liquid on certain buckets. 

Is there any mentioned in the NPR?

---

## Message 17 — Assistant update

I’ll separate the **economic interpolation argument** from the **RFET legal test**, because interpolation may let you value a missing tenor without automatically making that tenor modellable under FRTB.

---

## Message 18 — Assistant

Yes—but with an important regulatory distinction:

\[
\boxed{\text{Interpolation can solve a curve-construction problem, but it does not automatically solve an RFET liquidity problem.}}
\]

You may be able to calculate a 2Y rate from liquid 1Y and 3Y pillars, but that calculated 2Y value is not itself a real price observation.

# 1. Your example

Assume your SOFR curve has internal risk factors at:

\[
6M,\ 1Y,\ 2Y,\ 3Y,\ 4Y,\ 5Y
\]

and your eligible RPO counts are:

| Tenor | RPO count | RFET result |
|---|---:|---|
| 6M | 120 | Pass |
| 1Y | 110 | Pass |
| 2Y | 8 | Fail |
| 3Y | 105 | Pass |
| 4Y | 10 | Fail |
| 5Y | 90 | Pass |

Economically, your pricing system can construct the missing 2Y and 4Y points:

\[
2Y=\operatorname{Interpolate}(1Y,3Y)
\]

\[
4Y=\operatorname{Interpolate}(3Y,5Y)
\]

Therefore, the trading or risk model can still produce a complete daily curve:

\[
6M,\ 1Y,\ \boxed{2Y},\ 3Y,\ \boxed{4Y},\ 5Y
\]

But this does **not** mean that the 2Y and 4Y risk factors have passed RFET.

---

# 2. What interpolation genuinely helps with

Interpolation can help you design a more efficient risk-factor representation.

Instead of defining six independently calibrated risk factors:

\[
RF=
\{6M,1Y,2Y,3Y,4Y,5Y\}
\]

you could define only the liquid curve pillars as independent model risk factors:

\[
RF_{\text{pillars}}
=
\{6M,1Y,3Y,5Y\}
\]

Then derive:

\[
R_{2Y}=h(R_{1Y},R_{3Y})
\]

and:

\[
R_{4Y}=h(R_{3Y},R_{5Y})
\]

The 2Y and 4Y curve points would be **model outputs**, not independent calibration inputs.

This can reduce the number of independent RFET points you are trying to support.

Conceptually:

```text id="n759yl"
Observed and modellable pillars
        1Y          3Y          5Y
         ●-----------●-----------●
              ↑            ↑
        interpolated 2Y  interpolated 4Y
```

The potential simplification is:

\[
6\text{ independent RFs}
\quad\longrightarrow\quad
4\text{ independent RFs}
\]

However, the legitimacy of that simplification depends on how your internal model defines the risk factors and how the interpolated basis risk is captured.

---

# 3. What interpolation cannot do

Suppose you have:

- 100 RPOs at 1Y;
- 5 RPOs at 2Y;
- 100 RPOs at 3Y.

You cannot create additional 2Y RPO dates by calculating:

\[
R_{2Y}
=
\frac{R_{1Y}+R_{3Y}}{2}
\]

The resulting value is a synthetic or model-derived observation.

It is not:

- an executed arm’s-length transaction;
- an eligible committed quote;
- another qualifying real market price.

The US NPR requires the RFET to be supported by qualifying real prices and limits counting to no more than one qualifying observation per day for the relevant risk factor. The proposed thresholds are either 24 observations with at least four in every 90-day period, or 100 observations over the prior 12 months. ([archive.fdic.gov](https://archive.fdic.gov/view/fdic/15443/fdic_15443_DS1.pdf))

Therefore:

\[
\boxed{
\text{Interpolation creates curve values, not RPOs.}
}
\]

---

# 4. Three possible regulatory designs

## Design A — Every tenor is an independent risk factor

Your ES model contains separate independent factors:

\[
R_{1Y},R_{2Y},R_{3Y},R_{4Y},R_{5Y}
\]

Under this design, the 2Y and 4Y factors remain subject to RFET.

If their applicable buckets fail, they are NMRFs even though the pricing curve can interpolate their market values.

Therefore:

| Risk factor | Pricing available? | RFET result |
|---|---:|---:|
| 2Y | Yes, through interpolation | Fail |
| 4Y | Yes, through interpolation | Fail |

Interpolation does not rescue them.

---

## Design B — Use sparse liquid pillars as the actual risk factors

Your ES model contains only:

\[
R_{1Y},R_{3Y},R_{5Y}
\]

The 2Y and 4Y values are deterministic transformations:

\[
R_{2Y}=h(R_{1Y},R_{3Y})
\]

\[
R_{4Y}=h(R_{3Y},R_{5Y})
\]

Here, you are no longer claiming that 2Y and 4Y are independently modelled stochastic risk factors.

Instead, the risk at those points is generated by shocks to neighboring liquid pillars.

This can reduce RFET burden because you have fewer independent factors requiring market-liquidity evidence.

But you must demonstrate that:

- the representation captures the material curve risk;
- the interpolation is conceptually sound;
- the same representation is used consistently in ES, RTPL and PLA;
- residual or basis risk is not ignored;
- the coarser representation does not hide material curve-shape exposure.

The Basel framework specifically says interpolation based on combinations of modellable risk factors should be consistent with the mappings used for PLA and should not be based on a separate, broader RFET bucketing arrangement. ([bis.org](https://www.bis.org/basel_framework/chapter/MAR/31.htm?tldate=20211222&utm_source=chatgpt.com))

---

## Design C — Modellable interpolated component plus NMRF basis

You could represent the 2Y rate as:

\[
R_{2Y}^{\text{actual}}
=
R_{2Y}^{\text{interpolated}}
+
B_{2Y}
\]

where:

\[
R_{2Y}^{\text{interpolated}}
=
h(R_{1Y},R_{3Y})
\]

and:

\[
B_{2Y}
=
R_{2Y}^{\text{actual}}
-
R_{2Y}^{\text{interpolated}}
\]

Then:

- the interpolated component is driven by modellable 1Y and 3Y factors;
- the residual basis \(B_{2Y}\) is treated separately;
- if that basis lacks sufficient RPOs, it becomes an NMRF.

This is the most intellectually honest design where the intermediate point has material independent behavior.

The US NPR explicitly contemplates decomposition into a modellable component and a nonmodellable basis component. It also identifies interpolation and PCA as potentially conceptually sound methods for combining modellable risk factors. ([archive.fdic.gov](https://archive.fdic.gov/view/fdic/15443/fdic_15443_DS1.pdf))

---

# 5. The critical US NPR limitation

The US NPR language is stricter than simply saying:

> If both neighboring points are modellable, the interpolated point is automatically modellable.

The proposal states that a risk factor derived from a combination of modellable factors would itself be modellable **only if that derived risk factor also passes RFET**. Alternatively, the bank may decompose it into a modellable component and an NMRF basis. ([archive.fdic.gov](https://archive.fdic.gov/view/fdic/15443/fdic_15443_DS1.pdf))

That means the following argument is not sufficient under the NPR:

> “The 1Y and 3Y rates passed, so our 2Y rate automatically passes because we interpolate it.”

A safer interpretation is:

### Permitted logic

> “Our independent model factors are 1Y and 3Y. The 2Y point is not a separate stochastic factor; it is a deterministic value generated by those factors.”

### Riskier logic

> “The 2Y rate is a separate risk factor, but we will call it modellable solely because it can be interpolated.”

The second approach conflicts with the NPR’s express requirement that a derived risk factor must also pass RFET unless the risk is decomposed appropriately. ([archive.fdic.gov](https://archive.fdic.gov/view/fdic/15443/fdic_15443_DS1.pdf))

---

# 6. How bucketing may help more than interpolation

The larger RFET optimization may come from the **standard bucketing approach**, not interpolation itself.

Under the NPR, a bank allocates each RPO to one bucket for a risk factor and counts all RPOs allocated to that bucket to determine whether the risk factors in the bucket pass. If a bucket has enough qualifying RPOs and the data-quality requirements are met, all risk factors within that bucket are deemed modellable. ([archive.fdic.gov](https://archive.fdic.gov/view/fdic/15443/fdic_15443_DS1.pdf))

For example, suppose the applicable standard bucket covers:

\[
1Y\text{–}3Y
\]

and contains:

| RPO maturity | Count |
|---|---:|
| 1Y swaps | 45 |
| 2Y swaps | 8 |
| 3Y swaps | 50 |
| Total bucket | 103 |

If the 1Y, 2Y and 3Y observations are representative of the relevant risk factors in that bucket, the total bucket may satisfy the quantitative threshold even though the standalone 2Y count is only eight.

This is materially different from saying:

> Interpolation makes the 2Y observations liquid.

The correct statement is:

> The regulatory bucket may provide a common representative RPO pool for the risk factors assigned to it.

The NPR says an RPO must be allocated to a bucket for which it is representative of the risk factors in that bucket; all allocated RPOs are then counted to assess whether those risk factors pass. ([archive.fdic.gov](https://archive.fdic.gov/view/fdic/15443/fdic_15443_DS1.pdf))

---

# 7. Your practical choices

Assume:

| Tenor | Result |
|---|---|
| 6M | Pass |
| 1Y | Pass |
| 2Y | Fail |
| 3Y | Pass |
| 4Y | Fail |
| 5Y | Pass |

You have four main options.

## Option 1: Standard regulatory bucketing

Pool representative RPOs into the applicable standard maturity bucket.

This may allow the entire bucket to pass without requiring each internal curve tenor to have its own standalone 24 or 100 observations.

This is likely your strongest direct RPO-count simplification.

---

## Option 2: Redesign the curve to liquid pillars

Use:

\[
6M,\ 1Y,\ 3Y,\ 5Y
\]

as independent ES factors and interpolate 2Y and 4Y.

This reduces the number of independent risk factors, but requires model, PLA and risk-capture justification.

---

## Option 3: Interpolated factor plus basis

Model:

\[
2Y^{\text{actual}}
=
2Y^{\text{interpolated}}
+
2Y^{\text{basis}}
\]

The interpolated part comes from liquid neighbors. The residual basis is NMRF unless it independently passes.

This preserves the missing curve-shape risk.

---

## Option 4: Leave each tenor independent

Retain all six risk factors.

Then 2Y and 4Y are NMRFs unless their buckets pass through sufficient representative RPOs.

This is the simplest conceptually, but may create higher NMRF capital.

---

# 8. Example: a trade exposed specifically to 2Y

Suppose a trade has:

\[
DV01_{2Y}=\$500{,}000
\]

If your model represents 2Y as a linear interpolation between 1Y and 3Y:

\[
R_{2Y}
=
0.5R_{1Y}+0.5R_{3Y}
\]

you might allocate the sensitivity as:

\[
DV01_{1Y}=250{,}000
\]

\[
DV01_{3Y}=250{,}000
\]

This works if the 2Y movement is well explained by the neighboring pillars.

But suppose actual changes satisfy:

\[
\Delta R_{2Y}
=
0.5\Delta R_{1Y}
+
0.5\Delta R_{3Y}
+
\Delta B_{2Y}
\]

Then the P&L is:

\[
\Delta V
=
500{,}000
\left[
0.5\Delta R_{1Y}
+
0.5\Delta R_{3Y}
\right]
+
500{,}000\Delta B_{2Y}
\]

The final term is the residual curve-basis risk:

\[
500{,}000\Delta B_{2Y}
\]

If you omit that basis, you could understate:

- key-rate risk;
- butterfly risk;
- local curve deformation;
- RTPL;
- ES;
- stressed loss.

That is why interpolation must be accompanied by evidence that the residual is immaterial or separately capitalized.

---

# 9. Why overly broad interpolation is dangerous

Assume you only keep:

\[
6M \quad\text{and}\quad 5Y
\]

and interpolate every maturity between them.

Mathematically, you can produce:

\[
1Y,\ 2Y,\ 3Y,\ 4Y
\]

But economically, you have removed:

- slope changes;
- curvature;
- humps;
- central-bank meeting effects;
- localized supply-and-demand effects;
- butterfly risk.

The NPR warns that supervisors may require factors to be treated as nonmodellable where banks use unsound extrapolation or irregular bucketing approaches. ([archive.fdic.gov](https://archive.fdic.gov/view/fdic/15443/fdic_15443_DS1.pdf))

So the objective is not:

> Minimize the number of RPO buckets at any cost.

It is:

> Find the least granular risk-factor representation that still captures all material market risk and remains consistent with pricing and PLA.

---

# 10. Is interpolation mentioned in the NPR?

**Yes.**

The 2023 US Basel III Endgame NPR expressly discusses:

1. Using combinations of modellable risk factors in calibration.
2. Decomposing a derived factor into a modellable component and a nonmodellable basis.
3. Using interpolation or PCA where conceptually sound.
4. Potential supervisory rejection of unsound extrapolation or irregular bucketing.
5. The requirement that a derived risk factor also pass RFET if it is treated as a risk factor in its own right. ([archive.fdic.gov](https://archive.fdic.gov/view/fdic/15443/fdic_15443_DS1.pdf))

The NPR also recognizes the trade-off between granular risk factors and RFET feasibility: more granular buckets may improve PLA representation, but they require sufficient real prices for each additional risk-factor bucket. ([archive.fdic.gov](https://archive.fdic.gov/view/fdic/15443/fdic_15443_DS1.pdf))

That passage strongly supports the strategic question you are asking:

\[
\boxed{
\text{How granular must the curve really be, and where can sound interpolation replace independent factors?}
}
\]

---

# 11. Recommended interpretation for your PoC

For a SOFR OIS curve, I would test three representations:

| Representation | Independent RFs | Treatment of missing tenors |
|---|---|---|
| Full granularity | 6M, 1Y, 2Y, 3Y, 4Y, 5Y | Failed tenors become NMRF unless bucket passes |
| Liquid pillars | 6M, 1Y, 3Y, 5Y | 2Y and 4Y derived by interpolation |
| Pillar plus basis | 6M, 1Y, 3Y, 5Y plus residuals | Interpolation modellable; residual basis tested/NMRF |

For each representation, measure:

- RFET pass rate;
- NMRF capital;
- RTPL impact;
- PLA impact;
- ES change;
- residual unexplained P&L;
- key-rate and butterfly-risk capture;
- hedge representation.

My preliminary conclusion is:

\[
\boxed{
\text{Standard bucketing simplifies RPO counting; interpolation simplifies the model representation.}
}
\]

They are complementary but not interchangeable.

Interpolation helps you avoid requiring an independent liquid calibration point at every internal tenor. Standard bucketing helps you use representative RPOs across a regulatory maturity segment. Neither allows you to manufacture qualifying RPOs for an otherwise illiquid factor.

---

## Message 19 — User

What is the regulatory or baseline language on the below points
The 2023 US Basel III Endgame NPR expressly discusses:
Using combinations of modellable risk factors in calibration.
Decomposing a derived factor into a modellable component and a nonmodellable basis.
Using interpolation or PCA where conceptually sound.
Potential supervisory rejection of unsound extrapolation or irregular bucketing.
The requirement that a derived risk factor also pass RFET if it is treated as a risk factor in its own right. �
FDIC Archive
The NPR also recognizes the trade-off between granular risk factors and RFET feasibility: more granular buckets may improve PLA representation, but they require sufficient real prices for each additional risk-factor bucket. �
FDIC Archive

---

## Message 20 — Assistant update

I’ll pull the exact NPR passages and separate verbatim regulatory language from interpretation, so you can see precisely what is stated versus inferred.

---

## Message 21 — Assistant

The points come from **two different layers** of the 2023 US Basel III Endgame NPR:

1. **The proposed regulatory text**—the operative language that would have been inserted into the capital rule.
2. **The Supplementary Information/preamble**—the agencies’ explanation of how they intended the proposed rule to work.

That distinction matters because most of the detailed language on interpolation, PCA, basis decomposition and supervisory challenge appears in the **preamble**, while the proposed rule text is much shorter.

---

# 1. Combinations of modellable risk factors

## Proposed rule text

The proposed rule states:

> “The data used may include combinations of modellable risk factors.”

This appears in the proposed regulatory text under the data requirements for modellable risk factors. It establishes the baseline permission to use combinations of modellable factors when calibrating the ES-based measure. ([archive.fdic.gov](https://archive.fdic.gov/view/fdic/15443/fdic_15443_DS1.pdf))

The relevant proposed rule structure is:

\[
\text{Risk factor passes RFET}
\rightarrow
\text{calibration data satisfy data-quality requirements}
\rightarrow
\text{factor may enter ES}
\]

The proposal separately says that a bank may use different calibration data from the RPO data used to pass RFET. ([archive.fdic.gov](https://archive.fdic.gov/view/fdic/15443/fdic_15443_DS1.pdf))

## Preamble explanation

The preamble expands this by saying the data used to calibrate the IMCC ES model may include combinations of other modellable risk factors. ([archive.fdic.gov](https://archive.fdic.gov/view/fdic/15443/fdic_15443_DS1.pdf))

### Meaning

The NPR permits a bank to construct a model input using other modellable inputs. For example:

\[
R_{2Y}^{\text{derived}}
=
w_1R_{1Y}+w_3R_{3Y}
\]

But this permission concerns the **data and calibration methodology**. It does not, by itself, waive the RFET requirement for a separately identified 2Y risk factor.

---

# 2. Derived risk factor must also pass RFET

This requirement is expressly stated in the **preamble**:

> A risk factor derived from modellable risk factors is modellable only if the derived factor also passes RFET.

The exact discussion appears on Federal Register page 64134. ([archive.fdic.gov](https://archive.fdic.gov/view/fdic/15443/fdic_15443_DS1.pdf))

In logical form:

\[
RF_1\text{ passes}
\quad+\quad
RF_3\text{ passes}
\]

does **not automatically imply**:

\[
RF_{2Y}=h(RF_1,RF_3)\text{ passes}
\]

If the 2Y point remains a risk factor in its own right, the NPR’s preamble indicates that it must itself satisfy RFET.

## Important drafting distinction

The detailed “derived factor must also pass” condition is not spelled out with the same specificity in proposed §__.214(b)(7). The codified proposal only says that calibration data may include combinations of modellable risk factors. The additional condition appears in the agencies’ explanatory preamble. ([archive.fdic.gov](https://archive.fdic.gov/view/fdic/15443/fdic_15443_DS1.pdf))

Nevertheless, the preamble is strong evidence of the agencies’ intended interpretation.

---

# 3. Modellable component plus nonmodellable basis

The NPR preamble provides an alternative to treating the entire derived factor as one risk factor.

A banking organization may decompose it into:

\[
R^{\text{actual}}
=
R^{\text{modellable component}}
+
R^{\text{basis}}
\]

where the basis represents the difference between the modellable representation and the actual nonmodellable risk factor. ([archive.fdic.gov](https://archive.fdic.gov/view/fdic/15443/fdic_15443_DS1.pdf))

For your SOFR example:

\[
R_{2Y}^{\text{actual}}
=
R_{2Y}^{\text{interpolated}}
+
B_{2Y}
\]

with:

\[
R_{2Y}^{\text{interpolated}}
=
h(R_{1Y},R_{3Y})
\]

and:

\[
B_{2Y}
=
R_{2Y}^{\text{actual}}
-
h(R_{1Y},R_{3Y})
\]

The treatment would conceptually be:

| Component | Regulatory treatment |
|---|---|
| Interpolated component based on modellable factors | Potentially included in ES |
| Residual 2Y basis | NMRF unless separately supportable as modellable |

This is the regulatory basis for saying:

> Interpolation may provide the modellable component, but the unexplained local basis cannot simply disappear.

---

# 4. Interpolation and PCA

The NPR preamble expressly identifies two methodologies:

- interpolation;
- principal component analysis.

The agencies say these approaches may be used to derive modellable risk factors from combinations of other modellable factors, provided that the methods are **conceptually sound**. ([archive.fdic.gov](https://archive.fdic.gov/view/fdic/15443/fdic_15443_DS1.pdf))

For an interest-rate curve, examples include:

## Interpolation

\[
R_{2Y}
=
wR_{1Y}+(1-w)R_{3Y}
\]

or interpolation in:

- zero rates;
- discount factors;
- log discount factors;
- forward rates.

## PCA

A full curve may be represented by a smaller number of orthogonal factors:

\[
\Delta R(t)
=
\beta_{1,t}PC_1
+
\beta_{2,t}PC_2
+
\beta_{3,t}PC_3
+
\epsilon_t
\]

where the principal components frequently correspond economically to:

- level;
- slope;
- curvature.

The NPR does not say that interpolation or PCA is automatically acceptable. The qualifier is that the method must be conceptually sound and remains subject to supervisory review. ([archive.fdic.gov](https://archive.fdic.gov/view/fdic/15443/fdic_15443_DS1.pdf))

---

# 5. Supervisory rejection of unsound extrapolation or irregular bucketing

The preamble says the agencies intended to use supervisory horizontal reviews to assess banks’ use of combinations of risk factors.

It then gives a specific example: supervisors could require factors to be treated as nonmodellable where a bank uses:

- unsound extrapolation; or
- irregular bucketing approaches.

([archive.fdic.gov](https://archive.fdic.gov/view/fdic/15443/fdic_15443_DS1.pdf))

The practical implication is:

\[
\text{Mathematically possible interpolation}
\neq
\text{regulatorily acceptable representation}
\]

For example, deriving every tenor from only a 6M and 10Y quote could generate a complete curve mathematically, but it might materially suppress:

- local slope risk;
- butterfly risk;
- central-bank meeting effects;
- tenor-specific liquidity;
- curve-basis volatility.

The proposed rule also expressly gives the agency authority to determine that data used for modellable factors are unsuitable for ES calibration. ([archive.fdic.gov](https://archive.fdic.gov/view/fdic/15443/fdic_15443_DS1.pdf))

---

# 6. Granularity versus RFET feasibility

This trade-off appears clearly in the NPR preamble’s discussion of bucketing.

The agencies state that more granular buckets may help a desk pass PLA because the risk-factor structure can align more closely with front-office pricing. But the same granularity makes RFET harder because the bank must source enough real prices for every additional risk-factor bucket. ([archive.fdic.gov](https://archive.fdic.gov/view/fdic/15443/fdic_15443_DS1.pdf))

The regulatory tension can be expressed as:

\[
\text{More granularity}
\Rightarrow
\begin{cases}
\text{better pricing and PLA representation}\\
\text{more RFET buckets requiring RPO support}
\end{cases}
\]

Conversely:

\[
\text{Less granularity}
\Rightarrow
\begin{cases}
\text{easier RPO concentration and RFET support}\\
\text{greater risk of missing local curve risk}\\
\text{potentially weaker PLA performance}
\end{cases}
\]

The agencies therefore proposed flexibility for a bank to use its own bucketing structure, but imposed an additional burden to demonstrate that a more granular structure is appropriate. The own buckets must also correspond to the segmentation used in the internal model for PLA purposes. ([archive.fdic.gov](https://archive.fdic.gov/view/fdic/15443/fdic_15443_DS1.pdf))

---

# 7. Regulatory bucket language

The proposed regulatory text provides that:

- every RPO must be allocated to one bucket for a risk factor;
- all RPOs allocated to that bucket are counted to assess whether the risk factors in the bucket pass;
- buckets must be formed at the curve or surface level;
- the bank may use the prescribed standard buckets or its own buckets;
- under the own-bucketing approach, each bucket contains only one risk factor;
- the own risk factor must correspond to a factor included in RTPL.

([archive.fdic.gov](https://archive.fdic.gov/view/fdic/15443/fdic_15443_DS1.pdf))

The preamble adds that an RPO should be allocated to a bucket for which it is representative of the risk factors in that bucket, and all prices mapped to that bucket are counted. ([archive.fdic.gov](https://archive.fdic.gov/view/fdic/15443/fdic_15443_DS1.pdf))

Therefore, for a standard bucket containing 1Y, 2Y and 3Y risk factors, the relevant question is not necessarily:

> Did the 2Y tenor independently receive 24 observations?

It may instead be:

> Does the applicable regulatory bucket contain enough representative RPOs, and are those observations representative of the risk factors assigned to that bucket?

That is the regulatory pooling mechanism. It is separate from interpolation.

---

# 8. RFET threshold language

The proposed rule requires sufficient representative real prices and establishes either:

\[
24\text{ observations over 12 months}
\]

with:

\[
\geq4\text{ observations in every 90-day period}
\]

or:

\[
100\text{ observations over 12 months}
\]

with no more than one qualifying observation counted per day for the relevant position/risk-factor treatment. ([archive.fdic.gov](https://archive.fdic.gov/view/fdic/15443/fdic_15443_DS1.pdf))

If a standard or own bucket has enough real prices and its risk factors satisfy the data-quality requirements, all risk factors within the bucket are deemed modellable. Otherwise, the failed factors are classified as NMRFs. ([archive.fdic.gov](https://archive.fdic.gov/view/fdic/15443/fdic_15443_DS1.pdf))

---

# 9. Putting the provisions together

For an interpolated 2Y SOFR point between liquid 1Y and 3Y points, the NPR supports three possible analyses.

## Case A: 2Y is independently defined as a risk factor

Then the preamble indicates:

\[
2Y\text{ derived factor must pass RFET}
\]

The fact that 1Y and 3Y are modellable does not automatically make 2Y modellable. ([archive.fdic.gov](https://archive.fdic.gov/view/fdic/15443/fdic_15443_DS1.pdf))

## Case B: 2Y is not an independent risk factor

The model could define only 1Y and 3Y as stochastic factors and calculate the 2Y curve value deterministically from them.

In that design, the bank must still demonstrate:

- conceptual soundness;
- appropriate volatility and correlation;
- capture of material local basis risk;
- consistency with RTPL/PLA;
- no unsound extrapolation or irregular bucketing.

The NPR does not expressly grant an automatic exemption simply because the 2Y value is called an interpolation output.

## Case C: 2Y is decomposed

\[
R_{2Y}
=
R_{2Y}^{\text{interpolated}}
+
B_{2Y}
\]

The interpolated component may be based on modellable inputs, while the residual basis is treated as nonmodellable unless independently supported. This is the clearest approach expressly contemplated by the preamble. ([archive.fdic.gov](https://archive.fdic.gov/view/fdic/15443/fdic_15443_DS1.pdf))

---

# 10. What is explicit versus interpretive

| Statement | NPR location | Status |
|---|---|---|
| Calibration data may include combinations of modellable RFs | Proposed regulatory text | Explicit |
| Derived RF must also pass RFET | Preamble | Explicit agency interpretation |
| Derived factor may be split into modellable component and NMRF basis | Preamble | Explicit |
| Interpolation and PCA may be used if conceptually sound | Preamble | Explicit |
| Unsound extrapolation or irregular bucketing can cause NMRF treatment | Preamble | Explicit supervisory intent |
| More granular buckets help PLA but make RFET harder | Preamble | Explicit |
| Standard buckets pool representative RPOs | Proposed rule and preamble | Explicit |
| Interpolation manufactures new RPOs | Nowhere; it does not | Not permitted/inconsistent with RFET |
| Liquid neighboring tenors automatically make an intermediate tenor modellable | Not stated | Unsupported |

# Bottom line

The most defensible reading of the 2023 NPR is:

\[
\boxed{
\text{Interpolation is permitted as a calibration or risk-factor derivation technique, not as a substitute for qualifying real-price evidence.}
}
\]

And:

\[
\boxed{
\text{If the interpolated point remains a distinct risk factor, it must pass RFET or its residual basis must be treated as nonmodellable.}
}
\]

The direct mechanism for reducing RPO-count pressure is primarily **standard regulatory bucketing**. Interpolation and PCA help reduce or transform the model’s independent factor representation, but they remain subject to the RFET, data-quality, PLA consistency and supervisory-soundness requirements.

---

## Message 22 — User

Now I have another issue.
Which is , i present risk factor using forward buckets but my rpos is at swap rate

Tenor
Result
6M
Pass
1Y
Pass
2Y
Fail
3Y
Pass
4Y
Fail
5Y
Pass

In this case, because 2Y fails, or 4Y fails, does tjat mean all my forward buckets after 2Y would fails the rpo count?

---

## Message 23 — Assistant update

I’ll separate the **mathematical dependency** of forward buckets from the **regulatory RFET mapping**, because a failed 2Y swap quote does not automatically imply every forward bucket beyond 2Y fails.

---

## Message 24 — Assistant

No. A failed 2Y swap-rate RPO bucket does **not automatically make every forward-rate bucket after 2Y nonmodellable**.

The correct answer depends on how the swap-rate observations are mapped to your forward risk factors and which RFET bucketing approach you use.

# 1. Separate three different things

You have:

1. **Market observations:** par SOFR swap rates  
   \[
   S_{6M},S_{1Y},S_{2Y},S_{3Y},S_{4Y},S_{5Y}
   \]

2. **Curve-construction variables:** discount factors  
   \[
   P(0,6M),P(0,1Y),\ldots,P(0,5Y)
   \]

3. **Internal ES risk factors:** forward buckets, for example  
   \[
   F(0,6M),F(6M,1Y),F(1Y,2Y),F(2Y,3Y),F(3Y,4Y),F(4Y,5Y)
   \]

The fact that forward rates are mathematically derived from the full par curve does not mean the RFET result must mechanically cascade through every later tenor.

RFET is based on whether a real price is **representative of the risk factor** and whether the applicable risk-factor bucket has enough qualifying observations. A price is representative when the institution can extract the value of the risk factor from that real price, subject to documented mapping methodology. ([osfi-bsif.gc.ca](https://www.osfi-bsif.gc.ca/en/guidance/guidance-library/capital-adequacy-requirements-car-2024-chapter-9-market-risk))

---

# 2. Mathematical dependence does extend beyond 2Y

For example:

\[
F(2Y,3Y)
=
\frac{P(0,2Y)/P(0,3Y)-1}{1}
\]

and:

\[
F(3Y,4Y)
=
\frac{P(0,3Y)/P(0,4Y)-1}{1}
\]

The discount factors \(P(0,3Y)\) and \(P(0,4Y)\) were bootstrapped using earlier par quotes, potentially including the 2Y quote.

Therefore, in the numerical calibration:

\[
S_{2Y}\longrightarrow P(0,2Y),P(0,3Y),P(0,4Y),\ldots
\]

There can be a nonzero Jacobian relationship such as:

\[
\frac{\partial F(3Y,4Y)}{\partial S_{2Y}}\neq0
\]

But that mathematical sensitivity is not itself the RFET decision.

RFET asks whether each forward risk factor, or the regulatory bucket containing it, has sufficient representative real prices.

---

# 3. The simplest mapping intuition

Consider these forward buckets:

| Forward risk factor | Most directly associated par-curve region |
|---|---|
| \(F(0,6M)\) | 6M instruments |
| \(F(6M,1Y)\) | 6M and 1Y instruments |
| \(F(1Y,2Y)\) | 1Y and 2Y instruments |
| \(F(2Y,3Y)\) | 2Y and 3Y instruments |
| \(F(3Y,4Y)\) | 3Y and 4Y instruments |
| \(F(4Y,5Y)\) | 4Y and 5Y instruments |

If the 2Y par point lacks sufficient RPOs, the most directly affected forward buckets are normally:

\[
F(1Y,2Y)
\quad\text{and potentially}\quad
F(2Y,3Y)
\]

It does not necessarily follow that:

\[
F(3Y,4Y)
\quad\text{or}\quad
F(4Y,5Y)
\]

must fail merely because the 2Y par quote failed.

Likewise, a failed 4Y point would most directly affect the forward segments around 4Y:

\[
F(3Y,4Y),\quad F(4Y,5Y)
\]

not every later forward on the curve.

---

# 4. Why there is no automatic “all later forwards fail” rule

The Basel RFET language says that a real price should be counted for all risk factors for which it is representative. It also says a real price is representative where the bank can extract the risk-factor value from that real price. ([osfi-bsif.gc.ca](https://www.osfi-bsif.gc.ca/en/guidance/guidance-library/capital-adequacy-requirements-car-2024-chapter-9-market-risk))

That supports a mapping based on economic representativeness, not simply on every mathematical dependency in the bootstrap.

A 5Y swap price mathematically depends on discount factors from today through 5Y, but it would be too broad to argue that one 5Y swap RPO automatically supports every individual forward bucket from overnight through 5Y.

You need a methodology demonstrating which forwards can reasonably be extracted from which swap observations.

---

# 5. Scenario A: Own bucketing at the forward-risk-factor level

Under own bucketing:

- each bucket contains only one risk factor;
- the risk factors must correspond to RTPL risk factors;
- buckets must not overlap. ([osfi-bsif.gc.ca](https://www.osfi-bsif.gc.ca/en/guidance/guidance-library/capital-adequacy-requirements-car-2024-chapter-9-market-risk))

Suppose your own buckets are:

| Own RFET bucket | Forward RF |
|---|---|
| B1 | \(F(0,6M)\) |
| B2 | \(F(6M,1Y)\) |
| B3 | \(F(1Y,2Y)\) |
| B4 | \(F(2Y,3Y)\) |
| B5 | \(F(3Y,4Y)\) |
| B6 | \(F(4Y,5Y)\) |

Then each forward bucket must have enough representative RPOs.

Your par swap observations must be translated or mapped to those forward factors.

A possible result might be:

| Forward RF | Relevant swap RPO support | Possible RFET result |
|---|---|---|
| \(F(0,6M)\) | 6M | Pass |
| \(F(6M,1Y)\) | 6M, 1Y | Pass |
| \(F(1Y,2Y)\) | 1Y, 2Y | Fail |
| \(F(2Y,3Y)\) | 2Y, 3Y | Depends on mapping/counts |
| \(F(3Y,4Y)\) | 3Y, 4Y | Fail or depends |
| \(F(4Y,5Y)\) | 4Y, 5Y | Depends on mapping/counts |

The failed 2Y par point does not automatically force B5 or B6 to fail.

But B3 and B4 may be difficult to support because both touch the 2Y curve segment.

---

# 6. Scenario B: Regulatory bucketing

For interest-rate risk factors with one maturity dimension, the standard maturity buckets include:

\[
0\le t<0.75
\]

\[
0.75\le t<1.5
\]

\[
1.5\le t<4
\]

\[
4\le t<7
\]

and longer buckets thereafter. ([osfi-bsif.gc.ca](https://www.osfi-bsif.gc.ca/en/guidance/guidance-library/capital-adequacy-requirements-car-2024-chapter-9-market-risk))

Your tenors would approximately fall into:

| Tenor | Regulatory bucket |
|---|---|
| 6M | \(0\)–\(0.75Y\) |
| 1Y | \(0.75\)–\(1.5Y\) |
| 2Y | \(1.5\)–\(4Y\) |
| 3Y | \(1.5\)–\(4Y\) |
| 4Y | \(4\)–\(7Y\) |
| 5Y | \(4\)–\(7Y\) |

Under regulatory bucketing, all representative RPOs assigned to a bucket may be counted in assessing whether risk factors in that bucket pass. ([osfi-bsif.gc.ca](https://www.osfi-bsif.gc.ca/en/guidance/guidance-library/capital-adequacy-requirements-car-2024-chapter-9-market-risk))

Therefore:

### Bucket \(1.5Y\)–\(4Y\)

This could contain representative RPOs from:

- 2Y swaps;
- 3Y swaps;
- possibly other instruments in that maturity region.

Even if standalone 2Y observations fail, the regulatory bucket may pass based on the combined representative observations.

### Bucket \(4Y\)–\(7Y\)

This could contain:

- 4Y swaps;
- 5Y swaps;
- possibly 6Y or 7Y observations.

Even if standalone 4Y observations fail, the bucket could pass because 5Y observations provide sufficient representative evidence.

This is why the table:

| Tenor | Standalone result |
|---|---|
| 2Y | Fail |
| 3Y | Pass |

does not necessarily mean the regulatory \(1.5Y\)–\(4Y\) bucket fails.

You need to test the bucket, not merely each instrument tenor in isolation.

---

# 7. How to assign maturity to a forward bucket

This is an important design decision.

For:

\[
F(2Y,3Y)
\]

possible maturity representations include:

- start maturity: 2Y;
- end maturity: 3Y;
- midpoint: 2.5Y;
- period represented by both dimensions.

For a standard one-dimensional forward curve, banks usually need a documented rule that reflects how the risk factor is represented in RTPL and ES.

If the forward is represented by its end date, then:

\[
F(2Y,3Y)\rightarrow3Y
\]

and it falls in:

\[
1.5Y\le t<4Y
\]

Similarly:

\[
F(3Y,4Y)\rightarrow4Y
\]

which would fall in:

\[
4Y\le t<7Y
\]

because the standard bucket boundary is inclusive at 4Y for the latter bucket. ([osfi-bsif.gc.ca](https://www.osfi-bsif.gc.ca/en/guidance/guidance-library/capital-adequacy-requirements-car-2024-chapter-9-market-risk))

But your bank must define this consistently. You should not choose start date for one forward and end date for another merely to optimize modellability.

---

# 8. A more accurate interpretation of your results

Assume the standalone swap observations are:

| Swap tenor | Standalone count result |
|---|---|
| 6M | Pass |
| 1Y | Pass |
| 2Y | Fail |
| 3Y | Pass |
| 4Y | Fail |
| 5Y | Pass |

A reasonable first assessment is:

### Short end

\[
F(0,6M),F(6M,1Y)
\]

likely have strong support.

### Around 2Y

\[
F(1Y,2Y)
\]

has weak direct support.

\[
F(2Y,3Y)
\]

may still have support from the 3Y swap and from the combined \(1.5Y\)–\(4Y\) regulatory bucket, depending on representativeness.

### Around 4Y

\[
F(3Y,4Y)
\]

has weak direct 4Y support.

\[
F(4Y,5Y)
\]

may still be supportable using the 5Y observations and the combined \(4Y\)–\(7Y\) regulatory bucket.

Thus the likely pattern is local gaps around failed pillars, not an automatic failure cascade.

---

# 9. When could failures cascade more broadly?

A broader cascade could occur if your model defines each forward as a derived combination of factors mapped to distinct RFET buckets.

The Basel rule says:

> A risk factor derived from a combination of modellable risk factors mapped to distinct buckets is modellable only if the derived risk factor also passes RFET.

Interpolation must also be consistent with the RTPL mapping and cannot rely on broader alternative buckets solely for the interpolation. ([osfi-bsif.gc.ca](https://www.osfi-bsif.gc.ca/en/guidance/guidance-library/capital-adequacy-requirements-car-2024-chapter-9-market-risk))

For example, suppose:

\[
F(3Y,5Y)
=
g(S_{1Y},S_{2Y},S_{3Y},S_{4Y},S_{5Y})
\]

and your methodology says the factor depends materially on all five separate RFET buckets.

If one required input is NMRF and you have no separately passing RFET test for the derived forward, you may not be able to classify the complete derived factor as modellable.

But that is different from an automatic rule saying:

> Any earlier failed quote makes all later forwards NMRF.

The result depends on the formal factor representation and mapping.

---

# 10. Parametric-function exception

There is another potentially relevant provision.

Where a bank uses a parametric function to represent a curve and defines the function’s parameters as risk factors, the RFET must be passed at the level of the **market data used to calibrate the parameters**, rather than directly at the unobservable parameter level. ([osfi-bsif.gc.ca](https://www.osfi-bsif.gc.ca/en/guidance/guidance-library/capital-adequacy-requirements-car-2024-chapter-9-market-risk))

For example, if your forward curve is generated by parameters:

\[
\theta=(\theta_1,\theta_2,\theta_3)
\]

and those parameters are calibrated from swap rates, the RFET may be conducted on the swap-rate market data used to calibrate \(\theta\).

However, ordinary forward buckets such as:

\[
F(1Y,2Y),F(2Y,3Y),F(3Y,4Y)
\]

are not necessarily a parametric representation. They may simply be individual curve risk factors. You should not assume the parametric-function rule applies unless the model genuinely uses parameters of a curve function as its risk factors.

---

# 11. The main mapping test you need

For every forward bucket, ask:

> Which real-price instruments allow us to extract the value of this forward risk factor?

For example:

| Forward factor | Candidate representative RPOs |
|---|---|
| \(F(1Y,2Y)\) | 1Y and 2Y swaps, forward-starting swaps, SOFR futures covering the period |
| \(F(2Y,3Y)\) | 2Y and 3Y swaps, 1Y×2Y forward swaps, relevant futures |
| \(F(3Y,4Y)\) | 3Y and 4Y swaps, 1Y forward starting at 3Y |
| \(F(4Y,5Y)\) | 4Y and 5Y swaps, 1Y forward starting at 4Y |

The strongest observations are instruments that directly isolate the forward period, such as:

\[
2Y\times1Y
\]

or equivalently a one-year swap starting in two years.

Spot-starting par swaps provide indirect information because the forward must be extracted through the curve bootstrap.

That may still be representative, but the extraction methodology and Jacobian should be documented.

---

# 12. Recommended PoC design

Build an RPO-to-forward mapping matrix:

\[
M_{ij}
=
\text{representativeness of swap quote }j
\text{ for forward RF }i
\]

For example:

| Forward RF | 1Y swap | 2Y swap | 3Y swap | 4Y swap | 5Y swap |
|---|---:|---:|---:|---:|---:|
| \(F(0,1Y)\) | High | Low | Low | Low | Low |
| \(F(1Y,2Y)\) | Medium | High | Medium | Low | Low |
| \(F(2Y,3Y)\) | Low | Medium | High | Medium | Low |
| \(F(3Y,4Y)\) | Low | Low | Medium | High | Medium |
| \(F(4Y,5Y)\) | Low | Low | Low | Medium | High |

Then use:

- instrument cash-flow structure;
- quote-to-forward Jacobian;
- interpolation methodology;
- RFET standard bucket;
- RTPL mapping;

to justify whether each observation is representative.

Do not use the Jacobian mechanically as the only test. A tiny nonzero sensitivity does not necessarily make an RPO economically representative.

# Bottom line

\[
\boxed{\text{A failed 2Y swap-rate point does not automatically make all forwards after 2Y fail.}}
\]

More precisely:

- It can weaken the modellability evidence for forwards adjacent to 2Y.
- A failed 4Y point can weaken forwards adjacent to 4Y.
- Standard regulatory bucketing may allow the combined 2Y/3Y or 4Y/5Y RPO pool to pass.
- Each forward factor still needs a documented representative-RPO mapping.
- If the forward is derived across distinct RFET buckets, the derived factor may also need to pass RFET.
- Mathematical bootstrap dependency alone is not equivalent to regulatory nonmodellability.

---

## Message 25 — User

save all the teaching materiasl as .MD file

---

## Message 26 — Assistant update

I’ll consolidate the full learning sequence into one structured Markdown handbook: SOFR curve foundations, bootstrapping, forwards, interpolation, Jacobians, and the FRTB IMA/RPO implications.

---

## Message 27 — Assistant

Saved the full teaching material as a Markdown handbook:

[Download the SOFR Forward Curve and FRTB RPO Teaching Handbook](sandbox:/mnt/data/SOFR_Forward_Curve_FRTB_RPO_Teaching_Handbook.md)

---

## Message 28 — User

please. save All , every notes, every details ( exact the same ) that are discused on this thread as MD. and word documents. 

i don't want to copy paste. do it for me. 

Don't change the syntax--> save ever question and response on this thread as is

---

## Message 29 — Assistant update

I’ll compile the complete visible user-and-assistant transcript from this thread, preserving the original wording and markdown syntax, into both `.md` and `.docx` files.

---

## Message 30 — Assistant update

I’m preserving the transcript as a verbatim archive of the visible **User** and **Assistant** messages, including intermediate assistant updates, while excluding hidden system instructions and internal tool logs.

---

## Message 31 — Assistant update

The archive will use raw markdown text inside the Word document rather than converting formulas and headings into styled Word objects. That keeps the wording, code fences, tables, equations, and links unchanged.
