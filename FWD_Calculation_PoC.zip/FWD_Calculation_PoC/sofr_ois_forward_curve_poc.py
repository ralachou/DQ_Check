"""
Educational SOFR OIS curve bootstrap.

Purpose
-------
Convert hypothetical par OIS quotes into:
1. discount factors P(0,T)
2. continuously compounded zero rates z(T)
3. simple forward rates between adjacent curve pillars
4. instantaneous forward approximations
5. a quote-to-forward Jacobian by bump-and-rebootstrap

This is a teaching PoC, not a production curve engine. It simplifies calendars,
payment lags, lookbacks, lockouts, day-count details, and uses year fractions
directly. Production implementation should use dated cash flows and full market
conventions.
"""

from __future__ import annotations

import numpy as np
import pandas as pd
from scipy.optimize import brentq


# Hypothetical par SOFR OIS quotes, entered as decimals.
MARKET_QUOTES = {
    "1M": 0.0430,
    "3M": 0.0428,
    "6M": 0.0425,
    "9M": 0.0422,
    "1Y": 0.0420,
    "2Y": 0.0405,
    "3Y": 0.0395,
    "4Y": 0.0390,
    "5Y": 0.0388,
    "10Y": 0.0395,
    "20Y": 0.0402,
    "30Y": 0.0400,
}

TENOR_TO_YEARS = {
    "1M": 1.0 / 12.0,
    "3M": 3.0 / 12.0,
    "6M": 6.0 / 12.0,
    "9M": 9.0 / 12.0,
    "1Y": 1.0,
    "2Y": 2.0,
    "3Y": 3.0,
    "4Y": 4.0,
    "5Y": 5.0,
    "10Y": 10.0,
    "20Y": 20.0,
    "30Y": 30.0,
}


def fixed_payment_times(maturity: float) -> np.ndarray:
    """Annual fixed payments, plus a final stub if maturity is below/unequal 1Y."""
    if maturity <= 1.0:
        return np.array([maturity], dtype=float)

    whole_years = int(np.floor(maturity + 1e-12))
    times = list(np.arange(1.0, whole_years + 1.0, 1.0))
    if maturity - whole_years > 1e-10:
        times.append(maturity)
    return np.asarray(times, dtype=float)


def accrual_fractions(payment_times: np.ndarray) -> np.ndarray:
    """Year fractions from one payment date to the next."""
    return np.diff(np.concatenate(([0.0], payment_times)))


def log_linear_discount(
    query_times: np.ndarray | float,
    node_times: np.ndarray,
    node_dfs: np.ndarray,
) -> np.ndarray:
    """
    Log-linear interpolation of discount factors.

    ln P(0,t) is linear between adjacent nodes. P(0,0)=1 is included.
    """
    q = np.atleast_1d(np.asarray(query_times, dtype=float))
    times = np.concatenate(([0.0], np.asarray(node_times, dtype=float)))
    log_dfs = np.concatenate(([0.0], np.log(np.asarray(node_dfs, dtype=float))))

    if np.any(q < -1e-14) or np.any(q > times[-1] + 1e-12):
        raise ValueError("Interpolation requested outside solved curve range.")

    result = np.exp(np.interp(q, times, log_dfs))
    return result


def par_ois_rate(
    maturity: float,
    node_times: np.ndarray,
    node_dfs: np.ndarray,
) -> float:
    """
    Simplified spot-starting OIS par rate.

    Fixed-leg PV per unit notional:
        K * sum_i(alpha_i * P(0,t_i))

    Floating-leg PV per unit notional for a spot-starting par OIS:
        1 - P(0,T)

    Therefore:
        K = [1 - P(0,T)] / sum_i(alpha_i * P(0,t_i))
    """
    pay_times = fixed_payment_times(maturity)
    accruals = accrual_fractions(pay_times)
    dfs = log_linear_discount(pay_times, node_times, node_dfs)
    annuity = float(np.dot(accruals, dfs))
    return (1.0 - dfs[-1]) / annuity


def bootstrap_ois_curve(market_quotes: dict[str, float]) -> pd.DataFrame:
    """
    Sequentially solve one discount factor per market quote.

    At each pillar T_n, choose P(0,T_n) so the model par rate equals
    the observed market par rate. Intermediate coupon-date DFs are obtained
    by log-linear interpolation.
    """
    labels = sorted(market_quotes, key=lambda x: TENOR_TO_YEARS[x])
    solved_times: list[float] = []
    solved_dfs: list[float] = []

    for label in labels:
        maturity = TENOR_TO_YEARS[label]
        quote = market_quotes[label]

        def objective(candidate_df: float) -> float:
            trial_times = np.asarray(solved_times + [maturity], dtype=float)
            trial_dfs = np.asarray(solved_dfs + [candidate_df], dtype=float)
            return par_ois_rate(maturity, trial_times, trial_dfs) - quote

        # Educationally broad positive-DF bracket.
        candidate = brentq(objective, 1e-6, 2.0)
        solved_times.append(maturity)
        solved_dfs.append(candidate)

    times = np.asarray(solved_times)
    dfs = np.asarray(solved_dfs)
    quotes = np.asarray([market_quotes[x] for x in labels])

    zero_cc = -np.log(dfs) / times

    prev_times = np.concatenate(([0.0], times[:-1]))
    prev_dfs = np.concatenate(([1.0], dfs[:-1]))
    simple_fwds = (prev_dfs / dfs - 1.0) / (times - prev_times)
    cc_fwds = np.log(prev_dfs / dfs) / (times - prev_times)

    curve = pd.DataFrame(
        {
            "tenor": labels,
            "time_years": times,
            "market_par_rate": quotes,
            "discount_factor": dfs,
            "zero_rate_cc": zero_cc,
            "simple_forward_from_previous": simple_fwds,
            "cc_forward_from_previous": cc_fwds,
        }
    )

    # Confirm exact repricing.
    curve["repriced_par_rate"] = [
        par_ois_rate(t, times[: i + 1], dfs[: i + 1])
        for i, t in enumerate(times)
    ]
    curve["repricing_error_bp"] = (
        curve["repriced_par_rate"] - curve["market_par_rate"]
    ) * 10_000.0

    return curve


def forward_from_discount_factors(
    df_start: float,
    df_end: float,
    year_fraction: float,
) -> float:
    """Simple annualized forward rate F(t1,t2)."""
    if df_start <= 0.0 or df_end <= 0.0 or year_fraction <= 0.0:
        raise ValueError("Discount factors and year fraction must be positive.")
    return (df_start / df_end - 1.0) / year_fraction


def quote_to_forward_jacobian(
    market_quotes: dict[str, float],
    bump_bp: float = 1.0,
) -> pd.DataFrame:
    """
    Finite-difference Jacobian:
        J[i,j] = d Forward_i / d Quote_j

    Each quote is bumped independently, then the entire curve is re-bootstrapped.
    Values are shown as basis points of forward movement per 1 bp quote bump.
    """
    base = bootstrap_ois_curve(market_quotes)
    base_fwds = base["simple_forward_from_previous"].to_numpy()
    quote_labels = base["tenor"].tolist()
    jac = np.zeros((len(base_fwds), len(quote_labels)))

    bump = bump_bp / 10_000.0
    for j, quote_label in enumerate(quote_labels):
        bumped_quotes = dict(market_quotes)
        bumped_quotes[quote_label] += bump
        bumped_curve = bootstrap_ois_curve(bumped_quotes)
        bumped_fwds = bumped_curve["simple_forward_from_previous"].to_numpy()
        jac[:, j] = (bumped_fwds - base_fwds) * 10_000.0 / bump_bp

    return pd.DataFrame(
        jac,
        index=[f"FWD_{x}" for x in quote_labels],
        columns=[f"QUOTE_{x}" for x in quote_labels],
    )


def main() -> None:
    curve = bootstrap_ois_curve(MARKET_QUOTES)
    jacobian = quote_to_forward_jacobian(MARKET_QUOTES)

    pd.set_option("display.width", 180)
    pd.set_option("display.max_columns", 20)
    pd.set_option("display.float_format", lambda x: f"{x:,.8f}")

    print("\nBOOTSTRAPPED SOFR OIS CURVE\n")
    print(curve.to_string(index=False))

    print("\nQUOTE-TO-FORWARD JACOBIAN")
    print("(bp movement in each forward for a +1 bp bump to each par quote)\n")
    print(jacobian.to_string())

    curve.to_csv("sofr_ois_bootstrapped_curve.csv", index=False)
    jacobian.to_csv("sofr_ois_quote_to_forward_jacobian.csv")


if __name__ == "__main__":
    main()
