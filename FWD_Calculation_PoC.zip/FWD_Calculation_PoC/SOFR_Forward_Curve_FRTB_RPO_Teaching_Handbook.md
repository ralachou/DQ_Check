# SOFR Forward Rates, Curve Construction, and FRTB IMA / RPO Mapping

## Purpose

This handbook consolidates the full teaching material on:

1. SOFR OIS market observables
2. Discount factors, zero rates, par rates, and forward rates
3. Bootstrapping a SOFR OIS curve
4. Computing forwards such as \(F(3Y,5Y)\)
5. Missing tenor quotes and interpolation
6. Par-to-forward Jacobians
7. FRTB IMA Risk Factor Eligibility Test (RFET)
8. Mapping swap-rate RPOs to forward-rate risk factors
9. Regulatory implications of interpolation, bucketing, and derived factors

---

# Part I — Foundations

## 1. What the market actually gives us

The market usually does not give a complete forward curve directly.

Instead, we observe market instruments such as:

- Overnight SOFR
- SOFR futures
- SOFR OIS par swap rates
- Forward-starting swaps
- Other short-term cash or futures instruments

The curve-building problem is:

\[
\boxed{
\text{Market quotes}
\rightarrow
\text{Discount factors}
\rightarrow
\text{Zero rates}
\rightarrow
\text{Forward rates}
}
\]

A SOFR OIS exchanges:

- a fixed rate; and
- compounded overnight SOFR.

The quoted fixed rate is normally a **par swap rate**.

## 2. Discount factor

The discount factor \(P(0,T)\) means:

> The value today of receiving $1 at future time \(T\).

Example:

\[
P(0,1Y)=0.96
\]

means that receiving $1 one year from today is worth $0.96 today.

Any future cash flow can be valued as:

\[
PV=\sum_i CF_iP(0,t_i)
\]

## 3. Zero rate

A zero rate is the rate from today to one specific future date.

Using continuous compounding:

\[
P(0,T)=e^{-z(T)T}
\]

Therefore:

\[
\boxed{
z(T)=-\frac{\ln P(0,T)}{T}
}
\]

The zero rate and discount factor are two representations of the same information.

## 4. Forward rate

A forward rate applies between two future dates:

\[
F(T_1,T_2)
\]

For simple annualized compounding:

\[
\boxed{
F(T_1,T_2)
=
\frac{P(0,T_1)/P(0,T_2)-1}
{\tau(T_1,T_2)}
}
\]

For continuous compounding:

\[
\boxed{
f(T_1,T_2)
=
\frac{\ln[P(0,T_1)/P(0,T_2)]}
{T_2-T_1}
}
\]

Using continuously compounded zero rates:

\[
\boxed{
f(T_1,T_2)
=
\frac{z(T_2)T_2-z(T_1)T_1}
{T_2-T_1}
}
\]

## 5. What is a par swap rate?

A par swap rate is the fixed rate that makes a new swap worth zero at inception.

\[
PV_{\text{fixed}}=PV_{\text{floating}}
\]

For a simplified spot-starting OIS:

\[
PV_{\text{fixed}}
=
K\sum_{i=1}^{n}\alpha_iP(0,t_i)
\]

and:

\[
PV_{\text{floating}}
=
1-P(0,T_n)
\]

Therefore:

\[
\boxed{
K_n
=
\frac{1-P(0,T_n)}
{\sum_{i=1}^{n}\alpha_iP(0,t_i)}
}
\]

---

# Part II — Bootstrapping

## 6. Why bootstrapping is needed

Par swap rates are not zero rates.

A 5Y par swap rate depends on all fixed-leg payment dates through 5Y.

Bootstrapping solves the curve sequentially:

\[
1M\rightarrow3M\rightarrow6M\rightarrow9M\rightarrow1Y
\rightarrow2Y\rightarrow3Y\rightarrow4Y\rightarrow5Y
\rightarrow10Y\rightarrow20Y\rightarrow30Y
\]

At each maturity, solve the unknown discount factor so the model reproduces the market par quote.

## 7. One-period discount factor

For a one-payment instrument:

\[
K\alpha P(0,T)=1-P(0,T)
\]

Therefore:

\[
\boxed{
P(0,T)=\frac{1}{1+K\alpha}
}
\]

## 8. Multi-period bootstrap formula

For annual fixed payments:

\[
K_n\sum_{i=1}^{n}P_i=1-P_n
\]

Then:

\[
\boxed{
P_n
=
\frac{
1-K_n\sum_{i=1}^{n-1}P_i
}{
1+K_n
}
}
\]

More generally:

\[
\boxed{
P(0,T_n)
=
\frac{
1-K_n\sum_{i=1}^{n-1}\alpha_iP(0,t_i)
}{
1+K_n\alpha_n
}
}
\]

---

# Part III — Why \(F(3Y,5Y)\) Needs the Earlier Curve

## 9. Direct mathematical requirement

To compute:

\[
F(3Y,5Y)
\]

we directly need only:

\[
P(0,3Y)
\quad\text{and}\quad
P(0,5Y)
\]

The simple forward formula is:

\[
\boxed{
F(3Y,5Y)
=
\frac{P(0,3Y)/P(0,5Y)-1}{2}
}
\]

However, the discount factors themselves come from the full earlier curve.

## 10. Solving the 1Y discount factor

Assume annual payments and:

\[
K_{1Y}=4.00\%
\]

Then:

\[
P_1=\frac{1}{1+K_1}
\]

\[
P_1=\frac{1}{1.04}=0.961538
\]

## 11. Solving the 2Y discount factor

Assume:

\[
K_{2Y}=4.20\%
\]

The 2Y swap equation is:

\[
K_2(P_1+P_2)=1-P_2
\]

Therefore:

\[
\boxed{
P_2=
\frac{1-K_2P_1}{1+K_2}
}
\]

Using \(P_1=0.961538\):

\[
P_2\approx0.920936
\]

## 12. Solving the 3Y discount factor

Assume:

\[
K_{3Y}=4.30\%
\]

The 3Y equation is:

\[
K_3(P_1+P_2+P_3)=1-P_3
\]

Therefore:

\[
\boxed{
P_3=
\frac{
1-K_3(P_1+P_2)
}{
1+K_3
}
}
\]

Using the previously solved values:

\[
P_3\approx0.881164
\]

Therefore:

\[
P(0,3Y)=g(K_{1Y},K_{2Y},K_{3Y})
\]

## 13. Solving the 5Y discount factor

The 5Y par equation is:

\[
K_5(P_1+P_2+P_3+P_4+P_5)=1-P_5
\]

Therefore:

\[
\boxed{
P_5=
\frac{
1-K_5(P_1+P_2+P_3+P_4)
}{
1+K_5
}
}
\]

Thus:

\[
P(0,5Y)=g(K_{1Y},K_{2Y},K_{3Y},K_{4Y},K_{5Y})
\]

## 14. Computing \(F(3Y,5Y)\)

Suppose:

\[
P_3=0.881164
\]

and:

\[
P_5=0.801735
\]

Then:

\[
F(3Y,5Y)
=
\frac{0.881164/0.801735-1}{2}
\]

\[
\boxed{
F(3Y,5Y)\approx4.95\%
}
\]

## 15. Dependency chain

```text
1Y quote ──────► P(0,1Y)
                    │
2Y quote ───────────┼──► P(0,2Y)
                    │       │
3Y quote ───────────┼───────┼──► P(0,3Y)
                    │       │       │
4Y quote/interpolation ──────┼───────┼──► P(0,4Y)
                    │       │       │       │
5Y quote ───────────┴───────┴───────┴───────┼──► P(0,5Y)
                                             │
                         P(0,3Y), P(0,5Y) ───┴──► F(3Y,5Y)
```

---

# Part IV — Missing Quotes and Interpolation

## 16. What happens if 2Y and 3Y quotes are missing?

There are three distinct cases.

### Case 1 — Alternative short-end instruments exist

You may use:

- SOFR futures
- Forward-starting swaps
- Other liquid short-dated OIS instruments
- Cash or futures instruments covering the missing period

Example for quarterly futures:

\[
P(0,t+0.25)
=
\frac{P(0,t)}
{1+F(t,t+0.25)\times0.25}
\]

Sequential quarterly futures can generate discount factors between 1Y and 3Y.

### Case 2 — Interpolation is used

Suppose only 1Y and 4Y are observed.

#### Method A — Linear zero-rate interpolation

\[
z(t)
=
z(T_1)
+
\frac{t-T_1}{T_2-T_1}
\left[z(T_2)-z(T_1)\right]
\]

Then:

\[
P(0,t)=e^{-z(t)t}
\]

#### Method B — Log-linear discount-factor interpolation

\[
\ln P(0,t)
=
\ln P(0,T_1)
+
\frac{t-T_1}{T_2-T_1}
\left[
\ln P(0,T_2)-\ln P(0,T_1)
\right]
\]

#### Method C — Linear discount-factor interpolation

\[
P(0,t)
=
P(0,T_1)
+
\frac{t-T_1}{T_2-T_1}
\left[
P(0,T_2)-P(0,T_1)
\right]
\]

All three methods can match the endpoint anchors, but produce different intermediate discount factors, zero rates, forwards, Jacobians, and hedge sensitivities.

\[
\boxed{
\text{Missing quote}
\Rightarrow
\text{greater model dependency}
}
\]

### Case 3 — The system is underdetermined

Suppose only a 3Y par quote is known.

\[
K_3(P_1+P_2+P_3)=1-P_3
\]

Unknowns:

\[
P_1,\ P_2,\ P_3
\]

One equation with three unknowns does not uniquely determine the curve.

\[
\boxed{
\text{One 3Y par quote does not define the entire 0–3Y curve.}
}
\]

## 17. Dense versus sparse curve

### Dense curve

\[
1Y,\ 2Y,\ 3Y,\ 4Y,\ 5Y
\]

Advantages:

- more direct market anchors;
- less interpolation;
- more local risk;
- more transparent hedging.

### Sparse curve

\[
1Y,\ 3Y,\ 5Y
\]

Consequences:

- 2Y and 4Y are interpolated;
- intermediate forwards are more model-dependent;
- quote risk spreads over broader segments;
- local curve risk may be less precisely represented.

---

# Part V — Par-to-Forward Jacobian

## 18. Transformation

Let market par quotes be \(\mathbf q\), and forwards be \(\mathbf f\):

\[
\boxed{
\mathbf f=g(\mathbf q)
}
\]

## 19. Jacobian definition

\[
\boxed{
J_{ij}
=
\frac{\partial f_i}{\partial q_j}
}
\]

## 20. Numerical Jacobian

Bump one quote and rebootstrap:

\[
\boxed{
J_{ij}
\approx
\frac{
f_i(\mathbf q+\epsilon\mathbf e_j)-f_i(\mathbf q)
}{
\epsilon
}
}
\]

## 21. Risk transformation

\[
\boxed{
\frac{\partial V}{\partial \mathbf q}
=
J^\mathsf T
\frac{\partial V}{\partial \mathbf f}
}
\]

---

# Part VI — FRTB IMA, RPOs, and Interpolation

## 22. Main distinction

\[
\boxed{
\text{Interpolation can solve a curve-construction problem, but it does not automatically solve an RFET liquidity problem.}
}
\]

An interpolated market value is not automatically a qualifying real price observation.

Interpolation creates model values and derived curve points. It does not create executed trades, committed quotes, or additional RPO dates.

## 23. Example RPO profile

| Tenor | Result |
|---|---|
| 6M | Pass |
| 1Y | Pass |
| 2Y | Fail |
| 3Y | Pass |
| 4Y | Fail |
| 5Y | Pass |

The pricing model can still interpolate 2Y and 4Y, but modellability depends on the risk-factor definition, RFET bucketing, representative-RPO mapping, and residual basis treatment.

## 24. Three model designs

### Design A — Every tenor is an independent risk factor

\[
R_{1Y},R_{2Y},R_{3Y},R_{4Y},R_{5Y}
\]

If 2Y and 4Y fail their applicable RFET tests, they are NMRFs even if prices can be interpolated.

### Design B — Sparse liquid pillars

Use only:

\[
R_{1Y},R_{3Y},R_{5Y}
\]

and define:

\[
R_{2Y}=h(R_{1Y},R_{3Y})
\]

\[
R_{4Y}=h(R_{3Y},R_{5Y})
\]

### Design C — Interpolated component plus basis

\[
R_{2Y}^{\text{actual}}
=
R_{2Y}^{\text{interpolated}}
+
B_{2Y}
\]

where:

\[
B_{2Y}
=
R_{2Y}^{\text{actual}}
-
h(R_{1Y},R_{3Y})
\]

## 25. Standard bucketing versus interpolation

\[
\boxed{
\text{Standard bucketing simplifies RPO counting.}
}
\]

\[
\boxed{
\text{Interpolation simplifies model representation.}
}
\]

They are complementary, not interchangeable.

---

# Part VII — Regulatory Baseline Language

## 26. Combinations of modellable factors

The 2023 US Basel III Endgame NPR states that calibration data may include combinations of modellable risk factors.

This supports methods such as interpolation and PCA, but does not mean a separately identified derived factor automatically passes RFET.

## 27. Derived factor must also pass RFET

The NPR preamble explains that a factor derived from modellable factors is itself modellable only if the derived factor also passes RFET.

\[
RF_1\text{ passes}
+
RF_3\text{ passes}
\not\Rightarrow
RF_{2Y}\text{ automatically passes}
\]

## 28. Modellable component plus NMRF basis

\[
R^{\text{actual}}
=
R^{\text{modellable}}
+
R^{\text{basis}}
\]

The residual basis is treated as NMRF unless independently supportable.

## 29. Interpolation and PCA

The NPR preamble mentions interpolation and PCA where conceptually sound.

The methods remain subject to model validation, RFET consistency, PLA/RTPL consistency, and supervisory review.

## 30. Unsound extrapolation or irregular bucketing

Supervisors may reject unsound extrapolation, irregular bucketing, or combinations that suppress material risk.

## 31. Granularity trade-off

More granular factors improve local risk capture and PLA alignment, but create more RFET points and RPO requirements.

---

# Part VIII — Swap-Rate RPOs and Forward-Rate Risk Factors

## 32. The three layers

### Market observations

\[
S_{6M},S_{1Y},S_{2Y},S_{3Y},S_{4Y},S_{5Y}
\]

### Curve variables

\[
P(0,6M),P(0,1Y),\ldots,P(0,5Y)
\]

### Forward risk factors

\[
F(0,6M),F(6M,1Y),F(1Y,2Y),F(2Y,3Y),F(3Y,4Y),F(4Y,5Y)
\]

A failed 2Y swap-rate RPO bucket does not automatically make every later forward factor fail.

## 33. Local mapping intuition

| Forward factor | Most directly associated swap region |
|---|---|
| \(F(0,6M)\) | 6M |
| \(F(6M,1Y)\) | 6M and 1Y |
| \(F(1Y,2Y)\) | 1Y and 2Y |
| \(F(2Y,3Y)\) | 2Y and 3Y |
| \(F(3Y,4Y)\) | 3Y and 4Y |
| \(F(4Y,5Y)\) | 4Y and 5Y |

A failed 2Y point most directly affects \(F(1Y,2Y)\) and potentially \(F(2Y,3Y)\).

A failed 4Y point most directly affects \(F(3Y,4Y)\) and potentially \(F(4Y,5Y)\).

## 34. Mathematical dependency is not RFET dependency

Because of bootstrapping, an earlier swap quote may have a nonzero Jacobian sensitivity to later forwards.

But RFET asks whether the real price is representative of the risk factor and whether the applicable RFET bucket has enough qualifying observations.

## 35. Own-bucketing example

| Bucket | Forward RF |
|---|---|
| B1 | \(F(0,6M)\) |
| B2 | \(F(6M,1Y)\) |
| B3 | \(F(1Y,2Y)\) |
| B4 | \(F(2Y,3Y)\) |
| B5 | \(F(3Y,4Y)\) |
| B6 | \(F(4Y,5Y)\) |

Each bucket must have enough representative RPOs.

## 36. Standard-bucketing example

| Tenor | Standard bucket |
|---|---|
| 6M | \(0\)–\(0.75Y\) |
| 1Y | \(0.75Y\)–\(1.5Y\) |
| 2Y | \(1.5Y\)–\(4Y\) |
| 3Y | \(1.5Y\)–\(4Y\) |
| 4Y | \(4Y\)–\(7Y\) |
| 5Y | \(4Y\)–\(7Y\) |

Even if 2Y standalone counts fail, the combined \(1.5Y\)–\(4Y\) bucket may pass if representative observations from the bucket are sufficient.

Likewise, a weak 4Y point may be supported by the overall \(4Y\)–\(7Y\) bucket, depending on representativeness.

## 37. Assigning maturity to a forward factor

For \(F(2Y,3Y)\), possible representations include:

- start date: 2Y;
- end date: 3Y;
- midpoint: 2.5Y;
- interval representation.

The bank must use a consistent documented approach across ES, RTPL, PLA, and RFET.

## 38. Candidate RPO support by forward

| Forward RF | Candidate representative RPOs |
|---|---|
| \(F(1Y,2Y)\) | 1Y/2Y swaps, forward-starting swaps, relevant SOFR futures |
| \(F(2Y,3Y)\) | 2Y/3Y swaps, 1Y forward starting in 2Y, relevant futures |
| \(F(3Y,4Y)\) | 3Y/4Y swaps, 1Y forward starting in 3Y |
| \(F(4Y,5Y)\) | 4Y/5Y swaps, 1Y forward starting in 4Y |

## 39. Mapping matrix

\[
M_{ij}
=
\text{representativeness of swap quote }j
\text{ for forward risk factor }i
\]

| Forward RF | 1Y swap | 2Y swap | 3Y swap | 4Y swap | 5Y swap |
|---|---:|---:|---:|---:|---:|
| \(F(0,1Y)\) | High | Low | Low | Low | Low |
| \(F(1Y,2Y)\) | Medium | High | Medium | Low | Low |
| \(F(2Y,3Y)\) | Low | Medium | High | Medium | Low |
| \(F(3Y,4Y)\) | Low | Low | Medium | High | Medium |
| \(F(4Y,5Y)\) | Low | Low | Low | Medium | High |

A tiny nonzero Jacobian sensitivity alone should not establish representativeness.

---

# Part IX — Key Conclusions

## 40. Forward-curve conclusion

\[
\boxed{
F(3Y,5Y)
\text{ directly needs }P(0,3Y)\text{ and }P(0,5Y)
}
\]

but those discount factors indirectly depend on earlier market quotes and interpolation.

## 41. Missing-data conclusion

\[
\boxed{
\text{Missing quotes do not always prevent curve construction.}
}
\]

Alternative instruments, interpolation, and parametric methods may fill gaps, but sparse data increases model dependency.

## 42. RFET conclusion

\[
\boxed{
\text{Interpolation does not manufacture RPOs.}
}
\]

## 43. Bucketing conclusion

\[
\boxed{
\text{Standard bucketing simplifies RPO counting.}
}
\]

\[
\boxed{
\text{Interpolation simplifies the risk-factor representation.}
}
\]

## 44. Forward-RPO mapping conclusion

\[
\boxed{
\text{A failed 2Y swap RPO bucket does not automatically make all later forward buckets fail.}
}
\]

The likely impact is local to adjacent forward segments, subject to representative-RPO mapping, bucketing, derived-factor treatment, and model design.

---

# References

- Federal Deposit Insurance Corporation archive, 2023 US Basel III Endgame NPR:  
  https://archive.fdic.gov/view/fdic/15443/fdic_15443_DS1.pdf

- Basel Framework, Market Risk, MAR31:  
  https://www.bis.org/basel_framework/chapter/MAR/31.htm

- OSFI Capital Adequacy Requirements, Market Risk:  
  https://www.osfi-bsif.gc.ca/en/guidance/guidance-library/capital-adequacy-requirements-car-2026-chapter-9-market-risk

- Federal Reserve Bank of New York, SOFR:  
  https://www.newyorkfed.org/markets/reference-rates/sofr

- CME Group, SOFR products and curve-construction resources:  
  https://www.cmegroup.com/markets/interest-rates/secured-overnight-financing-rate.html
