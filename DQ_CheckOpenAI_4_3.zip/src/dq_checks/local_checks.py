from __future__ import annotations

import json
import warnings
from typing import Any

import numpy as np
import pandas as pd

from dq_checks.base import DQCheck, severity_from_ratio, value_is_precomputed_shift
from dq_checks.taxonomy import (
    ML_FORECAST_BASED,
    PEER_CROSS_GROUP,
    RULE_BASED,
    STATISTICAL_BASIC,
    STATISTICAL_ROBUST,
)


def _finalize_output(
    df: pd.DataFrame,
    raw_score: pd.Series,
    threshold: float,
    reason_code: str,
    explain: str,
    artifacts: dict[str, Any] | None = None,
) -> pd.DataFrame:
    out = df[["risk_factor_id", "date"]].copy()
    out["raw_score"] = raw_score.astype(float).fillna(0.0)
    out["threshold"] = float(threshold)
    out["flag"] = out["raw_score"] >= threshold
    ratio = out["raw_score"] / (threshold + 1.0e-12)
    out["severity"] = severity_from_ratio(ratio)
    out.loc[~out["flag"], "severity"] = "Low"
    out["reason_code"] = np.where(out["flag"], reason_code, "OK")
    out["explain"] = np.where(out["flag"], explain, "No issue")
    out["artifacts_json"] = json.dumps(artifacts or {})
    return out


class RobustZScoreCheck(DQCheck):
    """
    This is a robust z-score using median/MAD (not mean/std).
    """
    def __init__(self, **params: Any) -> None:
        super().__init__(
            name="robust_zscore",
            family=STATISTICAL_ROBUST,
            scope="per_series",   # so each risk factor is scored independently
            fit_policy="per_series",
            **params,
        )

    def score(self, df: pd.DataFrame, context: dict[str, Any], model_state: dict[str, Any] | None = None) -> pd.DataFrame:
        """
        model_state -> Output from fit(...) if the check/model needs learned state
            or many local checks,  this is unused (None). For adapters/ML checks,  this can contain fitted model objects
        context : Runtime metadata passed by runner/engine.
                in some use cases, i want to know  series_semantics (level or shift) for semantic-aware checks like;
                    series_semantics (level or shift) for semantic-aware checks
                     peer_group (per-peer-group)
                     risk_factor_id (per-series) for special treatment
        Returns pd.DataFrame with standardized result columns like:
                risk_factor_id, date, raw_score, threshold, flag, severity, reason_code, explain, artifacts_json
        """



        del context, model_state
        window = int(self.params.get("window", 260))
        min_periods = int(self.params.get("min_periods", min(20, window)))
        threshold = float(self.params.get("threshold", 6.0))
        s = df["value"].astype(float) # series

        #rolling median
        med = s.rolling(window=window, min_periods=min_periods).median()                # medium = rolling_median(s, window, min_periods)

        #medianabsolute deviation(robust scale), i.e.median of abs(s - med)
        mad = (s - med).abs().rolling(window=window, min_periods=min_periods).median()  # mad  = rolling_median(abs(s - med), window, min_periods)

        #this is raw score : how to flag using Robust Z score.


        robust_z = ((s - med).abs()) / (1.4826 * mad + 1.0e-9)                           #=raw_score = abs(s - med) / (1.4826 * mad + 1e-9)

        """
        MAD is smaller than standard deviation under a Normal distribution 
        So i choose 1.4826 as  a normal-distribution scaling constant so MAD becomes comparable to standard deviation. 
             Basically, it puts consistency factor to put MAD on an approx std-dev scale :) 
                   (sigma):for normal data, sigma ≈ 1.4826 * MAD.
                    why ? because , so robust z-score becomes comparable to classical z-score magnitudes 
        Why 1e-9
          to avoid divide-by-zero or huge numeric blowups when mad is zero/near-zero
            basically, it  is a numerical stability guard, not a statistical parameter 
            very small enough to barely affect normal cases, but prevents crashes/infinite scores when variation is flat.
        but this breaks my code for flat/constant series 
            case1: entire window is flat series = [1.5, 1.5, 1.5, 1.5, 1.5]  ← new point also 1.5
                  median = 1.5, MAD = 0, numerator = 0
                  z = 0 / (0 + 1e-9) = 0 No flag
            Case 2: Entire window is flat, new point deviates
                 series = [1.5, 1.5, 1.5, 1.5, 2.0]  ← new point is 2.0
                     median = 1.5, MAD = 0, numerator = 0.5
                      z = 0.5 / (0 + 1e-9) = 500,000,000
        """

        #flag if  raw_score >= threshold (here threshold default is 6.0)

        return _finalize_output(
            df=df,
            raw_score=robust_z,
            threshold=threshold,
            reason_code="ROBUST_ZSCORE",
            explain=f"Absolute robust z-score exceeds threshold {threshold}",
            artifacts={"window": window},
        )


class RobustZScoreCheck_SkipFlatData(DQCheck):
    """
    Robust z-score with explicit flat-data handling:
    - stale window -> score -1
    - MAD == 0 -> score 0
    - MAD very small but non-zero -> cap score at z_cap
    """

    def __init__(self, **params: Any) -> None:
        super().__init__(
            name="robust_zscore_skip_flat_data",
            family=STATISTICAL_ROBUST,
            scope="per_series",
            fit_policy="per_series",
            **params,
        )

    def score(
        self,
        df: pd.DataFrame,
        context: dict[str, Any],
        model_state: dict[str, Any] | None = None,
    ) -> pd.DataFrame:
        del context, model_state
        window = int(self.params.get("window", 260))
        min_periods = int(self.params.get("min_periods", min(20, window)))
        threshold = float(self.params.get("threshold", 6.0))
        stale_tolerance = float(self.params.get("stale_tolerance", 1.0e-12))
        mad_zero_tolerance = float(self.params.get("mad_zero_tolerance", 1.0e-12))
        mad_small_threshold = float(self.params.get("mad_small_threshold", 1.0e-6))
        z_cap = float(self.params.get("z_cap", 99.0))

        s = df["value"].astype(float)
        med = s.rolling(window=window, min_periods=min_periods).median()
        mad = (s - med).abs().rolling(window=window, min_periods=min_periods).median()

        # Default robust z-score formula.
        robust_z = ((s - med).abs()) / (1.4826 * mad + 1.0e-9)

        rolling_min = s.rolling(window=window, min_periods=min_periods).min()
        rolling_max = s.rolling(window=window, min_periods=min_periods).max()
        stale_window = (rolling_max - rolling_min).abs() <= stale_tolerance

        mad_abs = mad.abs()
        mad_zero = mad_abs <= mad_zero_tolerance
        mad_small_nonzero = (mad_abs > mad_zero_tolerance) & (mad_abs <= mad_small_threshold)

        # :
        # 1) stale window => -1
        # 2) mad zero => 0
        # 3) mad very small non-zero => capped robust z
        # 4) else => default robust z
        score = pd.Series(
            np.where(
                stale_window.fillna(False).to_numpy(),
                -1.0,
                np.where(
                    mad_zero.fillna(False).to_numpy(),
                    0.0,
                    np.where(
                        mad_small_nonzero.fillna(False).to_numpy(),
                        robust_z.clip(upper=z_cap).to_numpy(),
                        robust_z.to_numpy(),
                    ),
                ),
            ),
            index=df.index,
            dtype=float,
        )

        return _finalize_output(
            df=df,
            raw_score=score,
            threshold=threshold,
            reason_code="ROBUST_ZSCORE_SKIP_FLAT",
            explain=(
                "Robust z-score exceeds threshold with flat-data safeguards "
                "(stale=-1, mad_zero=0, small_mad capped)."
            ),
            artifacts={
                "window": window,
                "stale_tolerance": stale_tolerance,
                "mad_zero_tolerance": mad_zero_tolerance,
                "mad_small_threshold": mad_small_threshold,
                "z_cap": z_cap,
                "rule_order": ["is_stale:-1", "is_mad_zero:0", "is_mad_small:cap", "else:robust_z"],
            },
        )


class RollingZScoreCheck(DQCheck):
    """Classical rolling mean/std z-score on level values."""

    def __init__(self, **params: Any) -> None:
        super().__init__(
            name="rolling_zscore",
            family=STATISTICAL_BASIC,
            scope="per_series",
            fit_policy="per_series",
            **params,
        )

    def score(self, df: pd.DataFrame, context: dict[str, Any], model_state: dict[str, Any] | None = None) -> pd.DataFrame:
        del context, model_state
        window = int(self.params.get("window", 260))
        min_periods = int(self.params.get("min_periods", min(20, window)))
        threshold = float(self.params.get("threshold", 4.0))
        s = df["value"].astype(float)
        mu = s.rolling(window=window, min_periods=min_periods).mean()
        sigma = s.rolling(window=window, min_periods=min_periods).std(ddof=0)
        z = ((s - mu).abs()) / (sigma + 1.0e-9)
        return _finalize_output(
            df=df,
            raw_score=z,
            threshold=threshold,
            reason_code="ROLLING_ZSCORE",
            explain=f"Absolute rolling z-score exceeds threshold {threshold}",
            artifacts={"window": window},
        )


class ZScoreMeanStdCheck(RollingZScoreCheck):
    """Alias of classical rolling z-score check with explicit model name."""

    def __init__(self, **params: Any) -> None:
        super().__init__(**params)
        self.name = "zscore_mean_std"


class MeanStdShift4SigmaCheck(DQCheck):
    """
    Mean/std detector on shifted series moves.
    |shift - rolling_mean(shift)| / rolling_std(shift) >= k
    """

    def __init__(self, **params: Any) -> None:
        super().__init__(
            name="mean_std_shift_4sigma",
            family=STATISTICAL_BASIC,
            scope="per_series",
            fit_policy="per_series",
            **params,
        )

    def score(self, df: pd.DataFrame, context: dict[str, Any], model_state: dict[str, Any] | None = None) -> pd.DataFrame:
        del model_state
        window = int(self.params.get("window", 252))
        shift_lag = int(self.params.get("shift_lag", 1))
        min_periods = int(self.params.get("min_periods", min(20, window)))
        threshold = float(self.params.get("threshold", 4.0))
        s = df["value"].astype(float)
        # If value already represents shifts, avoid differencing again.
        shift = s.fillna(0.0) if value_is_precomputed_shift(context) else s.diff(shift_lag).fillna(0.0)
        mu = shift.rolling(window=window, min_periods=min_periods).mean()
        sigma = shift.rolling(window=window, min_periods=min_periods).std(ddof=0)
        z = ((shift - mu).abs()) / (sigma + 1.0e-9)
        return _finalize_output(
            df=df,
            raw_score=z,
            threshold=threshold,
            reason_code="MEAN_STD_SHIFT_4SIGMA",
            explain=f"Absolute shift z-score exceeds {threshold} sigma",
            artifacts={"window": window, "shift_lag": shift_lag},
        )


class RobustZScoreMeanStdCheck(DQCheck):
    """Hybrid robust check: center=rolling median, scale=rolling std."""

    def __init__(self, **params: Any) -> None:
        super().__init__(
            name="robust_zscore_mean_std",
            family=STATISTICAL_ROBUST,
            scope="per_series",
            fit_policy="per_series",
            **params,
        )

    def score(self, df: pd.DataFrame, context: dict[str, Any], model_state: dict[str, Any] | None = None) -> pd.DataFrame:
        del context, model_state
        window = int(self.params.get("window", 260))
        min_periods = int(self.params.get("min_periods", min(20, window)))
        threshold = float(self.params.get("threshold", 4.5))
        s = df["value"].astype(float)
        med = s.rolling(window=window, min_periods=min_periods).median()
        sigma = s.rolling(window=window, min_periods=min_periods).std(ddof=0)
        z = ((s - med).abs()) / (sigma + 1.0e-9)
        return _finalize_output(
            df=df,
            raw_score=z,
            threshold=threshold,
            reason_code="ROBUST_ZSCORE_MEAN_STD",
            explain=f"Absolute median/std z-score exceeds threshold {threshold}",
            artifacts={"window": window},
        )


class QuantileBandCheck(DQCheck):
    def __init__(self, **params: Any) -> None:
        super().__init__(
            name="quantile_band",
            family=STATISTICAL_ROBUST,
            scope="per_series",
            fit_policy="per_series",
            **params,
        )

    def score(self, df: pd.DataFrame, context: dict[str, Any], model_state: dict[str, Any] | None = None) -> pd.DataFrame:
        del context, model_state
        window = int(self.params.get("window", 260))
        high_q = float(self.params.get("high_q", 0.995))
        low_q = float(self.params.get("low_q", 0.005))
        s = df["value"].astype(float)
        q_hi = s.rolling(window, min_periods=max(20, window // 4)).quantile(high_q)
        q_lo = s.rolling(window, min_periods=max(20, window // 4)).quantile(low_q)
        raw = np.maximum((s - q_hi).clip(lower=0.0), (q_lo - s).clip(lower=0.0))
        band = (q_hi - q_lo).replace(0, np.nan)
        score = (raw / (band + 1.0e-9)).fillna(0.0)
        return _finalize_output(
            df=df,
            raw_score=score,
            threshold=float(self.params.get("threshold", 0.2)),
            reason_code="QUANTILE_BAND",
            explain="Value outside rolling quantile band",
            artifacts={"window": window, "high_q": high_q, "low_q": low_q},
        )


class IQRCheck(DQCheck):
    def __init__(self, **params: Any) -> None:
        super().__init__(
            name="iqr",
            family=STATISTICAL_ROBUST,
            scope="per_series",
            fit_policy="per_series",
            **params,
        )

    def score(self, df: pd.DataFrame, context: dict[str, Any], model_state: dict[str, Any] | None = None) -> pd.DataFrame:
        del context, model_state
        window = int(self.params.get("window", 260))
        c = float(self.params.get("c", 4.0))
        s = df["value"].astype(float)
        q1 = s.rolling(window, min_periods=max(20, window // 4)).quantile(0.25)
        q3 = s.rolling(window, min_periods=max(20, window // 4)).quantile(0.75)
        iqr = q3 - q1
        med = s.rolling(window, min_periods=max(20, window // 4)).median()
        score = ((s - med).abs() / (iqr + 1.0e-9)).fillna(0.0)
        return _finalize_output(
            df=df,
            raw_score=score,
            threshold=max(c / 2.0, 0.1),
            reason_code="IQR_BAND",
            explain=f"Absolute distance from rolling median exceeds {c}x IQR rule",
            artifacts={"window": window, "c": c},
        )


class RuleAbsShiftGtCheck(DQCheck):
    def __init__(self, **params: Any) -> None:
        super().__init__(
            name="rule_abs_shift_gt",
            family=RULE_BASED,
            scope="per_series",
            fit_policy="per_series",
            **params,
        )

    def score(self, df: pd.DataFrame, context: dict[str, Any], model_state: dict[str, Any] | None = None) -> pd.DataFrame:
        del model_state
        shift_lag = int(self.params.get("shift_lag", 1))
        threshold = float(self.params.get("threshold", 2.0))
        s = df["value"].astype(float)
        # If value already represents shifts, threshold absolute shift directly.
        shift = s.fillna(0.0).abs() if value_is_precomputed_shift(context) else s.diff(shift_lag).fillna(0.0).abs()
        return _finalize_output(
            df=df,
            raw_score=shift,
            threshold=threshold,
            reason_code="RULE_ABS_SHIFT_GT",
            explain=f"Rule breached: abs(shift_{shift_lag}) > {threshold}",
            artifacts={"shift_lag": shift_lag},
        )


class StaleNoChangeCheck(DQCheck):
    def __init__(self, **params: Any) -> None:
        super().__init__(
            name="stale_values",
            family=RULE_BASED,
            scope="per_series",
            fit_policy="per_series",
            **params,
        )

    def score(self, df: pd.DataFrame, context: dict[str, Any], model_state: dict[str, Any] | None = None) -> pd.DataFrame:
        del context, model_state
        stale_days = int(self.params.get("stale_days", 5))
        change = df["value"].diff().abs().fillna(0.0)
        no_change = (change <= 1.0e-12).astype(int)
        run = no_change.groupby((no_change == 0).cumsum()).cumsum()
        return _finalize_output(
            df=df,
            raw_score=run,
            threshold=float(stale_days),
            reason_code="STALE_VALUES",
            explain=f"{stale_days}+ consecutive unchanged values",
            artifacts={"stale_days": stale_days},
        )


class MissingGapsCheck(DQCheck):
    def __init__(self, **params: Any) -> None:
        super().__init__(
            name="missing_gaps",
            family=RULE_BASED,
            scope="per_series",
            fit_policy="per_series",
            **params,
        )

    def score(self, df: pd.DataFrame, context: dict[str, Any], model_state: dict[str, Any] | None = None) -> pd.DataFrame:
        del context, model_state
        if df.empty:
            return self.empty_result(df, "No rows in input.")
        rf_id = str(df["risk_factor_id"].iloc[0])
        date_index = pd.to_datetime(df["date"])
        full_range = pd.date_range(date_index.min(), date_index.max(), freq="B")
        missing_dates = full_range.difference(pd.DatetimeIndex(date_index))
        missing_df = pd.DataFrame({"risk_factor_id": rf_id, "date": missing_dates, "value": np.nan})
        combined = pd.concat([df[["risk_factor_id", "date", "value"]], missing_df], ignore_index=True).sort_values("date")
        is_missing = combined["value"].isna().astype(float)
        out = _finalize_output(
            df=combined,
            raw_score=is_missing,
            threshold=0.5,
            reason_code="MISSING_BUSINESS_DATE",
            explain="Expected business date missing",
            artifacts={"calendar": "business_day"},
        )
        return out[out["flag"]].reset_index(drop=True)


class JumpSpikeCheck(DQCheck):
    def __init__(self, **params: Any) -> None:
        super().__init__(
            name="jump_spike",
            family=STATISTICAL_ROBUST,
            scope="per_series",
            fit_policy="per_series",
            **params,
        )

    def score(self, df: pd.DataFrame, context: dict[str, Any], model_state: dict[str, Any] | None = None) -> pd.DataFrame:
        del model_state
        window = int(self.params.get("window", 60))
        threshold = float(self.params.get("threshold", 5.0))
        s = df["value"].astype(float)
        # If value already represents shifts/returns, score it directly.
        returns = s.fillna(0.0) if value_is_precomputed_shift(context) else s.diff().fillna(0.0)
        med = returns.rolling(window=window, min_periods=max(10, window // 4)).median()
        mad = (returns - med).abs().rolling(window=window, min_periods=max(10, window // 4)).median()
        score = (returns - med).abs() / (1.4826 * mad + 1.0e-9)
        return _finalize_output(
            df=df,
            raw_score=score,
            threshold=threshold,
            reason_code="RETURN_SPIKE",
            explain="Jump/spike detected from robust return statistics",
            artifacts={"window": window},
        )


class CUSUMDriftCheck(DQCheck):
    def __init__(self, **params: Any) -> None:
        super().__init__(
            name="cusum_drift",
            family=STATISTICAL_ROBUST,
            scope="per_series",
            fit_policy="per_series",
            **params,
        )

    def score(self, df: pd.DataFrame, context: dict[str, Any], model_state: dict[str, Any] | None = None) -> pd.DataFrame:
        del model_state
        drift = float(self.params.get("drift", 0.0))
        threshold = float(self.params.get("threshold", 6.0))
        s = df["value"].astype(float)
        # If value already represents shifts, feed that into CUSUM directly.
        x = s.fillna(0.0) if value_is_precomputed_shift(context) else s.diff().fillna(0.0)
        std = x.rolling(window=60, min_periods=20).std(ddof=0).fillna(x.std(ddof=0) + 1.0e-9)
        z = (x - drift) / (std + 1.0e-9)
        pos = z.clip(lower=0).cumsum()
        neg = (-z).clip(lower=0).cumsum()
        score = np.maximum(pos, neg)
        return _finalize_output(
            df=df,
            raw_score=score,
            threshold=threshold,
            reason_code="CUSUM_DRIFT",
            explain="CUSUM drift indicates structural mean shift",
            artifacts={"drift": drift},
        )


def _ks_statistic_sample(a: np.ndarray, b: np.ndarray) -> float:
    if len(a) == 0 or len(b) == 0:
        return 0.0
    grid = np.unique(np.concatenate([a, b]))
    cdf_a = np.searchsorted(np.sort(a), grid, side="right") / len(a)
    cdf_b = np.searchsorted(np.sort(b), grid, side="right") / len(b)
    return float(np.max(np.abs(cdf_a - cdf_b)))


class RollingKSCheck(DQCheck):
    def __init__(self, **params: Any) -> None:
        super().__init__(
            name="rolling_ks",
            family=STATISTICAL_ROBUST,
            scope="per_series",
            fit_policy="per_series",
            **params,
        )

    def score(self, df: pd.DataFrame, context: dict[str, Any], model_state: dict[str, Any] | None = None) -> pd.DataFrame:
        del context, model_state
        window = int(self.params.get("window", 120))
        ref = int(self.params.get("reference", 260))
        threshold = float(self.params.get("threshold", 0.35))
        values = df["value"].astype(float).to_numpy()
        scores = np.zeros(len(values), dtype=float)
        for i in range(len(values)):
            cur_start = max(0, i - window + 1)
            ref_end = cur_start
            ref_start = max(0, ref_end - ref)
            cur = values[cur_start : i + 1]
            baseline = values[ref_start:ref_end]
            if len(cur) >= max(20, window // 3) and len(baseline) >= max(20, ref // 3):
                scores[i] = _ks_statistic_sample(cur, baseline)
        return _finalize_output(
            df=df,
            raw_score=pd.Series(scores, index=df.index),
            threshold=threshold,
            reason_code="ROLLING_KS_SHIFT",
            explain="Rolling KS indicates distribution shift",
            artifacts={"window": window, "reference": ref},
        )


class ForecastARIMAResidualCheck(DQCheck):
    def __init__(self, **params: Any) -> None:
        super().__init__(
            name="arima_residual",
            family=ML_FORECAST_BASED,
            scope="per_series",
            fit_policy="per_series",
            **params,
        )

    def score(self, df: pd.DataFrame, context: dict[str, Any], model_state: dict[str, Any] | None = None) -> pd.DataFrame:
        del context, model_state
        threshold = float(self.params.get("threshold", 4.0))
        order = tuple(self.params.get("order", (1, 0, 0)))
        s = df["value"].astype(float).copy()
        pred = pd.Series(index=s.index, dtype=float)
        used = "fallback_rollmean"
        try:
            from statsmodels.tsa.arima.model import ARIMA

            fit_min = int(self.params.get("fit_min_points", 40))
            if len(s.dropna()) >= fit_min:
                s_fit = s.ffill().bfill()
                model = ARIMA(s_fit, order=order)
                res = model.fit()
                in_sample = pd.Series(res.predict(start=0, end=len(s) - 1), index=s.index)
                pred = in_sample.shift(1)
                used = "statsmodels_arima_single_fit"
        except Exception as exc:
            warnings.warn(f"ARIMA unavailable/failed, using rolling fallback: {exc}")

        if pred.isna().all():
            w = int(self.params.get("fallback_window", 20))
            pred = s.shift(1).rolling(w, min_periods=max(5, w // 3)).mean()

        resid = (s - pred).abs().fillna(0.0)
        sigma = resid.rolling(60, min_periods=20).std(ddof=0)
        score = (resid / (sigma + 1.0e-9)).fillna(0.0)
        return _finalize_output(
            df=df,
            raw_score=score,
            threshold=threshold,
            reason_code="ARIMA_RESIDUAL",
            explain="Forecast residual anomaly exceeds threshold",
            artifacts={"order": list(order), "engine": used},
        )


def _peer_stats(df: pd.DataFrame) -> pd.DataFrame:
    x = df.copy()
    x["value"] = pd.to_numeric(x["value"], errors="coerce")
    g = x.groupby("date", as_index=False)["value"].agg(
        peer_median="median",
        peer_q25=lambda s: s.quantile(0.25),
        peer_q75=lambda s: s.quantile(0.75),
        peer_mad=lambda s: (s - s.median()).abs().median(),
    )
    return x.merge(g, on="date", how="left")


class PeerMedianDeviationCheck(DQCheck):
    def __init__(self, **params: Any) -> None:
        super().__init__(
            name="peer_median_dev",
            family=PEER_CROSS_GROUP,
            scope="per_peer_group",
            fit_policy="per_peer_group",
            **params,
        )

    def score(self, df: pd.DataFrame, context: dict[str, Any], model_state: dict[str, Any] | None = None) -> pd.DataFrame:
        del context, model_state
        if df["risk_factor_id"].nunique() < 2:
            return self.empty_result(df, "Peer group size < 2.")
        t = _peer_stats(df)
        iqr = (t["peer_q75"] - t["peer_q25"]).replace(0, np.nan)
        score = ((t["value"] - t["peer_median"]).abs() / (iqr + 1.0e-9)).fillna(0.0)
        return _finalize_output(
            df=t,
            raw_score=score,
            threshold=float(self.params.get("threshold", 2.0)),
            reason_code="PEER_MEDIAN_DEV",
            explain="Deviation from peer median exceeds threshold.",
            artifacts={},
        )


class PeerMADCheck(DQCheck):
    def __init__(self, **params: Any) -> None:
        super().__init__(
            name="peer_mad",
            family=PEER_CROSS_GROUP,
            scope="per_peer_group",
            fit_policy="per_peer_group",
            **params,
        )

    def score(self, df: pd.DataFrame, context: dict[str, Any], model_state: dict[str, Any] | None = None) -> pd.DataFrame:
        del context, model_state
        if df["risk_factor_id"].nunique() < 2:
            return self.empty_result(df, "Peer group size < 2.")
        t = _peer_stats(df)
        score = ((t["value"] - t["peer_median"]).abs() / (t["peer_mad"] + 1.0e-9)).fillna(0.0)
        return _finalize_output(
            df=t,
            raw_score=score,
            threshold=float(self.params.get("threshold", 3.0)),
            reason_code="PEER_MAD",
            explain="Deviation from peer median in MAD units exceeds threshold.",
            artifacts={},
        )


class PeerRobustZCheck(DQCheck):
    def __init__(self, **params: Any) -> None:
        super().__init__(
            name="peer_robust_z",
            family=PEER_CROSS_GROUP,
            scope="per_peer_group",
            fit_policy="per_peer_group",
            **params,
        )

    def score(self, df: pd.DataFrame, context: dict[str, Any], model_state: dict[str, Any] | None = None) -> pd.DataFrame:
        del context, model_state
        if df["risk_factor_id"].nunique() < 2:
            return self.empty_result(df, "Peer group size < 2.")
        t = _peer_stats(df)
        score = ((t["value"] - t["peer_median"]).abs() / (1.4826 * t["peer_mad"] + 1.0e-9)).fillna(0.0)
        return _finalize_output(
            df=t,
            raw_score=score,
            threshold=float(self.params.get("threshold", 3.0)),
            reason_code="PEER_ROBUST_Z",
            explain="Peer robust z-score exceeds threshold.",
            artifacts={},
        )


class PeerPercentileCheck(DQCheck):
    def __init__(self, **params: Any) -> None:
        super().__init__(
            name="peer_percentile",
            family=PEER_CROSS_GROUP,
            scope="per_peer_group",
            fit_policy="per_peer_group",
            **params,
        )

    def score(self, df: pd.DataFrame, context: dict[str, Any], model_state: dict[str, Any] | None = None) -> pd.DataFrame:
        del context, model_state
        if df["risk_factor_id"].nunique() < 2:
            return self.empty_result(df, "Peer group size < 2.")
        t = df.copy()
        t["value"] = pd.to_numeric(t["value"], errors="coerce")
        t["peer_pct"] = t.groupby("date")["value"].rank(pct=True)
        score = (t["peer_pct"] - 0.5).abs() * 2.0
        return _finalize_output(
            df=t,
            raw_score=score,
            threshold=float(self.params.get("threshold", 0.95)),
            reason_code="PEER_PERCENTILE",
            explain="Peer percentile indicates cross-sectional tail outlier.",
            artifacts={},
        )
