# RFET IMA Workbench — Python / Streamlit PoC  (v2 schema)

Interactive proof-of-concept for the FRTB IMA Risk Factor Eligibility Test.
All sample data lives in `rfet_data.xlsx` — edit in Excel, save, and the app
picks up the changes on refresh.

## What's in the box

| File | Purpose |
|---|---|
| `app.py` | Streamlit app — 10 interactive sections. |
| `rfet_data.xlsx` | All sample data (31 RFs in `risk_factors`, plus 4 supporting sheets). **This is what you edit.** |
| `requirements.txt` | Python dependencies. |
| `README.md` | This file. |

## Quick start

```bash
pip install -r requirements.txt
streamlit run app.py
```

The app opens at http://localhost:8501.

## Editing data

1. Open `rfet_data.xlsx` in Excel.
2. Edit any cell — add an RF row, change a classification, bump a threshold.
3. Save the file.
4. In the browser: click **🔄 Reload data** in the sidebar (or refresh).

The cache key includes the file mtime, so a save invalidates it automatically.

## Sheets

| Sheet | Rows | What it drives |
|---|---|---|
| `readme` | — | In-workbook usage notes. |
| `risk_factors` | 31 | The core dataset — one row per RF. |
| `asset_classes` | 11 | Business-scope decisions (include / defer / exclude). |
| `pipeline_stages` | 7 | RPO pipeline funnel volumes. |
| `rf_types` | 5 | Mapping-engine logic per RF type. |
| `config` | 8 | Thresholds, as-of date, cycle. |

**Do not rename sheets or header columns** — the app reads them by name.

## `risk_factors` v2 schema

| Column | Meaning |
|---|---|
| `rf_id`, `rf_name`, `asset_class`, `product`, `currency`, `tenor` | Identification |
| `source_system`, `pricing_mdo`, `risk_rf` | Upstream lineage |
| `rfet_ready` | Gate before testing (`yes`/`no`) |
| `RF_to_LH` | FRTB liquidity horizon: `10d` / `20d` / `40d` / `60d` / `120d` |
| `rfet_classification` | `Modellable` / `Type A NMRF` / `Type B NMRF` |
| `qualititave_res`, `Quantititave_res` | Precomputed pass/fail |
| `rpo_count`, `rpo_threshold` | Quant test (threshold = **24** if LH ≤ 20d, else **16**) |
| `qual1_capture_idio` … `qual6_proxy_fit` | Six qualitative tests |
| `rf_to_rpo_category`, `rf_to_rpo_lineage` | Mapping into the RPO pipeline |
| `target_date`, `evidence_status`, `remediation_status`, `remediation_path`, `notes` | Workflow |
| `capital_impact` *(derived in-app)* | `High` = Type B, `Low` = Type A, `None` = Modellable |

### Valid status values (auto-coloured)

| Value | Colour |
|---|---|
| `pass`, `yes`, `Modellable`, `Include`, `Ready`, `Complete` | 🟢 green |
| `warn`, `Type A NMRF`, `Defer`, `Partial`, `In Review`, `In Progress`, `Open`, `Low` | 🟡 amber |
| `fail`, `no`, `missing`, `Type B NMRF`, `Not Ready`, `High` | 🔴 red |
| `Not Required`, `Deferred`, `Defer to SA`, `Excluded` | ⚪ gray |

## Application sections

1. **Executive Overview** — KPI strip (incl. **Capital Impact: High / Low** buckets), flow strip, classification by AC, capital-impact split, top High-impact items table.
2. **Business Scope Nomination** — AC × sub-product scoring chart and decision table.
3. **MDO → RF Lineage** — pricing MDO → risk_rf supply chain + RPO category & lineage.
4. **RF Ready for RFET** — readiness by source system + detail table with LH.
5. **RFET Test Engine** — 6 qual tests + precomputed Qual/Quant results + RPO test per RF, with per-RF drill-down.
6. **RPO Pipeline** — 7-stage funnel chart + expandable stage details.
7. **Mapping Engine** — RF-type cards (single-dim, curve, surface, composed, parametric).
8. **Classification Dashboard** — AC × classification heatmap + LH split + capital impact split.
9. **Remediation Dashboard** — kanban (Open / In Progress / Deferred) + paths doughnut + capital-at-risk chart.
10. **About / Data model** — schema notes and demo script.

## Demo script (8 min)

1. **Executive Overview** — read off the High vs Low capital impact split.
2. **Business Scope** — show why exotic / small-issuer sub-products are deferred.
3. **Lineage** — show RFs with missing `pricing_mdo` (broken upstream).
4. **RFET Engine** — drill into **RF-IRRATE-004** (textbook Type A: qual ✓, RPO famine);
   then **RF-IRVOL-008** (SABR Beta — parametric must map to calibration instruments, not the parameter itself).
5. **RPO Pipeline** — 4.2M raw observations → ~890K mapped RPOs.
6. **Mapping Engine** — note the five mapping logics.
7. **Classification** — heatmap + LH split + capital impact bars.
8. **Remediation** — kanban view by status.

## Extending

- **New RF:** append a row to `risk_factors`. It flows through every section automatically.
- **Change thresholds:** edit `config.rpo_threshold_default` (or the per-row `rpo_threshold` directly).
- **New sub-product:** add a row to `asset_classes`.
- **Hook to live data:** replace `pd.read_excel(...)` in `load_data()` with a database query.
