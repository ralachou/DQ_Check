"""
RFET IMA Workbench — Streamlit app  (v3)
Run with:  streamlit run app.py
Data lives in rfet_data.xlsx — edit in Excel, save, refresh browser.
"""
from __future__ import annotations
from pathlib import Path

import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st

# ---------------------------------------------------------------------------
# Config & theme
# ---------------------------------------------------------------------------
APP_DIR = Path(__file__).parent
DATA_FILE = APP_DIR / 'rfet_data.xlsx'

st.set_page_config(
    page_title='RFET IMA Workbench',
    page_icon='📊',
    layout='wide',
    initial_sidebar_state='expanded',
)

# Colour tokens (match the HTML PoC)
COL_PASS = '#0F8F5E'
COL_WARN = '#C97A14'
COL_FAIL = '#B83C4F'
COL_MUTE = '#6B7280'
COL_NAVY = '#0B1A2E'
COL_BRASS = '#B8935A'
COL_CREAM = '#F2EFE7'

STATUS_COLORS = {
    'pass': COL_PASS, 'warn': COL_WARN, 'fail': COL_FAIL,
    'Modellable': COL_PASS, 'Type A NMRF': COL_WARN, 'Type B NMRF': COL_FAIL,
    'Defer to SA': COL_MUTE, 'Excluded': COL_MUTE,
    'Include': COL_PASS, 'Defer': COL_WARN, 'Exclude': COL_MUTE,
    'Ready': COL_PASS, 'Partial': COL_WARN, 'Not Ready': COL_FAIL,
    'Complete': COL_PASS, 'In Review': COL_WARN, 'missing': COL_FAIL, 'Missing': COL_FAIL,
    'None': COL_MUTE, 'Open': COL_WARN, 'In Progress': COL_WARN, 'Deferred': COL_MUTE,
    'Not Required': COL_MUTE, 'TBD': COL_MUTE,
    'yes': COL_PASS, 'no': COL_FAIL,
    'High': COL_FAIL, 'Low': COL_WARN,
}

# Six qualitative tests — display labels + descriptions
QUAL_TESTS = [
    ('qual1_capture_idio', 'Capture idio',  'Idiosyncratic Risk Capture',
     "Does the RF capture name- or instrument-specific risk that isn't driven by broader "
     "market factors? A name-specific spread should not be fully absorbed by the index proxy."),
    ('qual2_vol_corr',     'Vol / Corr',    'Volatility & Correlation',
     "Is the RF's modelled volatility consistent with observed market vol, and do its "
     "correlations to neighbouring RFs match empirical observation?"),
    ('qual3_rpo_rep',      'RPO repr.',     'RPO Representativeness',
     "Are the underlying real-price observations representative of the RF being modelled — "
     "same product, similar size, similar counterparty profile?"),
    ('qual4_update_freq',  'Update freq.',  'Update Frequency',
     "Is the RF refreshed in the risk system frequently enough to track price moves over "
     "its liquidity horizon (LH)?"),
    ('qual5_stress_rep',   'Stress repr.',  'Stress Period Representativeness',
     "Does the available history span a sufficiently stressful period to be meaningful for "
     "stressed-ES capital calculations?"),
    ('qual6_proxy_fit',    'Proxy fit',     'Proxy Fit Quality',
     "Where the RF acts as a proxy (or is being proxied), is the statistical fit between "
     "proxy and target acceptable per governance standards?"),
]

# Global CSS tweaks
st.markdown("""
<style>
    .block-container { padding-top: 1.5rem; padding-bottom: 2rem; max-width: 1400px; }
    section[data-testid="stSidebar"] { background: #F2EFE7; }
    h1, h2, h3 { font-family: 'Georgia', serif; color: #0B1A2E; }
    .pill {
        display: inline-block; padding: 2px 10px; border-radius: 999px;
        font-size: 0.78rem; font-weight: 600; letter-spacing: 0.02em;
        border: 1px solid;
    }
    .pill-pass  { color: #0F8F5E; background:#E8F5EE; border-color:#B6E0C7; }
    .pill-warn  { color: #C97A14; background:#FCEFD9; border-color:#F1D49A; }
    .pill-fail  { color: #B83C4F; background:#F8E3E7; border-color:#EFC0C9; }
    .pill-mute  { color: #6B7280; background:#F1F2F4; border-color:#D8DBE0; }

    /* Standard KPI card (still used on detail pages) */
    .kpi-card {
        background: white; border:1px solid #E5E7EB; border-radius:10px;
        padding:14px 16px; box-shadow: 0 1px 2px rgba(0,0,0,0.03);
    }
    .kpi-label { font-size:0.78rem; color:#6B7280; text-transform:uppercase;
                 letter-spacing:0.06em; font-weight:600; }
    .kpi-value { font-size:1.65rem; font-weight:700; color:#0B1A2E; margin-top:4px; }
    .kpi-sub   { font-size:0.78rem; color:#6B7280; margin-top:2px; }

    /* Hero KPI card — bigger, bolder, used on Executive Overview */
    .hero-kpi {
        background: white; border:1px solid #E5E7EB; border-radius:10px;
        padding:18px 18px; box-shadow: 0 2px 6px rgba(0,0,0,0.05);
        border-top: 3px solid #B8935A;
    }
    .hero-kpi-label { font-size:0.82rem; color:#0B1A2E; text-transform:uppercase;
                      letter-spacing:0.08em; font-weight:700; }
    .hero-kpi-value { font-size:2.4rem; font-weight:800; color:#0B1A2E; margin-top:6px;
                      line-height:1; }
    .hero-kpi-sub   { font-size:0.78rem; color:#6B7280; margin-top:6px; }

    /* Cycle badge */
    .cycle-badge {
        display:inline-block; background:#B8935A; color:white;
        padding:6px 14px; border-radius:6px; font-weight:700;
        letter-spacing:0.04em; font-size:0.95rem; margin-right:10px;
    }
    .asof-badge {
        display:inline-block; background:#0B1A2E; color:white;
        padding:6px 14px; border-radius:6px; font-weight:600;
        letter-spacing:0.04em; font-size:0.92rem;
    }

    .stage-box {
        background:white; border:1px solid #E5E7EB; border-left:4px solid #B8935A;
        padding:10px 14px; border-radius:6px; margin-bottom:8px;
    }
    .qual-card {
        background:white; border:1px solid #E5E7EB; border-radius:8px;
        padding:14px 16px; margin-bottom:12px;
        box-shadow: 0 1px 2px rgba(0,0,0,0.03);
    }
    .qual-card-head { display:flex; justify-content:space-between; align-items:baseline;
                      border-bottom:1px solid #E5E7EB; padding-bottom:8px; margin-bottom:10px; }
    .qual-card-title { font-family:Georgia, serif; color:#0B1A2E;
                       font-size:1.05rem; font-weight:700; }
    .qual-card-ref   { color:#6B7280; font-size:0.78rem; font-family:monospace; }
    .qual-card-desc  { color:#374151; font-size:0.9rem; line-height:1.5; }

    .kanban-card {
        background:white; border:1px solid #E5E7EB; border-radius:6px;
        padding:10px; margin-bottom:8px; font-size:0.85rem;
    }
    .kanban-col-head { font-weight:700; color:#0B1A2E; text-transform:uppercase;
                      letter-spacing:0.06em; font-size:0.78rem; margin-bottom:8px; }
</style>
""", unsafe_allow_html=True)


# ---------------------------------------------------------------------------
# Data loading
# ---------------------------------------------------------------------------
def _file_mtime(p: Path) -> float:
    return p.stat().st_mtime if p.exists() else 0.0


def _capital_bucket(cls: str) -> str:
    """Modellable → TBD, Type A NMRF → Low, Type B NMRF → High."""
    if cls == 'Type A NMRF':
        return 'Low'
    if cls == 'Type B NMRF':
        return 'High'
    return 'TBD'


@st.cache_data(show_spinner=False)
def load_data(mtime: float):
    sheets = pd.read_excel(DATA_FILE, sheet_name=None)
    rf = sheets['risk_factors'].copy()
    rf['capital_impact'] = rf['rfet_classification'].apply(_capital_bucket)
    cfg = sheets.get('config')
    if cfg is not None:
        cfg = dict(zip(cfg['key'], cfg['value']))
    return {
        'rf': rf,
        'ac': sheets['asset_classes'],
        'pipe': sheets['pipeline_stages'],
        'types': sheets['rf_types'],
        'cfg': cfg or {},
    }


def get_data():
    if not DATA_FILE.exists():
        st.error(f"Data file not found: {DATA_FILE}")
        st.stop()
    return load_data(_file_mtime(DATA_FILE))


# ---------------------------------------------------------------------------
# Small helpers
# ---------------------------------------------------------------------------
def pill(value) -> str:
    if value is None or (isinstance(value, float) and pd.isna(value)):
        return '<span class="pill pill-mute">—</span>'
    v = str(value).strip()
    if v == '':
        return '<span class="pill pill-mute">—</span>'
    vl = v.lower()
    cls = 'pill-mute'
    if vl in ('pass', 'yes') or v in ('Modellable', 'Include', 'Ready', 'Complete'):
        cls = 'pill-pass'
    elif vl in ('warn',) or v in ('Type A NMRF', 'Defer', 'Partial', 'In Review',
                                   'In Progress', 'Open', 'Low'):
        cls = 'pill-warn'
    elif vl in ('fail', 'no', 'missing') or v in ('Type B NMRF', 'Not Ready',
                                                    'Missing', 'High'):
        cls = 'pill-fail'
    return f'<span class="pill {cls}">{v}</span>'


def kpi(label: str, value, sub: str = ''):
    st.markdown(
        f'<div class="kpi-card"><div class="kpi-label">{label}</div>'
        f'<div class="kpi-value">{value}</div>'
        f'<div class="kpi-sub">{sub}</div></div>',
        unsafe_allow_html=True,
    )


def hero_kpi(label: str, value, sub: str = ''):
    """Larger, bolder KPI card for the Executive Overview strip."""
    st.markdown(
        f'<div class="hero-kpi"><div class="hero-kpi-label">{label}</div>'
        f'<div class="hero-kpi-value">{value}</div>'
        f'<div class="hero-kpi-sub">{sub}</div></div>',
        unsafe_allow_html=True,
    )


def render_df_with_pills(df: pd.DataFrame, pill_cols: list[str]):
    disp = df.copy()
    for c in pill_cols:
        if c in disp.columns:
            disp[c] = disp[c].apply(pill)
    html = disp.to_html(escape=False, index=False, classes='dataframe', border=0)
    st.markdown(
        '<style>'
        '.dataframe { font-size: 0.85rem; border-collapse: collapse; width: 100%; }'
        '.dataframe th { background: #0B1A2E; color: white; padding: 8px 10px; text-align: left;'
        '  font-weight: 600; letter-spacing: 0.02em; }'
        '.dataframe td { padding: 6px 10px; border-bottom: 1px solid #E5E7EB; }'
        '.dataframe tr:hover td { background: #FAF7EF; }'
        '</style>' + html,
        unsafe_allow_html=True,
    )


def asset_class_filter(df: pd.DataFrame, key: str = 'ac_filter') -> pd.DataFrame:
    classes = sorted(df['asset_class'].unique())
    chosen = st.sidebar.multiselect(
        'Asset class filter', classes, default=classes, key=key,
    )
    return df[df['asset_class'].isin(chosen)] if chosen else df


# ===========================================================================
# PAGES
# ===========================================================================
def page_exec(data):
    rf = data['rf']
    cfg = data['cfg']
    st.title('Executive Overview')

    # Prominent cycle + as-of badges
    st.markdown(
        f'<div style="margin-bottom:14px;">'
        f'<span class="cycle-badge">Cycle: {cfg.get("rfet_cycle", "—")}</span>'
        f'<span class="asof-badge">As-of: {cfg.get("as_of_date", "—")}</span>'
        f'<span style="margin-left:14px;color:#6B7280;">{len(rf)} risk factors in scope</span>'
        f'</div>',
        unsafe_allow_html=True,
    )

    # KPI strip — 7 hero cards
    n_total = len(rf)
    n_mod = (rf['rfet_classification'] == 'Modellable').sum()
    n_a   = (rf['rfet_classification'] == 'Type A NMRF').sum()
    n_b   = (rf['rfet_classification'] == 'Type B NMRF').sum()
    n_high = (rf['capital_impact'] == 'High').sum()
    n_low  = (rf['capital_impact'] == 'Low').sum()
    backlog = (rf['remediation_status'].isin(['Open', 'In Progress'])).sum()

    cols = st.columns(7)
    with cols[0]: hero_kpi('Total RFs',          n_total, 'in current scope')
    with cols[1]: hero_kpi('Modellable',         n_mod,   f'{n_mod/n_total:.0%} of population')
    with cols[2]: hero_kpi('Type A NMRF',        n_a,     'qual ✓, RPO famine')
    with cols[3]: hero_kpi('Type B NMRF',        n_b,     'qual gaps / broken')
    with cols[4]: hero_kpi('Capital High Impact', n_high, 'Type B NMRFs')
    with cols[5]: hero_kpi('Capital Low Impact',  n_low,  'Type A NMRFs')
    with cols[6]: hero_kpi('Backlog',            backlog, 'open + in-progress')

    st.markdown('---')

    # Flow strip
    st.subheader('End-to-end RFET flow')
    stages = ['Business Scope', 'RF Identification', 'RF Ready for RFET',
              'Qualitative Test', 'Quantitative Test', 'Classification',
              'Remediation', 'Capital Output']
    flow_cols = st.columns(len(stages))
    for c, s in zip(flow_cols, stages):
        with c:
            st.markdown(
                f'<div style="background:#0B1A2E;color:white;padding:10px 8px;'
                f'border-radius:6px;text-align:center;font-size:0.78rem;'
                f'font-weight:600;">{s}</div>',
                unsafe_allow_html=True,
            )

    st.markdown('---')

    left, right = st.columns([3, 2])
    with left:
        st.subheader('Classification by asset class')
        cross = (rf.groupby(['asset_class', 'rfet_classification']).size()
                 .reset_index(name='count'))
        fig = px.bar(cross, x='asset_class', y='count', color='rfet_classification',
                    color_discrete_map=STATUS_COLORS,
                    category_orders={'rfet_classification':
                                     ['Modellable', 'Type A NMRF', 'Type B NMRF']})
        fig.update_layout(barmode='stack', height=380, margin=dict(t=20, b=10),
                         plot_bgcolor='white', legend_title='')
        st.plotly_chart(fig, use_container_width=True)

    with right:
        st.subheader('Capital impact split')
        ci_counts = rf['capital_impact'].value_counts().reset_index()
        ci_counts.columns = ['Capital impact', 'Count']
        order = ['High', 'Low', 'TBD']
        ci_counts['__o'] = ci_counts['Capital impact'].map(
            {v: i for i, v in enumerate(order)})
        ci_counts = ci_counts.sort_values('__o').drop(columns='__o')
        fig2 = px.bar(ci_counts, x='Capital impact', y='Count',
                     color='Capital impact', color_discrete_map=STATUS_COLORS,
                     text='Count')
        fig2.update_traces(textposition='outside')
        fig2.update_layout(height=380, plot_bgcolor='white', showlegend=False,
                          margin=dict(t=20, b=10), xaxis_title='', yaxis_title='')
        st.plotly_chart(fig2, use_container_width=True)

    st.markdown('---')
    st.subheader('Top High-impact items needing attention')
    top = (rf[rf['capital_impact'] == 'High']
           [['rf_id', 'rf_name', 'asset_class', 'rfet_classification',
             'capital_impact', 'remediation_status', 'remediation_path']])
    if len(top) == 0:
        st.info('No High-impact items.')
    else:
        top.columns = ['ID', 'Name', 'AC', 'Classification', 'Capital Impact',
                      'Remediation', 'Path']
        render_df_with_pills(top, ['Classification', 'Capital Impact', 'Remediation'])


def page_scope(data):
    ac = data['ac']
    st.title('Desks in Scope')
    st.caption('Asset class × sub-product decisions: include / defer / exclude. '
              'All scores on a **1–10 scale**. Edit `asset_classes` sheet to change.')

    fig = go.Figure()
    fig.add_trace(go.Bar(
        x=ac['sub_product'], y=ac['capital_impact_score'], name='Capital impact',
        marker_color=COL_NAVY,
    ))
    fig.add_trace(go.Bar(
        x=ac['sub_product'], y=ac['model_pass_probability_score'],
        name='Model pass prob',
        marker_color=COL_BRASS,
    ))
    fig.add_trace(go.Bar(
        x=ac['sub_product'], y=ac['cost_benefit_score'], name='Cost-benefit',
        marker_color=COL_PASS,
    ))
    fig.update_layout(barmode='group', height=400, plot_bgcolor='white',
                     margin=dict(t=20, b=80), xaxis_tickangle=-30,
                     yaxis=dict(range=[0, 10], title='Score (1–10)'))
    st.plotly_chart(fig, use_container_width=True)

    st.subheader('Decision table')
    render_df_with_pills(ac, ['decision', 'bt_pla_readiness'])


def page_lineage(data):
    rf = data['rf']
    st.title('MDO → Risk Factor Lineage')
    st.caption('Pricing MDO and Risk RF supply chain per risk factor.')
    rf_f = asset_class_filter(rf)

    # Trimmed: removed RPO Category and RPO Lineage
    cols = ['rf_id', 'rf_name', 'asset_class', 'source_system',
            'pricing_mdo', 'risk_rf', 'rfet_ready']
    disp = rf_f[cols].copy()
    disp.columns = ['ID', 'Name', 'AC', 'Source', 'Pricing MDO',
                   'Risk RF', 'RFET Ready']
    disp['Pricing MDO'] = disp['Pricing MDO'].fillna('— missing —')
    disp['Risk RF'] = disp['Risk RF'].fillna('— missing —')
    render_df_with_pills(disp, ['RFET Ready'])


def page_ready(data):
    rf = data['rf']
    st.title('RF_to_LH mapping')
    st.caption('Each risk factor is mapped to its FRTB liquidity horizon '
              '(10d / 20d / 40d / 60d / 120d) and its readiness state by source system.')

    # LH distribution chart
    lh_order = ['10d', '20d', '40d', '60d', '120d']
    lh_counts = (rf.groupby(['RF_to_LH', 'rfet_classification']).size()
                .reset_index(name='count'))
    lh_counts['__o'] = lh_counts['RF_to_LH'].map({v: i for i, v in enumerate(lh_order)})
    lh_counts = lh_counts.sort_values('__o')
    st.subheader('LH distribution across the RF population')
    fig_lh = px.bar(lh_counts, x='RF_to_LH', y='count',
                   color='rfet_classification',
                   color_discrete_map=STATUS_COLORS,
                   category_orders={'RF_to_LH': lh_order,
                                    'rfet_classification':
                                        ['Modellable', 'Type A NMRF', 'Type B NMRF']})
    fig_lh.update_layout(barmode='stack', height=320, plot_bgcolor='white',
                        margin=dict(t=20, b=10), xaxis_title='Liquidity Horizon',
                        yaxis_title='# RFs', legend_title='')
    st.plotly_chart(fig_lh, use_container_width=True)

    st.markdown('---')
    rf['_ready_lo'] = rf['rfet_ready'].astype(str).str.lower()
    by_src = rf.groupby('source_system').agg(
        total=('rf_id', 'count'),
        ready=('_ready_lo', lambda s: ((s == 'yes') | (s == 'pass')).sum()),
        blocked=('_ready_lo', lambda s: ((s == 'no') | (s == 'fail')).sum()),
    ).reset_index()
    by_src.columns = ['Source', 'Total RFs', 'Ready', 'Blocked']
    st.subheader('Readiness by source system')
    render_df_with_pills(by_src, [])

    st.markdown('---')
    st.subheader('Readiness detail')
    rf_f = asset_class_filter(rf)
    # Trimmed: removed Evidence column
    cols = ['rf_id', 'rf_name', 'source_system', 'rfet_ready', 'RF_to_LH']
    disp = rf_f[cols].copy()
    disp.columns = ['ID', 'Name', 'Source', 'RFET Ready', 'LH']
    render_df_with_pills(disp, ['RFET Ready'])


def page_engine(data):
    rf = data['rf']
    st.title('RFET Tests Details')
    st.caption("Six qualitative tests + Quantitative test (RPO count ≥ threshold). "
              "Threshold is **24** for LH ≤ 20d, **16** otherwise.")
    rf_f = asset_class_filter(rf)

    cols = (['rf_id', 'rf_name', 'asset_class', 'RF_to_LH']
            + [c for c, _, _, _ in QUAL_TESTS]
            + ['qualititave_res', 'rpo_count', 'rpo_threshold',
               'Quantititave_res', 'rfet_classification'])
    disp = rf_f[cols].copy()
    disp.columns = (['ID', 'Name', 'AC', 'LH']
                    + [lbl for _, lbl, _, _ in QUAL_TESTS]
                    + ['Qual', 'RPOs', 'RPO Thr', 'Quant', 'Classification'])
    render_df_with_pills(
        disp,
        [lbl for _, lbl, _, _ in QUAL_TESTS] + ['Qual', 'Quant', 'Classification'],
    )

    st.markdown('---')
    st.subheader('Drill into a single risk factor')
    rfid = st.selectbox('Choose an RF', rf_f['rf_id'].tolist())
    row = rf_f[rf_f['rf_id'] == rfid].iloc[0]
    render_rf_drilldown(row)


def render_rf_drilldown(row):
    """Detailed per-RF panel — RPO Category and Capital Impact removed."""
    c1, c2, c3 = st.columns([2, 1, 1])
    with c1:
        st.markdown(f"### {row['rf_id']} — {row['rf_name']}")
        st.caption(f"{row['asset_class']} · {row['product']} · "
                  f"{row['currency']} · {row['tenor']} · LH {row['RF_to_LH']}")
    with c2:
        kpi('Classification', row['rfet_classification'])
    with c3:
        kpi('RFET Ready', row['rfet_ready'])

    st.markdown('#### Qualitative tests (6)')
    q_cols = st.columns(6)
    for c, (key, label, _, _) in zip(q_cols, QUAL_TESTS):
        with c:
            st.markdown(
                f'<div class="kpi-card"><div class="kpi-label">{label}</div>'
                f'<div style="margin-top:6px;">{pill(row[key])}</div></div>',
                unsafe_allow_html=True,
            )

    st.markdown('#### Test results & quantitative')
    q1, q2, q3, q4, q5 = st.columns(5)
    rpo_pass = int(row['rpo_count']) >= int(row['rpo_threshold'])
    with q1: kpi('Qual result',  row['qualititave_res'])
    with q2: kpi('Quant result', row['Quantititave_res'])
    with q3: kpi('RPO count',    int(row['rpo_count']))
    with q4: kpi('RPO threshold', int(row['rpo_threshold']),
                 f"LH {row['RF_to_LH']}")
    with q5: kpi('RPO test', '✓ Pass' if rpo_pass else '✗ Fail')

    st.markdown('#### Remediation')
    r1, r2, r3 = st.columns(3)
    with r1: kpi('Evidence',  row.get('evidence_status', '—'))
    with r2: kpi('Status',    row.get('remediation_status', '—'))
    with r3: kpi('Target',    row.get('target_date', '—'))
    path = row.get('remediation_path', '')
    if pd.notna(path) and str(path).strip() not in ('', '—'):
        st.markdown(f"**Path:** {path}")
    notes = row.get('notes', '')
    if pd.notna(notes) and str(notes).strip():
        st.info(f"**Note:** {notes}")


def page_classification_summary(data):
    """RFET Classification Summary — moved up, slimmed down."""
    rf = data['rf']
    st.title('RFET Classification Summary')
    st.caption('Final RFET outcomes per risk factor.')

    # Heatmap
    pivot = (rf.groupby(['asset_class', 'rfet_classification']).size()
             .unstack(fill_value=0))
    for c in ['Modellable', 'Type A NMRF', 'Type B NMRF']:
        if c not in pivot.columns:
            pivot[c] = 0
    pivot = pivot[['Modellable', 'Type A NMRF', 'Type B NMRF']]

    fig = px.imshow(
        pivot.values, x=pivot.columns, y=pivot.index,
        color_continuous_scale='RdBu_r', text_auto=True, aspect='auto',
    )
    fig.update_layout(height=320, margin=dict(t=20, b=20),
                     coloraxis_colorbar={'title': 'Count'})
    st.subheader('Heatmap: asset class × classification')
    st.plotly_chart(fig, use_container_width=True)

    st.markdown('---')

    c1, c2 = st.columns(2)
    with c1:
        st.subheader('Classification × Liquidity Horizon')
        cross_lh = (rf.groupby(['RF_to_LH', 'rfet_classification']).size()
                    .reset_index(name='count'))
        lh_order = ['10d', '20d', '40d', '60d', '120d']
        cross_lh['__o'] = cross_lh['RF_to_LH'].map({v: i for i, v in enumerate(lh_order)})
        cross_lh = cross_lh.sort_values('__o')
        fig2 = px.bar(cross_lh, x='RF_to_LH', y='count', color='rfet_classification',
                     color_discrete_map=STATUS_COLORS,
                     category_orders={'RF_to_LH': lh_order})
        fig2.update_layout(barmode='stack', height=340, plot_bgcolor='white',
                          margin=dict(t=20, b=10), xaxis_title='LH',
                          yaxis_title='count', legend_title='')
        st.plotly_chart(fig2, use_container_width=True)

    with c2:
        st.subheader('Population by classification')
        cls_counts = rf['rfet_classification'].value_counts().reset_index()
        cls_counts.columns = ['Classification', 'Count']
        order = ['Modellable', 'Type A NMRF', 'Type B NMRF']
        cls_counts['__o'] = cls_counts['Classification'].map(
            {v: i for i, v in enumerate(order)})
        cls_counts = cls_counts.sort_values('__o').drop(columns='__o')
        fig3 = px.bar(cls_counts, x='Classification', y='Count',
                     color='Classification', color_discrete_map=STATUS_COLORS,
                     text='Count')
        fig3.update_traces(textposition='outside')
        fig3.update_layout(height=340, plot_bgcolor='white', showlegend=False,
                          margin=dict(t=20, b=10), xaxis_title='', yaxis_title='')
        st.plotly_chart(fig3, use_container_width=True)

    st.markdown('---')
    st.subheader('Classification summary table')
    rf_f = asset_class_filter(rf, key='cls_filter')
    # Slimmed: ID, Name, AC, LH, classification, qual_result, quant_result
    cols = ['rf_id', 'rf_name', 'asset_class', 'RF_to_LH',
            'rfet_classification', 'qualititave_res', 'Quantititave_res']
    disp = rf_f[cols].copy()
    disp.columns = ['ID', 'Name', 'AC', 'LH', 'Classification',
                   'Qual Result', 'Quant Result']
    render_df_with_pills(disp, ['Classification', 'Qual Result', 'Quant Result'])


def page_qual_buildout(data):
    """Qualitative Tests Buildout — describes each of the six tests."""
    rf = data['rf']
    st.title('Qualitative Tests Buildout')
    st.caption('Description, evaluation criteria, and population results for each of the '
              'six qualitative tests under RFET.')

    # Per-RF qualitative test results table (ID, Name + 6 qualN_ columns)
    st.subheader('Per-RF qualitative test results')
    rf_f = asset_class_filter(rf, key='qual_filter')
    qual_cols = [c for c, _, _, _ in QUAL_TESTS]
    disp = rf_f[['rf_id', 'rf_name'] + qual_cols].copy()
    disp.columns = ['ID', 'Name'] + qual_cols  # keep the qualN_ names visible
    render_df_with_pills(disp, qual_cols)

    st.markdown('---')
    # High-level summary chart: pass/fail per test
    summary_rows = []
    for col, _, name, _ in QUAL_TESTS:
        s = rf[col].astype(str).str.lower()
        summary_rows.append({
            'Test': name,
            'pass': (s == 'pass').sum(),
            'warn': (s == 'warn').sum(),
            'fail': (s == 'fail').sum(),
        })
    summary_df = pd.DataFrame(summary_rows)
    summary_long = summary_df.melt(id_vars='Test', var_name='Result', value_name='Count')
    fig = px.bar(summary_long, x='Test', y='Count', color='Result',
                color_discrete_map={'pass': COL_PASS, 'warn': COL_WARN, 'fail': COL_FAIL},
                category_orders={'Result': ['pass', 'warn', 'fail']})
    fig.update_layout(barmode='stack', height=340, plot_bgcolor='white',
                     margin=dict(t=20, b=10), xaxis_tickangle=-15,
                     legend_title='', xaxis_title='', yaxis_title='RFs')
    st.subheader('Population results across the six tests')
    st.plotly_chart(fig, use_container_width=True)

    st.markdown('---')
    st.subheader('Test descriptions')

    # Card per test
    for i, (col, label, name, desc) in enumerate(QUAL_TESTS, 1):
        results = rf[col].astype(str).str.lower().value_counts().to_dict()
        n_pass = results.get('pass', 0)
        n_warn = results.get('warn', 0)
        n_fail = results.get('fail', 0)

        # Top 3 failing RFs for this test
        failing = rf[rf[col].astype(str).str.lower() != 'pass'][['rf_id', 'rf_name', col]]
        failing_html = ''
        if len(failing) > 0:
            failing_html = '<div style="margin-top:10px;color:#374151;font-size:0.85rem;">'
            failing_html += '<b>RFs not passing:</b> '
            items = []
            for _, r in failing.head(6).iterrows():
                items.append(f'{r["rf_id"]} ({r[col]})')
            failing_html += ', '.join(items)
            if len(failing) > 6:
                failing_html += f' &nbsp;<span style="color:#6B7280;">+{len(failing)-6} more</span>'
            failing_html += '</div>'

        st.markdown(
            f'<div class="qual-card">'
            f'<div class="qual-card-head">'
            f'<span class="qual-card-title">{i}. {name}</span>'
            f'<span class="qual-card-ref">{col}</span>'
            f'</div>'
            f'<div class="qual-card-desc">{desc}</div>'
            f'<div style="margin-top:10px;">'
            f'{pill("pass")} &nbsp;{n_pass} &nbsp;&nbsp;'
            f'{pill("warn")} &nbsp;{n_warn} &nbsp;&nbsp;'
            f'{pill("fail")} &nbsp;{n_fail}'
            f'</div>'
            f'{failing_html}'
            f'</div>',
            unsafe_allow_html=True,
        )


def page_quant_buildout(data):
    """Quantitative Tests Buildout — main table + 4 sub-tabs."""
    rf = data['rf']
    pipe = data['pipe']
    types = data['types']

    st.title('Quantitative Tests Buildout')
    st.caption("RPO-based quantitative test plus the four pipeline stages that feed it.")

    tabs = st.tabs(['Overview', 'RPO Pipeline',
                   'Storage / Ingest / Norm / Bucket',
                   'Aggregation', 'RPO → RF Mapping'])

    # ---------- Tab 1: Overview ----------
    with tabs[0]:
        st.subheader('Per-RF Quantitative results')
        st.caption('Threshold = **24** for LH ≤ 20d, **16** otherwise. '
                  'Quant pass requires RPO count ≥ threshold.')
        rf_f = asset_class_filter(rf, key='quant_filter')
        cols = ['rf_id', 'rf_name', 'asset_class', 'RF_to_LH',
                'rpo_count', 'rpo_threshold', 'Quantititave_res',
                'rf_to_rpo_category', 'rf_to_rpo_lineage']
        disp = rf_f[cols].copy()
        disp.columns = ['ID', 'Name', 'AC', 'LH', 'RPO Count',
                       'RPO Threshold', 'Result', 'RPO Category', 'RPO Lineage']
        render_df_with_pills(disp, ['Result'])

    # ---------- Tab 2: RPO Pipeline (full funnel) ----------
    with tabs[1]:
        st.subheader('End-to-end RPO pipeline — 7 stages')
        st.caption('Raw observations on the left, RFET-ready RPO counts on the right.')
        fig = go.Figure(go.Funnel(
            y=pipe['name'], x=pipe['output_volume'],
            textinfo='value+percent initial',
            marker={'color': [COL_NAVY] * len(pipe)},
        ))
        fig.update_layout(height=440, margin=dict(t=20, b=20))
        st.plotly_chart(fig, use_container_width=True)

        st.markdown('---')
        st.subheader('Stage detail')
        for _, s in pipe.iterrows():
            with st.expander(f"Stage {s['stage']} — {s['name']} "
                            f"({s['input_volume']:,} → {s['output_volume']:,}, "
                            f"drop {s['drop_pct']:.1f}%)"):
                st.markdown(f"**Description:** {s['description']}")
                c1, c2, c3 = st.columns(3)
                with c1: kpi('Owner', s['owner'])
                with c2: kpi('Input', f"{s['input_volume']:,}")
                with c3: kpi('Output', f"{s['output_volume']:,}")
                st.markdown(f"**Inputs:** {s['inputs']}")
                st.markdown(f"**Outputs:** {s['outputs']}")

    # ---------- Tab 3: Storage / Ingest / Norm / Bucket (stages 1-5) ----------
    with tabs[2]:
        st.subheader('Storage, Ingesting, Normalization & Bucketing')
        st.caption('Pipeline stages 1–5: from raw vendor feed to bucket-tagged observations.')
        sub = pipe[pipe['stage'].between(1, 5)]
        fig = go.Figure(go.Funnel(
            y=sub['name'], x=sub['output_volume'],
            textinfo='value+percent initial',
            marker={'color': [COL_BRASS] * len(sub)},
        ))
        fig.update_layout(height=380, margin=dict(t=20, b=20))
        st.plotly_chart(fig, use_container_width=True)

        st.markdown('---')
        for _, s in sub.iterrows():
            st.markdown(
                f'<div class="stage-box">'
                f'<h4 style="margin:0;color:#0B1A2E;">Stage {s["stage"]} — {s["name"]}</h4>'
                f'<p style="color:#374151;margin:6px 0;font-size:0.9rem;">{s["description"]}</p>'
                f'<div style="font-size:0.85rem;color:#52647A;">'
                f'<b>In:</b> {s["inputs"]}<br>'
                f'<b>Out:</b> {s["outputs"]}<br>'
                f'<b>Volume:</b> {s["input_volume"]:,} → {s["output_volume"]:,} '
                f'<span style="color:#B83C4F;">(–{s["drop_pct"]:.1f}%)</span>'
                f' &nbsp;·&nbsp; <b>Owner:</b> {s["owner"]}'
                f'</div></div>',
                unsafe_allow_html=True,
            )

    # ---------- Tab 4: Aggregation (stage 6) ----------
    with tabs[3]:
        st.subheader('Aggregation to RPOs')
        st.caption('Pipeline stage 6: collapse intra-day observations, dedupe counterparty, '
                  'and emit the per-RF RPO time series.')
        sub = pipe[pipe['stage'] == 6]
        if len(sub) > 0:
            s = sub.iloc[0]
            cols = st.columns(4)
            with cols[0]: kpi('Stage', f"{s['stage']}")
            with cols[1]: kpi('Input volume', f"{s['input_volume']:,}")
            with cols[2]: kpi('Output volume', f"{s['output_volume']:,}")
            with cols[3]: kpi('Drop', f"{s['drop_pct']:.1f}%")
            st.markdown('---')
            st.markdown(f"**Description:** {s['description']}")
            st.markdown(f"**Inputs:** {s['inputs']}")
            st.markdown(f"**Outputs:** {s['outputs']}")
            st.markdown(f"**Owner:** {s['owner']}")

        # RPO count distribution across the population
        st.markdown('---')
        st.subheader('RPO count distribution across the RF population')
        fig = px.histogram(rf, x='rpo_count', nbins=20, color='rfet_classification',
                          color_discrete_map=STATUS_COLORS,
                          category_orders={'rfet_classification':
                                           ['Modellable', 'Type A NMRF', 'Type B NMRF']})
        fig.update_layout(height=340, plot_bgcolor='white',
                         margin=dict(t=20, b=10), legend_title='',
                         xaxis_title='RPO count', yaxis_title='# RFs')
        st.plotly_chart(fig, use_container_width=True)

    # ---------- Tab 5: RPO → RF Mapping ----------
    with tabs[4]:
        st.subheader('RPO → Risk Factor mapping')
        st.caption('Pipeline stage 7 — how observations get attached to each RF type.')

        for _, t in types.iterrows():
            st.markdown(
                f'<div class="stage-box">'
                f'<h4 style="margin:0;color:#0B1A2E;">{t["rf_type"]}</h4>'
                f'<p style="color:#6B7280;margin:4px 0 8px 0;font-size:0.88rem;">'
                f'{t["description"]}</p>'
                f'<div style="font-size:0.9rem;"><b>Mapping logic:</b> {t["mapping_logic"]}</div>'
                f'<div style="font-size:0.9rem;margin-top:6px;color:#52647A;">'
                f'<b>Example:</b> {t["worked_example"]}</div>'
                f'</div>',
                unsafe_allow_html=True,
            )

        st.markdown('---')
        st.subheader('Risk factors by mapping category')
        cat_counts = rf.groupby('rf_to_rpo_category').size().reset_index(name='count')
        fig = px.bar(cat_counts, x='rf_to_rpo_category', y='count',
                    color='rf_to_rpo_category', text='count')
        fig.update_traces(textposition='outside')
        fig.update_layout(height=320, plot_bgcolor='white', showlegend=False,
                         margin=dict(t=20, b=10),
                         xaxis_title='', yaxis_title='# RFs')
        st.plotly_chart(fig, use_container_width=True)


def page_remediate(data):
    rf = data['rf']
    st.title('IMA RF Readiness and Remediation')
    st.caption('Backlog of NMRFs with paths back to modellable (or to SA).')

    rem = rf[rf['rfet_classification'].isin(['Type A NMRF', 'Type B NMRF'])].copy()

    c1, c2 = st.columns([1, 1])
    with c1:
        st.subheader('Remediation paths')
        path_counts = rem['remediation_path'].fillna('Unspecified').value_counts().reset_index()
        path_counts.columns = ['Path', 'Count']
        fig = px.pie(path_counts, values='Count', names='Path', hole=0.55)
        fig.update_layout(height=360, margin=dict(t=20, b=20))
        st.plotly_chart(fig, use_container_width=True)

    with c2:
        st.subheader('Capital impact split (NMRFs)')
        ci_by = rem.groupby('capital_impact').size().reset_index(name='count')
        order = ['High', 'Low']
        ci_by['__o'] = ci_by['capital_impact'].map({v: i for i, v in enumerate(order)})
        ci_by = ci_by.sort_values('__o')
        fig2 = px.bar(ci_by, x='capital_impact', y='count',
                     color='capital_impact', color_discrete_map=STATUS_COLORS,
                     text='count')
        fig2.update_traces(textposition='outside')
        fig2.update_layout(height=360, plot_bgcolor='white', showlegend=False,
                          margin=dict(t=20, b=10),
                          xaxis_title='', yaxis_title='count')
        st.plotly_chart(fig2, use_container_width=True)

    st.markdown('---')
    st.subheader('Kanban — by remediation status')
    statuses = ['Open', 'In Progress', 'Deferred']
    kan_cols = st.columns(len(statuses))
    for c, status in zip(kan_cols, statuses):
        items = rem[rem['remediation_status'] == status]
        with c:
            st.markdown(f'<div class="kanban-col-head">{status} '
                       f'({len(items)})</div>', unsafe_allow_html=True)
            for _, r in items.iterrows():
                st.markdown(
                    f'<div class="kanban-card">'
                    f'<b>{r["rf_id"]}</b><br>'
                    f'<span style="color:#6B7280;font-size:0.78rem;">'
                    f'{str(r["rf_name"])[:40]}</span><br>'
                    f'<div style="margin-top:6px;">{pill(r["rfet_classification"])}'
                    f' &nbsp; {pill(r["capital_impact"])}</div>'
                    f'<div style="color:#6B7280;font-size:0.78rem;margin-top:4px;">'
                    f'{r["asset_class"]} · LH {r["RF_to_LH"]}</div>'
                    f'</div>',
                    unsafe_allow_html=True,
                )

    st.markdown('---')
    st.subheader('Remediation table')
    cols = ['rf_id', 'rf_name', 'asset_class', 'rfet_classification',
            'remediation_status', 'remediation_path', 'capital_impact',
            'target_date']
    disp = rem[cols].copy()
    disp.columns = ['ID', 'Name', 'AC', 'Classification', 'Status', 'Path',
                   'Capital Impact', 'Target']
    render_df_with_pills(disp, ['Classification', 'Status', 'Capital Impact'])


def page_about(data):
    st.title('About this PoC')
    st.markdown("""
**RFET IMA Workbench** — interactive proof-of-concept for the Risk Factor
Eligibility Test under FRTB Internal Models Approach.

#### Navigation
1. **Executive Overview** — population-level KPIs and charts.
2. **Desks in Scope** — business-scope nomination (include / defer / exclude).
3. **MDO → RF Lineage** — upstream pricing MDO and risk RF supply chain.
4. **RF Ready for RFET** — gate state per RF.
5. **RFET Tests Details** — the six qual tests + quant test per RF, with drill-down.
6. **RFET Classification Summary** — slim outcomes table + heatmap.
7. **Qualitative Tests Buildout** — description of each of the six qual tests.
8. **Quantitative Tests Buildout** (5 tabs)
    - Overview — per-RF quant table
    - RPO Pipeline — 7-stage funnel
    - Storage / Ingest / Norm / Bucket — pipeline stages 1–5
    - Aggregation — pipeline stage 6
    - RPO → RF Mapping — pipeline stage 7 (the 5 mapping logics)
9. **IMA RF Readiness and Remediation** — kanban backlog + paths.
10. **About / Data model** — this page.

#### Data model — `risk_factors` v2 schema

| Column | Meaning |
|---|---|
| `rf_id`, `rf_name`, `asset_class`, `product`, `currency`, `tenor` | Identification |
| `source_system`, `pricing_mdo`, `risk_rf` | Upstream lineage |
| `rfet_ready` | Gate before testing (`yes` / `no`) |
| `RF_to_LH` | FRTB liquidity horizon: 10d / 20d / 40d / 60d / 120d |
| `rfet_classification` | Modellable / Type A NMRF / Type B NMRF |
| `qualititave_res`, `Quantititave_res` | Precomputed pass/fail results |
| `rpo_count`, `rpo_threshold` | Quant test (threshold = 24 if LH ≤ 20d else 16) |
| `qual1_capture_idio` … `qual6_proxy_fit` | Six qualitative tests |
| `rf_to_rpo_category`, `rf_to_rpo_lineage` | Mapping into the RPO pipeline |
| `target_date`, `evidence_status`, `remediation_status`, `remediation_path`, `notes` | Workflow |
| `capital_impact` *(derived in-app)* | High = Type B, Low = Type A, **TBD** = Modellable |

#### Colour key
- 🟢 **pass / Modellable / Complete / yes**
- 🟡 **warn / Type A NMRF / Low / Partial / In Progress / Open**
- 🔴 **fail / Type B NMRF / High / Missing**
- ⚪ **TBD / Not Required / Deferred / Defer to SA**
""")


# ===========================================================================
# SIDEBAR + ROUTER
# ===========================================================================
PAGES = {
    'Executive Overview':                page_exec,
    'Desks in Scope':                    page_scope,
    'MDO → RF Lineage':                  page_lineage,
    'RF_to_LH mapping':                  page_ready,
    'RFET Classification Summary':       page_classification_summary,
    'RFET Tests Details':                page_engine,
    'Qualitative Tests Buildout':        page_qual_buildout,
    'Quantitative Tests Buildout':       page_quant_buildout,
    'IMA RF Readiness and Remediation':  page_remediate,
}


def main():
    data = get_data()
    cfg = data['cfg']

    with st.sidebar:
        st.markdown(f"### 📊 RFET IMA")
        st.markdown(
            f'<div style="background:#B8935A;color:white;padding:6px 12px;'
            f'border-radius:6px;font-weight:700;font-size:0.9rem;text-align:center;'
            f'margin-bottom:6px;">Cycle: {cfg.get("rfet_cycle", "—")}</div>',
            unsafe_allow_html=True,
        )
        st.caption(f"As-of {cfg.get('as_of_date', '—')}")
        page = st.radio('Navigation', list(PAGES.keys()), label_visibility='collapsed')

        st.markdown('---')
        if st.button('🔄 Reload data', use_container_width=True):
            st.cache_data.clear()
            st.rerun()

    PAGES[page](data)


if __name__ == '__main__':
    main()
