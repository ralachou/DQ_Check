from __future__ import annotations

from typing import Any

import pandas as pd

TAXONOMY_LEVELS = ["rf_level1", "rf_level2", "rf_level3", "rf_level4", "rf_level5"]
TAXONOMY_COLUMNS = ["asset_class", "ccy"] + TAXONOMY_LEVELS
TAXONOMY_PEER_KEYS = ["asset_class", "ccy"] + TAXONOMY_LEVELS
DEFAULT_NULL_TOKEN = "null"

_MISSING_STRINGS = {"", "nan", "none", "null", "<na>", "nat"}

_ALIASES: dict[str, list[str]] = {
    "risk_factor_id": ["risk_factor_id", "driverName", "driver_name"],
    "asset_class": ["asset_class", "assetClass", "rf_asset_class"],
    "ccy": ["ccy", "currency", "rf_ccy"],
    "rf_level1": ["rf_level1", "rfLevel1"],
    "rf_level2": ["rf_level2", "rfLevel2"],
    "rf_level3": ["rf_level3", "rfLevel3"],
    "rf_level4": ["rf_level4", "rfLevel4"],
    "rf_level5": ["rf_level5", "rfLevel5"],
}


def _find_col(df: pd.DataFrame, names: list[str]) -> str | None:
    for n in names:
        if n in df.columns:
            return n
    lower_map = {str(c).strip().lower(): str(c) for c in df.columns}
    for n in names:
        hit = lower_map.get(str(n).strip().lower())
        if hit is not None:
            return hit
    return None


def _clean_text_series(series: pd.Series, default: str = DEFAULT_NULL_TOKEN) -> pd.Series:
    s = series.astype("string").fillna(default).str.strip()
    lower = s.str.lower()
    s = s.mask(lower.isin(_MISSING_STRINGS), default)
    return s.astype(str)


def _coalesce_series(parts: list[pd.Series], default: str = DEFAULT_NULL_TOKEN) -> pd.Series:
    if not parts:
        return pd.Series(dtype=str)
    out = _clean_text_series(parts[0], default=default)
    for p in parts[1:]:
        nxt = _clean_text_series(p, default=default)
        out = out.where(out != default, nxt)
    return _clean_text_series(out, default=default)


def normalize_taxonomy_frame(
    df: pd.DataFrame,
    *,
    default: str = DEFAULT_NULL_TOKEN,
    require_risk_factor_id: bool = False,
) -> pd.DataFrame:
    """Normalize taxonomy columns with consistent non-destructive fallbacks.

    Fallback rules:
    - asset_class <- asset_class OR rf_level1
    - ccy         <- ccy OR rf_level2
    - rf_level1   <- rf_level1 OR asset_class
    - rf_level2   <- rf_level2 OR ccy
    - rf_level3..5 default to "null" when missing
    """

    out = df.copy()

    id_col = _find_col(out, _ALIASES["risk_factor_id"])
    if id_col is None:
        if require_risk_factor_id:
            raise ValueError("Missing risk factor identifier column (risk_factor_id/driverName/driver_name).")
        out["risk_factor_id"] = default
    elif id_col != "risk_factor_id":
        out["risk_factor_id"] = out[id_col]

    for col in TAXONOMY_COLUMNS:
        src = _find_col(out, _ALIASES.get(col, [col]))
        if src is None:
            out[col] = default
        elif col not in out.columns:
            out[col] = out[src]

    out["asset_class"] = _coalesce_series([out["asset_class"], out["rf_level1"]], default=default)
    out["ccy"] = _coalesce_series([out["ccy"], out["rf_level2"]], default=default)
    out["rf_level1"] = _coalesce_series([out["rf_level1"], out["asset_class"]], default=default)
    out["rf_level2"] = _coalesce_series([out["rf_level2"], out["ccy"]], default=default)
    out["rf_level3"] = _clean_text_series(out["rf_level3"], default=default)
    out["rf_level4"] = _clean_text_series(out["rf_level4"], default=default)
    out["rf_level5"] = _clean_text_series(out["rf_level5"], default=default)
    out["risk_factor_id"] = _clean_text_series(out["risk_factor_id"], default=default)

    return out


def apply_taxonomy_filters(df: pd.DataFrame, filters: dict[str, Any] | None = None) -> pd.DataFrame:
    out = normalize_taxonomy_frame(df, require_risk_factor_id=False)
    for k, v in (filters or {}).items():
        if k not in out.columns:
            continue
        if isinstance(v, list):
            target = {str(x) for x in v}
            out = out[out[k].astype(str).isin(target)]
        else:
            out = out[out[k].astype(str) == str(v)]
    return out.reset_index(drop=True)
