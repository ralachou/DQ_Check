# FRTB IMA — RFET Technical Build Detail

*Companion deep-dive to the deck (`FRTB_IMA_US_2026.pptx`). US scope, framed against the 19 March 2026 Basel III re-proposal. This is the working source-of-truth for detail; once it settles we fold the relevant pieces back into the slides.*

---

## 0. How to read this

The deck explains *what* the Risk-Factor Eligibility Test (RFET) is at a leadership altitude. This document goes one level down — to what technology actually has to build, what "passing" each test requires factor-by-factor, and **where the real work is: getting risk factors that fail today to pass.**

It is anchored to the uploaded build inventory (`WF_ima_rfet_tech_build_inventory.xlsx`), which splits the program into two halves:

- **RFET (10 components, all flagged "Yes" — committed build).** These are the engines that *run* the test: data plumbing, the two test engines, the classifier, monitoring and governance.
- **IMA Risk-Factor Readiness (8 components, all "TBD").** These are the engines that *change the answer* — the remediation that turns a non-modellable factor into a modellable one. This is the long pole, and it is mostly unscoped.

The headline for tech: **running RFET is the easy half; passing it is the hard half, and the hard half is still TBD.**

---

## 1. Why IMA — and why these are daily deliverables

**Why pursue IMA at all.** The Internal Models Approach is an opportunity to *lower* capital relative to the Standardised Approach, because a model can better reflect:

- **non-linear risks**,
- **hedging**, and
- **diversification**

— and so reduce capital on desks that pass ongoing validation. The trade-off is that IMA is **intensive on data, computation, and the validation loop**: the capital benefit is only retained while the desk keeps demonstrating, day after day, that its models work.

**These are daily deliverables.** PLA, backtesting, and modellability (RFET) metrics are **computed every business day** — not monthly, not quarterly. What is assessed over a rolling window is the **pass/fail decision**, deliberately, so that a single noisy day does not flip a desk's status:

> **Daily computations, rolling decisions.** The numbers are produced daily; the verdict is taken over a rolling window to avoid day-to-day flip-flops.

The three daily-computed, rolling-decided deliverables of an IMA desk:

| # | Deliverable | Computed daily | Decided over a rolling window |
|---|---|---|---|
| 1 | **Profit & Loss Attribution (PLA / "PLAT")** | Daily comparison of the model's risk-theoretical P&L (RTPL) against the desk's hypothetical P&L (HPL) from front-office pricing | Green / amber / red zone over the most recent ~250 business days |
| 2 | **Backtesting** | Daily comparison of forecast risk against realised outcomes | Exceptions accumulate over the window and drive the zone / multiplier outcome |
| 3 | **Risk-Factor Eligibility Test (RFET)** | Daily RPO ingestion, counting, coverage and near-breach analytics | Modellability decided over the rolling 12-month window, formally refreshed quarterly |

This document covers **deliverable 3 (RFET)** in depth; PLA and backtesting get their own companion docs, but they share this cadence and the same *compute-daily, decide-over-a-window* discipline. For tech the implication is concrete: **the RFET pipeline is a daily production job**, not a quarter-end batch — the quarterly event is only when the accumulated daily evidence is formally turned into a classification.

---

## 2. What RFET decides (and why it is a build, not a calculation)

RFET runs **per risk factor, per bucket**: the metrics are **computed daily** and the eligibility decision is taken over a **rolling 12-month window, formally refreshed quarterly** (see Section 1). For every risk factor inside an IMA-eligible desk it answers one question — *do we hold enough good-quality market data to model this factor reliably?* — and routes the factor to one of three outcomes:

| Outcome | Passes qualitative? | Passes quantitative (≥24 RPOs)? | Capital treatment |
|---|---|---|---|
| **Modellable** | Yes | Yes | Expected Shortfall (ES), inside IMCC with full correlations |
| **NMRF — Type A** | Yes | No | IMCC **and** SES; aggregated with full diversification (ρ = 0) |
| **NMRF — Type B** | No | — | SES only; aggregated with supervisory correlation ρ = 0.36 (limited diversification) |

The capital gradient is the whole point of the build: Modellable is cheapest, Type A is a middle tier introduced by the March 2026 proposal, and Type B is the punitive floor. **Every factor the readiness work moves up this ladder is capital saved.** That is why classification cannot be a spreadsheet — it has to be a governed, auditable production process that **runs daily and is decided over the rolling window.**

---

## 3. The data plumbing RFET runs on

These are the "Yes" components that feed the two tests. None of them decide modellability on their own; they assemble the inputs.

| ID | Component | What it builds | Why RFET needs it |
|---|---|---|---|
| **d** | MDO→RF Mapping & Lineage Engine | Automated ingestion of front-office Market-Data-Object (MDO) catalogs and risk RF catalogs; mapping, classification, lineage, exception queue, APIs | Defines the **universe of factors** to be tested and ties each one back to its front-office source with full lineage |
| **e** | RPO Data Platform | Multi-source Real-Price-Observation ingestion, storage, normalization, **deduplication (one price per factor per day)**, bucketing & aggregation, query APIs | Produces the **clean, de-duplicated, timestamped real-price history** that the quantitative count runs on |
| **f** | RPO→RF Mapping & Translation Engine | Links RPO identifiers to internal RF keys with **method and confidence**, change detection, exception handling | Decides **which observed prices count toward which factor** — the representativeness link the qualitative test audits |
| **g** | Liquidity-Horizon Assignment Engine | Rule-based + metadata-driven LH per RF; outputs an auditable LH per factor | RFET outputs feed ES/SES, both of which are scaled by liquidity horizon |
| **c** | RFET Target Architecture & Integration | Integration contracts and deployment model for all RFET services and data flows | The backbone that makes the above reproducible and wired into the capital engines |

**Tech note — the de-dup rule is load-bearing.** At most one real price counts per factor per day. If the platform double-counts (same trade booked twice, a quote echoed across vendors), a factor can look modellable when it is not — a model-risk and audit failure. The de-dup, timestamping and consistent cross-source / cross-time-zone handling in component **e** is where this is enforced.

---

## 4. The qualitative test — and the work to pass it

The qualitative test is a **data-quality gate**: is the data behind this factor good enough to model it, regardless of how many prices we have? It is run by the **Qualitative Test Workflow & Evidence Engine (component i)** — a rule/workflow engine with SME review and override, evidence capture, and audit-ready decisions.

### The six rules

The data behind a factor must:

1. **Capture both systematic and idiosyncratic risk** of the positions it drives.
2. **Reflect the factor's volatility and correlation** with other factors.
3. Be based on **real prices** (or proxies that are demonstrably representative).
4. Be **updated at least weekly**, with documented backfill and gap policies.
5. For a reduced set, **reflect the 12-month stress period** used in ES.
6. Remain subject to **supervisory rejection** (e.g., if price variation sits below the bid-ask spread, the supervisor may still reject the input).

### What "pass" requires, and where the work is

Each rule is a build requirement *and* a potential remediation trigger. When a factor fails a rule, the fix lives in the **Risk-Factor Readiness backlog (the TBD components)** — that is the "work to make them pass."

| Rule that fails | Typical root cause | Remediation lever | Readiness component (TBD) |
|---|---|---|---|
| 1 — captures systematic + idiosyncratic risk | Issuer/name-level risk not separately represented | Build issuer-level / idiosyncratic factors | **g** Idiosyncratic RF Enhancements |
| 2 — reflects volatility & correlation | Stale, smoothed or flat series; vol convention mismatch | Re-derive series; align conventions (esp. equity vs FX vol) | **f** Derived RF Time Series, **h** FX Vol Alignment |
| 3 — based on real / representative prices | No direct prices for the factor | Stand up a **validated, monitored proxy** with documented relationship | **a** Proxy Framework |
| 4 — updated ≥ weekly, gap/backfill policy | Sparse or gappy history | Governed gap detection, backfill, derived series as production pipelines | **c** Data-Quality Remediation, **f** Derived RF Time Series |
| 5 — reflects the 12-month stress period | History does not reach back to the 2007+ stress window | **Extend histories to 2007** with evidence and benchmark-transition adjustments | **b** History Inventory & Extension |
| (carry / shock distortions in the series) | Series not comparable across time (carry, regime shifts) | Carry adjustment; historical-shock adjustment | **d** Carry Adjustment, **e** Historical-Shock Adjustment |

The critical design point: **component i records the decision; the readiness components change it.** Passing rule 3 for a factor with no direct prices, for example, is not a workflow problem — it is a proxy-engineering problem, and the proxy engine (a) does not exist yet (TBD).

---

## 5. The quantitative test — and the work to pass it

The quantitative test is a **counting gate**: does the factor have enough real-price observations (RPOs) in the rolling 12-month window? It is run by the **Quantitative Test Engine (component h)** — rolling 12-month RPO counting per RF bucket, with the **24 / 16** thresholds, trend tracking and near-breach analytics — and surfaced by the **Monitoring Dashboards & Predictive Alerts (component k)**.

### The counting rule

A factor is **modellable on the count** when, over the prior 12 months:

- it has **≥ 24 real-price observations**, **with no 90-day sub-period containing fewer than 4** (i.e., the distribution must hold across all four quarters — a floor of ≥ 16/yr implied by the per-window rule); **or**
- it has **≥ 100 real-price observations** over the 12 months (the Basel alternative).

**March 2026 change:** the US re-proposal leans on the **24-observation gate**, making modellability materially easier to achieve than the Basel "100" alternative. The engine's two tracked numbers map directly onto the rule:

- **24** — the annual count threshold (pass/fail).
- **16** — the distribution-implied floor (≥ 4 in each of the four 90-day windows) and the natural **near-breach early-warning band**; a factor drifting toward it should raise a predictive alert *before* it falls out of modellability at the next quarterly refresh.

Counting uses the de-duplicated RPOs from the data platform (one per factor per day) and is done **per bucket** (Section 6), not per individual factor in isolation.

### What "pass" requires, and where the work is

| Failure mode | Remediation lever | Readiness component (TBD) |
|---|---|---|
| Too few prices for the factor itself | Source more real prices: pooled/vendor utilities, committed quotes, internal trades | (data sourcing — RPO platform **e**, already "Yes") |
| Factor genuinely illiquid, no prices to find | Borrow modellability via a **representative proxy** + capitalise the residual basis as an NMRF | **a** Proxy Framework |
| Liquid base, illiquid tail/spread | **Decompose** into a modellable base factor + a small non-modellable spread (the "modellable-plus-spread" trick) | **f** Derived RF Time Series |
| Prices exist but don't reach the stress window | Extend history to 2007 (needed for ES calibration even once the count passes) | **b** History Inventory & Extension |
| Prices map to the wrong factor / convention | Fix the RPO→RF translation and vol-convention alignment | **f** mapping (translation engine, "Yes"), **h** FX Vol Alignment |

The honest summary: when the count fails, you either **find more prices** (a sourcing problem the "Yes" platform can address) or you **change the factor** (a proxy / decomposition problem the TBD readiness engines must address). The second path is where capital is actually won or lost.

---

## 6. Bucketing — the unit you count in

RFET counts prices for **grid points of a curve, surface or cube**, not for abstract factors. How buckets are defined determines how many factors clear the count.

| Approach | Rule | Engineering implication |
|---|---|---|
| **Regulatory buckets** | A fixed set of standard buckets by maturity / strike dimension (IR-FX-CO single & multi-maturity; CR & EQ; any factor by strike/moneyness). A price in a bucket passes the bucket for **all** factors in it. | Maximises shared evidence — many factors can clear on shared bucket prices |
| **Own buckets** | The bank may define its own buckets **only if** each contains exactly one factor and the buckets partition the curve/surface/cube. | Higher fidelity, but no sharing — use selectively |
| **Parametric functions** | For Nelson–Siegel, SABR, PCA, etc., a parameter is modellable **only if every calibration data-point sits in modellable buckets** — otherwise the parameter is an NMRF. | Calibration-input coverage must be tracked, not just outputs |

Bucketing and representativeness live in the RPO platform (**e**) and the RPO→RF translation engine (**f**). Choosing regulatory vs own buckets per asset class is an early, high-leverage modellability decision.

---

## 7. Classification, monitoring and change control

| ID | Component | Role |
|---|---|---|
| **j** | RFET Classification Engine | Combines quantitative + qualitative outputs into **Modellable / NMRF Type A / NMRF Type B**, and tracks changes over time |
| **k** | Monitoring Dashboards & Predictive Alerts | Modellability status, RPO coverage heatmaps, qualitative outcomes, drill-down lineage; **predictive alerts** for impending threshold breaches |
| **l** | BAU Governance, Reclassification & Orchestration | Scheduling/orchestration for daily runs and the quarterly refresh; exception queue; approvals; audit logs |

Design points for tech:
- **Reclassification needs hysteresis.** A factor flipping Modellable↔NMRF every quarter destabilises capital. The classifier (j) should support smoothing/confirmation logic and a documented reclassification policy, governed by (l).
- **Predict, don't just report.** The value of (k) is catching a factor *drifting toward* the 16-floor before the quarterly cut, so sourcing or proxy work can start in time.
- **Everything is audit-evidence.** The qualitative engine (i) and governance layer (l) must produce defensible, timestamped decision records — this is a supervisory-approval gate, not an internal MI nicety.

---

## 8. The remediation backlog — IMA Risk-Factor Readiness (the TBD work)

This is the answer to *"where will there be work to make them pass."* All eight are flagged **TBD** in the inventory, and all eight currently share the same generic build description ("assess gaps, define requirements, implement transformations/derived series as governed production pipelines") — meaning they are **identified but not yet specified.** That is the program's principal unknown.

| ID | Component | Which test(s) it unblocks | Status |
|---|---|---|---|
| **a** | Proxy Framework (registry + validation + monitoring) | Qualitative (rule 3, representativeness) **and** quantitative (borrowed modellability) | TBD |
| **b** | History Inventory & Extension Platform (to 2007, with benchmark-transition adjustments) | Qualitative (rule 5, stress period) + ES calibration | TBD |
| **c** | Data-Quality Remediation Framework | Qualitative (rules 1, 2, 4) | TBD |
| **d** | Carry Adjustment Module | Qualitative (series comparability) | TBD |
| **e** | Historical-Shock Adjustment Module | Qualitative (series comparability across regimes) | TBD |
| **f** | Derived RF Time Series Framework | Quantitative (decomposition) + qualitative (re-derived series) | TBD |
| **g** | Idiosyncratic Risk Factor Enhancements | Qualitative (rule 1, idiosyncratic risk) | TBD |
| **h** | FX Vol Alignment (Equity vs FX) | Qualitative (rule 2, vol convention) + correct RPO mapping | TBD |

**Sequencing implication.** The "Yes" RFET engines can be built against a known specification. The readiness backlog cannot start until a **current-state assessment** says *which* factors fail *which* tests today and by how much — that assessment is the gating first move, and it drives the scope, sizing and cost of all eight TBD items. The Proxy Framework (a) and History Extension (b) are the most likely tall poles because they unblock both tests and feed ES calibration.

---

## 9. Build-inventory cross-reference

Full inventory (18 components), with the RFET stage each supports.

| Program area | ID | Component | Tech build | RFET stage / test supported |
|---|---|---|---|---|
| RFET | c | Target Architecture & Integration | Yes | Backbone / integration |
| RFET | d | MDO→RF Mapping & Lineage | Yes | Factor universe & lineage |
| RFET | e | RPO Data Platform | Yes | Quantitative inputs (RPOs, dedup, bucketing) |
| RFET | f | RPO→RF Mapping & Translation | Yes | Representativeness link (both tests) |
| RFET | g | Liquidity-Horizon Assignment | Yes | LH per factor → ES/SES |
| RFET | h | Quantitative Test Engine | Yes | **Quantitative test** (24/16 count) |
| RFET | i | Qualitative Test Workflow & Evidence | Yes | **Qualitative test** (six rules) |
| RFET | j | RFET Classification Engine | Yes | Outcome (Modellable / Type A / Type B) |
| RFET | k | Monitoring Dashboards & Predictive Alerts | Yes | Monitoring / near-breach alerts |
| RFET | l | BAU Governance, Reclassification & Orchestration | Yes | Cadence, approvals, audit |
| Risk-Factor Readiness | a | Proxy Framework | TBD | **Pass** — qual rule 3 + quant |
| Risk-Factor Readiness | b | History Inventory & Extension | TBD | **Pass** — qual rule 5 + ES |
| Risk-Factor Readiness | c | Data-Quality Remediation | TBD | **Pass** — qual rules 1/2/4 |
| Risk-Factor Readiness | d | Carry Adjustment | TBD | **Pass** — series comparability |
| Risk-Factor Readiness | e | Historical-Shock Adjustment | TBD | **Pass** — series comparability |
| Risk-Factor Readiness | f | Derived RF Time Series | TBD | **Pass** — quant decomposition |
| Risk-Factor Readiness | g | Idiosyncratic RF Enhancements | TBD | **Pass** — qual rule 1 |
| Risk-Factor Readiness | h | FX Vol Alignment | TBD | **Pass** — qual rule 2 |

**Inventory summary:** 18 total — 10 RFET, 8 Risk-Factor Readiness. Tech build: 11 Yes, 1 Partial, 6 TBD/Partial. The "Yes" weight sits in the engines that *run* RFET; the "TBD" weight sits entirely in the engines that *pass* it.

---

## 10. Open calibration points (proposal, not final)

These are the numbers and treatments most likely to move between the March 2026 proposal and the Q4 2026 final rule — encode them as **configuration, not code**:

- **24 vs 100** — the observation threshold the US ultimately fixes (the proposal leans on 24).
- **Type A / Type B treatment** — the ρ = 0 vs ρ = 0.36 aggregation split and Type A's IMCC inclusion.
- **The 16 near-breach band** — internal early-warning level; tune to data behaviour.
- **Bucketing definitions** — regulatory bucket boundaries per asset class.

---

## Appendix — glossary

- **MDO** — Market Data Object: a front-office market-data construct (curve point, vol point, etc.).
- **RF** — Risk Factor: the variable that drives a position's value and is tested for modellability.
- **RPO** — Real-Price Observation: an executed trade or committed (actionable) quote, de-duplicated to one per factor per day.
- **LH** — Liquidity Horizon: 10/20/40/60/120 days; scales ES and SES.
- **RFET** — Risk-Factor Eligibility Test: the qualitative + quantitative gate in this document.
- **Modellable / NMRF** — Modellable factors → ES; Non-Modellable Risk Factors → stress scenario capital (SES), split Type A / Type B.
- **IMCC** — Internally Modelled Capital Charge (the aggregated ES measure).
- **SES** — Stressed Expected Shortfall: the NMRF stress charge.
