from __future__ import annotations
from datetime import datetime
from pathlib import Path

import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st

# ---------------------------------------------------------------------------
# Config & theme
# ---------------------------------------------------------------------------
APP_DIR = Path(__file__).parent
DATA_FILE = APP_DIR / 'rfet_data.xlsx'
RPO_FILE = APP_DIR / 'rfet_qualitative_RPO.xlsx'
SLIDES_DIR = APP_DIR / 'slides'

st.set_page_config(
    page_title='RFET IMA Workbench',
    page_icon='📊',
    layout='wide',
    initial_sidebar_state='expanded',
)

# Colour tokens (match the HTML PoC)
COL_PASS = '#0F8F5E'
COL_WARN = '#C97A14'
COL_FAIL = '#B83C4F'
COL_MUTE = '#6B7280'
COL_NAVY = '#0B1A2E'
COL_BRASS = '#B8935A'
COL_CREAM = '#F2EFE7'

STATUS_COLORS = {
    'pass': COL_PASS, 'warn': COL_WARN, 'fail': COL_FAIL,
    'Modellable': COL_PASS, 'Type A NMRF': COL_WARN, 'Type B NMRF': COL_FAIL,
    'Defer to SA': COL_MUTE, 'Excluded': COL_MUTE,
    'Include': COL_PASS, 'Defer': COL_WARN, 'Exclude': COL_MUTE,
    'Ready': COL_PASS, 'Partial': COL_WARN, 'Not Ready': COL_FAIL,
    'Complete': COL_PASS, 'In Review': COL_WARN, 'missing': COL_FAIL, 'Missing': COL_FAIL,
    'None': COL_MUTE, 'Open': COL_WARN, 'In Progress': COL_WARN, 'Deferred': COL_MUTE,
    'Not Required': COL_MUTE, 'TBD': COL_MUTE,
    'yes': COL_PASS, 'no': COL_FAIL,
    'High': COL_FAIL, 'Low': COL_WARN,
}

# Six qualitative tests — display labels + descriptions
QUAL_TESTS = [
    ('qual1_capture_idio', 'Capture idio',  'Idiosyncratic Risk Capture',
     "Does the RF capture name- or instrument-specific risk that isn't driven by broader "
     "market factors? A name-specific spread should not be fully absorbed by the index proxy."),
    ('qual2_vol_corr',     'Vol / Corr',    'Volatility & Correlation',
     "Is the RF's modelled volatility consistent with observed market vol, and do its "
     "correlations to neighbouring RFs match empirical observation?"),
    ('qual3_rpo_rep',      'RPO repr.',     'RPO Representativeness',
     "Are the underlying real-price observations representative of the RF being modelled — "
     "same product, similar size, similar counterparty profile?"),
    ('qual4_update_freq',  'Update freq.',  'Update Frequency',
     "Is the RF refreshed in the risk system frequently enough to track price moves over "
     "its liquidity horizon (LH)?"),
    ('qual5_stress_rep',   'Stress repr.',  'Stress Period Representativeness',
     "Does the available history span a sufficiently stressful period to be meaningful for "
     "stressed-ES capital calculations?"),
    ('qual6_proxy_fit',    'Proxy fit',     'Proxy Fit Quality',
     "Where the RF acts as a proxy (or is being proxied), is the statistical fit between "
     "proxy and target acceptable per governance standards?"),
]

# Global CSS tweaks
st.markdown("""
<style>
    .block-container { padding-top: 1.5rem; padding-bottom: 2rem; max-width: 1400px; }
    section[data-testid="stSidebar"] { background: #F2EFE7; }
    h1, h2, h3 { font-family: 'Georgia', serif; color: #0B1A2E; }
    .pill {
        display: inline-block; padding: 2px 10px; border-radius: 999px;
        font-size: 0.78rem; font-weight: 600; letter-spacing: 0.02em;
        border: 1px solid;
    }
    .pill-pass  { color: #0F8F5E; background:#E8F5EE; border-color:#B6E0C7; }
    .pill-warn  { color: #C97A14; background:#FCEFD9; border-color:#F1D49A; }
    .pill-fail  { color: #B83C4F; background:#F8E3E7; border-color:#EFC0C9; }
    .pill-mute  { color: #6B7280; background:#F1F2F4; border-color:#D8DBE0; }

    /* Standard KPI card (still used on detail pages) */
    .kpi-card {
        background: white; border:1px solid #E5E7EB; border-radius:10px;
        padding:14px 16px; box-shadow: 0 1px 2px rgba(0,0,0,0.03);
    }
    .kpi-label { font-size:0.78rem; color:#6B7280; text-transform:uppercase;
                 letter-spacing:0.06em; font-weight:600; }
    .kpi-value { font-size:1.65rem; font-weight:700; color:#0B1A2E; margin-top:4px; }
    .kpi-sub   { font-size:0.78rem; color:#6B7280; margin-top:2px; }

    /* Hero KPI card — bigger, bolder, used on Executive Overview */
    .hero-kpi {
        background: white; border:1px solid #E5E7EB; border-radius:10px;
        padding:18px 18px; box-shadow: 0 2px 6px rgba(0,0,0,0.05);
        border-top: 3px solid #B8935A;
    }
    .hero-kpi-label { font-size:0.82rem; color:#0B1A2E; text-transform:uppercase;
                      letter-spacing:0.08em; font-weight:700; }
    .hero-kpi-value { font-size:2.4rem; font-weight:800; color:#0B1A2E; margin-top:6px;
                      line-height:1; }
    .hero-kpi-sub   { font-size:0.78rem; color:#6B7280; margin-top:6px; }

    /* Cycle badge */
    .cycle-badge {
        display:inline-block; background:#B8935A; color:white;
        padding:6px 14px; border-radius:6px; font-weight:700;
        letter-spacing:0.04em; font-size:0.95rem; margin-right:10px;
    }
    .asof-badge {
        display:inline-block; background:#0B1A2E; color:white;
        padding:6px 14px; border-radius:6px; font-weight:600;
        letter-spacing:0.04em; font-size:0.92rem;
    }

    .stage-box {
        background:white; border:1px solid #E5E7EB; border-left:4px solid #B8935A;
        padding:10px 14px; border-radius:6px; margin-bottom:8px;
    }
    .qual-card {
        background:white; border:1px solid #E5E7EB; border-radius:8px;
        padding:14px 16px; margin-bottom:12px;
        box-shadow: 0 1px 2px rgba(0,0,0,0.03);
    }
    .qual-card-head { display:flex; justify-content:space-between; align-items:baseline;
                      border-bottom:1px solid #E5E7EB; padding-bottom:8px; margin-bottom:10px; }
    .qual-card-title { font-family:Georgia, serif; color:#0B1A2E;
                       font-size:1.05rem; font-weight:700; }
    .qual-card-ref   { color:#6B7280; font-size:0.78rem; font-family:monospace; }
    .qual-card-desc  { color:#374151; font-size:0.9rem; line-height:1.5; }

    .kanban-card {
        background:white; border:1px solid #E5E7EB; border-radius:6px;
        padding:10px; margin-bottom:8px; font-size:0.85rem;
    }
    .kanban-col-head { font-weight:700; color:#0B1A2E; text-transform:uppercase;
                      letter-spacing:0.06em; font-size:0.78rem; margin-bottom:8px; }

    /* Navigation section headers — larger, bolder.
       Cross-version safety: Streamlit's internal DOM testids changed across
       releases, so we target multiple possible selectors and bump specificity
       (with chained `section[...] section[...]`) to defeat any emotion CSS
       loaded after this style block. */
    section[data-testid="stSidebar"] section[data-testid="stSidebar"] [data-testid="stNavSectionHeader"],
    section[data-testid="stSidebar"] header[data-testid="stNavSectionHeader"],
    section[data-testid="stSidebar"] [data-testid="stNavSectionHeader"] {
        overflow: visible !important;
    }
    section[data-testid="stSidebar"] section[data-testid="stSidebar"] [data-testid="stNavSectionHeader"] *,
    section[data-testid="stSidebar"] header[data-testid="stNavSectionHeader"] *,
    section[data-testid="stSidebar"] [data-testid="stNavSectionHeader"] p,
    section[data-testid="stSidebar"] [data-testid="stNavSectionHeader"] span,
    section[data-testid="stSidebar"] [data-testid="stNavSectionHeader"] div {
        font-weight: 700 !important;
        font-size: 1rem !important;
        color: #0B1A2E !important;
        letter-spacing: 0.02em !important;
        white-space: normal !important;
        line-height: 1.3 !important;
        overflow: visible !important;
        text-overflow: clip !important;
    }
    /* Older Streamlit versions (< ~1.36) didn't ship stNavSectionHeader and
       instead rendered group headers as plain st.subheader / h3 inside the
       sidebar. Bold those too if they appear above a stSidebarNavItems list. */
    section[data-testid="stSidebar"] h3,
    section[data-testid="stSidebar"] [data-testid="stHeader"] {
        font-weight: 700 !important;
        font-size: 1rem !important;
        color: #0B1A2E !important;
    }
    /* Nav link labels — allow wrap so long sub-page names show in full */
    section[data-testid="stSidebar"] [data-testid="stSidebarNavLink"] {
        height: auto !important;
        min-height: 36px;
    }
    section[data-testid="stSidebar"] [data-testid="stSidebarNavLink"] [data-testid="stMarkdownContainer"],
    section[data-testid="stSidebar"] [data-testid="stSidebarNavLink"] [data-testid="stMarkdownContainer"] p,
    section[data-testid="stSidebar"] [data-testid="stSidebarNavLink"] span {
        white-space: normal !important;
        overflow: visible !important;
        text-overflow: clip !important;
        line-height: 1.3 !important;
    }
</style>
""", unsafe_allow_html=True)


# ---------------------------------------------------------------------------
# Data loading
# ---------------------------------------------------------------------------
def _file_mtime(p: Path) -> float:
    return p.stat().st_mtime if p.exists() else 0.0


def _capital_bucket(cls: str) -> str:
    """Modellable → TBD, Type A NMRF → Low, Type B NMRF → High."""
    if cls == 'Type A NMRF':
        return 'Low'
    if cls == 'Type B NMRF':
        return 'High'
    return 'TBD'


@st.cache_data(show_spinner=False)
def load_data(mtime: float):
    sheets = pd.read_excel(DATA_FILE, sheet_name=None)
    rf = sheets['risk_factors'].copy()
    rf['capital_impact'] = rf['rfet_classification'].apply(_capital_bucket)
    cfg = sheets.get('config')
    if cfg is not None:
        cfg = dict(zip(cfg['key'], cfg['value']))

    # Build slides lookup: {(section, page): [ {tab_name, image_path}, ... ]}
    slides_map: dict[tuple[str, str], list[dict]] = {}
    if 'slides' in sheets:
        sl = sheets['slides'].copy()
        for _, row in sl.iterrows():
            section = str(row.get('Section', '')).strip()
            page = str(row.get('Page', '')).strip()
            pic = row.get('Picture link')
            if not section or not page or pd.isna(pic) or not str(pic).strip():
                continue
            tab_name = row.get('subPageName')
            tab_name = (str(tab_name).strip()
                       if pd.notna(tab_name) and str(tab_name).strip()
                       else None)
            slides_map.setdefault((section, page), []).append({
                'tab': tab_name,
                'image': str(pic).strip(),
            })

    return {
        'rf': rf,
        'ac': sheets['asset_classes'],
        'pipe': sheets['pipeline_stages'],
        'types': sheets['rf_types'],
        'cfg': cfg or {},
        'slides': slides_map,
    }


def get_data():
    if not DATA_FILE.exists():
        st.error(f"Data file not found: {DATA_FILE}")
        st.stop()
    return load_data(_file_mtime(DATA_FILE))


# ---------------------------------------------------------------------------
# RPO workbook loader (separate file, cached separately)
# ---------------------------------------------------------------------------
@st.cache_data(show_spinner=False)
def load_rpo_sheet(sheet_name: str, mtime: float) -> pd.DataFrame:
    """Read a sheet from rfet_qualitative_RPO.xlsx, returns DataFrame or empty if missing."""
    if not RPO_FILE.exists():
        return pd.DataFrame()
    try:
        return pd.read_excel(RPO_FILE, sheet_name=sheet_name)
    except (ValueError, KeyError):
        # Sheet not in workbook
        return pd.DataFrame()


@st.cache_data(show_spinner=False)
def load_rpo_sheet_raw(sheet_name: str, mtime: float) -> pd.DataFrame:
    """Read a sheet from rfet_qualitative_RPO.xlsx with no header row.

    Used when a single sheet contains multiple distinct tables stacked
    vertically (different column meanings per section), so the caller needs
    to slice the raw rows themselves.
    """
    if not RPO_FILE.exists():
        return pd.DataFrame()
    try:
        return pd.read_excel(RPO_FILE, sheet_name=sheet_name, header=None)
    except (ValueError, KeyError):
        return pd.DataFrame()


@st.cache_data(show_spinner=False)
def load_rpo_schema(sheet_name: str, mtime: float) -> list[dict]:
    """Read a schema sheet (RPO_IR_Schema / RPO_FX_Schema) preserving the
    hierarchy implied by which column holds the first non-null value per row,
    and resolving merged-cell wrapping in the Market Observables column.

    Returns a list of dicts with:
      - asset_class, product_group, product, sub_product : carry-forward labels
      - level                                            : 1..4 (which column drove the row)
      - market_observables, relevant_attribute           : with merges resolved

    The carry-forward fields make it trivial to render an indented tree.
    """
    from openpyxl import load_workbook
    if not RPO_FILE.exists():
        return []
    wb = load_workbook(RPO_FILE, data_only=True)
    if sheet_name not in wb.sheetnames:
        return []
    ws = wb[sheet_name]

    # Build merge map: for every (r, c) covered by a merged range, point at
    # the anchor cell so we can read the wrapped value.
    merge_map: dict[tuple[int, int], tuple[int, int]] = {}
    for mr in ws.merged_cells.ranges:
        anchor = (mr.min_row, mr.min_col)
        for r in range(mr.min_row, mr.max_row + 1):
            for c in range(mr.min_col, mr.max_col + 1):
                merge_map[(r, c)] = anchor

    def cell_val(r, c):
        """Cell value, resolving merge wrapping."""
        anchor = merge_map.get((r, c), (r, c))
        return ws.cell(row=anchor[0], column=anchor[1]).value

    rows: list[dict] = []
    carry = {'asset_class': None, 'product_group': None,
             'product': None, 'sub_product': None}

    for r in range(2, ws.max_row + 1):  # skip header row
        v1 = ws.cell(row=r, column=1).value
        v2 = ws.cell(row=r, column=2).value
        v3 = ws.cell(row=r, column=3).value
        v4 = ws.cell(row=r, column=4).value

        # Determine the level from the first non-null column
        level = 0
        if v1 is not None and str(v1).strip():
            carry['asset_class']   = str(v1).strip()
            # Reset deeper levels when a new asset class starts
            carry['product_group'] = None
            carry['product']       = None
            carry['sub_product']   = None
            level = 1
        elif v2 is not None and str(v2).strip():
            carry['product_group'] = str(v2).strip()
            carry['product']       = None
            carry['sub_product']   = None
            level = 2
        elif v3 is not None and str(v3).strip():
            carry['product']       = str(v3).strip()
            carry['sub_product']   = None
            level = 3
        elif v4 is not None and str(v4).strip():
            carry['sub_product']   = str(v4).strip()
            level = 4

        if level == 0:
            # Blank row — skip
            continue

        obs = cell_val(r, 5)
        attr = cell_val(r, 6)

        rows.append({
            'asset_class':   carry['asset_class'],
            'product_group': carry['product_group'],
            'product':       carry['product'],
            'sub_product':   carry['sub_product'],
            'level':         level,
            # The actual label for THIS row (the deepest non-null col)
            'label':         [None, carry['asset_class'], carry['product_group'],
                              carry['product'], carry['sub_product']][level],
            'market_observables': str(obs).strip() if obs is not None else '',
            'relevant_attribute': str(attr).strip() if attr is not None else '',
        })

    return rows


def render_schema_tree(sheet_name: str, obs_level: int = 3):
    """Render an RPO schema sheet as a 6-column hierarchical tree map.

    Six columns are always present and visually aligned:
      Asset Class | Product Group | Product | Sub Product / Instrument |
      Market Data Observables / Price Quotes | Relevant Attributes

    Per-level styling:
      Level 1 (Asset Class)       — outer `st.expander`, navy bar, large bold
      Level 2 (Product Group)     — nested `st.expander`, brass-tinted bar
      Level 3 (Product)           — section row inside the inner expander
      Level 4 (Sub Product)       — detail row inside the inner expander

    Args:
        sheet_name: RPO workbook sheet name.
        obs_level:  which level "owns" the Market Data Observables value.
                    IR=3 (per Product), FX=2 (per Product Group). The value
                    is shown once at that level and not repeated on children.
    """
    rows = load_rpo_schema(sheet_name, _file_mtime(RPO_FILE))
    if not rows:
        st.info('No schema data available for this view.')
        return

    # Group rows by (asset_class, product_group), preserving sheet order.
    # `acc[ac][pg]` -> list of rows (the L1/L2/L3/L4 mix for that PG).
    from collections import OrderedDict
    acc: OrderedDict[str, OrderedDict[str | None, list[dict]]] = OrderedDict()
    for r in rows:
        ac = r['asset_class']
        pg = r['product_group']  # may be None for the L1 row itself
        acc.setdefault(ac, OrderedDict()).setdefault(pg, []).append(r)

    # Six columns + their relative widths (CSS percentage). Chosen so the four
    # hierarchy columns are tight, observables gets room to wrap, and the
    # attributes column has comfortable space too.
    COLS = [
        ('Asset Class',                              '9%'),
        ('Product Group',                            '10%'),
        ('Product',                                  '13%'),
        ('Sub Product / Instrument',                 '22%'),
        ('Market Data Observables / Price Quotes',   '28%'),
        ('Relevant Attributes',                      '18%'),
    ]

    # Inject the shared CSS once per sheet render.
    st.markdown(
        '<style>'
        # Outer wrapper to constrain max width of the whole tree component.
        '.tree-wrap { width: 100%; }'
        # Header strip — visually anchors the columns above the expanders.
        '.tree-head { width: 100%; border-collapse: collapse;'
        '  table-layout: fixed; font-size: 0.85rem; }'
        '.tree-head th { background: #0B1A2E; color: white;'
        '  padding: 10px 10px; text-align: left; font-weight: 700;'
        '  letter-spacing: 0.02em; vertical-align: top;'
        '  border-right: 1px solid rgba(255,255,255,0.08); }'
        '.tree-head th:last-child { border-right: none; }'
        # Inner table inside each Product Group expander — same column widths
        # via the colgroup so things line up across expanders.
        '.tree-body { width: 100%; border-collapse: collapse;'
        '  table-layout: fixed; font-size: 0.85rem; margin-top: 0; }'
        '.tree-body td { padding: 6px 10px; vertical-align: top;'
        '  border-bottom: 1px solid #E5E7EB;'
        '  border-right: 1px solid #F1F2F4; }'
        '.tree-body td:last-child { border-right: none; }'
        # Wrap long text in the observables and attributes columns.
        '.tree-body td.obs, .tree-body td.attr {'
        '  white-space: pre-line; color: #374151; font-size: 0.82rem;'
        '  line-height: 1.45; word-break: break-word; }'
        # Level-3 row (Product) styling.
        '.tree-body tr.lvl3 td { background: #FAF7EF; }'
        '.tree-body tr.lvl3 td.lbl3 { color: #0B1A2E; font-weight: 600;'
        '  font-size: 0.92rem; }'
        # Level-4 row (Sub Product) styling.
        '.tree-body tr.lvl4 td { background: #FFFFFF; }'
        '.tree-body tr.lvl4 td.lbl4 { color: #52647A; font-weight: 500; }'
        # Hover lift on Level 3+4 rows.
        '.tree-body tr:hover td { background: #FFF8E8 !important; }'
        # Streamlit expander chrome — distinguish L1 vs L2 by nesting depth.
        # L1 expanders are at top level inside .tree-wrap;
        # L2 expanders are inside an L1 expander.
        # Selectors target [data-testid="stExpander"] containers and their
        # <summary> elements directly.
        # ---- L1 (Asset Class): dark navy chrome, large bold ----
        '[data-testid="stExpander"] > details > summary {'
        '  background: #0B1A2E !important; color: white !important;'
        '  font-weight: 700 !important; font-size: 1.05rem !important;'
        '  letter-spacing: 0.02em !important;'
        '  border-radius: 6px !important; padding: 12px 16px !important;'
        '  border: none !important; }'
        '[data-testid="stExpander"] > details > summary p,'
        '[data-testid="stExpander"] > details > summary span,'
        '[data-testid="stExpander"] > details > summary div {'
        '  color: white !important; font-weight: 700 !important;'
        '  font-size: 1.05rem !important; }'
        '[data-testid="stExpander"] > details > summary svg {'
        '  fill: white !important; stroke: white !important; }'
        # ---- L2 (Product Group): brass-tinted, slightly smaller. Override
        # the L1 styles when nested. ----
        '[data-testid="stExpander"] [data-testid="stExpander"] > details > summary {'
        '  background: #F2EFE7 !important;'
        '  border-left: 4px solid #B8935A !important;'
        '  font-weight: 700 !important; font-size: 0.95rem !important;'
        '  color: #0B1A2E !important; padding: 9px 14px !important;'
        '  border-radius: 4px !important; border-top: none !important;'
        '  border-right: none !important; border-bottom: none !important; }'
        '[data-testid="stExpander"] [data-testid="stExpander"] > details > summary p,'
        '[data-testid="stExpander"] [data-testid="stExpander"] > details > summary span,'
        '[data-testid="stExpander"] [data-testid="stExpander"] > details > summary div {'
        '  color: #0B1A2E !important; font-weight: 700 !important;'
        '  font-size: 0.95rem !important; }'
        '[data-testid="stExpander"] [data-testid="stExpander"] > details > summary svg {'
        '  fill: #0B1A2E !important; stroke: #0B1A2E !important; }'
        # Tighten gap between Product Group expanders inside an Asset Class
        '[data-testid="stExpander"] [data-testid="stExpander"] {'
        '  margin-bottom: 6px; margin-top: 4px; }'
        # The market-data + relevant-attribute strip shown *inside* a PG
        # expander when obs_level == 2 (FX case). Renders as a 6-col table
        # row with empty hierarchy cells and the text in cols 5-6.
        '.tree-body tr.pg-meta td { background: #FFFFFF;'
        '  border-bottom: 2px solid #E5E7EB; }'
        '</style>',
        unsafe_allow_html=True,
    )

    # ---- Render the header strip (always visible) ----
    colgroup = ''.join(f'<col style="width:{w};">' for _, w in COLS)
    th_html = ''.join(f'<th>{label}</th>' for label, _ in COLS)
    st.markdown(
        f'<div class="tree-wrap">'
        f'<table class="tree-head"><colgroup>{colgroup}</colgroup>'
        f'<thead><tr>{th_html}</tr></thead></table>'
        f'</div>',
        unsafe_allow_html=True,
    )

    def _escape(s):
        if not s:
            return ''
        return (str(s).replace('&', '&amp;')
                .replace('<', '&lt;').replace('>', '&gt;')
                .replace('\n', '<br>'))

    def _build_body_rows(pg_rows: list[dict],
                       obs_for_pg: str = '',
                       attr_for_pg: str = '') -> str:
        """Build the inner table HTML for a Product Group's L3/L4 rows.

        If obs_level == 2 and obs_for_pg is non-empty, a synthetic 'pg-meta'
        row is prepended showing the observables/attribute that apply to the
        whole product group.

        For obs_level == 3, observables/attributes are shown on the Level 3
        row that owns them (Product) and left blank on L4 children.
        """
        body = []
        # Prepend the pg-meta row for FX (obs at Level 2).
        if obs_level == 2 and (obs_for_pg or attr_for_pg):
            body.append(
                '<tr class="pg-meta">'
                '<td></td><td></td><td></td><td></td>'
                f'<td class="obs">{_escape(obs_for_pg)}</td>'
                f'<td class="attr">{_escape(attr_for_pg)}</td>'
                '</tr>'
            )

        # Walk L3/L4 rows, tracking the most-recent L3 so its observables
        # can carry to its own cell.
        current_l3_obs = ''
        current_l3_attr = ''
        last_obs_shown = None
        last_attr_shown = None

        # When obs_level==3, the source merged-cell anchor in the workbook
        # sometimes sits on the FIRST L4 row of a product (not on the L3
        # row itself). Pre-compute, per L3 row, the observables/attribute
        # to display by looking at the L3 row first, falling back to the
        # first non-empty value among its L4 children.
        if obs_level == 3:
            obs_for_l3: dict[int, tuple[str, str]] = {}
            # We need stable indices to map "L3 row" -> "its L4 children
            # in order". Walk once and group.
            for i, r in enumerate(pg_rows):
                if r['level'] != 3:
                    continue
                l3_obs = r['market_observables']
                l3_attr = r['relevant_attribute']
                if not l3_obs or not l3_attr:
                    # Look at subsequent L4 rows under this L3 (up to the
                    # next L3, if any).
                    for r2 in pg_rows[i + 1:]:
                        if r2['level'] == 3:
                            break
                        if r2['level'] == 4:
                            if not l3_obs and r2['market_observables']:
                                l3_obs = r2['market_observables']
                            if not l3_attr and r2['relevant_attribute']:
                                l3_attr = r2['relevant_attribute']
                            if l3_obs and l3_attr:
                                break
                obs_for_l3[id(r)] = (l3_obs, l3_attr)
        else:
            obs_for_l3 = {}

        for r in pg_rows:
            if r['level'] < 3:
                # L1 and L2 rows themselves don't produce body rows here.
                # We only used them earlier to derive obs_for_pg/attr_for_pg.
                continue

            lvl = r['level']
            label = _escape(r['label'])

            # Determine what goes in obs / attr cells for this row.
            if obs_level == 2:
                # Observables already shown at PG-meta. Always blank below.
                obs_cell = ''
                attr_cell = ''
            else:
                # obs_level == 3 (IR). Show on Level 3 only.
                if lvl == 3:
                    # Use the precomputed obs/attr (may have been lifted
                    # from a child L4 row if the source merge anchor sat
                    # there).
                    current_l3_obs, current_l3_attr = obs_for_l3.get(
                        id(r), (r['market_observables'], r['relevant_attribute']))
                    obs_cell = (current_l3_obs
                               if current_l3_obs != last_obs_shown else '')
                    attr_cell = (current_l3_attr
                                if current_l3_attr != last_attr_shown else '')
                    if current_l3_obs:
                        last_obs_shown = current_l3_obs
                    if current_l3_attr:
                        last_attr_shown = current_l3_attr
                else:  # L4
                    obs_cell = ''
                    attr_cell = ''

            # Build the 6 cells; only the column matching `lvl` carries the label.
            cells = ['<td></td>'] * 4
            # cells[0..3] correspond to AC, PG, Product, Sub Product
            # AC and PG are blank inside the body (they're in the expander labels).
            # Product = index 2, Sub Product = index 3.
            if lvl == 3:
                cells[2] = f'<td class="lbl3">{label}</td>'
            elif lvl == 4:
                # Indent the sub-product visually.
                cells[3] = (f'<td class="lbl4" style="padding-left:24px;">'
                           f'{label}</td>')

            cells.append(f'<td class="obs">{_escape(obs_cell)}</td>')
            cells.append(f'<td class="attr">{_escape(attr_cell)}</td>')

            body.append(f'<tr class="lvl{lvl}">' + ''.join(cells) + '</tr>')

        return ''.join(body)

    # ---- Render the tree ----
    for ac_name, pg_dict in acc.items():
        # Look up the L1 obs/attr (for IR these are usually empty; for FX
        # there's an asset-class-level summary)
        l1_row = next((r for r in rows if r['asset_class'] == ac_name
                       and r['level'] == 1), None)
        ac_summary = (l1_row['market_observables']
                     if l1_row and l1_row['market_observables'] else '')

        with st.expander(ac_name, expanded=True):
            # If there's an asset-class-level summary observables string, show
            # it as a small note above the product groups.
            if ac_summary:
                st.markdown(
                    f'<div style="background:#FFF8E8;border-left:3px solid #B8935A;'
                    f'padding:8px 12px;margin-bottom:8px;font-size:0.85rem;'
                    f'color:#374151;line-height:1.5;">'
                    f'<b style="color:#0B1A2E;">Asset-class observables:</b><br>'
                    f'{_escape(ac_summary)}</div>',
                    unsafe_allow_html=True,
                )

            for pg_name, pg_rows in pg_dict.items():
                if pg_name is None:
                    continue  # the L1-only row, already covered above

                # Look up obs/attr for this Product Group (only used when
                # obs_level == 2). Find the Level 2 row for this PG.
                l2_row = next((r for r in pg_rows if r['level'] == 2), None)
                pg_obs = l2_row['market_observables'] if l2_row else ''
                pg_attr = l2_row['relevant_attribute'] if l2_row else ''

                with st.expander(pg_name, expanded=True):
                    body_html = _build_body_rows(pg_rows,
                                                obs_for_pg=pg_obs,
                                                attr_for_pg=pg_attr)
                    if not body_html.strip():
                        # No L3/L4 children — but for FX the PG-meta row is
                        # the entire content. If obs_level==2 and we have
                        # obs text, show it standalone.
                        if obs_level == 2 and (pg_obs or pg_attr):
                            body_html = (
                                '<tr class="pg-meta">'
                                '<td></td><td></td><td></td><td></td>'
                                f'<td class="obs">{_escape(pg_obs)}</td>'
                                f'<td class="attr">{_escape(pg_attr)}</td>'
                                '</tr>'
                            )
                        else:
                            body_html = (
                                '<tr><td colspan="6" '
                                'style="color:#6B7280;font-style:italic;'
                                'padding:8px 10px;">'
                                'No sub-product detail.</td></tr>'
                            )
                    st.markdown(
                        f'<table class="tree-body">'
                        f'<colgroup>{colgroup}</colgroup>'
                        f'<tbody>{body_html}</tbody></table>',
                        unsafe_allow_html=True,
                    )


# Date columns that should always render as dd-MMM-YYYY (e.g. 01-Jan-2026)
DATE_COLS = {
    'Observation Date', 'Start Date', 'Expiry Date',
    'Observation Report Date', 'Maturity Date', 'Option Expiry Date',
}


def _format_date_value(v):
    """Coerce a value to dd-MMM-YYYY. Handles:
       - real datetimes / pandas Timestamps,
       - strings already in 'dd-MMM-YY' / 'dd-MMM-YYYY' / 'MMM-YY' / etc.,
       - NaN / None / empty.
       Anything we can't confidently parse is returned unchanged (after str())."""
    if v is None:
        return ''
    if isinstance(v, float) and pd.isna(v):
        return ''
    # Real datetime
    if isinstance(v, (pd.Timestamp, datetime, np.datetime64)):
        try:
            ts = pd.Timestamp(v)
            if pd.isna(ts):
                return ''
            return ts.strftime('%d-%b-%Y')
        except (ValueError, pd.errors.OutOfBoundsDatetime):
            return str(v)
    s = str(v).strip()
    if not s:
        return ''
    # String: try a small set of known patterns, in priority order
    for fmt in ('%d-%b-%Y', '%d-%b-%y', '%b-%y', '%b-%Y',
                '%Y-%m-%d', '%m/%d/%Y', '%d/%m/%Y'):
        try:
            ts = datetime.strptime(s, fmt)
            # Two-digit-year heuristic: pandas/strptime decides century, but
            # for our domain (FRTB testing 2025+) we want 25 -> 2025 not 1925.
            if fmt in ('%d-%b-%y', '%b-%y') and ts.year < 1969:
                ts = ts.replace(year=ts.year + 100)
            return ts.strftime('%d-%b-%Y')
        except ValueError:
            continue
    # Fall back to pandas' more lenient parser
    try:
        ts = pd.to_datetime(s, errors='raise')
        return ts.strftime('%d-%b-%Y')
    except (ValueError, TypeError):
        return s  # leave unparseable strings alone


def render_rpo_table(sheet_name: str, drop_cols: list[str] | None = None,
                    caption: str = '',
                    highlight_cols: dict[str, str] | None = None,
                    max_rows: int | None = None,
                    height: int | None = None):
    """Load a sheet from the RPO workbook and render it as a styled table.

    Args:
        sheet_name:      sheet in the RPO workbook to read.
        drop_cols:       columns to hide from the table.
        caption:         optional descriptive caption above the table.
        highlight_cols:  {column_name: css_color} to apply a background fill
                         (header + cells) to a column.
        max_rows:        if set, the table is wrapped in a fixed-height
                         scroll container showing the first `max_rows`
                         visible at a time. Header stays sticky on horizontal
                         scroll so column labels are always visible.
        height:          override the container pixel height. If unset and
                         max_rows is set, computed as (max_rows * 38px + 50px header).
    """
    df = load_rpo_sheet(sheet_name, _file_mtime(RPO_FILE))
    if df.empty:
        st.info('No data available for this view.')
        return
    if drop_cols:
        df = df.drop(columns=[c for c in drop_cols if c in df.columns])

    df = df.copy()
    for c in df.columns:
        # Date columns get the dd-MMM-YYYY treatment regardless of dtype
        if c in DATE_COLS:
            df[c] = df[c].apply(_format_date_value)
        elif pd.api.types.is_datetime64_any_dtype(df[c]):
            df[c] = df[c].dt.strftime('%d-%b-%Y').fillna('')
        else:
            df[c] = df[c].astype(object).where(df[c].notna(), '')

    if caption:
        st.caption(caption)
    render_df_with_pills(df, [],
                        highlight_cols=highlight_cols,
                        max_rows=max_rows,
                        height=height)


# ---------------------------------------------------------------------------
# Small helpers
# ---------------------------------------------------------------------------
def pill(value) -> str:
    if value is None or (isinstance(value, float) and pd.isna(value)):
        return '<span class="pill pill-mute">—</span>'
    v = str(value).strip()
    if v == '':
        return '<span class="pill pill-mute">—</span>'
    vl = v.lower()
    cls = 'pill-mute'
    if vl in ('pass', 'yes') or v in ('Modellable', 'Include', 'Ready', 'Complete'):
        cls = 'pill-pass'
    elif vl in ('warn',) or v in ('Type A NMRF', 'Defer', 'Partial', 'In Review',
                                   'In Progress', 'Open', 'Low'):
        cls = 'pill-warn'
    elif vl in ('fail', 'no', 'missing') or v in ('Type B NMRF', 'Not Ready',
                                                    'Missing', 'High'):
        cls = 'pill-fail'
    return f'<span class="pill {cls}">{v}</span>'


def kpi(label: str, value, sub: str = ''):
    st.markdown(
        f'<div class="kpi-card"><div class="kpi-label">{label}</div>'
        f'<div class="kpi-value">{value}</div>'
        f'<div class="kpi-sub">{sub}</div></div>',
        unsafe_allow_html=True,
    )


def hero_kpi(label: str, value, sub: str = ''):
    """Larger, bolder KPI card for the Executive Overview strip."""
    st.markdown(
        f'<div class="hero-kpi"><div class="hero-kpi-label">{label}</div>'
        f'<div class="hero-kpi-value">{value}</div>'
        f'<div class="hero-kpi-sub">{sub}</div></div>',
        unsafe_allow_html=True,
    )


def render_df_with_pills(df: pd.DataFrame, pill_cols: list[str],
                        wrap_cols: list[str] | None = None,
                        highlight_cols: dict[str, str] | None = None,
                        max_rows: int | None = None,
                        height: int | None = None,
                        col_widths: dict[str, str] | None = None):
    """Render df as an HTML table with the dark-header look.

    By default every cell is nowrap so short tokens like dates (`24-Nov-30`)
    don't get broken across lines on hyphens. Long descriptive columns can opt
    back in by passing their names in `wrap_cols`.

    Args:
        pill_cols:      columns to render through the `pill()` helper.
        wrap_cols:      columns whose text should wrap (max 320px by default,
                        unless overridden via `col_widths`).
        highlight_cols: {column_name: css_color} for per-column background.
                        Applies to header + body cells. Color can be any valid
                        CSS color literal (e.g. '#D6F0E2', 'lightgreen').
        max_rows:       if set, table is wrapped in a fixed-height scroll
                        container showing ~`max_rows` rows at a time. Header
                        becomes sticky so column labels survive vertical and
                        horizontal scroll.
        height:         override the container px height (only used when
                        max_rows is set). Default: max_rows * 38 + 50.
        col_widths:     {column_name: css_width} for explicit column sizing
                        (e.g. {'Count Logic': '420px'}). For wrap columns,
                        this also raises the wrap cap so long text gets the
                        extra space instead of overflowing.
    """
    disp = df.copy()
    for c in pill_cols:
        if c in disp.columns:
            disp[c] = disp[c].apply(pill)

    # Annotate cells that should wrap so we can target them via a class
    wrap_set = set(wrap_cols or [])
    col_classes = {c: ('wrap' if c in wrap_set else 'nowrap') for c in disp.columns}
    highlight_cols = highlight_cols or {}

    # Generate a unique id so per-table CSS doesn't leak to other tables on
    # the same page (multiple tables share the .dataframe class).
    table_id = f't{abs(hash((tuple(disp.columns), len(disp), id(disp)))) % 10_000_000}'

    head_cells = []
    for c in disp.columns:
        attrs = f' data-col="{c}"'
        head_cells.append(f'<th{attrs}>{c}</th>')
    head_html = ''.join(head_cells)

    body_rows = []
    pill_set = set(pill_cols)
    for _, row in disp.iterrows():
        cells = []
        for c in disp.columns:
            cls = col_classes[c]
            v = row[c]
            if pd.isna(v):
                rendered = ''
            elif c in pill_set:
                # Already HTML — leave alone
                rendered = str(v)
            elif cls == 'wrap':
                # Convert literal '\n' to <br> so multi-line cells from Excel
                # render properly. Escape HTML special chars first.
                s = (str(v).replace('&', '&amp;')
                          .replace('<', '&lt;').replace('>', '&gt;'))
                rendered = s.replace('\n', '<br>')
            else:
                rendered = str(v)
            cells.append(f'<td class="{cls}" data-col="{c}">{rendered}</td>')
        body_rows.append('<tr>' + ''.join(cells) + '</tr>')

    # Compute container height when limiting visible rows
    scroll_style = ''
    if max_rows is not None:
        h = height if height is not None else max_rows * 38 + 50
        scroll_style = f' style="max-height:{h}px; overflow-y:auto;"'

    html = (
        f'<div class="dataframe-scroll"{scroll_style} id="wrap-{table_id}">'
        f'<table class="dataframe" id="{table_id}">'
        f'<thead><tr>{head_html}</tr></thead>'
        f'<tbody>{"".join(body_rows)}</tbody>'
        f'</table>'
        f'</div>'
    )

    # Per-table highlight rules
    hl_css = ''
    if highlight_cols:
        rules = []
        for col_name, color in highlight_cols.items():
            # Escape any quotes in column names
            cn = col_name.replace('"', '&quot;')
            rules.append(
                f'#{table_id} th[data-col="{cn}"] {{ background:{color} !important;'
                f' color:#0B1A2E !important; }} '
                f'#{table_id} td[data-col="{cn}"] {{ background:{color} !important; }}'
            )
        hl_css = ' '.join(rules)

    # Per-column explicit widths. For wrap columns we also lift the wrap cap
    # so text uses the new width instead of being capped at 320px.
    width_css = ''
    if col_widths:
        rules = []
        for col_name, w in col_widths.items():
            cn = col_name.replace('"', '&quot;')
            rules.append(
                f'#{table_id} th[data-col="{cn}"],'
                f'#{table_id} td[data-col="{cn}"] {{ width:{w}; min-width:{w}; }}'
            )
            # If this column also wraps, override the default 320px max-width
            if col_name in (wrap_cols or []):
                rules.append(
                    f'#{table_id} td.wrap[data-col="{cn}"] {{ max-width:{w}; }}'
                )
        width_css = ' '.join(rules)

    # Sticky header CSS for the scrollable variant
    sticky_css = ''
    if max_rows is not None:
        sticky_css = (
            f'#{table_id} thead th {{ position: sticky; top: 0; z-index: 2; }}'
        )

    st.markdown(
        '<style>'
        # Base table styles (these are idempotent across multiple calls — same
        # rule emitted by every table is fine)
        '.dataframe-scroll { width: 100%; overflow-x: auto; }'
        '.dataframe { font-size: 0.85rem; border-collapse: collapse;'
        '  table-layout: auto; width: max-content; min-width: 100%; }'
        '.dataframe th { background: #0B1A2E; color: white; padding: 8px 10px;'
        '  text-align: left; font-weight: 600; letter-spacing: 0.02em;'
        '  white-space: nowrap; }'
        '.dataframe td { padding: 6px 10px; border-bottom: 1px solid #E5E7EB;'
        '  vertical-align: top; }'
        '.dataframe td.nowrap { white-space: nowrap; word-break: keep-all;'
        '  overflow-wrap: normal; }'
        '.dataframe td.wrap { white-space: normal; max-width: 320px; }'
        '.dataframe tr:hover td { background: #FAF7EF; }'
        # Per-table overrides (highlights + sticky header)
        + hl_css + sticky_css + width_css +
        '</style>' + html,
        unsafe_allow_html=True,
    )


def asset_class_filter(df: pd.DataFrame, key: str = 'ac_filter') -> pd.DataFrame:
    classes = sorted(df['asset_class'].unique())
    chosen = st.sidebar.multiselect(
        'Asset class filter', classes, default=classes, key=key,
    )
    return df[df['asset_class'].isin(chosen)] if chosen else df


def render_slides(data, section: str, page: str):
    """Render configured slides for (section, page).

    Multiple slides → tabs labelled by `subPageName`.
    Single slide   → rendered directly with no tab chrome.
    No slides      → silent no-op.
    Missing image  → small warning, no crash.
    """
    entries = data.get('slides', {}).get((section, page), [])
    if not entries:
        return

    def _show(entry):
        img_path = SLIDES_DIR / entry['image']
        if not img_path.exists():
            st.warning(
                f"Slide image not found: `slides/{entry['image']}`. "
                f"Drop the file into the `slides/` folder next to `app.py`."
            )
            return
        st.image(str(img_path), use_container_width=True)

    st.markdown('---')

    # Single slide → just show it
    if len(entries) == 1 or all(e['tab'] is None for e in entries):
        for e in entries:
            _show(e)
        return

    # Multiple slides → tabs (fall back to a synthetic name if tab is None)
    tab_names = [e['tab'] or f'Slide {i+1}' for i, e in enumerate(entries)]
    tabs = st.tabs(tab_names)
    for tab, entry in zip(tabs, entries):
        with tab:
            _show(entry)


def render_slide_image(data, section: str, page: str, sub_page_name: str):
    """Render the single slide identified by (section, page, sub_page_name)
    from the slides sheet. If no matching row or the image file is missing,
    show a small info note instead.

    Used by the new Executive Overview tab structure where each image tab
    pulls its own picture link from the configurable slides sheet.
    """
    entries = data.get('slides', {}).get((section, page), [])
    match = next((e for e in entries if e['tab'] == sub_page_name), None)
    if match is None:
        st.info(
            f'No slide configured for **{sub_page_name}**. Add a row to the '
            f'`slides` sheet with Section=`{section}`, Page=`{page}`, '
            f'subPageName=`{sub_page_name}` and a Picture link.'
        )
        return
    img_path = SLIDES_DIR / match['image']
    if not img_path.exists():
        st.warning(
            f"Slide image not found: `slides/{match['image']}`. "
            f"Drop the file into the `slides/` folder next to `app.py`."
        )
        return
    st.image(str(img_path), use_container_width=True)


# ===========================================================================
# PAGES
# ===========================================================================
def page_exec(data):
    rf = data['rf']
    cfg = data['cfg']
    st.title('Executive Overview')

    # Prominent cycle + as-of badges (commented out per request — re-enable
    # by uncommenting the three f-string lines below).
    # st.markdown(
    #     f'<div style="margin-bottom:14px;">'
    #     f'<span class="cycle-badge">Cycle: {cfg.get("rfet_cycle", "—")}</span>'
    #     f'<span class="asof-badge">As-of: {cfg.get("as_of_date", "—")}</span>'
    #     f'<span style="margin-left:14px;color:#6B7280;">{len(rf)} risk factors in scope</span>'
    #     f'</div>',
    #     unsafe_allow_html=True,
    # )
    st.caption('')

    # Five internal tabs, same horizontal-tab style as 2.1 RPO Data Platform
    tab_ima, tab_summ, tab_outcome, tab_tech, tab_modell = st.tabs([
        'How RFET Fits in IMA',
        'RFET_Summ_concept',
        'RFET Expected Outcome',
        'High Level Tech Req_pic',
        'RF Modellability by Capital Impact',
    ])

    # ---- 1. How RFET Fits in IMA ----
    with tab_ima:
        st.subheader('How RFET Fits in IMA')
        render_slide_image(data, 'Executive View', 'Executive Overview',
                          'How RFET Fits in IMA')

    # ---- 2. RFET_Summ_concept ----
    with tab_summ:
        st.subheader('RFET Summary Concept')
        render_slide_image(data, 'Executive View', 'Executive Overview',
                          'RFET_Summ_concept')

    # ---- 3. RFET Expected Outcome — duplicate of Classification Summary ----
    with tab_outcome:
        _render_classification_summary(data, key_prefix='exec_outcome',
                                      title='RFET Expected Outcome')

    # ---- 4. High Level Tech Req_pic ----
    with tab_tech:
        st.subheader('High Level Tech Requirements')
        render_slide_image(data, 'Executive View', 'Executive Overview',
                          'High Level Tech Req_pic')

    # ---- 5. RF Modellability by Capital Impact — former Executive Overview ----
    with tab_modell:
        _render_modellability_view(data)


def _render_modellability_view(data):
    """KPI cards + flow strip + classification/capital charts + top items.
    This is the content that previously made up the entire Executive Overview
    page, now scoped to a single tab."""
    rf = data['rf']

    # KPI strip — 7 hero cards
    n_total = len(rf)
    n_mod = (rf['rfet_classification'] == 'Modellable').sum()
    n_a   = (rf['rfet_classification'] == 'Type A NMRF').sum()
    n_b   = (rf['rfet_classification'] == 'Type B NMRF').sum()
    n_high = (rf['capital_impact'] == 'High').sum()
    n_low  = (rf['capital_impact'] == 'Low').sum()
    backlog = (rf['remediation_status'].isin(['Open', 'In Progress'])).sum()

    cols = st.columns(7)
    with cols[0]: hero_kpi('Total RFs',          n_total, 'in current scope')
    with cols[1]: hero_kpi('Modellable',         n_mod,   f'{n_mod/n_total:.0%} of population')
    with cols[2]: hero_kpi('Type A NMRF',        n_a,     'qual ✓, RPO famine')
    with cols[3]: hero_kpi('Type B NMRF',        n_b,     'qual gaps / broken')
    with cols[4]: hero_kpi('Capital High Impact', n_high, 'Type B NMRFs')
    with cols[5]: hero_kpi('Capital Low Impact',  n_low,  'Type A NMRFs')
    with cols[6]: hero_kpi('Backlog',            backlog, 'open + in-progress')

    st.markdown('---')

    # Flow strip
    st.subheader('End-to-end RFET flow')
    stages = ['Business Scope', 'RF Identification', 'RF Ready for RFET',
              'Qualitative Test', 'Quantitative Test', 'Classification',
              'Remediation', 'Capital Output']
    flow_cols = st.columns(len(stages))
    for c, s in zip(flow_cols, stages):
        with c:
            st.markdown(
                f'<div style="background:#0B1A2E;color:white;padding:10px 8px;'
                f'border-radius:6px;text-align:center;font-size:0.78rem;'
                f'font-weight:600;">{s}</div>',
                unsafe_allow_html=True,
            )

    st.markdown('---')

    left, right = st.columns([3, 2])
    with left:
        st.subheader('Classification by asset class')
        cross = (rf.groupby(['asset_class', 'rfet_classification']).size()
                 .reset_index(name='count'))
        fig = px.bar(cross, x='asset_class', y='count', color='rfet_classification',
                    color_discrete_map=STATUS_COLORS,
                    category_orders={'rfet_classification':
                                     ['Modellable', 'Type A NMRF', 'Type B NMRF']})
        fig.update_layout(barmode='stack', height=380, margin=dict(t=20, b=10),
                         plot_bgcolor='white', legend_title='')
        st.plotly_chart(fig, use_container_width=True)

    with right:
        st.subheader('Capital impact split')
        ci_counts = rf['capital_impact'].value_counts().reset_index()
        ci_counts.columns = ['Capital impact', 'Count']
        order = ['High', 'Low', 'TBD']
        ci_counts['__o'] = ci_counts['Capital impact'].map(
            {v: i for i, v in enumerate(order)})
        ci_counts = ci_counts.sort_values('__o').drop(columns='__o')
        fig2 = px.bar(ci_counts, x='Capital impact', y='Count',
                     color='Capital impact', color_discrete_map=STATUS_COLORS,
                     text='Count')
        fig2.update_traces(textposition='outside')
        fig2.update_layout(height=380, plot_bgcolor='white', showlegend=False,
                          margin=dict(t=20, b=10), xaxis_title='', yaxis_title='')
        st.plotly_chart(fig2, use_container_width=True)

    st.markdown('---')
    st.subheader('Top High-impact items needing attention')
    top = (rf[rf['capital_impact'] == 'High']
           [['rf_id', 'rf_name', 'asset_class', 'rfet_classification',
             'capital_impact', 'remediation_status', 'remediation_path']])
    if len(top) == 0:
        st.info('No High-impact items.')
    else:
        top.columns = ['ID', 'Name', 'AC', 'Classification', 'Capital Impact',
                      'Remediation', 'Path']
        render_df_with_pills(top, ['Classification', 'Capital Impact', 'Remediation'],
                            wrap_cols=['Name', 'Path'])


def page_scope(data):
    ac = data['ac']
    st.title('Desks in Scope')
    st.caption('')

    fig = go.Figure()
    fig.add_trace(go.Bar(
        x=ac['sub_product'], y=ac['capital_impact_score'], name='Capital impact',
        marker_color=COL_NAVY,
    ))
    fig.add_trace(go.Bar(
        x=ac['sub_product'], y=ac['model_pass_probability_score'],
        name='Model pass prob',
        marker_color=COL_BRASS,
    ))
    fig.add_trace(go.Bar(
        x=ac['sub_product'], y=ac['cost_benefit_score'], name='Cost-benefit',
        marker_color=COL_PASS,
    ))
    fig.update_layout(barmode='group', height=400, plot_bgcolor='white',
                     margin=dict(t=20, b=80), xaxis_tickangle=-30,
                     yaxis=dict(range=[0, 10], title='Score (1–10)'))
    st.plotly_chart(fig, use_container_width=True)

    st.subheader('Decision table')
    render_df_with_pills(ac, ['decision', 'bt_pla_readiness'],
                        wrap_cols=['rationale'])


def page_lineage(data):
    rf = data['rf']
    st.title('MDO → Risk Factor Lineage')
    st.caption('Pricing MDO and Risk RF supply chain per risk factor.')
    rf_f = asset_class_filter(rf)

    # Trimmed: removed RPO Category and RPO Lineage
    cols = ['rf_id', 'rf_name', 'asset_class', 'source_system',
            'pricing_mdo', 'risk_rf', 'rfet_ready']
    disp = rf_f[cols].copy()
    disp.columns = ['ID', 'Name', 'AC', 'Source', 'Pricing MDO',
                   'Risk RF', 'RFET Ready']
    disp['Pricing MDO'] = disp['Pricing MDO'].fillna('— missing —')
    disp['Risk RF'] = disp['Risk RF'].fillna('— missing —')
    render_df_with_pills(disp, ['RFET Ready'], wrap_cols=['Name'])

    render_slides(data, '5. Other IMA RF Tech Req', 'MDO → RF Lineage')


def page_ready(data):
    st.title('RF → LH Mapping')
    st.caption('')

    tab_intro, tab_list, tab_logic, tab_tech = st.tabs([
        'Liquidity Horizon Intro',
        'LH List',
        'LH Mapping Logic',
        'RF-LH Mapping Tech Delivery',
    ])

    # ---- 1. Liquidity Horizon Intro ----
    with tab_intro:
        st.subheader('Liquidity Horizon Intro')
        render_slide_image(data, '1. RF to Liquidity Horizon Mapping',
                          'RF → LH Mapping', 'Liquidity Horizon Intro')

    # ---- 2. LH List ----
    with tab_list:
        st.subheader('LH List')
        render_slide_image(data, '1. RF to Liquidity Horizon Mapping',
                          'RF → LH Mapping', 'LH List')

    # ---- 3. LH Mapping Logic — rule-based + metadata-driven + override flow ----
    with tab_logic:
        st.subheader('LH Mapping Logic')
        render_slide_image(data, '1. RF to Liquidity Horizon Mapping',
                          'RF → LH Mapping', 'LH Mapping Logic')

    # ---- 4. RF-LH Mapping Tech Delivery (former page contents) ----
    with tab_tech:
        _render_lh_tech_delivery(data)


def page_lh_assigned_es_ses(data):
    """Assigned LH in ES/SES — how the assigned LH flows into ES/SES capital.

    Two tabs:
      1. ES Scaling Rule using LH — the cascading √((LH_j − LH_{j-1})/T) rule
         (formerly the "How LH in Used in ES" tab on the RF → LH Mapping page).
      2. LH Special Handling in ES/SES — special-case handling.
    """
    st.title('Assigned LH in ES/SES')
    st.caption('')

    tab_rule, tab_special = st.tabs([
        'ES Scaling Rule using LH',
        'LH Special Handling in ES/SES',
    ])

    # ---- 1. ES Scaling Rule using LH ----
    with tab_rule:
        st.subheader('ES Scaling Rule using LH')
        render_slide_image(data, '1. RF to Liquidity Horizon Mapping',
                          'Assigned LH in ES/SES', 'ES Scaling Rule using LH')

    # ---- 2. LH Special Handling in ES/SES ----
    with tab_special:
        st.subheader('LH Special Handling in ES/SES')
        render_slide_image(data, '1. RF to Liquidity Horizon Mapping',
                          'Assigned LH in ES/SES', 'LH Special Handling in ES/SES')


def _render_lh_tech_delivery(data):
    """LH distribution + readiness-by-source + readiness detail.

    This is the content that previously made up the entire RF → LH Mapping
    page, now scoped to a single tab.
    """
    rf = data['rf']
    st.subheader('RF-LH Mapping Tech Delivery')
    st.caption('Each risk factor is mapped to its FRTB liquidity horizon '
              '(10d / 20d / 40d / 60d / 120d) and its readiness state by '
              'source system.')

    # LH distribution chart
    lh_order = ['10d', '20d', '40d', '60d', '120d']
    lh_counts = (rf.groupby(['RF_to_LH', 'rfet_classification']).size()
                .reset_index(name='count'))
    lh_counts['__o'] = lh_counts['RF_to_LH'].map({v: i for i, v in enumerate(lh_order)})
    lh_counts = lh_counts.sort_values('__o')
    st.markdown('**LH distribution across the RF population**')
    fig_lh = px.bar(lh_counts, x='RF_to_LH', y='count',
                   color='rfet_classification',
                   color_discrete_map=STATUS_COLORS,
                   category_orders={'RF_to_LH': lh_order,
                                    'rfet_classification':
                                        ['Modellable', 'Type A NMRF', 'Type B NMRF']})
    fig_lh.update_layout(barmode='stack', height=320, plot_bgcolor='white',
                        margin=dict(t=20, b=10), xaxis_title='Liquidity Horizon',
                        yaxis_title='# RFs', legend_title='')
    st.plotly_chart(fig_lh, use_container_width=True, key='lh_dist_chart')

    st.markdown('---')
    rf = rf.copy()
    rf['_ready_lo'] = rf['rfet_ready'].astype(str).str.lower()
    by_src = rf.groupby('source_system').agg(
        total=('rf_id', 'count'),
        ready=('_ready_lo', lambda s: ((s == 'yes') | (s == 'pass')).sum()),
        blocked=('_ready_lo', lambda s: ((s == 'no') | (s == 'fail')).sum()),
    ).reset_index()
    by_src.columns = ['Source', 'Total RFs', 'Ready', 'Blocked']
    st.markdown('**Readiness by source system**')
    render_df_with_pills(by_src, [])

    st.markdown('---')
    st.markdown('**Readiness detail**')
    rf_f = asset_class_filter(rf, key='lh_filter')
    cols = ['rf_id', 'rf_name', 'source_system', 'rfet_ready', 'RF_to_LH']
    disp = rf_f[cols].copy()
    disp.columns = ['ID', 'Name', 'Source', 'RFET Ready', 'LH']
    render_df_with_pills(disp, ['RFET Ready'], wrap_cols=['Name'])



def page_engine(data):
    rf = data['rf']
    st.title('RFET Tests Details')
    st.caption("Six qualitative tests + Quantitative test (RPO count ≥ threshold). "
              "Threshold is **24** for LH ≤ 20d, **16** otherwise.")
    rf_f = asset_class_filter(rf)

    cols = (['rf_id', 'rf_name', 'asset_class', 'RF_to_LH']
            + [c for c, _, _, _ in QUAL_TESTS]
            + ['qualititave_res', 'rpo_count', 'rpo_threshold',
               'Quantititave_res', 'rfet_classification'])
    disp = rf_f[cols].copy()
    disp.columns = (['ID', 'Name', 'AC', 'LH']
                    + [lbl for _, lbl, _, _ in QUAL_TESTS]
                    + ['Qual', 'RPOs', 'RPO Thr', 'Quant', 'Classification'])
    render_df_with_pills(
        disp,
        [lbl for _, lbl, _, _ in QUAL_TESTS] + ['Qual', 'Quant', 'Classification'],
        wrap_cols=['Name'],
    )

    st.markdown('---')
    st.subheader('Drill into a single risk factor')
    rfid = st.selectbox('Choose an RF', rf_f['rf_id'].tolist())
    row = rf_f[rf_f['rf_id'] == rfid].iloc[0]
    render_rf_drilldown(row)


def render_rf_drilldown(row):
    """Detailed per-RF panel — RPO Category and Capital Impact removed."""
    c1, c2, c3 = st.columns([2, 1, 1])
    with c1:
        st.markdown(f"### {row['rf_id']} — {row['rf_name']}")
        st.caption(f"{row['asset_class']} · {row['product']} · "
                  f"{row['currency']} · {row['tenor']} · LH {row['RF_to_LH']}")
    with c2:
        kpi('Classification', row['rfet_classification'])
    with c3:
        kpi('RFET Ready', row['rfet_ready'])

    st.markdown('#### Qualitative tests (6)')
    q_cols = st.columns(6)
    for c, (key, label, _, _) in zip(q_cols, QUAL_TESTS):
        with c:
            st.markdown(
                f'<div class="kpi-card"><div class="kpi-label">{label}</div>'
                f'<div style="margin-top:6px;">{pill(row[key])}</div></div>',
                unsafe_allow_html=True,
            )

    st.markdown('#### Test results & quantitative')
    q1, q2, q3, q4, q5 = st.columns(5)
    rpo_pass = int(row['rpo_count']) >= int(row['rpo_threshold'])
    with q1: kpi('Qual result',  row['qualititave_res'])
    with q2: kpi('Quant result', row['Quantititave_res'])
    with q3: kpi('RPO count',    int(row['rpo_count']))
    with q4: kpi('RPO threshold', int(row['rpo_threshold']),
                 f"LH {row['RF_to_LH']}")
    with q5: kpi('RPO test', '✓ Pass' if rpo_pass else '✗ Fail')

    st.markdown('#### Remediation')
    r1, r2, r3 = st.columns(3)
    with r1: kpi('Evidence',  row.get('evidence_status', '—'))
    with r2: kpi('Status',    row.get('remediation_status', '—'))
    with r3: kpi('Target',    row.get('target_date', '—'))
    path = row.get('remediation_path', '')
    if pd.notna(path) and str(path).strip() not in ('', '—'):
        st.markdown(f"**Path:** {path}")
    notes = row.get('notes', '')
    if pd.notna(notes) and str(notes).strip():
        st.info(f"**Note:** {notes}")


def _render_classification_summary(data, key_prefix: str = 'cls',
                                  title: str = 'RFET Classification Summary',
                                  caption: str = 'Final RFET outcomes per risk factor.',
                                  show_title: bool = True):
    """Shared renderer for the RFET classification summary view.

    Used by both:
      - the dedicated `page_classification_summary` page under section 4, and
      - the `RFET Expected Outcome` tab inside Executive Overview.

    `key_prefix` namespaces the asset-class filter widget so the two
    instances can coexist without Streamlit key collisions.
    """
    rf = data['rf']
    if show_title:
        st.subheader(title)
    if caption:
        st.caption(caption)

    # Heatmap
    pivot = (rf.groupby(['asset_class', 'rfet_classification']).size()
             .unstack(fill_value=0))
    for c in ['Modellable', 'Type A NMRF', 'Type B NMRF']:
        if c not in pivot.columns:
            pivot[c] = 0
    pivot = pivot[['Modellable', 'Type A NMRF', 'Type B NMRF']]

    fig = px.imshow(
        pivot.values, x=pivot.columns, y=pivot.index,
        color_continuous_scale='RdBu_r', text_auto=True, aspect='auto',
    )
    fig.update_layout(height=320, margin=dict(t=20, b=20),
                     coloraxis_colorbar={'title': 'Count'})
    st.markdown('**Heatmap: asset class × classification**')
    st.plotly_chart(fig, use_container_width=True,
                   key=f'{key_prefix}_heatmap')

    st.markdown('---')

    c1, c2 = st.columns(2)
    with c1:
        st.markdown('**Classification × Liquidity Horizon**')
        cross_lh = (rf.groupby(['RF_to_LH', 'rfet_classification']).size()
                    .reset_index(name='count'))
        lh_order = ['10d', '20d', '40d', '60d', '120d']
        cross_lh['__o'] = cross_lh['RF_to_LH'].map({v: i for i, v in enumerate(lh_order)})
        cross_lh = cross_lh.sort_values('__o')
        fig2 = px.bar(cross_lh, x='RF_to_LH', y='count', color='rfet_classification',
                     color_discrete_map=STATUS_COLORS,
                     category_orders={'RF_to_LH': lh_order})
        fig2.update_layout(barmode='stack', height=340, plot_bgcolor='white',
                          margin=dict(t=20, b=10), xaxis_title='LH',
                          yaxis_title='count', legend_title='')
        st.plotly_chart(fig2, use_container_width=True,
                       key=f'{key_prefix}_lh_bar')

    with c2:
        st.markdown('**Population by classification**')
        cls_counts = rf['rfet_classification'].value_counts().reset_index()
        cls_counts.columns = ['Classification', 'Count']
        order = ['Modellable', 'Type A NMRF', 'Type B NMRF']
        cls_counts['__o'] = cls_counts['Classification'].map(
            {v: i for i, v in enumerate(order)})
        cls_counts = cls_counts.sort_values('__o').drop(columns='__o')
        fig3 = px.bar(cls_counts, x='Classification', y='Count',
                     color='Classification', color_discrete_map=STATUS_COLORS,
                     text='Count')
        fig3.update_traces(textposition='outside')
        fig3.update_layout(height=340, plot_bgcolor='white', showlegend=False,
                          margin=dict(t=20, b=10), xaxis_title='', yaxis_title='')
        st.plotly_chart(fig3, use_container_width=True,
                       key=f'{key_prefix}_pop_bar')

    st.markdown('---')
    st.markdown('**Classification summary table**')
    rf_f = asset_class_filter(rf, key=f'{key_prefix}_filter')
    # Includes the new `is_Full_Set` column derived in Excel
    cols = ['rf_id', 'rf_name', 'asset_class', 'RF_to_LH',
            'rfet_classification', 'qualititave_res', 'Quantititave_res',
            'is_Full_Set']
    # Guard: if a fresh workbook hasn't been reloaded yet, fall back gracefully
    cols = [c for c in cols if c in rf_f.columns]
    disp = rf_f[cols].copy()
    # Friendly column titles in same order
    rename_map = {
        'rf_id': 'ID', 'rf_name': 'Name', 'asset_class': 'AC',
        'RF_to_LH': 'LH', 'rfet_classification': 'Classification',
        'qualititave_res': 'Qual Result', 'Quantititave_res': 'Quant Result',
        'is_Full_Set': 'Full Set?',
    }
    disp.columns = [rename_map[c] for c in cols]
    pill_cols = [c for c in ('Classification', 'Qual Result', 'Quant Result',
                            'Full Set?')
                if c in disp.columns]
    render_df_with_pills(disp, pill_cols, wrap_cols=['Name'])


def page_classification_summary(data):
    """RFET Classification Summary — section 4 page (thin wrapper)."""
    st.title('RFET Classification Summary')
    _render_classification_summary(data, key_prefix='cls',
                                  caption='Final RFET outcomes per risk factor.',
                                  show_title=False)

    render_slides(data, '4. RFET Classification Buildout',
                 'RFET Classification Summary')


def page_qual_buildout(data):
    """Qualitative Tests Buildout — describes each of the six tests."""
    rf = data['rf']
    st.title('Qualitative Tests Buildout')
    st.caption('')

    tab_it, tab_buildout = st.tabs([
        'Qualitative tests IT Deliverables',
        'Qualitative Tests Buildout',
    ])

    # ---- 1. IT Deliverables overview (image) ----
    with tab_it:
        st.subheader('Qualitative tests IT Deliverables')
        render_slide_image(data, '3. Qualitative Tests Buildout',
                          'Qualitative Tests Buildout',
                          'Qualitative tests IT Deliverables')

    # ---- 2. Buildout detail (existing content) ----
    with tab_buildout:
        _render_qual_buildout_detail(data)


def _render_qual_buildout_detail(data):
    """Per-RF results table + population chart + per-test cards.

    Extracted from the original `page_qual_buildout` so the page can host
    the new IT Deliverables image alongside the detail view in a tab strip.
    """
    rf = data['rf']

    # Per-RF qualitative test results table (ID, Name + 6 qualN_ columns)
    st.subheader('Per-RF qualitative test results')
    rf_f = asset_class_filter(rf, key='qual_filter')
    qual_cols = [c for c, _, _, _ in QUAL_TESTS]
    disp = rf_f[['rf_id', 'rf_name'] + qual_cols].copy()
    disp.columns = ['ID', 'Name'] + qual_cols  # keep the qualN_ names visible
    render_df_with_pills(disp, qual_cols, wrap_cols=['Name'])

    st.markdown('---')
    # High-level summary chart: pass/fail per test
    summary_rows = []
    for col, _, name, _ in QUAL_TESTS:
        s = rf[col].astype(str).str.lower()
        summary_rows.append({
            'Test': name,
            'pass': (s == 'pass').sum(),
            'warn': (s == 'warn').sum(),
            'fail': (s == 'fail').sum(),
        })
    summary_df = pd.DataFrame(summary_rows)
    summary_long = summary_df.melt(id_vars='Test', var_name='Result', value_name='Count')
    fig = px.bar(summary_long, x='Test', y='Count', color='Result',
                color_discrete_map={'pass': COL_PASS, 'warn': COL_WARN, 'fail': COL_FAIL},
                category_orders={'Result': ['pass', 'warn', 'fail']})
    fig.update_layout(barmode='stack', height=340, plot_bgcolor='white',
                     margin=dict(t=20, b=10), xaxis_tickangle=-15,
                     legend_title='', xaxis_title='', yaxis_title='RFs')
    st.subheader('Population results across the six tests')
    st.plotly_chart(fig, use_container_width=True, key='qual_pop_chart')

    st.markdown('---')
    st.subheader('Test descriptions')

    # Card per test
    for i, (col, label, name, desc) in enumerate(QUAL_TESTS, 1):
        results = rf[col].astype(str).str.lower().value_counts().to_dict()
        n_pass = results.get('pass', 0)
        n_warn = results.get('warn', 0)
        n_fail = results.get('fail', 0)

        # Top 3 failing RFs for this test
        failing = rf[rf[col].astype(str).str.lower() != 'pass'][['rf_id', 'rf_name', col]]
        failing_html = ''
        if len(failing) > 0:
            failing_html = '<div style="margin-top:10px;color:#374151;font-size:0.85rem;">'
            failing_html += '<b>RFs not passing:</b> '
            items = []
            for _, r in failing.head(6).iterrows():
                items.append(f'{r["rf_id"]} ({r[col]})')
            failing_html += ', '.join(items)
            if len(failing) > 6:
                failing_html += f' &nbsp;<span style="color:#6B7280;">+{len(failing)-6} more</span>'
            failing_html += '</div>'

        st.markdown(
            f'<div class="qual-card">'
            f'<div class="qual-card-head">'
            f'<span class="qual-card-title">{i}. {name}</span>'
            f'<span class="qual-card-ref">{col}</span>'
            f'</div>'
            f'<div class="qual-card-desc">{desc}</div>'
            f'<div style="margin-top:10px;">'
            f'{pill("pass")} &nbsp;{n_pass} &nbsp;&nbsp;'
            f'{pill("warn")} &nbsp;{n_warn} &nbsp;&nbsp;'
            f'{pill("fail")} &nbsp;{n_fail}'
            f'</div>'
            f'{failing_html}'
            f'</div>',
            unsafe_allow_html=True,
        )


def page_quant_buildout(data):
    """Quantitative Tests Buildout — Overview only.

    The previous four detail tabs (RPO Pipeline / Storage-Ingest-Norm-Bucket /
    Aggregation / RPO→RF Mapping) have been removed; that content is now
    covered by the dedicated sub-pages 2.1 RPO Data Platform, 2.2 RPO
    Bucketing Logic, 2.3 RPO Aggregation, and 2.4 RPO to RF Mapping. This
    page intentionally stays a single-view per-RF results table.
    """
    rf = data['rf']

    st.title('Quantitative Tests Buildout')
    st.caption("")

    st.subheader('Overview — Per-RF Quantitative results')
    st.caption('Threshold = **24** for LH ≤ 20d, **16** otherwise. '
              'Quant pass requires RPO count ≥ threshold.')
    rf_f = asset_class_filter(rf, key='quant_filter')
    cols = ['rf_id', 'rf_name', 'asset_class', 'RF_to_LH',
            'rpo_count', 'rpo_threshold', 'Quantititave_res',
            'rf_to_rpo_category', 'rf_to_rpo_lineage']
    disp = rf_f[cols].copy()
    disp.columns = ['ID', 'Name', 'AC', 'LH', 'RPO Count',
                   'RPO Threshold', 'Result', 'RPO Category', 'RPO Lineage']
    render_df_with_pills(disp, ['Result'], wrap_cols=['Name'])


def page_remediate(data):
    rf = data['rf']
    st.title('IMA RF Readiness and Remediation')
    st.caption('Backlog of NMRFs with paths back to modellable (or to SA).')

    rem = rf[rf['rfet_classification'].isin(['Type A NMRF', 'Type B NMRF'])].copy()

    c1, c2 = st.columns([1, 1])
    with c1:
        st.subheader('Remediation paths')
        path_counts = rem['remediation_path'].fillna('Unspecified').value_counts().reset_index()
        path_counts.columns = ['Path', 'Count']
        fig = px.pie(path_counts, values='Count', names='Path', hole=0.55)
        fig.update_layout(height=360, margin=dict(t=20, b=20))
        st.plotly_chart(fig, use_container_width=True)

    with c2:
        st.subheader('Capital impact split (NMRFs)')
        ci_by = rem.groupby('capital_impact').size().reset_index(name='count')
        order = ['High', 'Low']
        ci_by['__o'] = ci_by['capital_impact'].map({v: i for i, v in enumerate(order)})
        ci_by = ci_by.sort_values('__o')
        fig2 = px.bar(ci_by, x='capital_impact', y='count',
                     color='capital_impact', color_discrete_map=STATUS_COLORS,
                     text='count')
        fig2.update_traces(textposition='outside')
        fig2.update_layout(height=360, plot_bgcolor='white', showlegend=False,
                          margin=dict(t=20, b=10),
                          xaxis_title='', yaxis_title='count')
        st.plotly_chart(fig2, use_container_width=True)

    st.markdown('---')
    st.subheader('Kanban — by remediation status')
    statuses = ['Open', 'In Progress', 'Deferred']
    kan_cols = st.columns(len(statuses))
    for c, status in zip(kan_cols, statuses):
        items = rem[rem['remediation_status'] == status]
        with c:
            st.markdown(f'<div class="kanban-col-head">{status} '
                       f'({len(items)})</div>', unsafe_allow_html=True)
            for _, r in items.iterrows():
                st.markdown(
                    f'<div class="kanban-card">'
                    f'<b>{r["rf_id"]}</b><br>'
                    f'<span style="color:#6B7280;font-size:0.78rem;">'
                    f'{str(r["rf_name"])[:40]}</span><br>'
                    f'<div style="margin-top:6px;">{pill(r["rfet_classification"])}'
                    f' &nbsp; {pill(r["capital_impact"])}</div>'
                    f'<div style="color:#6B7280;font-size:0.78rem;margin-top:4px;">'
                    f'{r["asset_class"]} · LH {r["RF_to_LH"]}</div>'
                    f'</div>',
                    unsafe_allow_html=True,
                )

    st.markdown('---')
    st.subheader('Remediation table')
    cols = ['rf_id', 'rf_name', 'asset_class', 'rfet_classification',
            'remediation_status', 'remediation_path', 'capital_impact',
            'target_date']
    disp = rem[cols].copy()
    disp.columns = ['ID', 'Name', 'AC', 'Classification', 'Status', 'Path',
                   'Capital Impact', 'Target']
    render_df_with_pills(disp, ['Classification', 'Status', 'Capital Impact'],
                        wrap_cols=['Name', 'Path'])


def _placeholder(title: str, num: str, blurb: str):
    """Reusable empty-page stub for sub-sections not yet built out."""
    st.title(title)
    st.caption('')
    st.info(blurb)


def page_rpo_data_platform(data):
    st.title('RPO Data Platform')
    st.caption('')

    tab_overview, tab_ir_schema, tab_fx_schema, tab_sofr, tab_capfloor, tab_bond = \
        st.tabs([
            'RPO Data Platform Overview',
            'RPO_IR_Schema',
            'RPO_FX_Schema',
            'IR_SOFR_RawRPO_Sample',
            'IR_CapflourRPO_Raw_Sample',
            'FI_Bond_RawRPO_Sample',
        ])

    # ---- Overview — single PNG, no nested tabs / subheader ----
    # NOTE: do NOT use render_slides() here. It would pull EVERY slide row
    # registered under (Section='2. Quantitative Tests Buildout',
    # Page='2.1 RPO Data Platform') and render them as nested tabs — which
    # includes the IR/FX schema images that already have their own
    # top-level tabs. Use render_slide_image() with the explicit subPageName
    # so we render exactly the one Overview slide.
    with tab_overview:
        render_slide_image(data, '2. Quantitative Tests Buildout',
                          '2.1 RPO Data Platform', 'RPO Data Platform Overview')

    # ---- IR Schema — now displays a static PNG ----
    # The original hierarchical tree renderer is preserved in
    # `render_schema_tree('RPO_IR_Schema', obs_level=3)` and can be re-enabled
    # by swapping the call below.
    with tab_ir_schema:
        st.subheader('Interest Rate Schema')
        render_slide_image(data, '2. Quantitative Tests Buildout',
                          '2.1 RPO Data Platform', 'RPO_IR_Schema_pic')
        # render_schema_tree('RPO_IR_Schema', obs_level=3)  # legacy tree view

    # ---- FX Schema — now displays a static PNG ----
    # Legacy tree view: render_schema_tree('RPO_FX_Schema', obs_level=2)
    with tab_fx_schema:
        st.subheader('FX Schema')
        render_slide_image(data, '2. Quantitative Tests Buildout',
                          '2.1 RPO Data Platform', 'RPO_FX_Schema_pic')
        # render_schema_tree('RPO_FX_Schema', obs_level=2)  # legacy tree view

    # Columns to drop on the two IR raw sample sheets
    DROP_RAW = ['Time to Maturity', 'Start Tenor', 'Ticker']

    with tab_sofr:
        st.subheader('IR SOFR — Raw RPO sample')
        render_rpo_table('IR_SOFR_RawRPO_Sample', drop_cols=DROP_RAW)

    with tab_capfloor:
        st.subheader('IR Cap/Floor — Raw RPO sample')
        # 16 rows visible at a time with sticky header — same scroll container
        # behaviour as the cap/floor bucketing tab in section 2.2.
        render_rpo_table('IR_CapflourRPO_Raw_Sample', drop_cols=DROP_RAW,
                        max_rows=16)

    with tab_bond:
        st.subheader('FI Bond — Raw RPO sample')
        render_rpo_table('FI_Bond_RawRPO_Sample')


def page_rpo_bucketing(data):
    st.title('RPO Bucketing Logic')
    st.caption('')

    tab_sofr, tab_capfloor = st.tabs([
        'IR_SOFR_Bucketing',
        'IR_Capfloor_Bucketing',
    ])

    with tab_sofr:
        st.subheader('IR SOFR — Bucketing')
        render_rpo_table(
            'IR_SOFR_Bucketing',
            highlight_cols={
                'Expiry Date':        '#D6F0E2',  # light green
                'Time to Maturity':   '#FCE2C4',  # light orange
                'Bucket_Regulatory':  '#FCE2C4',  # light orange — regulatory bucket
                'Bucket_Internal':    '#FCE2C4',  # light orange — internal bucket (paired view)
            },
        )

    with tab_capfloor:
        st.subheader('IR Cap/Floor — Bucketing')
        # 16 rows visible at a time; sticky header so column labels stay put
        # when scrolling horizontally to wide right-hand columns.
        render_rpo_table('IR_Capfloor_Bucketing', max_rows=16)


def page_rpo_aggregation(data):
    st.title('RPO Aggregation')
    st.caption('')

    tab_sofr, tab_capfloor, tab_bond = st.tabs([
        'IR_SOFR_Aggregation',
        'IR_Capfloor_Aggregation',
        'FI_Bond_Aggregation',
    ])

    with tab_sofr:
        st.subheader('IR SOFR — Aggregation')
        render_rpo_table('IR_SOFR_Aggregation')

    with tab_capfloor:
        st.subheader('IR Cap/Floor — Aggregation')
        render_rpo_table('IR_Capfloor_Aggregation')

    with tab_bond:
        st.subheader('FI Bond — Aggregation')
        render_rpo_table('FI_Bond_Aggregation')


def page_rpo_mapping_engine(data):
    st.title('RPO to RF Mapping and Translation Engine')
    st.caption('')

    tab_approaches, tab_step, tab_sofr, tab_capfloor, tab_logic = st.tabs([
        'RPO-RF Mapping Approaches',
        'RPO-RF Mapping Logic',
        'RPO-RF_Mapping_SOFF_Sample',
        'RPO-RF-Mapping_VolCapfloor_Param',
        'RPO-RF-Mapping_VolCapfloor_Logic',
    ])

    # ---- 1. Mapping Approaches — image ----
    with tab_approaches:
        st.subheader('RPO-RF Mapping Approaches')
        render_slide_image(data, '2. Quantitative Tests Buildout',
                          '2.4 RPO to RF Mapping and Translation Engine',
                          'RPO-RF Mapping Approaches')

    # ---- 2. Mapping Logic (step-by-step) — image ----
    with tab_step:
        st.subheader('RPO-RF Mapping Logic')
        render_slide_image(data, '2. Quantitative Tests Buildout',
                          '2.4 RPO to RF Mapping and Translation Engine',
                          'RPO-RF Mapping Logic')

    # ---- 3. SOFR Sample mapping — sheet from rfet_qualitative_RPO ----
    with tab_sofr:
        st.subheader('RPO → RF Mapping — SOFR Sample')
        st.caption('Worked example: how each MDSOR / RFDM risk factor is '
                  'attached to its bucketed RPO group.')
        render_rpo_table('RPO-RF_Mapping_SOFF_Sample')

    # ---- 4. Capfloor Parametric — two-section page from one sheet ----
    with tab_capfloor:
        _render_capfloor_param_tables(data)

    # ---- 5. Capfloor Parametric mapping logic — image ----
    with tab_logic:
        st.subheader('RPO-RF Mapping — Capfloor Parametric Logic')
        render_slide_image(data, '2. Quantitative Tests Buildout',
                          '2.4 RPO to RF Mapping and Translation Engine',
                          'RPO-RF-Mapping_VolCapfloor_Logic')


def _render_capfloor_param_tables(data):
    """Render the two stacked tables from `RPO_RF_Mapping_Capfloor`.

    The source sheet has two distinct tables separated by blank rows:
      - rows 0-4: RPO bucket inventory (Mapping Category / Ticker /
                  Bucket / RPO Count / Strike Role)
      - rows 7-11: parameter logic mapping (Risk Factor Param / Parameter
                   Meaning / Required RPO Buckets / Count Logic /
                   Count From Totals)

    Both are rendered as separate tables on the same page so the user can
    visually correlate the bucket counts in the upper table with the
    counting math in the lower table.
    """
    st.subheader('RPO-RF Mapping — Capfloor Parametric')
    st.caption('Two views of the same mapping: the RPO bucket inventory '
              'above and the parameter-level count logic below.')

    # Read the source sheet header-less so we can extract both sub-tables
    sheet = 'RPO_RF_Mapping_Capfloor'
    raw = load_rpo_sheet_raw(sheet, _file_mtime(RPO_FILE))
    if raw is None or raw.empty:
        st.info(f'Sheet `{sheet}` is empty or missing.')
        return

    # --- Top table: rows 1-5 (data rows under the row-0 header) ---
    top_headers = ['Mapping Category', 'RPO Group Ticker', 'Bucket',
                  'RPO Count', 'Strike Role']
    top_df = raw.iloc[1:5].copy()
    top_df.columns = raw.iloc[0].tolist()[:5]
    # Force the user-spec column order/names
    top_df = top_df.reindex(columns=top_headers).reset_index(drop=True)

    st.markdown('**Section 1 — RPO bucket inventory (Strike-Role aware)**')
    render_df_with_pills(top_df, [], wrap_cols=['RPO Group Ticker'])

    st.markdown(' ')  # small gap

    # --- Bottom table: rows 8-12 (data rows under the row-7 header) ---
    # Per-spec column labels (note: workbook says 'Risk Factor' but spec
    # wants 'Risk Factor Param' for the display label).
    bot_headers = ['Risk Factor Param', 'Parameter Meaning',
                  'Required RPO Buckets', 'Count Logic', 'Count From Totals']
    bot_df = raw.iloc[8:12].copy()
    bot_df.columns = bot_headers[:len(bot_df.columns)]
    bot_df = bot_df.reindex(columns=bot_headers).reset_index(drop=True)

    st.markdown('**Section 2 — Risk-factor parameter logic and counting**')
    # Count Logic gets explicit wide width + wrap so its multi-line math is
    # fully visible.
    render_df_with_pills(
        bot_df, [],
        wrap_cols=['Parameter Meaning', 'Required RPO Buckets', 'Count Logic'],
        col_widths={
            'Risk Factor Param':    '220px',
            'Parameter Meaning':    '180px',
            'Required RPO Buckets': '160px',
            'Count Logic':          '420px',
            'Count From Totals':    '180px',
        },
    )


def page_counting_engine(data):
    _placeholder(
        'Counting Engine',
        '2.5',
        'This page will document the counting engine that produces the final RPO '
        'count per RF used in the quantitative test — including the rolling window, '
        'gap calculation, and threshold comparison logic.',
    )


def page_about(data):
    st.title('About this PoC')
    st.markdown("""
**RFET IMA Workbench** — interactive proof-of-concept for the Risk Factor
Eligibility Test under FRTB Internal Models Approach.

#### Navigation
1. **Executive Overview** — population-level KPIs and charts.
2. **Desks in Scope** — business-scope nomination (include / defer / exclude).
3. **MDO → RF Lineage** — upstream pricing MDO and risk RF supply chain.
4. **RF Ready for RFET** — gate state per RF.
5. **RFET Tests Details** — the six qual tests + quant test per RF, with drill-down.
6. **RFET Classification Summary** — slim outcomes table + heatmap.
7. **Qualitative Tests Buildout** — description of each of the six qual tests.
8. **Quantitative Tests Buildout** — per-RF quant results table (Overview).
   Detailed pipeline stages now live in dedicated pages:
    - 2.1 RPO Data Platform — schema, observables, raw RPO samples
    - 2.2 RPO Bucketing Logic — observation-to-bucket assignment
    - 2.3 RPO Aggregation — per-(RF, bucket) totals
    - 2.4 RPO to RF Mapping and Translation Engine — the four mapping approaches
    - 2.5 Counting Engine — threshold check vs Basel §215
9. **IMA RF Readiness and Remediation** — kanban backlog + paths.
10. **About / Data model** — this page.

#### Data model — `risk_factors` v2 schema

| Column | Meaning |
|---|---|
| `rf_id`, `rf_name`, `asset_class`, `product`, `currency`, `tenor` | Identification |
| `source_system`, `pricing_mdo`, `risk_rf` | Upstream lineage |
| `rfet_ready` | Gate before testing (`yes` / `no`) |
| `RF_to_LH` | FRTB liquidity horizon: 10d / 20d / 40d / 60d / 120d |
| `rfet_classification` | Modellable / Type A NMRF / Type B NMRF |
| `qualititave_res`, `Quantititave_res` | Precomputed pass/fail results |
| `rpo_count`, `rpo_threshold` | Quant test (threshold = 24 if LH ≤ 20d else 16) |
| `qual1_capture_idio` … `qual6_proxy_fit` | Six qualitative tests |
| `rf_to_rpo_category`, `rf_to_rpo_lineage` | Mapping into the RPO pipeline |
| `target_date`, `evidence_status`, `remediation_status`, `remediation_path`, `notes` | Workflow |
| `capital_impact` *(derived in-app)* | High = Type B, Low = Type A, **TBD** = Modellable |

#### Colour key
- 🟢 **pass / Modellable / Complete / yes**
- 🟡 **warn / Type A NMRF / Low / Partial / In Progress / Open**
- 🔴 **fail / Type B NMRF / High / Missing**
- ⚪ **TBD / Not Required / Deferred / Defer to SA**
""")


# ===========================================================================
# NAVIGATION  (st.navigation with grouped, collapsible sections)
# ===========================================================================
# Thin wrappers so st.Page can call each existing page renderer with the
# loaded data. They must be module-level (not nested inside main) so
# st.navigation derives a unique URL slug from each function name.
def _run_exec():       page_exec(get_data())
def _run_scope():      page_scope(get_data())
def _run_lineage():    page_lineage(get_data())
def _run_lh():         page_ready(get_data())
def _run_lh_assigned(): page_lh_assigned_es_ses(get_data())
def _run_engine():     page_engine(get_data())
def _run_cls():        page_classification_summary(get_data())
def _run_qual():       page_qual_buildout(get_data())
def _run_quant():      page_quant_buildout(get_data())
def _run_rpo_platform():  page_rpo_data_platform(get_data())
def _run_rpo_bucket():    page_rpo_bucketing(get_data())
def _run_rpo_agg():       page_rpo_aggregation(get_data())
def _run_rpo_mapping():   page_rpo_mapping_engine(get_data())
def _run_counting():      page_counting_engine(get_data())
def _run_remediate():  page_remediate(get_data())


def main():
    cfg = get_data()['cfg']

    # ---- Sidebar header (rendered ABOVE the nav widget) ----
    with st.sidebar:
        st.markdown('### 📊 RFET IMA')
        st.markdown(
            f'<div style="background:#B8935A;color:white;padding:6px 12px;'
            f'border-radius:6px;font-weight:700;font-size:0.9rem;text-align:center;'
            f'margin-bottom:6px;">Cycle: {cfg.get("rfet_cycle", "—")}</div>',
            unsafe_allow_html=True,
        )
        st.caption(f"As-of {cfg.get('as_of_date', '—')}")
        st.markdown('---')

    # ---- Grouped, collapsible navigation ----
    # Each top-level key becomes a collapsible section header in the sidebar.
    nav = st.navigation({
        'Executive View': [
            st.Page(_run_exec,  title='Executive Overview', default=True),
            st.Page(_run_scope, title='Desks in Scope'),
        ],
        '1. RF to Liquidity Horizon Mapping': [
            st.Page(_run_lh,          title='RF → LH Mapping'),
            st.Page(_run_lh_assigned, title='Assigned LH in ES/SES'),
        ],
        '2. Quantitative Tests Buildout': [
            st.Page(_run_quant,        title='Quantitative Tests Buildout'),
            st.Page(_run_rpo_platform, title='2.1  RPO Data Platform'),
            st.Page(_run_rpo_bucket,   title='2.2  RPO Bucketing Logic'),
            st.Page(_run_rpo_agg,      title='2.3  RPO Aggregation'),
            st.Page(_run_rpo_mapping,  title='2.4  RPO to RF Mapping and Translation Engine'),
            st.Page(_run_counting,     title='2.5  Counting Engine'),
        ],
        '3. Qualitative Tests Buildout': [
            st.Page(_run_qual, title='Qualitative Tests Buildout'),
        ],
        '4. RFET Classification Buildout': [
            st.Page(_run_cls,    title='RFET Classification Summary'),
            st.Page(_run_engine, title='RFET Tests Details'),
        ],
        '5. Other IMA RF Tech Req': [
            st.Page(_run_lineage,   title='MDO → RF Lineage'),
            st.Page(_run_remediate, title='IMA RF Readiness and Remediation'),
        ],
    })

    # ---- Sidebar footer (rendered BELOW the nav widget) ----
    with st.sidebar:
        st.markdown('---')
        # Data file + last-modified captions commented out per request.
        # st.caption(f"**Data file:** `{DATA_FILE.name}`")
        # mtime = _file_mtime(DATA_FILE)
        # if mtime:
        #     st.caption(f"**Last modified:** "
        #               f"{pd.Timestamp(mtime, unit='s').strftime('%Y-%m-%d %H:%M:%S')}")
        if st.button('🔄 Reload data', use_container_width=True):
            st.cache_data.clear()
            st.rerun()

    # Run the active page
    nav.run()


if __name__ == '__main__':
    main()
