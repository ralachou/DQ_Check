# RFET IMA Workbench — Python / Streamlit PoC

Interactive proof-of-concept for the FRTB IMA Risk Factor Eligibility Test.
All sample data lives in `rfet_data.xlsx` — edit in Excel, save, and the app
picks up the changes on refresh.

## What's in the box

| File | Purpose |
|---|---|
| `app.py` | Streamlit app — 10 interactive sections. |
| `rfet_data.xlsx` | All sample data (22 RFs, 11 AC decisions, 7 pipeline stages, 5 RF types, config). **This is what you edit.** |
| `requirements.txt` | Python dependencies. |
| `README.md` | This file. |

## Quick start

```bash
# 1) install dependencies (one time)
pip install -r requirements.txt

# 2) run the app
streamlit run app.py
```

The app opens at http://localhost:8501 in your default browser.

## Editing data

1. Open `rfet_data.xlsx` in Excel.
2. Edit any cell — add a new risk factor row, change a classification, bump a
   threshold in the `config` sheet, etc.
3. Save the file (`Ctrl/Cmd+S`).
4. Switch back to the browser and either:
   - Click the **🔄 Reload data** button in the sidebar, OR
   - Refresh the page.

The app uses file-mtime-based caching, so any save invalidates the cache
automatically.

### Sheets

| Sheet | Rows | What it drives |
|---|---|---|
| `readme` | — | In-workbook usage notes. |
| `risk_factors` | 22 | The heart of the dataset — one row per RF. |
| `asset_classes` | 11 | Business-scope decisions (include / defer / exclude). |
| `pipeline_stages` | 7 | RPO pipeline funnel volumes. |
| `rf_types` | 5 | Mapping-engine logic per RF type. |
| `config` | 8 | Thresholds (RPO min, gap max, window), as-of date, cycle. |

**Do not rename sheets or header columns** — the app reads them by name.

### Valid status values

The app colour-codes any cell containing these strings:

| Value | Colour |
|---|---|
| `pass`, `Modellable`, `Include`, `Ready`, `Complete` | 🟢 green |
| `warn`, `Type A NMRF`, `Defer`, `Partial`, `In Progress`, `In Review`, `Open` | 🟡 amber |
| `fail`, `Type B NMRF`, `Not Ready`, `Missing` | 🔴 red |
| `Excluded`, `Defer to SA`, `None`, `Deferred` | ⚪ gray |

## Application sections

1. **Executive Overview** — KPI strip, flow strip, classification chart, top remediation list.
2. **Business Scope Nomination** — AC × sub-product include/defer/exclude with scoring chart.
3. **MDO → RF Lineage** — pricing MDO and risk MDO supply chain table.
4. **RF Ready for RFET** — readiness by source system + detail table.
5. **RFET Test Engine** — 6 qual tests + quant (RPO count, gap) per RF, with per-RF drill-down.
6. **RPO Pipeline** — 7-stage funnel chart + expandable stage details.
7. **Mapping Engine** — RF-type cards (single-dim, curve, surface, composed, parametric).
8. **Classification Dashboard** — heatmap (AC × classification) + capital-impact bar chart.
9. **Remediation Dashboard** — kanban board + doughnut by path + capital-at-risk chart.
10. **About / Data model** — architecture notes and demo script.

## Demo script (8 min)

1. **Executive Overview** — population shape, capital impact at a glance.
2. **Business Scope** — show why exotic equities & small-issuer munis are deferred.
3. **Lineage** — open and point at **RF-FX-004** (broken lineage → Type B).
4. **RFET Engine** — drill into **RF-IR-003** (textbook Type A: qual ✓, RPO famine post-LIBOR).
5. **RPO Pipeline** — 4.2M raw observations funnel to ~890K mapped RPOs.
6. **Mapping Engine** — note SABR β can't be a direct RPO; maps to calibration instruments.
7. **Classification** — heatmap shows the population shape; bar chart shows where capital sits.
8. **Remediation** — kanban view of the backlog with owners and target dates.

## Extending

- **New RF:** append a row to `risk_factors`. It flows through every section automatically.
- **Change thresholds:** edit `config.rpo_threshold_default` or `gap_threshold_days` — the
  quant test re-runs immediately.
- **New sub-product:** add a row to `asset_classes` — shows up in the Scope page.
- **Hook to live data:** replace `pd.read_excel(...)` in `load_data()` with a database query
  or API call; everything else stays the same.

## Notes

- The app uses Plotly for charts (interactive hover, zoom, export to PNG).
- Status pills are rendered via a small CSS layer over `df.to_html()` — no extra dependencies.
- The HTML PoC (single-file, no install) remains available as a hand-off alternative.
