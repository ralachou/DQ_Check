"""
RFET IMA Workbench — Streamlit app
Run with:  streamlit run app.py
Data lives in rfet_data.xlsx — edit in Excel, save, refresh browser.
"""
from __future__ import annotations
import os
from pathlib import Path

import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st

# ---------------------------------------------------------------------------
# Config & theme
# ---------------------------------------------------------------------------
APP_DIR = Path(__file__).parent
DATA_FILE = APP_DIR / 'rfet_data.xlsx'

st.set_page_config(
    page_title='RFET IMA Workbench',
    page_icon='📊',
    layout='wide',
    initial_sidebar_state='expanded',
)

# Colour tokens (match the HTML PoC)
COL_PASS = '#0F8F5E'
COL_WARN = '#C97A14'
COL_FAIL = '#B83C4F'
COL_MUTE = '#6B7280'
COL_NAVY = '#0B1A2E'
COL_BRASS = '#B8935A'

STATUS_COLORS = {
    'pass': COL_PASS, 'warn': COL_WARN, 'fail': COL_FAIL,
    'Modellable': COL_PASS, 'Type A NMRF': COL_WARN, 'Type B NMRF': COL_FAIL,
    'Defer to SA': COL_MUTE, 'Excluded': COL_MUTE,
    'Include': COL_PASS, 'Defer': COL_WARN, 'Exclude': COL_MUTE,
    'Ready': COL_PASS, 'Partial': COL_WARN, 'Not Ready': COL_FAIL,
    'Complete': COL_PASS, 'In Review': COL_WARN, 'Missing': COL_FAIL,
    'None': COL_MUTE, 'Open': COL_WARN, 'In Progress': COL_WARN, 'Deferred': COL_MUTE,
}

# Global CSS tweaks
st.markdown("""
<style>
    .block-container { padding-top: 1.5rem; padding-bottom: 2rem; max-width: 1400px; }
    section[data-testid="stSidebar"] { background: #F2EFE7; }
    h1, h2, h3 { font-family: 'Georgia', serif; color: #0B1A2E; }
    .pill {
        display: inline-block; padding: 2px 10px; border-radius: 999px;
        font-size: 0.78rem; font-weight: 600; letter-spacing: 0.02em;
        border: 1px solid;
    }
    .pill-pass  { color: #0F8F5E; background:#E8F5EE; border-color:#B6E0C7; }
    .pill-warn  { color: #C97A14; background:#FCEFD9; border-color:#F1D49A; }
    .pill-fail  { color: #B83C4F; background:#F8E3E7; border-color:#EFC0C9; }
    .pill-mute  { color: #6B7280; background:#F1F2F4; border-color:#D8DBE0; }
    .kpi-card {
        background: white; border:1px solid #E5E7EB; border-radius:10px;
        padding:14px 16px; box-shadow: 0 1px 2px rgba(0,0,0,0.03);
    }
    .kpi-label { font-size:0.78rem; color:#6B7280; text-transform:uppercase; letter-spacing:0.06em; }
    .kpi-value { font-size:1.65rem; font-weight:700; color:#0B1A2E; margin-top:4px; }
    .kpi-sub   { font-size:0.78rem; color:#6B7280; margin-top:2px; }
    .stage-box {
        background:white; border:1px solid #E5E7EB; border-left:4px solid #B8935A;
        padding:10px 14px; border-radius:6px; margin-bottom:8px;
    }
    .kanban-card {
        background:white; border:1px solid #E5E7EB; border-radius:6px;
        padding:10px; margin-bottom:8px; font-size:0.85rem;
    }
    .kanban-col-head { font-weight:700; color:#0B1A2E; text-transform:uppercase;
                      letter-spacing:0.06em; font-size:0.78rem; margin-bottom:8px; }
    div[data-testid="stMetricValue"] { font-size: 1.5rem; }
</style>
""", unsafe_allow_html=True)


# ---------------------------------------------------------------------------
# Data loading (with mtime-based cache invalidation)
# ---------------------------------------------------------------------------
def _file_mtime(p: Path) -> float:
    return p.stat().st_mtime if p.exists() else 0.0


@st.cache_data(show_spinner=False)
def load_data(mtime: float):
    """Return dict of dataframes. mtime in cache key forces reload on file change."""
    sheets = pd.read_excel(DATA_FILE, sheet_name=None)
    cfg = sheets.get('config')
    if cfg is not None:
        cfg = dict(zip(cfg['key'], cfg['value']))
    return {
        'rf': sheets['risk_factors'],
        'ac': sheets['asset_classes'],
        'pipe': sheets['pipeline_stages'],
        'types': sheets['rf_types'],
        'cfg': cfg or {},
    }


def get_data():
    if not DATA_FILE.exists():
        st.error(f"Data file not found: {DATA_FILE}")
        st.stop()
    return load_data(_file_mtime(DATA_FILE))


# ---------------------------------------------------------------------------
# Small helpers
# ---------------------------------------------------------------------------
def pill(value: str) -> str:
    """Return an HTML pill span for a status value."""
    if value is None or (isinstance(value, float) and pd.isna(value)):
        return '<span class="pill pill-mute">—</span>'
    v = str(value)
    cls = 'pill-mute'
    if v.lower() in ('pass',) or v in ('Modellable', 'Include', 'Ready', 'Complete'):
        cls = 'pill-pass'
    elif v.lower() in ('warn',) or v in ('Type A NMRF', 'Defer', 'Partial', 'In Review',
                                         'In Progress', 'Open'):
        cls = 'pill-warn'
    elif v.lower() in ('fail',) or v in ('Type B NMRF', 'Not Ready', 'Missing'):
        cls = 'pill-fail'
    return f'<span class="pill {cls}">{v}</span>'


def kpi(label: str, value, sub: str = ''):
    st.markdown(
        f'<div class="kpi-card"><div class="kpi-label">{label}</div>'
        f'<div class="kpi-value">{value}</div>'
        f'<div class="kpi-sub">{sub}</div></div>',
        unsafe_allow_html=True,
    )


def render_df_with_pills(df: pd.DataFrame, pill_cols: list[str]):
    """Render a dataframe with HTML pills in specified columns."""
    disp = df.copy()
    for c in pill_cols:
        if c in disp.columns:
            disp[c] = disp[c].apply(pill)
    html = disp.to_html(escape=False, index=False,
                       classes='dataframe', border=0)
    st.markdown(
        '<style>'
        '.dataframe { font-size: 0.85rem; border-collapse: collapse; width: 100%; }'
        '.dataframe th { background: #0B1A2E; color: white; padding: 8px 10px; text-align: left;'
        '  font-weight: 600; letter-spacing: 0.02em; }'
        '.dataframe td { padding: 6px 10px; border-bottom: 1px solid #E5E7EB; }'
        '.dataframe tr:hover td { background: #FAF7EF; }'
        '</style>' + html,
        unsafe_allow_html=True,
    )


def asset_class_filter(df: pd.DataFrame, key: str = 'ac_filter') -> pd.DataFrame:
    """Sidebar AC filter, returns filtered df."""
    classes = sorted(df['asset_class'].unique())
    chosen = st.sidebar.multiselect(
        'Asset class filter', classes, default=classes, key=key,
    )
    return df[df['asset_class'].isin(chosen)] if chosen else df


# ===========================================================================
# PAGES
# ===========================================================================
def page_exec(data):
    rf = data['rf']
    cfg = data['cfg']
    st.title('Executive Overview')
    st.caption(f"Cycle {cfg.get('rfet_cycle', '—')}   ·   As-of {cfg.get('as_of_date', '—')}   ·   "
               f"{len(rf)} risk factors in scope")

    # KPI strip
    n_total = len(rf)
    n_mod = (rf['classification'] == 'Modellable').sum()
    n_a = (rf['classification'] == 'Type A NMRF').sum()
    n_b = (rf['classification'] == 'Type B NMRF').sum()
    n_sa = (rf['classification'] == 'Defer to SA').sum()
    cap = rf['capital_impact_usd_m'].sum()
    backlog = (rf['remediation_status'].isin(['Open', 'In Progress'])).sum()

    cols = st.columns(6)
    with cols[0]: kpi('Total RFs', n_total, 'in current scope')
    with cols[1]: kpi('Modellable', n_mod, f'{n_mod/n_total:.0%} of population')
    with cols[2]: kpi('Type A NMRF', n_a, 'qual ✓, RPO famine')
    with cols[3]: kpi('Type B NMRF', n_b, 'qual gaps or broken lineage')
    with cols[4]: kpi('Capital impact', f'${cap:.1f}M', 'NMRF add-on est.')
    with cols[5]: kpi('Backlog', backlog, 'open + in-progress')

    st.markdown('---')

    # Flow strip (8 stages)
    st.subheader('End-to-end RFET flow')
    stages = ['Business Scope', 'RF Identification', 'RF Ready for RFET',
              'Qualitative Test', 'Quantitative Test', 'Classification',
              'Remediation', 'Capital Output']
    flow_cols = st.columns(len(stages))
    for c, s in zip(flow_cols, stages):
        with c:
            st.markdown(
                f'<div style="background:#0B1A2E;color:white;padding:10px 8px;'
                f'border-radius:6px;text-align:center;font-size:0.78rem;'
                f'font-weight:600;">{s}</div>',
                unsafe_allow_html=True,
            )

    st.markdown('---')

    # Classification by asset class
    left, right = st.columns([3, 2])
    with left:
        st.subheader('Classification by asset class')
        cross = (rf.groupby(['asset_class', 'classification']).size()
                 .reset_index(name='count'))
        fig = px.bar(cross, x='asset_class', y='count', color='classification',
                    color_discrete_map=STATUS_COLORS,
                    category_orders={'classification':
                                     ['Modellable', 'Type A NMRF', 'Type B NMRF', 'Defer to SA']})
        fig.update_layout(barmode='stack', height=380, margin=dict(t=20, b=10),
                         plot_bgcolor='white', legend_title='')
        st.plotly_chart(fig, use_container_width=True)

    with right:
        st.subheader('Top remediation items')
        top = (rf[rf['classification'].isin(['Type A NMRF', 'Type B NMRF'])]
               .nlargest(6, 'capital_impact_usd_m')
               [['rf_id', 'rf_name', 'classification', 'capital_impact_usd_m']])
        top.columns = ['ID', 'Name', 'Classification', 'Capital ($M)']
        render_df_with_pills(top, ['Classification'])


def page_scope(data):
    ac = data['ac']
    st.title('Business Scope Nomination')
    st.caption('Asset class × sub-product decisions: include / defer / exclude. '
              'Edit `asset_classes` sheet to change.')

    # Scoring chart
    fig = go.Figure()
    fig.add_trace(go.Bar(
        x=ac['sub_product'], y=ac['capital_impact_score'], name='Capital impact',
        marker_color=COL_NAVY,
    ))
    fig.add_trace(go.Bar(
        x=ac['sub_product'], y=ac['model_pass_probability_pct']/10, name='Model pass prob (÷10)',
        marker_color=COL_BRASS,
    ))
    fig.add_trace(go.Bar(
        x=ac['sub_product'], y=ac['cost_benefit_score'], name='Cost-benefit',
        marker_color=COL_PASS,
    ))
    fig.update_layout(barmode='group', height=380, plot_bgcolor='white',
                     margin=dict(t=20, b=80), xaxis_tickangle=-30)
    st.plotly_chart(fig, use_container_width=True)

    st.subheader('Decision table')
    render_df_with_pills(ac, ['decision', 'bt_pla_readiness'])


def page_lineage(data):
    rf = data['rf']
    st.title('MDO → Risk Factor Lineage')
    st.caption('Pricing MDO and Risk MDO supply chain per risk factor.')
    rf_f = asset_class_filter(rf)

    cols = ['rf_id', 'rf_name', 'asset_class', 'source_system',
            'pricing_mdo', 'risk_mdo', 'lineage_status', 'data_quality',
            'rfet_ready']
    disp = rf_f[cols].copy()
    disp.columns = ['ID', 'Name', 'AC', 'Source', 'Pricing MDO',
                   'Risk MDO', 'Lineage', 'DQ', 'RFET Ready']
    disp['Pricing MDO'] = disp['Pricing MDO'].fillna('— missing —')
    render_df_with_pills(disp, ['Lineage', 'DQ', 'RFET Ready'])


def page_ready(data):
    rf = data['rf']
    st.title('RF Ready for RFET')
    st.caption('Combined view of source path × readiness state.')

    # Source path summary
    by_src = rf.groupby('source_system').agg(
        total=('rf_id', 'count'),
        ready=('rfet_ready', lambda s: (s == 'pass').sum()),
        partial=('rfet_ready', lambda s: (s == 'warn').sum()),
        blocked=('rfet_ready', lambda s: (s == 'fail').sum()),
    ).reset_index()
    by_src.columns = ['Source', 'Total RFs', 'Ready', 'Partial', 'Blocked']
    st.subheader('Readiness by source system')
    render_df_with_pills(by_src, [])

    st.markdown('---')
    st.subheader('Readiness detail')
    rf_f = asset_class_filter(rf)
    cols = ['rf_id', 'rf_name', 'source_system', 'lineage_status',
            'data_quality', 'rfet_ready', 'evidence_status']
    disp = rf_f[cols].copy()
    disp.columns = ['ID', 'Name', 'Source', 'Lineage', 'DQ', 'RFET Ready', 'Evidence']
    render_df_with_pills(disp, ['Lineage', 'DQ', 'RFET Ready', 'Evidence'])


def page_engine(data):
    rf = data['rf']
    cfg = data['cfg']
    st.title('RFET Test Engine')
    st.caption(f"Qualitative (6 tests) + Quantitative (RPO ≥ {cfg.get('rpo_threshold_default', 100)} "
              f"and gap ≤ {cfg.get('gap_threshold_days', 30)}d).")
    rf_f = asset_class_filter(rf)

    # Tabbed view: side-by-side qual / quant
    cols = ['rf_id', 'rf_name', 'asset_class',
            'qual_lineage', 'qual_repres', 'qual_idio',
            'qual_proxy', 'qual_decomp', 'qual_gov',
            'rpo_count', 'max_gap_days', 'classification']
    disp = rf_f[cols].copy()
    disp.columns = ['ID', 'Name', 'AC',
                   'Lineage', 'Repres', 'Idio',
                   'Proxy', 'Decomp', 'Gov',
                   'RPOs', 'Max gap (d)', 'Classification']
    render_df_with_pills(disp, ['Lineage', 'Repres', 'Idio', 'Proxy', 'Decomp', 'Gov',
                               'Classification'])

    st.markdown('---')
    st.subheader('Drill into a single risk factor')
    rfid = st.selectbox('Choose an RF', rf_f['rf_id'].tolist())
    row = rf_f[rf_f['rf_id'] == rfid].iloc[0]
    render_rf_drilldown(row, cfg)


def render_rf_drilldown(row, cfg):
    """Detailed per-RF panel."""
    c1, c2, c3 = st.columns([2, 1, 1])
    with c1:
        st.markdown(f"### {row['rf_id']} — {row['rf_name']}")
        st.caption(f"{row['asset_class']} · {row['product']} · {row['currency']} · {row['tenor']}")
    with c2:
        kpi('Classification', row['classification'])
    with c3:
        kpi('Capital impact', f"${row['capital_impact_usd_m']:.1f}M")

    st.markdown('#### Qualitative tests')
    q_cols = st.columns(6)
    for c, (name, key) in zip(q_cols, [
        ('Lineage', 'qual_lineage'), ('Repres.', 'qual_repres'),
        ('Idiosync.', 'qual_idio'), ('Proxy', 'qual_proxy'),
        ('Decomp', 'qual_decomp'), ('Governance', 'qual_gov'),
    ]):
        with c:
            st.markdown(
                f'<div class="kpi-card"><div class="kpi-label">{name}</div>'
                f'<div style="margin-top:6px;">{pill(row[key])}</div></div>',
                unsafe_allow_html=True,
            )

    st.markdown('#### Quantitative test')
    q1, q2, q3, q4 = st.columns(4)
    rpo_thr = int(cfg.get('rpo_threshold_default', 100))
    gap_thr = int(cfg.get('gap_threshold_days', 30))
    rpo_pass = row['rpo_count'] >= rpo_thr
    gap_pass = row['max_gap_days'] <= gap_thr
    with q1: kpi('RPO count', int(row['rpo_count']), f"threshold {rpo_thr}")
    with q2: kpi('Max gap (d)', int(row['max_gap_days']), f"threshold {gap_thr}")
    with q3: kpi('RPO test', '✓ Pass' if rpo_pass else '✗ Fail')
    with q4: kpi('Gap test', '✓ Pass' if gap_pass else '✗ Fail')

    st.markdown('#### Remediation')
    r1, r2, r3 = st.columns(3)
    with r1: kpi('Owner', row['owner'])
    with r2: kpi('Target', row['target_date'])
    with r3: kpi('Path', row['remediation_path'])
    if pd.notna(row['notes']):
        st.info(f"**Note:** {row['notes']}")


def page_pipeline(data):
    pipe = data['pipe']
    st.title('RPO Pipeline')
    st.caption('7-stage transformation: raw observations → RFET-ready RPO counts.')

    # Funnel chart
    fig = go.Figure(go.Funnel(
        y=pipe['name'],
        x=pipe['output_volume'],
        textinfo='value+percent initial',
        marker={'color': [COL_NAVY] * len(pipe)},
    ))
    fig.update_layout(height=420, margin=dict(t=20, b=20))
    st.plotly_chart(fig, use_container_width=True)

    st.markdown('---')
    st.subheader('Stage detail')
    for _, s in pipe.iterrows():
        with st.expander(f"Stage {s['stage']} — {s['name']} "
                        f"({s['input_volume']:,} → {s['output_volume']:,}, "
                        f"drop {s['drop_pct']:.1f}%)"):
            st.markdown(f"**Description:** {s['description']}")
            c1, c2, c3 = st.columns(3)
            with c1: kpi('Owner', s['owner'])
            with c2: kpi('Input', f"{s['input_volume']:,}")
            with c3: kpi('Output', f"{s['output_volume']:,}")
            st.markdown(f"**Inputs:** {s['inputs']}")
            st.markdown(f"**Outputs:** {s['outputs']}")


def page_mapping(data):
    types = data['types']
    st.title('RPO → RF Mapping Engine')
    st.caption('How observations get attached to each risk factor type.')

    for _, t in types.iterrows():
        with st.container():
            st.markdown(f'<div class="stage-box">'
                       f'<h4 style="margin:0;color:#0B1A2E;">{t["rf_type"]}</h4>'
                       f'<p style="color:#6B7280;margin:4px 0 8px 0;font-size:0.88rem;">'
                       f'{t["description"]}</p>'
                       f'<div style="font-size:0.9rem;"><b>Mapping logic:</b> {t["mapping_logic"]}</div>'
                       f'<div style="font-size:0.9rem;margin-top:6px;color:#52647A;">'
                       f'<b>Example:</b> {t["worked_example"]}</div>'
                       f'</div>',
                       unsafe_allow_html=True)


def page_classify(data):
    rf = data['rf']
    st.title('Classification Dashboard')
    st.caption('Final RFET outcomes and capital impact.')

    # Heatmap: asset class × classification
    pivot = (rf.groupby(['asset_class', 'classification']).size()
             .unstack(fill_value=0))
    # ensure column order
    for c in ['Modellable', 'Type A NMRF', 'Type B NMRF', 'Defer to SA']:
        if c not in pivot.columns:
            pivot[c] = 0
    pivot = pivot[['Modellable', 'Type A NMRF', 'Type B NMRF', 'Defer to SA']]

    fig = px.imshow(
        pivot.values, x=pivot.columns, y=pivot.index,
        color_continuous_scale='Blues', text_auto=True, aspect='auto',
    )
    fig.update_layout(height=320, margin=dict(t=20, b=20),
                     coloraxis_colorbar={'title': 'Count'})
    st.subheader('Heatmap: asset class × classification')
    st.plotly_chart(fig, use_container_width=True)

    st.markdown('---')

    # Capital impact bar
    cap_df = (rf[rf['capital_impact_usd_m'] > 0]
              .sort_values('capital_impact_usd_m', ascending=True))
    fig2 = px.bar(
        cap_df, x='capital_impact_usd_m', y='rf_id', orientation='h',
        color='classification', color_discrete_map=STATUS_COLORS,
        hover_data=['rf_name'],
    )
    fig2.update_layout(height=420, plot_bgcolor='white',
                      margin=dict(t=20, b=10), xaxis_title='Capital impact ($M)',
                      yaxis_title='', legend_title='')
    st.subheader('Capital impact by RF')
    st.plotly_chart(fig2, use_container_width=True)

    st.markdown('---')
    st.subheader('Full classification table')
    rf_f = asset_class_filter(rf, key='cls_filter')
    cols = ['rf_id', 'rf_name', 'asset_class', 'classification', 'rf_type',
            'rpo_count', 'capital_impact_usd_m', 'owner', 'target_date']
    disp = rf_f[cols].copy()
    disp.columns = ['ID', 'Name', 'AC', 'Classification', 'RF type',
                   'RPOs', 'Capital ($M)', 'Owner', 'Target']
    render_df_with_pills(disp, ['Classification'])


def page_remediate(data):
    rf = data['rf']
    st.title('Remediation Dashboard')
    st.caption('Backlog of NMRFs with paths back to modellable (or to SA).')

    rem = rf[rf['classification'].isin(['Type A NMRF', 'Type B NMRF', 'Defer to SA'])].copy()

    # Doughnut: by remediation path
    c1, c2 = st.columns([1, 1])
    with c1:
        st.subheader('Remediation paths')
        path_counts = rem['remediation_path'].fillna('Unspecified').value_counts().reset_index()
        path_counts.columns = ['Path', 'Count']
        fig = px.pie(path_counts, values='Count', names='Path', hole=0.55)
        fig.update_layout(height=340, margin=dict(t=20, b=20))
        st.plotly_chart(fig, use_container_width=True)

    with c2:
        st.subheader('Capital at risk by classification')
        cap_by_cls = (rem.groupby('classification')['capital_impact_usd_m'].sum()
                     .reset_index())
        fig2 = px.bar(cap_by_cls, x='classification', y='capital_impact_usd_m',
                     color='classification', color_discrete_map=STATUS_COLORS)
        fig2.update_layout(height=340, plot_bgcolor='white', showlegend=False,
                          margin=dict(t=20, b=10),
                          yaxis_title='Capital ($M)', xaxis_title='')
        st.plotly_chart(fig2, use_container_width=True)

    st.markdown('---')
    st.subheader('Kanban — by remediation status')
    statuses = ['Open', 'In Progress', 'Deferred', 'None']
    kan_cols = st.columns(len(statuses))
    for c, status in zip(kan_cols, statuses):
        items = rem[rem['remediation_status'] == status]
        with c:
            st.markdown(f'<div class="kanban-col-head">{status} '
                       f'({len(items)})</div>', unsafe_allow_html=True)
            for _, r in items.iterrows():
                st.markdown(
                    f'<div class="kanban-card">'
                    f'<b>{r["rf_id"]}</b><br>'
                    f'<span style="color:#6B7280;font-size:0.78rem;">'
                    f'{r["rf_name"][:40]}</span><br>'
                    f'<div style="margin-top:6px;">{pill(r["classification"])}</div>'
                    f'<div style="color:#6B7280;font-size:0.78rem;margin-top:4px;">'
                    f'${r["capital_impact_usd_m"]:.1f}M · {r["owner"]}</div>'
                    f'</div>',
                    unsafe_allow_html=True,
                )

    st.markdown('---')
    st.subheader('Remediation table')
    cols = ['rf_id', 'rf_name', 'classification', 'remediation_status',
            'remediation_path', 'owner', 'target_date', 'capital_impact_usd_m']
    disp = rem[cols].copy()
    disp.columns = ['ID', 'Name', 'Classification', 'Status', 'Path',
                   'Owner', 'Target', 'Capital ($M)']
    render_df_with_pills(disp, ['Classification', 'Status'])


def page_about(data):
    st.title('About this PoC')
    st.markdown("""
**RFET IMA Workbench** — interactive proof-of-concept for the Risk Factor
Eligibility Test under FRTB Internal Models Approach.

#### Architecture
- **Frontend:** Streamlit (pure Python).
- **Data:** all sample data lives in `rfet_data.xlsx` — edit in Excel, save,
  refresh the browser, and the app picks up the changes (mtime-based cache).
- **Charts:** Plotly (interactive hover, zoom, export).
- **Tables:** HTML render with status pills matching the colour key.

#### Data model (sheets in `rfet_data.xlsx`)
| Sheet | Rows | Purpose |
|---|---|---|
| `risk_factors` | 22 | One row per RF — the heart of the dataset. |
| `asset_classes` | 11 | Business-scope decisions per AC × sub-product. |
| `pipeline_stages` | 7 | RPO pipeline funnel with input/output volumes. |
| `rf_types` | 5 | Mapping-engine logic per RF type. |
| `config` | 8 | Thresholds and metadata. |

#### Colour key
- 🟢 **pass / Modellable / Include / Ready**
- 🟡 **warn / Type A NMRF / Defer / Partial / In Progress**
- 🔴 **fail / Type B NMRF / Not Ready / Missing**
- ⚪ **Excluded / Defer to SA / None**

#### Demo script (8 min)
1. **Executive Overview** — KPIs and population shape.
2. **Business Scope** — include/defer/exclude scoring.
3. **Lineage** — show RF-FX-004 (broken lineage → Type B).
4. **RFET Engine** — drill into **RF-IR-003** (textbook Type A: qual ✓, RPO famine).
5. **RPO Pipeline** — 4.2M raw obs funnel to ~890K mapped RPOs.
6. **Mapping Engine** — note that SABR β isn't a direct RPO.
7. **Classification** — heatmap + capital impact.
8. **Remediation** — kanban + paths.

#### Extending
- Add a row to `risk_factors` → it appears in every section.
- Change `rpo_threshold_default` in `config` → re-runs the quant test.
- Add a new sub-product to `asset_classes` → shows up in Scope.
""")


# ===========================================================================
# SIDEBAR + ROUTER
# ===========================================================================
PAGES = {
    'Executive Overview': page_exec,
    'Business Scope': page_scope,
    'MDO → RF Lineage': page_lineage,
    'RF Ready for RFET': page_ready,
    'RFET Test Engine': page_engine,
    'RPO Pipeline': page_pipeline,
    'Mapping Engine': page_mapping,
    'Classification': page_classify,
    'Remediation': page_remediate,
    'About / Data model': page_about,
}


def main():
    data = get_data()
    cfg = data['cfg']

    with st.sidebar:
        st.markdown(f"### 📊 RFET IMA")
        st.caption(f"Cycle {cfg.get('rfet_cycle', '—')}")
        st.caption(f"As-of {cfg.get('as_of_date', '—')}")
        page = st.radio('Navigation', list(PAGES.keys()), label_visibility='collapsed')

        st.markdown('---')
        st.caption(f"**Data file:** `{DATA_FILE.name}`")
        mtime = _file_mtime(DATA_FILE)
        if mtime:
            st.caption(f"**Last modified:** "
                      f"{pd.Timestamp(mtime, unit='s').strftime('%Y-%m-%d %H:%M:%S')}")
        if st.button('🔄 Reload data', use_container_width=True):
            st.cache_data.clear()
            st.rerun()

        st.markdown('---')
        st.caption("Edit `rfet_data.xlsx` in Excel and save, "
                  "then click Reload (or refresh the browser).")

    PAGES[page](data)


if __name__ == '__main__':
    main()
