from __future__ import annotations

import argparse
import json
from datetime import datetime
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

from common.schemas import config_hash, load_yaml
from common.taxonomy import (
    TAXONOMY_COLUMNS,
    TAXONOMY_PEER_KEYS,
    apply_peer_grouping,
    normalize_taxonomy_frame,
    resolve_peer_group_config,
)
from data.synthetic import write_demo_datasets
from data_access.parquet_repository import ParquetTimeSeriesRepository
from dq_checks.feature_builder import FeatureBuilder
from dq_checks.registry import ModelRegistry, ModelSpec
from normalization.normalizer import normalize_results
from triage.false_alarm import FalseAlarmReducer
from universe.builder import UniverseBuilder
from universe.definitions import UniverseDefinition

PROJECT_ROOT = Path(__file__).resolve().parents[2]


def _parse_csv(raw: str | None) -> list[str]:
    if not raw:
        return []
    return [x.strip() for x in raw.split(",") if x.strip()]


def _apply_analysis_field(series: pd.DataFrame, requested_field: str) -> tuple[pd.DataFrame, str]:
    field = str(requested_field or "value").strip()
    if field and field in series.columns:
        selected = field
    elif field == "shift" and "value" in series.columns:
        selected = "value"
        print("Warning: analysis field 'shift' not found. Falling back to 'value'.")
    elif "value" in series.columns:
        selected = "value"
        print(f"Warning: analysis field '{field}' not found. Falling back to 'value'.")
    else:
        raise ValueError(
            f"Requested analysis field '{field}' not found, and fallback 'value' is unavailable. "
            f"Available columns: {list(series.columns)}"
        )

    out = series.copy()
    out["value"] = pd.to_numeric(out[selected], errors="coerce")
    out = out.dropna(subset=["value", "date"]).reset_index(drop=True)
    if out.empty:
        raise ValueError(f"No numeric rows available after applying analysis field '{selected}'.")
    return out, selected


def _write_demo_output(df: pd.DataFrame, output_root: Path, name: str, output_format: str) -> list[str]:
    output_root.mkdir(parents=True, exist_ok=True)
    out: list[str] = []
    write_df = df.copy()
    # Parquet can fail on object columns containing nested dict/list/empty structs.
    for col in write_df.columns:
        if pd.api.types.is_object_dtype(write_df[col]):
            if write_df[col].map(lambda v: isinstance(v, (dict, list, tuple, set))).any():
                write_df[col] = write_df[col].map(lambda v: json.dumps(v, default=str) if isinstance(v, (dict, list, tuple, set)) else v)
    if output_format in {"parquet", "both"}:
        p = output_root / f"{name}.parquet"
        write_df.to_parquet(p, index=False)
        out.append(str(p))
    if output_format in {"excel", "both"}:
        p = output_root / f"{name}.xlsx"
        try:
            write_df.to_excel(p, index=False)
        except ImportError as exc:  # pragma: no cover
            raise RuntimeError("Excel output requires openpyxl. Install with: pip install openpyxl") from exc
        out.append(str(p))
    return out


def _check_profiles(specs: list[ModelSpec], catalog: dict[str, Any]) -> dict[str, dict[str, Any]]:
    profiles = catalog.get("normalization", {}).get("profiles", {})
    defaults = catalog.get("normalization", {}).get("defaults", {})
    global_severity = catalog.get("globals", {}).get("default_severity_thresholds", {})
    out: dict[str, dict[str, Any]] = {}
    for spec in specs:
        profile_cfg = profiles.get(spec.normalization_profile, {})
        strategy = profile_cfg.get("strategy", defaults.get("strategy", "ecdf"))
        out[spec.id] = {
            "normalization_strategy": strategy,
            "normalization_params": profile_cfg,
            "backend": spec.backend,
            "severity_mode": "fixed",
            "severity_thresholds": global_severity.get("quantile", {}),
            "fixed_thresholds": global_severity.get("fixed", {}),
            "model_version": spec.version_tag,
        }
    return out


def _build_universe_definition(catalog: dict[str, Any], universe_name: str) -> UniverseDefinition:
    uni = catalog.get("universes", {}).get(universe_name)
    if not uni:
        raise ValueError(f"Universe '{universe_name}' not found in catalog.")
    return UniverseDefinition(
        name=universe_name,
        description=str(uni.get("description", "")),
        filter_rules=uni.get("filters", {}),
    )


def _execute_per_series(check, data: pd.DataFrame, spec: ModelSpec) -> pd.DataFrame:
    parts = []
    for rf_id, series_df in data.groupby("risk_factor_id", sort=False):
        sdf = series_df.sort_values("date").reset_index(drop=True)
        state = check.fit(sdf, {"risk_factor_id": rf_id})
        scored = check.score(sdf, {"risk_factor_id": rf_id}, state)
        scored["check_id"] = spec.id
        scored["model_id"] = spec.id
        scored["backend"] = spec.backend
        scored["family"] = spec.family
        scored["fit_policy"] = spec.fit_policy
        parts.append(scored)
    return pd.concat(parts, ignore_index=True) if parts else pd.DataFrame()


def _execute_per_peer_group(
    check,
    data: pd.DataFrame,
    membership: pd.DataFrame,
    peer_group_keys: list[str],
    spec: ModelSpec,
    fb: FeatureBuilder,
) -> pd.DataFrame:
    peer_keys = [c for c in peer_group_keys if c in membership.columns]
    if not peer_keys:
        peer_keys = [c for c in TAXONOMY_PEER_KEYS if c in membership.columns]
    m = membership[["risk_factor_id"] + peer_keys]
    merged = data.merge(m, on="risk_factor_id", how="left")
    group_keys = peer_keys
    parts = []
    for _, grp in merged.groupby(group_keys, dropna=False, sort=False):
        if grp["risk_factor_id"].nunique() < 3:
            for rf_id, sdf in grp.groupby("risk_factor_id", sort=False):
                feat = fb.build_features(sdf[["risk_factor_id", "date", "value"]].copy())
                state = check.fit(feat, {"risk_factor_id": rf_id})
                scored = check.score(feat, {"risk_factor_id": rf_id}, state)
                scored["check_id"] = spec.id
                scored["model_id"] = spec.id
                scored["backend"] = spec.backend
                scored["family"] = spec.family
                scored["fit_policy"] = spec.fit_policy
                parts.append(scored)
            continue
        feat_grp = fb.build_batch(grp[["risk_factor_id", "date", "value"]], max_workers=4)
        state = check.fit(feat_grp, {"peer_group": True})
        scored = check.score(feat_grp, {"peer_group": True}, state)
        scored["check_id"] = spec.id
        scored["model_id"] = spec.id
        scored["backend"] = spec.backend
        scored["family"] = spec.family
        scored["fit_policy"] = spec.fit_policy
        parts.append(scored)
    return pd.concat(parts, ignore_index=True) if parts else pd.DataFrame()


def _execute_global(check, data: pd.DataFrame, spec: ModelSpec, fb: FeatureBuilder) -> pd.DataFrame:
    feat = fb.build_batch(data[["risk_factor_id", "date", "value"]], max_workers=4)
    state = check.fit(feat, {"global": True})
    scored = check.score(feat, {"global": True}, state)
    scored["check_id"] = spec.id
    scored["model_id"] = spec.id
    scored["backend"] = spec.backend
    scored["family"] = spec.family
    scored["fit_policy"] = spec.fit_policy
    return scored


def _preserve_raw_alert_flags(raw_results: pd.DataFrame, normalized: pd.DataFrame) -> pd.DataFrame:
    """Carry forward raw Layer 3 flag/severity into Layer 6 normalized frame."""
    if raw_results.empty or normalized.empty:
        return normalized
    keys = ["risk_factor_id", "date", "check_id"]
    if not set(keys).issubset(raw_results.columns) or not set(keys).issubset(normalized.columns):
        return normalized
    raw_flags = (
        raw_results[keys + [c for c in ["flag", "severity"] if c in raw_results.columns]]
        .drop_duplicates(subset=keys, keep="last")
        .rename(columns={"flag": "flag_raw", "severity": "severity_raw"})
    )
    out = normalized.merge(raw_flags, on=keys, how="left")
    out["flag_normalized"] = out.get("flag", False)
    out["severity_normalized"] = out.get("severity", "Low")
    if "flag_raw" in out.columns:
        out["flag"] = out["flag_raw"].fillna(out["flag"]).astype(bool)
    if "severity_raw" in out.columns:
        out["severity"] = out["severity_raw"].fillna(out["severity"]).astype(str)
    return out


def _inject_demo_labels(df: pd.DataFrame, seed: int, label_rate: float) -> pd.DataFrame:
    out = df.copy()
    rng = np.random.default_rng(seed)
    base = np.full(len(out), max(min(label_rate, 0.95), 0.01), dtype=float)
    low_med = out["severity"].isin(["Low", "Med"]).to_numpy()
    flagged = out["flag"].astype(bool).to_numpy()
    base[low_med] = np.clip(base[low_med] * 1.6, 0.01, 0.95)
    base[~flagged] = np.clip(base[~flagged] * 0.6, 0.01, 0.95)
    out["is_false_alarm"] = (rng.random(len(out)) < base).astype(int)
    if len(out) >= 2 and out["is_false_alarm"].nunique() < 2:
        out.loc[out.index[0], "is_false_alarm"] = 0
        out.loc[out.index[1], "is_false_alarm"] = 1
    return out


def _build_score_debug(df: pd.DataFrame, check_profiles: dict[str, dict[str, Any]], sample_per_check: int = 300) -> pd.DataFrame:
    if df.empty:
        return pd.DataFrame()
    cols = [
        "risk_factor_id",
        "date",
        "check_id",
        "family",
        "raw_score",
        "norm_score",
        "threshold",
        "flag",
        "severity",
        "severity_score_100",
    ]
    keep = [c for c in cols if c in df.columns]
    w = df[keep].copy()
    parts: list[pd.DataFrame] = []
    for check_id, part in w.groupby("check_id", sort=False):
        p = part.sort_values("norm_score", ascending=False).head(sample_per_check).copy()
        fixed = (check_profiles.get(str(check_id), {}) or {}).get("fixed_thresholds", {}) or {}
        med = float(fixed.get("med", 0.92))
        high = float(fixed.get("high", 0.975))
        critical = float(fixed.get("critical", 0.995))
        n = pd.to_numeric(p.get("norm_score"), errors="coerce").fillna(0.0)
        p["recomputed_flag"] = n >= med
        p["recomputed_severity"] = "Low"
        p.loc[n >= med, "recomputed_severity"] = "Med"
        p.loc[n >= high, "recomputed_severity"] = "High"
        p.loc[n >= critical, "recomputed_severity"] = "Critical"
        p["recomputed_severity_score_100"] = (n * 100.0).clip(0.0, 100.0).round(4)
        p["flag_match"] = p["recomputed_flag"].astype(bool) == p.get("flag", False).astype(bool)
        p["severity_match"] = p["recomputed_severity"].astype(str) == p.get("severity", "Low").astype(str)
        p["score_delta"] = (
            pd.to_numeric(p.get("severity_score_100"), errors="coerce").fillna(0.0)
            - pd.to_numeric(p["recomputed_severity_score_100"], errors="coerce").fillna(0.0)
        ).round(6)
        parts.append(p)
    return pd.concat(parts, ignore_index=True) if parts else pd.DataFrame()


def _as_df(records: Any) -> pd.DataFrame:
    if isinstance(records, pd.DataFrame):
        return records.copy()
    if isinstance(records, list):
        return pd.DataFrame(records)
    return pd.DataFrame()


def _importance_psi(previous: pd.DataFrame, current: pd.DataFrame, eps: float = 1.0e-12) -> tuple[float, pd.DataFrame]:
    if previous.empty or current.empty or "feature" not in previous.columns or "feature" not in current.columns:
        return float("nan"), pd.DataFrame()
    p = previous.copy()
    c = current.copy()
    if "importance_norm" not in p.columns:
        p["importance_norm"] = pd.to_numeric(p.get("importance"), errors="coerce").fillna(0.0)
        p["importance_norm"] = p["importance_norm"] / (p["importance_norm"].sum() + eps)
    if "importance_norm" not in c.columns:
        c["importance_norm"] = pd.to_numeric(c.get("importance"), errors="coerce").fillna(0.0)
        c["importance_norm"] = c["importance_norm"] / (c["importance_norm"].sum() + eps)
    m = p[["feature", "importance_norm"]].rename(columns={"importance_norm": "prev"}).merge(
        c[["feature", "importance_norm"]].rename(columns={"importance_norm": "curr"}),
        on="feature",
        how="outer",
    )
    m[["prev", "curr"]] = m[["prev", "curr"]].fillna(0.0)
    m["psi_component"] = (m["curr"] - m["prev"]) * np.log((m["curr"] + eps) / (m["prev"] + eps))
    m["abs_delta"] = (m["curr"] - m["prev"]).abs()
    psi_total = float(m["psi_component"].sum())
    return psi_total, m.sort_values("abs_delta", ascending=False).reset_index(drop=True)


def _latest_previous_global_importance(
    processed_path: Path,
    business_date: str,
    universe_name: str,
) -> pd.DataFrame:
    base = processed_path / "layer6_false_alarm_demo" / f"business_date={business_date}" / f"universe_name={universe_name}"
    if not base.exists():
        return pd.DataFrame()
    run_dirs = sorted([p for p in base.iterdir() if p.is_dir() and p.name.startswith("run_id=")])
    for d in reversed(run_dirs):
        fp = d / "feature_importance_global.parquet"
        if fp.exists():
            try:
                return pd.read_parquet(fp)
            except Exception:
                continue
    return pd.DataFrame()


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run Advanced DQ Checks on RF Layer 6 false-alarm demo.")
    parser.add_argument("--universe-name", default="MARS_SUBSET ")
    parser.add_argument("--config-path", default=str(PROJECT_ROOT / "configs" / "model_catalog.yaml"))
    parser.add_argument("--start-date", default="2019-01-02")
    parser.add_argument("--end-date", default="2020-12-31")
    parser.add_argument("--business-date", default="2026-02-27")
    parser.add_argument("--raw-path", default=str(PROJECT_ROOT / "data" / "raw"))
    parser.add_argument("--processed-path", default=str(PROJECT_ROOT / "data" / "processed"))
    parser.add_argument("--artifact-root", default=str(PROJECT_ROOT / "data" / "artifacts" / "normalization"))
    parser.add_argument("--num-factors", type=int, default=300)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--snapshot-days", type=int, default=2)
    parser.add_argument("--max-series", type=int, default=0, help="Limit number of risk factors for demo runtime.")
    parser.add_argument(
        "--analysis-field",
        default="shift",
        help="Numeric column used as analysis value (e.g., shift, value, close_value).",
    )
    parser.add_argument("--check-ids", default="", help="Comma-separated check IDs to run. Empty = all enabled checks.")
    parser.add_argument("--max-checks", type=int, default=0, help="If >0, run only first N checks after filtering.")
    parser.add_argument(
        "--with-supervised",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="Enable supervised triage mode (demo labels required).",
    )
    parser.add_argument(
        "--generate-demo-labels",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="Generate synthetic is_false_alarm labels for supervised demo mode.",
    )
    parser.add_argument("--label-rate", type=float, default=0.15, help="Base false alarm label rate for demo label generation.")
    parser.add_argument(
        "--supervised-candidates",
        default="xgboost",
        help="Comma-separated supervised model priority list (e.g., xgboost,lightgbm,random_forest,logistic_regression).",
    )
    parser.add_argument(
        "--calibration-method",
        default="auto",
        choices=["auto", "sigmoid", "isotonic", "none"],
        help="Probability calibration for supervised triage model.",
    )
    parser.add_argument(
        "--output-format",
        default="both",
        choices=["parquet", "excel", "both"],
        help="Demo artifact output format.",
    )
    parser.add_argument(
        "--generate-demo-data",
        action=argparse.BooleanOptionalAction,
        default=False,
        help="Generate synthetic data before running Layer 6 demo.",
    )
    parser.add_argument(
        "--score-debug-sample-size",
        type=int,
        default=300,
        help="Per-check sample size for score debug output.",
    )
    parser.add_argument(
        "--write-full-results",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="Write full Layer 6 parquet outputs (triaged_full / normalized_input_full) in addition to previews.",
    )
    parser.add_argument(
        "--preserve-check-flags",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="Keep raw Layer 3 check flag/severity in Layer 6 frame for apples-to-apples flag count comparison.",
    )
    return parser.parse_args()


def run_demo_layer6_false_alarm(args: argparse.Namespace) -> dict[str, Any]:
    raw_path = Path(args.raw_path)
    processed_path = Path(args.processed_path)
    business_date = str(pd.to_datetime(args.business_date).date())
    run_id = f"layer6_demo_{datetime.now().strftime('%Y%m%d_%H%M%S_%f')}"

    if args.generate_demo_data:
        write_demo_datasets(
            raw_path=raw_path,
            processed_path=processed_path,
            start_date=args.start_date,
            end_date=args.end_date,
            num_factors=args.num_factors,
            seed=args.seed,
            snapshot_days=args.snapshot_days,
        )

    catalog = load_yaml(args.config_path)
    cfg_hash = config_hash(catalog)
    repo = ParquetTimeSeriesRepository(base_path=raw_path, write_base_path=processed_path)

    definition = _build_universe_definition(catalog, args.universe_name)
    membership = UniverseBuilder(repo).build(definition)
    if membership.empty:
        raise ValueError(f"No membership found for universe '{args.universe_name}'.")
    membership = normalize_taxonomy_frame(membership, require_risk_factor_id=True)
    peer_cfg = resolve_peer_group_config(catalog, args.universe_name, membership=membership)
    membership, peer_group_keys = apply_peer_grouping(
        membership,
        peer_keys=peer_cfg.get("keys", TAXONOMY_PEER_KEYS),
        peer_rules=peer_cfg.get("rules", []),
    )
    if args.max_series > 0:
        membership = membership.head(args.max_series).copy()
    risk_factor_ids = membership["risk_factor_id"].astype(str).tolist()

    series = repo.get_series(
        risk_factor_ids=risk_factor_ids,
        start_date=args.start_date,
        end_date=args.end_date,
        business_date=business_date,
    )
    if series.empty:
        raise ValueError("No time-series rows loaded for selected universe/date/business_date.")
    series, resolved_analysis_field = _apply_analysis_field(series, args.analysis_field)

    registry = ModelRegistry()
    specs = [s for s in registry.load_universe_specs(catalog, args.universe_name) if s.enabled]
    check_filter = set(_parse_csv(args.check_ids))
    if check_filter:
        specs = [s for s in specs if s.id in check_filter]
    if args.max_checks > 0:
        specs = specs[: args.max_checks]
    if not specs:
        raise ValueError("No checks selected for Layer 6 demo.")

    checks: dict[str, Any] = {}
    for spec in specs:
        checks[spec.id] = registry.build_from_spec(spec, checks)

    fb = FeatureBuilder()
    raw_parts = []
    for spec in specs:
        check = checks[spec.id]
        if spec.fit_policy == "global":
            out = _execute_global(check, series, spec, fb)
        elif spec.fit_policy == "per_peer_group":
            out = _execute_per_peer_group(check, series, membership, peer_group_keys, spec, fb)
        else:
            out = _execute_per_series(check, series, spec)
        out["run_id"] = run_id
        out["universe_name"] = args.universe_name
        out["business_date"] = pd.to_datetime(business_date)
        raw_parts.append(out)
    raw_results = pd.concat(raw_parts, ignore_index=True) if raw_parts else pd.DataFrame()
    if raw_results.empty:
        raise ValueError("No raw check results were produced.")
    raw_flag_count = int(raw_results["flag"].fillna(False).astype(bool).sum()) if "flag" in raw_results.columns else 0

    profiles = _check_profiles(specs, catalog)
    normalized = normalize_results(
        results_df=raw_results,
        check_profiles=profiles,
        run_id=run_id,
        config_hash=cfg_hash,
        business_date=business_date,
        artifact_root=args.artifact_root,
    )
    if bool(args.preserve_check_flags):
        normalized = _preserve_raw_alert_flags(raw_results=raw_results, normalized=normalized)
    normalized_flag_count = int(normalized["flag"].fillna(False).astype(bool).sum()) if "flag" in normalized.columns else 0
    triage_cfg = catalog.get("triage", {}) if isinstance(catalog, dict) else {}
    supervised_cfg = triage_cfg.get("supervised", {}) if isinstance(triage_cfg, dict) else {}
    target_cfg = supervised_cfg.get("target", {}) if isinstance(supervised_cfg, dict) else {}
    target_label = str(target_cfg.get("label_col", "is_false_alarm"))

    if args.with_supervised and args.generate_demo_labels:
        normalized = _inject_demo_labels(normalized, seed=args.seed, label_rate=args.label_rate)
        if target_label == "p_bad_data":
            normalized["p_bad_data"] = 1 - pd.to_numeric(normalized["is_false_alarm"], errors="coerce").fillna(0).astype(int)

    membership_cols = ["risk_factor_id"] + [
        c for c in list(TAXONOMY_COLUMNS) + list(peer_group_keys) if c in membership.columns
    ]
    legacy_candidates = triage_cfg.get("supervised_candidates", ["xgboost", "lightgbm", "random_forest", "logistic_regression"])
    cfg_candidates = supervised_cfg.get("candidates", legacy_candidates)
    configured_candidates = list(
        cfg_candidates
    )
    cli_candidates = _parse_csv(args.supervised_candidates)
    selected_candidates = cli_candidates if cli_candidates else configured_candidates
    cli_calibration = str(args.calibration_method).lower()
    if cli_calibration in {"auto", ""}:
        calibration_method = None
    else:
        calibration_method = None if cli_calibration == "none" else cli_calibration
    event_calendar = pd.DataFrame(triage_cfg.get("event_calendar", []))
    triager = FalseAlarmReducer(
        regime_windows=catalog.get("globals", {}).get("regime_windows", []),
        peer_keys=peer_group_keys,
        event_calendar=event_calendar,
        event_window_days=int(triage_cfg.get("event_window_days", 1)),
        min_peer_group_size=int(triage_cfg.get("min_peer_group_size", 5)),
        peer_confirm_ratio=float(triage_cfg.get("peer_confirm_ratio", 0.60)),
        stress_threshold_multiplier=float(triage_cfg.get("stress_threshold_multiplier", 1.5)),
        supervised_candidates=selected_candidates,
        calibration_method=calibration_method,
        supervised_config=supervised_cfg,
    )
    triaged, triage_audit = triager.run(
        alerts_df=normalized.merge(membership[membership_cols], on="risk_factor_id", how="left"),
        raw_df=series,
        membership=membership[membership_cols],
        with_supervised=bool(args.with_supervised),
        label_col=target_label,
    )
    triaged["run_id"] = run_id
    triaged["universe_name"] = args.universe_name
    triaged["business_date"] = pd.to_datetime(business_date)

    summary_by_action = (
        triaged.groupby("recommended_action", as_index=False)
        .agg(
            row_count=("date", "count"),
            mean_confidence=("confidence_estimate", "mean"),
        )
        .sort_values("row_count", ascending=False)
    )
    summary_by_regime = (
        triaged.groupby("regime_tag", as_index=False)
        .agg(
            row_count=("date", "count"),
            flagged=("flag", "sum"),
            peer_confirmed=("peer_confirmed", "sum"),
        )
        .sort_values("row_count", ascending=False)
    )
    summary_by_check = (
        triaged.groupby(["check_id", "family"], as_index=False)
        .agg(
            row_count=("date", "count"),
            flagged=("flag", "sum"),
            confirm_bad_data=("recommended_action", lambda s: int((s == "CONFIRM_BAD_DATA").sum())),
            accept_move=("recommended_action", lambda s: int((s == "ACCEPT_MOVE").sum())),
        )
        .sort_values("flagged", ascending=False)
    )
    peer_summary = pd.DataFrame(
        [
            {
                "peer_confirmed_rows": int(triaged["peer_confirmed"].sum()),
                "peer_unconfirmed_rows": int((~triaged["peer_confirmed"].astype(bool)).sum()),
                "avg_peer_confidence": float(pd.to_numeric(triaged["peer_confidence"], errors="coerce").fillna(0.0).mean()),
            }
        ]
    )
    triage_model_df = pd.DataFrame([triage_audit.get("triage_model", {})])
    feature_importance_global = _as_df(triage_audit.get("feature_importance_global", []))
    feature_importance_local = _as_df(triage_audit.get("feature_importance_local", []))
    feature_importance_summary = _as_df([triage_audit.get("feature_importance_summary", {})])
    monitoring_cfg = (((supervised_cfg.get("monitoring", {}) or {}).get("feature_importance", {}) or {}))
    drift_enabled = bool((monitoring_cfg.get("drift", {}) or {}).get("enabled", False))
    psi_threshold = float((monitoring_cfg.get("drift", {}) or {}).get("psi_threshold", 0.2))
    prev_global = _latest_previous_global_importance(processed_path, business_date=business_date, universe_name=args.universe_name) if drift_enabled else pd.DataFrame()
    psi_total, psi_components = _importance_psi(prev_global, feature_importance_global) if drift_enabled else (float("nan"), pd.DataFrame())
    feature_importance_drift = pd.DataFrame(
        [
            {
                "psi_total": psi_total,
                "psi_threshold": psi_threshold,
                "drift_alert": bool(pd.notna(psi_total) and psi_total >= psi_threshold),
                "prev_rows": int(len(prev_global)),
                "current_rows": int(len(feature_importance_global)),
            }
        ]
    )
    score_debug = _build_score_debug(triaged, profiles, sample_per_check=max(50, int(args.score_debug_sample_size)))

    triaged_preview = triaged.sort_values(["recommended_action", "confidence_estimate"], ascending=[True, False]).head(5000).reset_index(drop=True)
    normalized_preview = normalized.sort_values("norm_score", ascending=False).head(5000).reset_index(drop=True)

    output_root = (
        processed_path
        / "layer6_false_alarm_demo"
        / f"business_date={business_date}"
        / f"universe_name={args.universe_name}"
        / f"run_id={run_id}"
    )
    saved_files = {
        "normalized_input_preview": _write_demo_output(normalized_preview, output_root, "normalized_input_preview", args.output_format),
        "triaged_preview": _write_demo_output(triaged_preview, output_root, "triaged_preview", args.output_format),
        "summary_by_action": _write_demo_output(summary_by_action, output_root, "summary_by_action", args.output_format),
        "summary_by_regime": _write_demo_output(summary_by_regime, output_root, "summary_by_regime", args.output_format),
        "summary_by_check": _write_demo_output(summary_by_check, output_root, "summary_by_check", args.output_format),
        "peer_summary": _write_demo_output(peer_summary, output_root, "peer_summary", args.output_format),
        "triage_model": _write_demo_output(triage_model_df, output_root, "triage_model", args.output_format),
        "score_debug": _write_demo_output(score_debug, output_root, "score_debug", args.output_format),
        "feature_importance_global": _write_demo_output(feature_importance_global, output_root, "feature_importance_global", args.output_format) if not feature_importance_global.empty else [],
        "feature_importance_local": _write_demo_output(feature_importance_local, output_root, "feature_importance_local", args.output_format) if not feature_importance_local.empty else [],
        "feature_importance_summary": _write_demo_output(feature_importance_summary, output_root, "feature_importance_summary", args.output_format) if not feature_importance_summary.empty else [],
        "feature_importance_drift": _write_demo_output(feature_importance_drift, output_root, "feature_importance_drift", args.output_format),
        "feature_importance_drift_components": _write_demo_output(psi_components.head(200), output_root, "feature_importance_drift_components", args.output_format) if not psi_components.empty else [],
    }
    if args.write_full_results and args.output_format in {"parquet", "both"}:
        saved_files["normalized_input_full"] = _write_demo_output(normalized, output_root, "normalized_input_full", "parquet")
        saved_files["triaged_full"] = _write_demo_output(triaged, output_root, "triaged_full", "parquet")

    manifest = {
        "layer": "Layer 6 - False Alarm Reduction + Triage Scorer",
        "run_id": run_id,
        "universe_name": args.universe_name,
        "config_path": str(Path(args.config_path).resolve()),
        "config_hash": cfg_hash,
        "inputs": {
            "business_date": business_date,
            "start_date": args.start_date,
            "end_date": args.end_date,
            "analysis_field_requested": str(args.analysis_field),
            "analysis_field_used": resolved_analysis_field,
            "risk_factor_count": int(membership["risk_factor_id"].nunique()),
            "timeseries_rows": int(len(series)),
            "checks_executed": [s.id for s in specs],
            "with_supervised": bool(args.with_supervised),
            "peer_group_keys": peer_group_keys,
            "peer_group_source": str(peer_cfg.get("source", "default")),
            "generate_demo_labels": bool(args.generate_demo_labels),
            "label_rate": float(args.label_rate),
            "supervised_target_label": target_label,
            "supervised_candidates": selected_candidates,
            "calibration_method": calibration_method or "config_or_none",
            "training_mode": str(supervised_cfg.get("training_mode", "ablation")),
            "feature_families": supervised_cfg.get("feature_families", []),
            "feature_importance_monitoring_enabled": bool(monitoring_cfg.get("enabled", False)),
            "feature_importance_method": str(monitoring_cfg.get("method", "xgb_gain")),
            "feature_importance_top_k": int(monitoring_cfg.get("top_k", 30)),
            "feature_importance_drift_enabled": drift_enabled,
            "feature_importance_drift_psi_threshold": psi_threshold,
            "preserve_check_flags": bool(args.preserve_check_flags),
        },
        "triage_audit": triage_audit,
        "outputs": {
            "output_root": str(output_root),
            "saved_files": saved_files,
            "raw_layer3_flag_count": raw_flag_count,
            "normalized_flag_count": normalized_flag_count,
            "normalized_rows": int(len(normalized)),
            "triaged_rows": int(len(triaged)),
            "confirm_bad_data_rows": int((triaged["recommended_action"] == "CONFIRM_BAD_DATA").sum()),
            "accept_move_rows": int((triaged["recommended_action"] == "ACCEPT_MOVE").sum()),
            "needs_review_rows": int((triaged["recommended_action"] == "NEEDS_REVIEW").sum()),
            "monitor_no_action_rows": int((triaged["recommended_action"] == "MONITOR_NO_ACTION").sum()),
            "scored_rows_with_p_bad_data": int(pd.to_numeric(triaged.get("p_bad_data"), errors="coerce").notna().sum()) if "p_bad_data" in triaged.columns else 0,
            "feature_importance_global_rows": int(len(feature_importance_global)),
            "feature_importance_local_rows": int(len(feature_importance_local)),
            "feature_importance_psi_total": None if pd.isna(psi_total) else float(psi_total),
            "feature_importance_drift_alert": bool(pd.notna(psi_total) and psi_total >= psi_threshold),
        },
    }
    manifest_path = output_root / "manifest.json"
    manifest_path.write_text(json.dumps(manifest, indent=2), encoding="utf-8")

    print("=== Layer 6 False Alarm Demo Summary ===")
    print(f"Run ID: {run_id}")
    print(f"Universe: {args.universe_name}")
    print(f"Business date: {business_date}")
    print(f"Analysis field used: {resolved_analysis_field}")
    print(f"Preserve check flags: {bool(args.preserve_check_flags)}")
    print(f"Raw Layer3 flag count: {raw_flag_count:,}")
    print(f"Normalized flag count: {normalized_flag_count:,}")
    print(f"Normalized rows: {len(normalized):,}")
    print(f"Triaged rows: {len(triaged):,}")
    print(f"CONFIRM_BAD_DATA rows: {(triaged['recommended_action'] == 'CONFIRM_BAD_DATA').sum():,}")
    print(f"ACCEPT_MOVE rows: {(triaged['recommended_action'] == 'ACCEPT_MOVE').sum():,}")
    print(f"NEEDS_REVIEW rows: {(triaged['recommended_action'] == 'NEEDS_REVIEW').sum():,}")
    print(f"Feature importance rows (global/local): {len(feature_importance_global):,}/{len(feature_importance_local):,}")
    if pd.notna(psi_total):
        print(f"Feature importance PSI: {float(psi_total):.4f} (threshold={psi_threshold:.4f}, alert={bool(psi_total >= psi_threshold)})")
    print(f"Output root: {output_root}")
    print(f"Manifest: {manifest_path}")

    return manifest


def main() -> None:
    import time

    args = parse_args()

    start = time.perf_counter()
    run_demo_layer6_false_alarm(args)
    end = time.perf_counter()


    elapsed_minutes = (end-start)/60
    elapsed_seconds = end-start
    hours = int(elapsed_seconds //3600)
    minutes = int((elapsed_seconds % 3600) //60)

    print(f"Total runtime: {hours}h {minutes}m" )
    print(f"Total runtime: {elapsed_minutes:.2f} minutes")


if __name__ == "__main__":
    main()
