﻿from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
from typing import Any

import dash
import dash_ag_grid as dag
import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import yaml
from dash import Dash, Input, Output, State, dcc, html

from common.taxonomy import DEFAULT_NULL_TOKEN, TAXONOMY_COLUMNS, normalize_taxonomy_frame
from dq_checks.taxonomy import canonicalize_family
from ui.app import PROJECT_ROOT, load_data, load_data_with_debug

RF_LEVELS = ["rf_level1", "rf_level2", "rf_level3", "rf_level4", "rf_level5"]
SEV_MAP = {"Low": 0, "Med": 1, "High": 2, "Critical": 3}
REV_SEV = {0: "Low", 1: "Med", 2: "High", 3: "Critical"}
RF_HIERARCHY_GROUP_COL = "RF_Hiearchy_Group"
SEV_COLOR_MAP = {"Critical": "#d62728", "High": "#1f77b4", "Med": "#2ca02c", "Low": "#9aa0a6"}
TREE_LEVELS_HIERARCHY = ["asset_class", "ccy", "rf_level1", "rf_level2"]
# Temporary UI toggle: keep Tab 3 implementation/callbacks, but hide it from users.
SHOW_MODEL_COMPARISON_TAB = False
SEV_CANONICAL = {
    "critical": "Critical",
    "high": "High",
    "med": "Med",
    "medium": "Med",
    "low": "Low",
}


def _empty_fig(title: str) -> go.Figure:
    fig = go.Figure()
    fig.update_layout(title=title, template="plotly_white", xaxis={"visible": False}, yaxis={"visible": False})
    return fig


def _sev_rank(s: pd.Series) -> pd.Series:
    return s.map(SEV_MAP).fillna(0).astype(int)


def _rank_to_sev(v: int | float) -> str:
    return REV_SEV.get(int(v), "Low")


def _norm_severity(s: pd.Series) -> pd.Series:
    out = s.astype(str).str.strip().str.lower().map(SEV_CANONICAL)
    return out.fillna("Low")


def _norm_regime(v: Any) -> str:
    t = str(v or "").lower().strip()
    if t in {"stress", "high_vol", "crisis"}:
        return "stress"
    if t in {"elevated", "watch"}:
        return "elevated"
    return "normal"


def get_risk_factor_series(
    time_series_raw: pd.DataFrame,
    risk_factor_id: str | None,
    start_date: str | None = None,
    end_date: str | None = None,
) -> pd.DataFrame:
    if not risk_factor_id or time_series_raw.empty:
        return pd.DataFrame(columns=["risk_factor_id", "date_norm", "value"])
    ts = time_series_raw.copy()
    if "date_norm" not in ts.columns:
        ts["date_norm"] = pd.to_datetime(ts.get("date"), errors="coerce").dt.normalize()
    ts = ts[ts["risk_factor_id"].astype(str) == str(risk_factor_id)].copy()
    if start_date:
        ts = ts[ts["date_norm"] >= pd.to_datetime(start_date, errors="coerce").normalize()]
    if end_date:
        ts = ts[ts["date_norm"] <= pd.to_datetime(end_date, errors="coerce").normalize()]
    if "value" not in ts.columns:
        ts["value"] = np.nan
    return ts[["risk_factor_id", "date_norm", "value"]].sort_values("date_norm")


def get_flagged_points(
    df_flags: pd.DataFrame,
    risk_factor_id: str | None,
    selected_checks: list[str] | None = None,
    start_date: str | None = None,
    end_date: str | None = None,
) -> pd.DataFrame:
    if not risk_factor_id or df_flags.empty:
        return pd.DataFrame(columns=["risk_factor_id", "date_norm", "check_id"])
    f = df_flags.copy()
    if "date_norm" not in f.columns:
        f["date_norm"] = pd.to_datetime(f.get("date"), errors="coerce").dt.normalize()
    flag_col = "flag" if "flag" in f.columns else "is_flagged" if "is_flagged" in f.columns else None
    if flag_col is not None:
        f = f[f[flag_col].fillna(False).astype(bool)]
    else:
        f = f.iloc[0:0].copy()
    f = f[f["risk_factor_id"].astype(str) == str(risk_factor_id)]
    if selected_checks:
        f = f[f["check_id"].astype(str).isin([str(x) for x in selected_checks])]
    if start_date:
        f = f[f["date_norm"] >= pd.to_datetime(start_date, errors="coerce").normalize()]
    if end_date:
        f = f[f["date_norm"] <= pd.to_datetime(end_date, errors="coerce").normalize()]
    if "normalized_score" not in f.columns and "norm_score" in f.columns:
        f["normalized_score"] = pd.to_numeric(f["norm_score"], errors="coerce")
    if "severity_score" not in f.columns:
        src = "raw_score" if "raw_score" in f.columns else "normalized_score" if "normalized_score" in f.columns else None
        f["severity_score"] = pd.to_numeric(f[src], errors="coerce") if src else np.nan
    return f


def _join_flagged_with_series(flags: pd.DataFrame, series_df: pd.DataFrame) -> pd.DataFrame:
    if flags.empty or series_df.empty:
        return pd.DataFrame(columns=["risk_factor_id", "date_norm", "value", "check_id"])
    j = flags.merge(
        series_df[["risk_factor_id", "date_norm", "value"]],
        on=["risk_factor_id", "date_norm"],
        how="left",
    )
    j = j[pd.notna(j["value"])].copy()
    return j


def _hover_customdata(df: pd.DataFrame) -> np.ndarray:
    out = pd.DataFrame(index=df.index)
    out["risk_factor_id"] = df.get("risk_factor_id", "").astype(str)
    out["date"] = pd.to_datetime(df.get("date_norm"), errors="coerce").dt.strftime("%Y-%m-%d")
    out["value"] = pd.to_numeric(df.get("value"), errors="coerce")
    out["check_id"] = df.get("check_id", "").astype(str)
    out["severity_score"] = pd.to_numeric(df.get("severity_score"), errors="coerce")
    out["normalized_score"] = pd.to_numeric(df.get("normalized_score"), errors="coerce")
    return out.values


def build_overlay_figure(series_df: pd.DataFrame, flagged_with_values: pd.DataFrame, risk_factor_id: str) -> go.Figure:
    fig = go.Figure()
    if series_df.empty:
        return _empty_fig(f"No raw series for {risk_factor_id}")
    fig.add_trace(go.Scatter(x=series_df["date_norm"], y=series_df["value"], mode="lines", name="raw series", line={"color": "#1f4e79"}))
    if flagged_with_values.empty:
        fig.add_annotation(text="No flagged points found for selected checks", xref="paper", yref="paper", x=0.01, y=0.98, showarrow=False)
        fig.update_layout(template="plotly_white", title=f"Raw Time Series: {risk_factor_id}")
        return fig
    for check_id, g in flagged_with_values.groupby(flagged_with_values["check_id"].astype(str)):
        cd = _hover_customdata(g)
        fig.add_trace(
            go.Scatter(
                x=g["date_norm"],
                y=g["value"],
                mode="markers",
                name=f"flag:{check_id}",
                marker={"size": 9},
                customdata=cd,
                hovertemplate=(
                    "risk_factor_id=%{customdata[0]}<br>"
                    "date=%{customdata[1]}<br>"
                    "value=%{customdata[2]:.6f}<br>"
                    "check_id=%{customdata[3]}<br>"
                    "severity_score=%{customdata[4]:.6f}<br>"
                    "normalized_score=%{customdata[5]:.6f}<extra></extra>"
                ),
            )
        )
    fig.update_layout(template="plotly_white", title=f"Raw Time Series + Flagged Points (Overlay): {risk_factor_id}")
    return fig


def build_single_check_figure(series_df: pd.DataFrame, flagged_one_check: pd.DataFrame, risk_factor_id: str, check_id: str) -> go.Figure:
    fig = go.Figure()
    if series_df.empty:
        return _empty_fig(f"No raw series for {risk_factor_id}")
    fig.add_trace(go.Scatter(x=series_df["date_norm"], y=series_df["value"], mode="lines", name="raw series", line={"color": "#1f4e79"}))
    if not flagged_one_check.empty:
        cd = _hover_customdata(flagged_one_check)
        fig.add_trace(
            go.Scatter(
                x=flagged_one_check["date_norm"],
                y=flagged_one_check["value"],
                mode="markers",
                name=f"flag:{check_id}",
                marker={"size": 9},
                customdata=cd,
                hovertemplate=(
                    "risk_factor_id=%{customdata[0]}<br>"
                    "date=%{customdata[1]}<br>"
                    "value=%{customdata[2]:.6f}<br>"
                    "check_id=%{customdata[3]}<br>"
                    "severity_score=%{customdata[4]:.6f}<br>"
                    "normalized_score=%{customdata[5]:.6f}<extra></extra>"
                ),
            )
        )
    fig.update_layout(template="plotly_white", title=f"{risk_factor_id} | {check_id}")
    return fig


def build_separate_figures_layout(
    series_df: pd.DataFrame,
    flagged_with_values: pd.DataFrame,
    risk_factor_id: str,
    selected_checks: list[str],
    mode: str = "separate",
) -> go.Figure:
    checks = [str(x) for x in (selected_checks or [])]
    if series_df.empty:
        return _empty_fig(f"No raw series for {risk_factor_id}")
    if not checks:
        checks = sorted(flagged_with_values.get("check_id", pd.Series(dtype=str)).astype(str).unique().tolist())
    if not checks:
        fig = go.Figure()
        fig.add_trace(go.Scatter(x=series_df["date_norm"], y=series_df["value"], mode="lines", name="raw series"))
        fig.add_annotation(text="No flagged points found for selected checks", xref="paper", yref="paper", x=0.01, y=0.98, showarrow=False)
        fig.update_layout(template="plotly_white", title=f"Raw Time Series: {risk_factor_id}")
        return fig

    if mode == "small_multiples":
        n = len(checks)
        cols = 2
        rows = int(np.ceil(n / cols))
        fig = make_subplots(rows=rows, cols=cols, subplot_titles=checks, shared_xaxes=False)
        for i, chk in enumerate(checks):
            r = (i // cols) + 1
            c = (i % cols) + 1
            fig.add_trace(go.Scatter(x=series_df["date_norm"], y=series_df["value"], mode="lines", name=f"raw:{chk}", line={"color": "#1f4e79"}, showlegend=(i == 0)), row=r, col=c)
            g = flagged_with_values[flagged_with_values["check_id"].astype(str) == chk]
            if not g.empty:
                cd = _hover_customdata(g)
                fig.add_trace(go.Scatter(x=g["date_norm"], y=g["value"], mode="markers", marker={"size": 8}, name=f"flag:{chk}", showlegend=(i == 0), customdata=cd), row=r, col=c)
        fig.update_layout(template="plotly_white", height=max(450, 280 * rows), title=f"Raw + flagged points (small multiples): {risk_factor_id}")
        return fig

    fig = make_subplots(rows=len(checks), cols=1, shared_xaxes=True, subplot_titles=checks, vertical_spacing=0.03)
    for i, chk in enumerate(checks, start=1):
        fig.add_trace(go.Scatter(x=series_df["date_norm"], y=series_df["value"], mode="lines", name=f"raw:{chk}", line={"color": "#1f4e79"}, showlegend=(i == 1)), row=i, col=1)
        g = flagged_with_values[flagged_with_values["check_id"].astype(str) == chk]
        if not g.empty:
            cd = _hover_customdata(g)
            fig.add_trace(
                go.Scatter(
                    x=g["date_norm"],
                    y=g["value"],
                    mode="markers",
                    name=f"flag:{chk}",
                    marker={"size": 8},
                    showlegend=(i == 1),
                    customdata=cd,
                    hovertemplate=(
                        "risk_factor_id=%{customdata[0]}<br>"
                        "date=%{customdata[1]}<br>"
                        "value=%{customdata[2]:.6f}<br>"
                        "check_id=%{customdata[3]}<br>"
                        "severity_score=%{customdata[4]:.6f}<br>"
                        "normalized_score=%{customdata[5]:.6f}<extra></extra>"
                    ),
                ),
                row=i,
                col=1,
            )
    fig.update_layout(template="plotly_white", height=max(420, 260 * len(checks)), title=f"Raw + flagged points by check (stacked): {risk_factor_id}")
    return fig


def _read_yaml(path: str | Path | None) -> dict[str, Any]:
    if not path:
        return {}
    p = Path(path)
    if not p.exists():
        return {}
    with p.open("r", encoding="utf-8") as fh:
        data = yaml.safe_load(fh) or {}
    return data if isinstance(data, dict) else {}


def _load_triage_labels(path: str | Path | None) -> pd.DataFrame:
    if not path:
        return pd.DataFrame()
    p = Path(path)
    if not p.exists():
        return pd.DataFrame()
    try:
        if p.suffix.lower() == ".csv":
            out = pd.read_csv(p)
        else:
            out = pd.read_parquet(p)
        if "timestamp" in out.columns:
            out["timestamp"] = pd.to_datetime(out["timestamp"], errors="coerce")
        if "date" in out.columns:
            out["date"] = pd.to_datetime(out["date"], errors="coerce")
        return out
    except Exception:
        return pd.DataFrame()


def _persist_triage_labels(path: str | Path | None, rows: list[dict[str, Any]]) -> None:
    if not path:
        return
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    out = pd.DataFrame(rows)
    if out.empty:
        return
    if "timestamp" in out.columns:
        out["timestamp"] = pd.to_datetime(out["timestamp"], errors="coerce")
    if "date" in out.columns:
        out["date"] = pd.to_datetime(out["date"], errors="coerce")
    if p.suffix.lower() == ".csv":
        out.to_csv(p, index=False)
    else:
        out.to_parquet(p, index=False)


def _load_optional_table(path: str | Path | None) -> pd.DataFrame:
    if not path:
        return pd.DataFrame()
    p = Path(path)
    if not p.exists():
        return pd.DataFrame()
    try:
        if p.suffix.lower() == ".csv":
            return pd.read_csv(p)
        return pd.read_parquet(p)
    except Exception:
        return pd.DataFrame()


def _parse_json_dict(value: Any) -> dict[str, Any]:
    if isinstance(value, dict):
        return value
    if isinstance(value, str):
        text = value.strip()
        if text.startswith("{") and text.endswith("}"):
            try:
                payload = json.loads(text)
                if isinstance(payload, dict):
                    return payload
            except Exception:
                return {}
    return {}


def _parse_json_list(value: Any) -> list[Any]:
    if isinstance(value, list):
        return value
    if isinstance(value, str):
        text = value.strip()
        if text.startswith("[") and text.endswith("]"):
            try:
                payload = json.loads(text)
                if isinstance(payload, list):
                    return payload
            except Exception:
                return []
    return []


def _regime_windows(cfg: dict[str, Any]) -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []
    for row in cfg.get("globals", {}).get("regime_windows", []) or []:
        s = pd.to_datetime(row.get("start_date"), errors="coerce")
        e = pd.to_datetime(row.get("end_date"), errors="coerce")
        if pd.notna(s) and pd.notna(e):
            out.append({"id": str(row.get("id", "regime")), "start": s.normalize(), "end": e.normalize(), "tag": _norm_regime(row.get("regime_tag"))})
    return out


def _event_calendar(cfg: dict[str, Any]) -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []
    for row in cfg.get("triage", {}).get("event_calendar", []) or []:
        d = pd.to_datetime(row.get("date") or row.get("event_date"), errors="coerce")
        if pd.notna(d):
            out.append({"date": d.normalize(), "label": str(row.get("type", row.get("name", "Event")))})
    return out


def _hierarchy_cols(asset: str) -> list[str]:
    ac = str(asset or "").upper()
    if ac.startswith("IR_") or "TREASURY" in ac:
        return ["asset_class", "rf_level2", "rf_level3", "tenor_bucket", "risk_factor_id"]
    if ac.startswith("CP_"):
        return ["asset_class", "rating", "rf_level3", "risk_factor_id"]
    if ac.startswith("EQ_"):
        return ["asset_class", "rf_level3", "rf_level2", "risk_factor_id"]
    if ac.startswith("FX_"):
        return ["asset_class", "rf_level3", "rf_level5", "risk_factor_id"]
    return ["asset_class", "universe_name", "risk_factor_id"]


def _ensure_data(data: dict[str, pd.DataFrame]) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    dq = data["dq_results"].copy()
    ts = data["timeseries_raw"].copy()
    mem = normalize_taxonomy_frame(data["membership"].copy(), require_risk_factor_id=False)

    for c in ["universe_name", "vendor", "rating", "tenor_bucket"]:
        if c not in mem.columns:
            mem[c] = DEFAULT_NULL_TOKEN

    if "date" in dq.columns:
        dq["date"] = pd.to_datetime(dq["date"], errors="coerce")
    if "date" in ts.columns:
        ts["date"] = pd.to_datetime(ts["date"], errors="coerce")
    dq_dates = pd.to_datetime(dq["date"], errors="coerce") if "date" in dq.columns else pd.Series(pd.NaT, index=dq.index)
    ts_dates = pd.to_datetime(ts["date"], errors="coerce") if "date" in ts.columns else pd.Series(pd.NaT, index=ts.index)
    dq["date_norm"] = dq_dates.dt.normalize()
    ts["date_norm"] = ts_dates.dt.normalize()

    if "flag" not in dq.columns:
        dq["flag"] = False
    dq["flag"] = dq["flag"].fillna(False).astype(bool)

    if "severity" not in dq.columns:
        dq["severity"] = "Low"
    dq["severity"] = _norm_severity(dq["severity"])
    dq["severity_rank"] = _sev_rank(dq["severity"])

    if "norm_score" not in dq.columns:
        dq["norm_score"] = 0.0
    dq["norm_score"] = pd.to_numeric(dq["norm_score"], errors="coerce").fillna(0.0)

    if "family" not in dq.columns:
        dq["family"] = "unknown"
    if "check_id" not in dq.columns:
        dq["check_id"] = "unknown"
    if "model_id" not in dq.columns:
        dq["model_id"] = dq["check_id"]
    if "reason_code" not in dq.columns:
        dq["reason_code"] = "NA"
    if "peer_confirmed" not in dq.columns:
        dq["peer_confirmed"] = False
    regime_src = dq["regime_tag"] if "regime_tag" in dq.columns else pd.Series("normal", index=dq.index)
    dq["regime_bucket"] = regime_src.map(_norm_regime)

    if not mem.empty:
        enrich_cols = [c for c in RF_LEVELS + ["asset_class", "ccy", "universe_name", "vendor", "rating", "tenor_bucket"] if c in mem.columns]
        need_enrich = [c for c in enrich_cols if c not in dq.columns]
        if need_enrich:
            right = mem[["risk_factor_id"] + need_enrich].drop_duplicates(subset=["risk_factor_id"])
            dq = dq.merge(right, on="risk_factor_id", how="left")
    dq = normalize_taxonomy_frame(dq, require_risk_factor_id=False)

    dq["family"] = dq["family"].astype(str).map(lambda x: canonicalize_family(x))
    dq["check_id"] = dq["check_id"].astype(str)
    dq["model_id"] = dq["model_id"].astype(str)

    # Guardrail: if membership does not align with dq_results, derive missing membership from dq.
    if "risk_factor_id" in dq.columns:
        dq_ids = set(dq["risk_factor_id"].astype(str).dropna().unique().tolist())
        mem_ids = set(mem["risk_factor_id"].astype(str).dropna().unique().tolist()) if "risk_factor_id" in mem.columns else set()
        missing_ids = dq_ids - mem_ids
        if missing_ids:
            enrich_cols = RF_LEVELS + ["asset_class", "ccy", "universe_name", "vendor", "rating", "tenor_bucket"]
            use_cols = [c for c in ["risk_factor_id"] + enrich_cols if c in dq.columns]
            mem_from_dq = dq[dq["risk_factor_id"].astype(str).isin(missing_ids)][use_cols].drop_duplicates(subset=["risk_factor_id"]).copy()
            for c in enrich_cols:
                if c not in mem_from_dq.columns:
                    mem_from_dq[c] = DEFAULT_NULL_TOKEN
            if mem.empty:
                mem = mem_from_dq
            else:
                for c in mem_from_dq.columns:
                    if c not in mem.columns:
                        mem[c] = DEFAULT_NULL_TOKEN
                for c in mem.columns:
                    if c not in mem_from_dq.columns:
                        mem_from_dq[c] = DEFAULT_NULL_TOKEN
                mem = pd.concat([mem, mem_from_dq[mem.columns]], ignore_index=True).drop_duplicates(subset=["risk_factor_id"])

    mem = normalize_taxonomy_frame(mem, require_risk_factor_id=False)
    for c in TAXONOMY_COLUMNS:
        if c not in mem.columns:
            mem[c] = DEFAULT_NULL_TOKEN

    return dq, ts, mem


def _dqOutliersSum_grouping(df: pd.DataFrame, mode: str) -> pd.Series:
    m = str(mode or "asset_class")
    if m == "asset_class":
        if "asset_class" in df.columns:
            return df["asset_class"].fillna(DEFAULT_NULL_TOKEN).astype(str)
        return df.get("rf_level1", pd.Series(DEFAULT_NULL_TOKEN, index=df.index)).fillna(DEFAULT_NULL_TOKEN).astype(str)
    asset_ccy_map: dict[str, list[str]] = {
        "asset_ccy": ["asset_class", "ccy"],
        "asset_ccy_rf1": ["asset_class", "ccy", "rf_level1"],
        "asset_ccy_rf1_rf2": ["asset_class", "ccy", "rf_level1", "rf_level2"],
        "asset_ccy_rf1_rf2_rf3": ["asset_class", "ccy", "rf_level1", "rf_level2", "rf_level3"],
        "asset_ccy_rf1_rf2_rf3_rf4": ["asset_class", "ccy", "rf_level1", "rf_level2", "rf_level3", "rf_level4"],
        "asset_ccy_rf1_rf2_rf3_rf4_rf5": ["asset_class", "ccy", "rf_level1", "rf_level2", "rf_level3", "rf_level4", "rf_level5"],
    }
    if m in asset_ccy_map:
        cols = asset_ccy_map[m]
        parts = [df.get(c, pd.Series(DEFAULT_NULL_TOKEN, index=df.index)).fillna(DEFAULT_NULL_TOKEN).astype(str) for c in cols]
        out = parts[0]
        for p in parts[1:]:
            out = out.str.cat(p, sep=" | ")
        return out
    if m == "rf_level1":
        return df.get("rf_level1", pd.Series(DEFAULT_NULL_TOKEN, index=df.index)).fillna(DEFAULT_NULL_TOKEN).astype(str)
    levels = ["rf_level1", "rf_level2", "rf_level3", "rf_level4", "rf_level5"]
    depth_map = {
        "rf1_rf2": 2,
        "rf1_rf2_rf3": 3,
        "rf1_rf2_rf3_rf4": 4,
        "rf1_rf2_rf3_rf4_rf5": 5,
    }
    depth = depth_map.get(m, 1)
    parts: list[pd.Series] = []
    for c in levels[:depth]:
        parts.append(df.get(c, pd.Series(DEFAULT_NULL_TOKEN, index=df.index)).fillna(DEFAULT_NULL_TOKEN).astype(str))
    out = parts[0]
    for p in parts[1:]:
        out = out.str.cat(p, sep=" | ")
    return out


def _leaf_paths(mem: pd.DataFrame, path_mode: str = "hierarchy") -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    mode = str(path_mode or "hierarchy")
    for _, r in mem.iterrows():
        if mode == "analytic":
            cols = [RF_HIERARCHY_GROUP_COL, "asset_class", "ccy", "rf_level1", "rf_level2", "rf_level3", "rf_level4", "rf_level5", "risk_factor_id"]
        else:
            cols = TREE_LEVELS_HIERARCHY + ["risk_factor_id"]
        path = []
        for c in cols:
            if c == "risk_factor_id":
                path.append(str(r.get("risk_factor_id", "NA")))
            else:
                v = r.get(c, "NA")
                path.append(str(v) if pd.notna(v) and str(v) else DEFAULT_NULL_TOKEN)
        rec = {"risk_factor_id": str(r.get("risk_factor_id", "")), "hierarchy": path, "path_len": len(path)}
        for i in range(1, 11):
            rec[f"path_{i}"] = path[i - 1] if i <= len(path) else None
        rows.append(rec)
    out = pd.DataFrame(rows)
    return out

def _latest_date(df: pd.DataFrame) -> pd.Timestamp:
    def _naive(ts: pd.Timestamp) -> pd.Timestamp:
        if getattr(ts, "tzinfo", None) is not None:
            return ts.tz_localize(None)
        return ts

    if df.empty:
        return _naive(pd.Timestamp.utcnow()).normalize()
    d = pd.to_datetime(df.get("date_norm"), errors="coerce").max()
    if pd.isna(d):
        return _naive(pd.Timestamp.utcnow()).normalize()
    return _naive(pd.Timestamp(d)).normalize()


def _branch_members(mem: pd.DataFrame, branch_path: list[str], path_mode: str = "hierarchy", group_mode: str = "rf1_rf2") -> pd.Series:
    if not branch_path:
        return mem["risk_factor_id"].astype(str)
    m = mem.copy()
    if str(path_mode or "hierarchy") == "analytic" and RF_HIERARCHY_GROUP_COL not in m.columns:
        m[RF_HIERARCHY_GROUP_COL] = _dqOutliersSum_grouping(m, group_mode)
    p = _leaf_paths(m, path_mode=path_mode)
    key = tuple(str(x) for x in branch_path)

    def prefix(v: list[str]) -> bool:
        t = tuple(str(x) for x in v[: len(key)])
        return t == key

    return p[p["hierarchy"].map(prefix)]["risk_factor_id"].astype(str)


def _tree_rows(
    mem: pd.DataFrame,
    latest_flags: pd.DataFrame,
    flags_30d: pd.DataFrame,
    path_mode: str = "hierarchy",
    group_mode: str = "rf1_rf2",
) -> list[dict[str, Any]]:
    m = mem.copy()
    if "risk_factor_id" in m.columns:
        m = m.drop_duplicates(subset=["risk_factor_id"])
    if not m.empty:
        m[RF_HIERARCHY_GROUP_COL] = _dqOutliersSum_grouping(m, group_mode)
    p = _leaf_paths(m, path_mode=path_mode)
    if p.empty:
        return []
    level_labels = (
        TREE_LEVELS_HIERARCHY
        if str(path_mode or "hierarchy") == "hierarchy"
        else [RF_HIERARCHY_GROUP_COL, "asset_class", "ccy", "rf_level1", "rf_level2", "rf_level3", "rf_level4", "rf_level5"]
    )

    lf = pd.DataFrame(columns=["risk_factor_id", "flagged", "critical", "worst_rank"])
    if not latest_flags.empty:
        lf = latest_flags.groupby("risk_factor_id", as_index=False).agg(
            flagged=("flag", "max"),
            critical=("severity", lambda s: (s == "Critical").any()),
            worst_rank=("severity_rank", "max"),
        )
    leaf = p.merge(lf, on="risk_factor_id", how="left")
    leaf["flagged"] = leaf["flagged"].fillna(False).astype(bool)
    leaf["critical"] = leaf["critical"].fillna(False).astype(bool)
    leaf["worst_rank"] = pd.to_numeric(leaf["worst_rank"], errors="coerce").fillna(0).astype(int)

    max_depth = int(leaf["path_len"].max()) if not leaf.empty else 1
    path_cols_all = [f"path_{i}" for i in range(1, max_depth + 1)]

    latest = _latest_date(latest_flags)
    idx = pd.date_range(latest - pd.Timedelta(days=29), latest, freq="D")

    t = pd.DataFrame(columns=["risk_factor_id", "date_norm", "cnt"])
    if not flags_30d.empty:
        t = flags_30d.groupby(["risk_factor_id", "date_norm"], as_index=False).size().rename(columns={"size": "cnt"})
    t = t.merge(leaf[["risk_factor_id"] + path_cols_all], on="risk_factor_id", how="left")

    out: list[dict[str, Any]] = []
    include_leaves = str(path_mode or "hierarchy") != "hierarchy"

    for depth in range(1, max_depth):
        cols = [f"path_{i}" for i in range(1, depth + 1)]
        node = leaf[leaf[f"path_{depth}"].notna()]
        if node.empty:
            continue
        agg = node.groupby(cols, as_index=False).agg(
            total_factors=("risk_factor_id", "nunique"),
            flagged=("flagged", "sum"),
            critical=("critical", "sum"),
            worst_rank=("worst_rank", "max"),
        )
        agg = agg[agg["flagged"] > 0].copy()
        if agg.empty:
            continue

        trend_map: dict[tuple[Any, ...], str] = {}
        if not t.empty:
            tr = t[t[f"path_{depth}"].notna()].groupby(cols + ["date_norm"], as_index=False)["risk_factor_id"].nunique().rename(columns={"risk_factor_id": "cnt"})
            for key, g in tr.groupby(cols):
                k = key if isinstance(key, tuple) else (key,)
                vals = (
                    g.groupby("date_norm", as_index=True)["cnt"]
                    .sum()
                    .reindex(idx, fill_value=0)
                    .astype(int)
                    .tolist()
                )
                trend_map[k] = ",".join(str(x) for x in vals)

        for _, r in agg.iterrows():
            k = tuple(r[c] for c in cols)
            f = int(r["flagged"])
            n = int(r["total_factors"])
            level_name = level_labels[depth - 1] if depth - 1 < len(level_labels) else f"level_{depth}"
            hierarchy_path = " > ".join(str(r[c]) for c in cols)
            out.append(
                {
                    "hierarchy": [str(r[c]) for c in cols],
                    "name": str(r[cols[-1]]),
                    "hierarchy_name": str(r[cols[-1]]),
                    "hierarchy_level": level_name,
                    "hierarchy_path": hierarchy_path,
                    "node_depth": depth,
                    "is_leaf": False,
                    "risk_factor_id": "",
                    "total_factors": n,
                    "flagged": f,
                    "flagged_count": f,
                    "critical": int(r["critical"]),
                    "worst_severity": _rank_to_sev(int(r["worst_rank"])),
                    "flag_rate": round(100.0 * f / n, 2) if n > 0 else 0.0,
                    "trend_30d": trend_map.get(k, ""),
                }
            )

    leaf_trend: dict[str, str] = {}
    if not t.empty:
        for rf, g in t.groupby("risk_factor_id"):
            vals = (
                g.groupby("date_norm", as_index=True)["cnt"]
                .sum()
                .reindex(idx, fill_value=0)
                .astype(int)
                .tolist()
            )
            leaf_trend[str(rf)] = ",".join(str(x) for x in vals)

    if include_leaves:
        for _, r in leaf.iterrows():
            if not bool(r["flagged"]):
                continue
            out.append(
                {
                    "hierarchy": r["hierarchy"],
                    "name": str(r["risk_factor_id"]),
                    "hierarchy_name": str(r["risk_factor_id"]),
                    "hierarchy_level": "risk_factor_id",
                    "hierarchy_path": " > ".join(str(x) for x in r["hierarchy"]),
                    "node_depth": len(r["hierarchy"]),
                    "is_leaf": True,
                    "risk_factor_id": str(r["risk_factor_id"]),
                    "total_factors": 1,
                    "flagged": int(bool(r["flagged"])),
                    "flagged_count": int(bool(r["flagged"])),
                    "critical": int(bool(r["critical"])),
                    "worst_severity": _rank_to_sev(int(r["worst_rank"])),
                    "flag_rate": float(100.0 if bool(r["flagged"]) else 0.0),
                    "trend_30d": leaf_trend.get(str(r["risk_factor_id"]), ""),
                }
            )
    out = sorted(
        out,
        key=lambda x: (
            len(x.get("hierarchy", [])),
            tuple(x.get("hierarchy", [])[:-1]),
            -int(x.get("flagged", 0)),
            -int(SEV_MAP.get(str(x.get("worst_severity", "Low")), 0)),
            str(x.get("name", "")),
        ),
    )
    return out


def _indicator_status(name: str, value: float | None) -> tuple[str, str, str]:
    if value is None or np.isnan(value):
        return name, "N/A", "#6c757d"
    key = name.lower()
    if key == "vix":
        if value < 20:
            return name, f"{value:.1f} (normal)", "#1a7f37"
        if value < 30:
            return name, f"{value:.1f} (elevated)", "#b26a00"
        return name, f"{value:.1f} (stress)", "#b42318"
    if key == "move":
        if value < 100:
            return name, f"{value:.1f} (normal)", "#1a7f37"
        if value < 140:
            return name, f"{value:.1f} (elevated)", "#b26a00"
        return name, f"{value:.1f} (stress)", "#b42318"
    if value < 80:
        return name, f"{value:.1f} (normal)", "#1a7f37"
    if value < 120:
        return name, f"{value:.1f} (elevated)", "#b26a00"
    return name, f"{value:.1f} (stress)", "#b42318"


def _latest_numeric(df: pd.DataFrame, cols: list[str]) -> float | None:
    for c in cols:
        if c in df.columns:
            s = pd.to_numeric(df[c], errors="coerce").dropna()
            if not s.empty:
                return float(s.iloc[-1])
    return None


def _market_movers_snapshot(r: pd.DataFrame, f_scope: pd.DataFrame) -> list[dict[str, Any]]:
    """Compute market mover values/status labels used by the Tab 1 regime banner.

    This is intentionally separated so UI rendering can be toggled independently.
    """
    vix = _latest_numeric(r.sort_values("date_norm"), ["vix", "vix_level", "regime_vix"])
    move = _latest_numeric(r.sort_values("date_norm"), ["move", "move_level", "regime_move"])
    cdx = _latest_numeric(r.sort_values("date_norm"), ["cdx_ig", "cdx_ig_level"])

    if vix is None or move is None or cdx is None:
        stress_ratio = float((f_scope["regime_bucket"] == "stress").mean()) if not f_scope.empty else 0.0
        vix = 15.0 + 35.0 * stress_ratio if vix is None else vix
        move = 80.0 + 80.0 * stress_ratio if move is None else move
        cdx = 60.0 + 100.0 * stress_ratio if cdx is None else cdx

    out: list[dict[str, Any]] = []
    for nm, vv in [("VIX", vix), ("MOVE", move), ("CDX IG", cdx)]:
        title, value_text, color = _indicator_status(nm, vv)
        out.append({"name": title, "value": vv, "value_text": value_text, "color": color})
    return out


def _trend_arrow(cur: int, prev: int) -> str:
    if cur > prev:
        return "? degrading"
    if cur < prev:
        return "? improving"
    return "? flat"


def _action_truth(action: str) -> int | None:
    a = str(action or "").upper()
    if a == "CONFIRM_ISSUE":
        return 1
    if a in {"DISMISS_FALSE_ALARM", "KNOWN_EXPECTED"}:
        return 0
    return None

def create_app(
    data: dict[str, pd.DataFrame],
    config_path: str | Path | None = None,
    triage_path: str | Path | None = None,
    analyst_id: str | None = None,
    initial_start_date: str | None = None,
    initial_end_date: str | None = None,
    triage_model_df: pd.DataFrame | None = None,
    feature_importance_global_df: pd.DataFrame | None = None,
    feature_importance_local_df: pd.DataFrame | None = None,
    feature_importance_drift_df: pd.DataFrame | None = None,
    feature_importance_drift_components_df: pd.DataFrame | None = None,
) -> Dash:
    dq, ts, mem = _ensure_data(data)
    cfg = _read_yaml(config_path)
    regimes = _regime_windows(cfg)
    events = _event_calendar(cfg)

    if analyst_id is None:
        analyst_id = os.getenv("USERNAME", "analyst")

    first_flag = pd.DataFrame(columns=["risk_factor_id", "check_id", "first_flag_date"])
    if not dq.empty:
        first_flag = dq[dq["flag"]].groupby(["risk_factor_id", "check_id"], as_index=False)["date_norm"].min().rename(columns={"date_norm": "first_flag_date"})

    date_bounds: list[tuple[pd.Timestamp, pd.Timestamp]] = []
    for frame in (ts, dq):
        if "date_norm" not in frame.columns:
            continue
        vals = pd.to_datetime(frame["date_norm"], errors="coerce").dropna()
        if vals.empty:
            continue
        date_bounds.append((vals.min().normalize(), vals.max().normalize()))
    if date_bounds:
        dmin = min(x[0] for x in date_bounds)
        dmax = max(x[1] for x in date_bounds)
    else:
        dmax = _latest_date(dq)
        dmin = dmax - pd.Timedelta(days=90)

    start_ts = pd.to_datetime(initial_start_date, errors="coerce")
    end_ts = pd.to_datetime(initial_end_date, errors="coerce")
    if pd.isna(start_ts):
        start_ts = dmin
    if pd.isna(end_ts):
        end_ts = dmax
    start_ts = max(start_ts.normalize(), dmin)
    end_ts = min(end_ts.normalize(), dmax)
    if start_ts > end_ts:
        start_ts, end_ts = dmin, dmax
    start_default = str(start_ts.date())
    end_default = str(end_ts.date())

    assets = sorted(mem.get("asset_class", mem.get("rf_level1", pd.Series(dtype=str))).dropna().astype(str).unique().tolist())
    ccy_vals = sorted(mem.get("ccy", pd.Series(dtype=str)).dropna().astype(str).unique().tolist())
    rf1_vals = sorted(mem.get("rf_level1", pd.Series(dtype=str)).dropna().astype(str).unique().tolist())
    rf2_vals = sorted(mem.get("rf_level2", pd.Series(dtype=str)).dropna().astype(str).unique().tolist())
    rf3_vals = sorted(mem.get("rf_level3", pd.Series(dtype=str)).dropna().astype(str).unique().tolist())
    rf4_vals = sorted(mem.get("rf_level4", pd.Series(dtype=str)).dropna().astype(str).unique().tolist())
    universes = sorted(mem.get("universe_name", pd.Series(dtype=str)).dropna().astype(str).unique().tolist())
    families = sorted(dq.get("family", pd.Series(dtype=str)).dropna().astype(str).unique().tolist())
    checks = sorted(dq.get("check_id", pd.Series(dtype=str)).dropna().astype(str).unique().tolist())
    business_dates: list[str] = []
    for frame in [dq, ts, mem]:
        if "business_date" in frame.columns:
            vals = pd.to_datetime(frame["business_date"], errors="coerce").dropna().dt.strftime("%Y-%m-%d").unique().tolist()
            business_dates.extend(vals)
    business_dates = sorted(set(business_dates))
    default_business_date = business_dates[-1] if business_dates else ""

    triage_df = _load_triage_labels(triage_path)
    triage_model_data = triage_model_df.copy() if triage_model_df is not None else pd.DataFrame()
    fi_global_data = feature_importance_global_df.copy() if feature_importance_global_df is not None else pd.DataFrame()
    fi_local_data = feature_importance_local_df.copy() if feature_importance_local_df is not None else pd.DataFrame()
    fi_drift_data = feature_importance_drift_df.copy() if feature_importance_drift_df is not None else pd.DataFrame()
    fi_drift_components_data = (
        feature_importance_drift_components_df.copy() if feature_importance_drift_components_df is not None else pd.DataFrame()
    )

    app = Dash(__name__)
    app.layout = html.Div(
        [
            html.H2("Advanced DQ Checks on RF - Reports and Insights"),
            html.Details(
                [
                    html.Summary("Debug State"),
                    html.Pre(id="v2-debug-info", style={"whiteSpace": "pre-wrap", "fontSize": "12px"}),
                ],
                open=False,
            ),
            dcc.Store(
                id="v2-store",
                data={
                    "selected_risk_factor_id": None,
                    "selected_branch_path": [],
                    "filters": {
                        "asset_class": [],
                        "ccy": [],
                        "rf_level1": [],
                        "rf_level2": [],
                        "rf_level3": [],
                        "rf_level4": [],
                        "universe": [],
                        "family": [],
                        "check_id": [],
                        "severity": [],
                        "business_date": default_business_date,
                        "group_by": "asset_class",
                        "summary_scope": "latest_flagged",
                        "regime": ["all"],
                        "show_only": "all",
                        "start_date": start_default,
                        "end_date": end_default,
                    },
                },
            ),
            dcc.Store(id="v2-triage-labels", data=triage_df.to_dict("records") if not triage_df.empty else []),
            dcc.Store(id="v2-peer-date-map", data=[]),
            html.Div(
                [
                    dcc.Dropdown(id="v2-filter-asset", options=[{"label": x, "value": x} for x in assets], multi=True, placeholder="asset_class"),
                    dcc.Dropdown(id="v2-filter-ccy", options=[{"label": x, "value": x} for x in ccy_vals], multi=True, placeholder="ccy"),
                    dcc.Dropdown(id="v2-filter-rf1", options=[{"label": x, "value": x} for x in rf1_vals], multi=True, placeholder="rf_level1"),
                    dcc.Dropdown(id="v2-filter-rf2", options=[{"label": x, "value": x} for x in rf2_vals], multi=True, placeholder="rf_level2"),
                    dcc.Dropdown(id="v2-filter-rf3", options=[{"label": x, "value": x} for x in rf3_vals], multi=True, placeholder="rf_level3"),
                    dcc.Dropdown(id="v2-filter-rf4", options=[{"label": x, "value": x} for x in rf4_vals], multi=True, placeholder="rf_level4"),
                    dcc.Dropdown(id="v2-filter-universe", options=[{"label": x, "value": x} for x in universes], multi=True, placeholder="universe"),
                    dcc.Dropdown(id="v2-filter-family", options=[{"label": x, "value": x} for x in families], multi=True, placeholder="check family"),
                    dcc.Dropdown(id="v2-filter-check", options=[{"label": x, "value": x} for x in checks], multi=True, placeholder="check/model id"),
                    dcc.Dropdown(id="v2-filter-sev", options=[{"label": x, "value": x} for x in ["Low", "Med", "High", "Critical"]], multi=True, placeholder="severity"),
                    dcc.Dropdown(
                        id="v2-filter-business-date",
                        options=[{"label": d, "value": d} for d in business_dates],
                        value=default_business_date if default_business_date else None,
                        multi=False,
                        placeholder="business_date",
                    ),
                    dcc.Dropdown(
                        id="v2-filter-group-by",
                        options=[
                            {"label": "asset_class", "value": "asset_class"},
                            {"label": "asset_class + ccy", "value": "asset_ccy"},
                            {"label": "asset_class + ccy + rf_level1", "value": "asset_ccy_rf1"},
                            {"label": "asset_class + ccy + rf_level1 + rf_level2", "value": "asset_ccy_rf1_rf2"},
                            {"label": "asset_class + ccy + rf_level1 + rf_level2 + rf_level3", "value": "asset_ccy_rf1_rf2_rf3"},
                            {"label": "asset_class + ccy + rf_level1 + rf_level2 + rf_level3 + rf_level4", "value": "asset_ccy_rf1_rf2_rf3_rf4"},
                            {"label": "asset_class + ccy + rf_level1 + rf_level2 + rf_level3 + rf_level4 + rf_level5", "value": "asset_ccy_rf1_rf2_rf3_rf4_rf5"},
                        ],
                        value="asset_class",
                        multi=False,
                        placeholder="Hierarchy grouping",
                    ),
                    dcc.Dropdown(
                        id="v2-filter-summary-scope",
                        options=[
                            {"label": "latest flagged date", "value": "latest_flagged"},
                            {"label": "entire range", "value": "entire_range"},
                            {"label": "selected UI range", "value": "selected_range"},
                        ],
                        value="latest_flagged",
                        multi=False,
                        placeholder="summary scope",
                    ),
                    dcc.Dropdown(id="v2-filter-regime", options=[{"label": "All", "value": "all"}, {"label": "Normal", "value": "normal"}, {"label": "Elevated", "value": "elevated"}, {"label": "Stress", "value": "stress"}], value=["all"], multi=True),
                    dcc.Dropdown(id="v2-filter-show-only", options=[{"label": "all", "value": "all"}], value="all", disabled=True),
                ],
                style={"display": "grid", "gridTemplateColumns": "repeat(auto-fit,minmax(220px,1fr))", "gap": "8px", "marginBottom": "8px"},
            ),
            html.Div(
                [
                    html.Div("Summary Range", style={"fontWeight": 600, "marginRight": "8px"}),
                    dcc.DatePickerRange(
                        id="v2-filter-range",
                        start_date=start_default,
                        end_date=end_default,
                        min_date_allowed=str(dmin.date()),
                        max_date_allowed=str(dmax.date()),
                        display_format="YYYY-MM-DD",
                        minimum_nights=0,
                        clearable=False,
                    ),
                    html.Div(id="v2-range-hint", style={"fontSize": "12px", "color": "#57606a", "marginLeft": "8px"}),
                ],
                style={"display": "flex", "alignItems": "center", "gap": "8px", "marginBottom": "10px", "flexWrap": "wrap"},
            ),
            dcc.Tabs(
                id="v2-tabs",
                value="tab1",
                children=[
                    dcc.Tab(
                        label="DQ Outliers Summary",
                        value="tab1",
                        children=[
                            html.Div(id="v2-regime-banner", style={"border": "1px solid #d0d7de", "padding": "8px"}),
                            html.Div(id="v2-kpis", style={"display": "grid", "gridTemplateColumns": "repeat(5,1fr)", "gap": "8px", "margin": "8px 0"}),
                            dcc.Graph(id="v2-health-matrix"),
                            html.Div(
                                [
                                    dcc.Graph(id="v2-alert-trend"),
                                    dcc.Graph(id="v2-breakdown"),
                                    html.Div(
                                        [
                                            dcc.Dropdown(
                                                id="v2-checkid-family-filter",
                                                options=[{"label": "All Families", "value": "__ALL__"}] + [{"label": f, "value": f} for f in families],
                                                value="__ALL__",
                                                clearable=False,
                                            ),
                                            dcc.Graph(id="v2-checkid-breakdown"),
                                        ]
                                    ),
                                ],
                                style={"display": "grid", "gridTemplateColumns": "1.1fr 1fr 1.2fr", "gap": "8px"},
                            ),
                            html.Div(
                                [
                                    html.H4("Top flagged outliers shortlist"),
                                    html.Div(
                                        [
                                            dcc.Dropdown(id="v2-top-filter-asset", options=[{"label": "All asset_class", "value": "__ALL__"}] + [{"label": x, "value": x} for x in assets], value="__ALL__", clearable=False),
                                            dcc.Dropdown(id="v2-top-filter-family", options=[{"label": "All family", "value": "__ALL__"}] + [{"label": x, "value": x} for x in families], value="__ALL__", clearable=False),
                                            dcc.Dropdown(id="v2-top-filter-check", options=[{"label": "All check_id", "value": "__ALL__"}] + [{"label": x, "value": x} for x in checks], value="__ALL__", clearable=False),
                                            dcc.Input(id="v2-top-n", type="number", value=10, min=1, step=1, placeholder="Top N"),
                                        ],
                                        style={"display": "grid", "gridTemplateColumns": "1fr 1fr 1fr 160px", "gap": "8px"},
                                    ),
                                    dag.AgGrid(
                                        id="v2-top10",
                                        columnDefs=[
                                            {"field": "risk_factor_id"},
                                            {"field": "date"},
                                            {"field": "value"},
                                            {"field": "shifts"},
                                            {"field": "prevValue"},
                                            {"field": "asset_class"},
                                            {"field": "family"},
                                            {"field": "check_id"},
                                            {"field": "raw_score"},
                                            {"field": "norm_score"},
                                            {"field": "worst_severity"},
                                            {"field": "peer_confirmed"},
                                        ],
                                        rowData=[],
                                        defaultColDef={"flex": 1, "sortable": True, "filter": True, "resizable": True},
                                        dashGridOptions={"rowSelection": "single"},
                                        style={"height": 320},
                                    ),
                                ],
                                style={"display": "grid", "gridTemplateColumns": "1fr", "gap": "8px"},
                            ),
                        ],
                    ),
                    dcc.Tab(
                        label="Hierarchy Drilldown",
                        value="tab2",
                        children=[
                            html.Div(
                                [
                                    dcc.Dropdown(
                                        id="v2-tab2-mode",
                                        options=[
                                            {"label": "Hierarchy mode", "value": "hierarchy"},
                                            {"label": "Analytic mode", "value": "analytic"},
                                        ],
                                        value="hierarchy",
                                        clearable=False,
                                    ),
                                    dcc.Dropdown(
                                        id="v2-tab2-group-by",
                                        options=[
                                            {"label": "asset_class", "value": "asset_class"},
                                            {"label": "rf_level1", "value": "rf_level1"},
                                            {"label": "rf_level1 + rf_level2", "value": "rf1_rf2"},
                                            {"label": "rf_level1 + rf_level2 + rf_level3", "value": "rf1_rf2_rf3"},
                                            {"label": "rf_level1 + rf_level2 + rf_level3 + rf_level4", "value": "rf1_rf2_rf3_rf4"},
                                            {"label": "rf_level1 + ... + rf_level5", "value": "rf1_rf2_rf3_rf4_rf5"},
                                        ],
                                        value="rf1_rf2",
                                        clearable=False,
                                    ),
                                    dcc.Dropdown(id="v2-tab2-rf-select", options=[], placeholder="select risk_factor_id", clearable=True),
                                    dcc.Dropdown(
                                        id="v2-tab2-peer-confirmed",
                                        options=[
                                            {"label": "peer_confirmed: all", "value": "all"},
                                            {"label": "peer_confirmed: true", "value": "true"},
                                            {"label": "peer_confirmed: false", "value": "false"},
                                        ],
                                        value="all",
                                        clearable=False,
                                    ),
                                    dcc.Input(id="v2-tab2-top-n", type="number", value=20, min=1, step=1, placeholder="Top N"),
                                ],
                                style={"display": "grid", "gridTemplateColumns": "1fr 1fr 1.3fr 1fr 120px", "gap": "8px", "marginBottom": "8px"},
                            ),
                            html.Div(
                                [
                                    dcc.Dropdown(id="v2-tab2-asset", options=[{"label": x, "value": x} for x in assets], multi=True, placeholder="asset_class"),
                                    dcc.Dropdown(id="v2-tab2-ccy", options=[{"label": x, "value": x} for x in ccy_vals], multi=True, placeholder="ccy"),
                                    dcc.Dropdown(id="v2-tab2-rf1", options=[{"label": x, "value": x} for x in rf1_vals], multi=True, placeholder="rf_level1"),
                                    dcc.Dropdown(id="v2-tab2-rf2", options=[{"label": x, "value": x} for x in rf2_vals], multi=True, placeholder="rf_level2"),
                                    dcc.Dropdown(id="v2-tab2-rf3", options=[{"label": x, "value": x} for x in rf3_vals], multi=True, placeholder="rf_level3"),
                                    dcc.Dropdown(id="v2-tab2-rf4", options=[{"label": x, "value": x} for x in rf4_vals], multi=True, placeholder="rf_level4"),
                                    dcc.Dropdown(id="v2-tab2-family", options=[{"label": x, "value": x} for x in families], multi=True, placeholder="family"),
                                    dcc.Dropdown(id="v2-tab2-check", options=[{"label": x, "value": x} for x in checks], multi=True, placeholder="check_id"),
                                    dcc.Dropdown(id="v2-tab2-severity", options=[{"label": x, "value": x} for x in ["Critical", "High", "Med", "Low"]], multi=True, placeholder="severity"),
                                    html.Div(
                                        [
                                            html.Div("Min norm_score", style={"fontSize": "12px", "marginBottom": "4px"}),
                                            dcc.Slider(id="v2-tab2-min-score", min=0.0, max=1.0, step=0.01, value=0.0, marks={0: "0.0", 0.5: "0.5", 1.0: "1.0"}),
                                        ]
                                    ),
                                ],
                                style={"display": "grid", "gridTemplateColumns": "repeat(5, 1fr)", "gap": "8px", "marginBottom": "8px"},
                            ),
                            html.Div(id="v2-tab2-kpis", style={"display": "grid", "gridTemplateColumns": "repeat(6,1fr)", "gap": "8px", "marginBottom": "8px"}),
                            html.Div(
                                [
                                    dag.AgGrid(
                                        id="v2-tree",
                                        enableEnterpriseModules=False,
                                        columnDefs=[
                                            {"field": "hierarchy_level", "headerName": "hierarchy_level"},
                                            {"field": "hierarchy_path", "headerName": "hierarchy_path"},
                                            {"field": "flagged_count", "headerName": "flagged_count", "type": "numericColumn"},
                                            {"field": "total_factors", "headerName": "total_factors", "type": "numericColumn"},
                                            {"field": "critical", "headerName": "critical", "type": "numericColumn"},
                                            {"field": "worst_severity", "headerName": "worst_severity"},
                                            {"field": "flag_rate", "headerName": "flag_rate (%)", "type": "numericColumn"},
                                            {"field": "trend_30d", "headerName": "trend_30d"},
                                        ],
                                        rowData=[],
                                        defaultColDef={"flex": 1, "sortable": True, "filter": True, "resizable": True},
                                        dashGridOptions={
                                            "treeData": True,
                                            "getDataPath": {"function": "getDataPath(params.data)"},
                                            "autoGroupColumnDef": {
                                                "headerName": "hierarchy_name",
                                                "minWidth": 340,
                                                "cellRendererParams": {"suppressCount": True},
                                            },
                                            "groupDefaultExpanded": 0,
                                            "rowSelection": "single",
                                            "rowBuffer": 30,
                                            "animateRows": True,
                                            "suppressAggFuncInHeader": True,
                                        },
                                        style={"height": 520},
                                    ),
                                    html.Div(
                                        [
                                            html.H4("Branch Summary"),
                                            dcc.Graph(id="v2-branch-trend"),
                                            dcc.Graph(id="v2-branch-reason"),
                                            html.Div(id="v2-context", style={"border": "1px solid #d0d7de", "padding": "8px"}),
                                        ]
                                    ),
                                ],
                                style={"display": "grid", "gridTemplateColumns": "1.3fr 1fr", "gap": "8px"},
                            ),
                            html.H4("Risk Factor Detail"),
                            html.Div(
                                [
                                    dcc.Dropdown(id="v2-tab2-rf-exact", options=[], placeholder="exact risk_factor_id", clearable=True),
                                    dcc.Dropdown(id="v2-tab2-series-check", options=[], multi=True, placeholder="Select check_id(s)"),
                                    dcc.RadioItems(
                                        id="v2-tab2-series-view",
                                        options=[
                                            {"label": "Overlay", "value": "overlay"},
                                            {"label": "Separate (vertical)", "value": "separate"},
                                            {"label": "Small multiples", "value": "small_multiples"},
                                        ],
                                        value="overlay",
                                        inline=True,
                                    ),
                                    dcc.Checklist(id="v2-overlay-toggle", options=[{"label": "Peer median +/-1s", "value": "peer_band"}, {"label": "Bollinger", "value": "bollinger"}, {"label": "Regime", "value": "regime"}, {"label": "Events", "value": "events"}], value=[], inline=True),
                                ],
                                style={"display": "grid", "gridTemplateColumns": "0.9fr 1.3fr 0.7fr 1fr", "gap": "8px", "marginBottom": "8px"},
                            ),
                            html.Div(
                                [
                                    dcc.DatePickerRange(
                                        id="v2-tab2-series-range",
                                        start_date=start_default,
                                        end_date=end_default,
                                        min_date_allowed=str(dmin.date()),
                                        max_date_allowed=str(dmax.date()),
                                        display_format="YYYY-MM-DD",
                                        minimum_nights=0,
                                        clearable=False,
                                    ),
                                    dcc.Checklist(
                                        id="v2-tab2-show-flag-window",
                                        options=[{"label": "Show only flagged window", "value": "flag_window"}],
                                        value=[],
                                        inline=True,
                                    ),
                                ],
                                style={"display": "grid", "gridTemplateColumns": "1fr 1fr", "gap": "8px", "marginBottom": "8px"},
                            ),
                            html.Div([dcc.Graph(id="v2-series"), dcc.Graph(id="v2-model-overlay")], style={"display": "grid", "gridTemplateColumns": "1fr 1fr", "gap": "8px"}),
                        ],
                    ),
                    dcc.Tab(
                        label="Model Comparison & Outliers Explorer",
                        value="tab3",
                        style={"display": "block" if SHOW_MODEL_COMPARISON_TAB else "none"},
                        selected_style={"display": "block" if SHOW_MODEL_COMPARISON_TAB else "none"},
                        children=[
                            html.Div([dcc.Dropdown(id="v2-compare-universe", options=[{"label": u, "value": u} for u in universes], placeholder="universe"), dcc.DatePickerRange(id="v2-compare-range", start_date=start_default, end_date=end_default, min_date_allowed=str(dmin.date()), max_date_allowed=str(dmax.date()), display_format="YYYY-MM-DD", minimum_nights=0, clearable=False), dcc.Dropdown(id="v2-compare-models", options=[{"label": c, "value": c} for c in checks], multi=True, placeholder="select 2-4 models"), dcc.Checklist(id="v2-compare-solo", options=[{"label": "Solo flags only", "value": "solo"}], value=[])], style={"display": "grid", "gridTemplateColumns": "1fr 1fr 2fr 1fr", "gap": "8px", "margin": "8px 0"}),
                            dag.AgGrid(id="v2-compare-ranked", columnDefs=[], rowData=[], defaultColDef={"flex": 1, "sortable": True, "filter": True}, dashGridOptions={"rowSelection": "single"}, style={"height": 260}),
                            html.Div([dcc.Graph(id="v2-overlap"), dcc.Graph(id="v2-score-corr")], style={"display": "grid", "gridTemplateColumns": "1fr 1fr", "gap": "8px"}),
                            dag.AgGrid(id="v2-disagreement", columnDefs=[], rowData=[], defaultColDef={"flex": 1, "sortable": True, "filter": True}, style={"height": 220}),
                            html.Div(id="v2-model-metrics", style={"border": "1px solid #d0d7de", "padding": "8px", "marginTop": "8px"}),
                            dcc.Graph(id="v2-model-perf"),
                            html.Details([html.Summary("Severity distribution"), dcc.Graph(id="v2-severity-dist")], open=True),
                            html.Details([html.Summary("Score histogram"), dcc.Graph(id="v2-score-hist")], open=False),
                        ],
                    ),
                    dcc.Tab(
                        label="Peer Group Explorer",
                        value="tab4",
                        children=[
                            html.Div([dcc.Dropdown(id="v2-peer-universe", options=[{"label": u, "value": u} for u in universes], placeholder="universe (optional)"), dcc.Dropdown(id="v2-peer-asset", options=[{"label": x, "value": x} for x in assets], placeholder="asset_class"), dcc.Dropdown(id="v2-peer-group", placeholder="peer group"), dcc.DatePickerRange(id="v2-peer-range", start_date=start_default, end_date=end_default, min_date_allowed=str(dmin.date()), max_date_allowed=str(dmax.date()), display_format="YYYY-MM-DD", minimum_nights=0, clearable=False)], style={"display": "grid", "gridTemplateColumns": "1fr 1fr 1fr 1fr", "gap": "8px", "margin": "8px 0"}),
                            dcc.Slider(id="v2-peer-date-slider", min=0, max=0, step=1, value=0, marks={0: "N/A"}),
                            html.Div([dcc.Graph(id="v2-peer-multiline"), dcc.Graph(id="v2-peer-cross")], style={"display": "grid", "gridTemplateColumns": "1fr 1fr", "gap": "8px"}),
                            dcc.Graph(id="v2-peer-corr"),
                            dag.AgGrid(id="v2-peer-health", columnDefs=[{"field": "peer_group"}, {"field": "member_count"}, {"field": "flagged_pct"}, {"field": "dispersion_mad"}, {"field": "worst_member"}, {"field": "avg_corr"}, {"field": "corr_stability"}], rowData=[], defaultColDef={"flex": 1, "sortable": True, "filter": True}, dashGridOptions={"rowSelection": "single"}, style={"height": 240}),
                            dcc.Graph(id="v2-factor-vs-peer"),
                        ],
                    ),
                    dcc.Tab(
                        label="Supervised Diagnostics",
                        value="tab5",
                        children=[
                            html.Div(id="v2-sup-summary", style={"border": "1px solid #d0d7de", "padding": "8px", "marginTop": "8px"}),
                            dag.AgGrid(
                                id="v2-sup-ablation",
                                columnDefs=[
                                    {"field": "experiment"},
                                    {"field": "candidate"},
                                    {"field": "primary_score"},
                                    {"field": "features_count"},
                                ],
                                rowData=[],
                                defaultColDef={"flex": 1, "sortable": True, "filter": True, "resizable": True},
                                style={"height": 220, "marginTop": "8px"},
                            ),
                            html.Div(
                                [dcc.Graph(id="v2-sup-prob-by-severity"), dcc.Graph(id="v2-sup-false-alarm-by-severity")],
                                style={"display": "grid", "gridTemplateColumns": "1fr 1fr", "gap": "8px"},
                            ),
                            html.Div(
                                [dcc.Graph(id="v2-sup-feature-importance"), dcc.Graph(id="v2-sup-feature-drift")],
                                style={"display": "grid", "gridTemplateColumns": "1fr 1fr", "gap": "8px"},
                            ),
                            html.Div(
                                [
                                    dag.AgGrid(
                                        id="v2-sup-top-global",
                                        columnDefs=[
                                            {"field": "feature"},
                                            {"field": "importance_norm"},
                                            {"field": "source_model"},
                                            {"field": "importance_method"},
                                        ],
                                        rowData=[],
                                        defaultColDef={"flex": 1, "sortable": True, "filter": True, "resizable": True},
                                        style={"height": 220},
                                    ),
                                    dag.AgGrid(
                                        id="v2-sup-top-local",
                                        columnDefs=[
                                            {"field": "risk_factor_id"},
                                            {"field": "date"},
                                            {"field": "feature"},
                                            {"field": "abs_contribution"},
                                            {"field": "local_rank"},
                                            {"field": "p_bad_data"},
                                        ],
                                        rowData=[],
                                        defaultColDef={"flex": 1, "sortable": True, "filter": True, "resizable": True},
                                        style={"height": 220},
                                    ),
                                ],
                                style={"display": "grid", "gridTemplateColumns": "1fr 1fr", "gap": "8px"},
                            ),
                        ],
                    ),
                ],
            ),
        ],
        style={"padding": "12px"},
    )

    def _apply_filters(state: dict[str, Any] | None) -> tuple[pd.DataFrame, pd.DataFrame]:
        f = (state or {}).get("filters", {})
        r = dq.copy()
        m = mem.copy()
        summary_scope = str(f.get("summary_scope", "latest_flagged"))
        asset = f.get("asset_class") or []
        ccy = f.get("ccy") or []
        rf1 = f.get("rf_level1") or []
        rf2 = f.get("rf_level2") or []
        rf3 = f.get("rf_level3") or []
        rf4 = f.get("rf_level4") or []
        universe = f.get("universe") or []
        family = f.get("family") or []
        check_ids = f.get("check_id") or []
        sev = f.get("severity") or []
        business_date = f.get("business_date")
        regime = f.get("regime") or ["all"]

        if asset:
            m = m[m["asset_class"].isin(asset)]
            r = r[r["risk_factor_id"].isin(m["risk_factor_id"])]
        if ccy:
            m = m[m["ccy"].isin(ccy)]
            r = r[r["risk_factor_id"].isin(m["risk_factor_id"])]
        if rf1:
            m = m[m["rf_level1"].isin(rf1)]
            r = r[r["risk_factor_id"].isin(m["risk_factor_id"])]
        if rf2:
            m = m[m["rf_level2"].isin(rf2)]
            r = r[r["risk_factor_id"].isin(m["risk_factor_id"])]
        if rf3:
            m = m[m["rf_level3"].isin(rf3)]
            r = r[r["risk_factor_id"].isin(m["risk_factor_id"])]
        if rf4:
            m = m[m["rf_level4"].isin(rf4)]
            r = r[r["risk_factor_id"].isin(m["risk_factor_id"])]
        if universe:
            if "universe_name" in m.columns:
                m = m[m["universe_name"].isin(universe)]
                r = r[r["risk_factor_id"].isin(m["risk_factor_id"])]
            if "universe_name" in r.columns:
                r = r[r["universe_name"].isin(universe)]
        if family:
            r = r[r["family"].isin(family)]
        if check_ids:
            r = r[r["check_id"].astype(str).isin([str(x) for x in check_ids])]
        if sev:
            r = r[r["severity"].isin(sev)]
        if business_date:
            biz_ts = pd.to_datetime(business_date, errors="coerce")
            if pd.notna(biz_ts):
                if "business_date" in r.columns:
                    r = r[pd.to_datetime(r["business_date"], errors="coerce").dt.normalize() == biz_ts.normalize()]
                if "business_date" in m.columns:
                    m = m[pd.to_datetime(m["business_date"], errors="coerce").dt.normalize() == biz_ts.normalize()]
        if regime and "all" not in regime:
            r = r[r["regime_bucket"].isin(regime)]

        sd = f.get("start_date")
        ed = f.get("end_date")
        use_date_range = summary_scope in {"latest_flagged", "selected_range", "range"}
        if use_date_range:
            if sd:
                r = r[r["date_norm"] >= pd.to_datetime(sd).normalize()]
            if ed:
                r = r[r["date_norm"] <= pd.to_datetime(ed).normalize()]

        return r, m

    def _filtered_ts(state: dict[str, Any] | None) -> pd.DataFrame:
        out = ts.copy()
        f = (state or {}).get("filters", {})
        business_date = f.get("business_date")
        if business_date and "business_date" in out.columns:
            biz_ts = pd.to_datetime(business_date, errors="coerce")
            if pd.notna(biz_ts):
                out = out[pd.to_datetime(out["business_date"], errors="coerce").dt.normalize() == biz_ts.normalize()]
        return out

    @app.callback(
        Output("v2-filter-universe", "options"),
        Output("v2-filter-universe", "value"),
        Input("v2-filter-asset", "value"),
        Input("v2-filter-ccy", "value"),
        Input("v2-filter-rf1", "value"),
        Input("v2-filter-rf2", "value"),
        Input("v2-filter-rf3", "value"),
        Input("v2-filter-rf4", "value"),
        State("v2-filter-universe", "value"),
    )
    def sync_universe_options(asset_vals, ccy_vals, rf1_vals, rf2_vals, rf3_vals, rf4_vals, current_vals):
        x = mem.copy()
        if asset_vals:
            x = x[x["asset_class"].isin(asset_vals)]
        if ccy_vals:
            x = x[x["ccy"].isin(ccy_vals)]
        if rf1_vals:
            x = x[x["rf_level1"].isin(rf1_vals)]
        if rf2_vals:
            x = x[x["rf_level2"].isin(rf2_vals)]
        if rf3_vals:
            x = x[x["rf_level3"].isin(rf3_vals)]
        if rf4_vals:
            x = x[x["rf_level4"].isin(rf4_vals)]
        vals = sorted(x.get("universe_name", pd.Series(dtype=str)).dropna().astype(str).unique().tolist())
        keep = [v for v in (current_vals or []) if v in vals]
        return [{"label": v, "value": v} for v in vals], keep

    @app.callback(
        Output("v2-filter-range", "disabled"),
        Output("v2-range-hint", "children"),
        Input("v2-filter-summary-scope", "value"),
        Input("v2-filter-range", "start_date"),
        Input("v2-filter-range", "end_date"),
    )
    def sync_range_controls(summary_scope, start_date, end_date):
        s_txt = str(start_date or "")
        e_txt = str(end_date or "")
        if summary_scope == "entire_range":
            return True, "Entire range mode: date picker is ignored."
        if summary_scope in {"selected_range", "range"}:
            return False, f"Selected UI range: {s_txt} -> {e_txt}"
        return False, f"Active range window (used to find latest flagged): {s_txt} -> {e_txt}"

    @app.callback(
        Output("v2-store", "data", allow_duplicate=True),
        Input("v2-filter-asset", "value"),
        Input("v2-filter-ccy", "value"),
        Input("v2-filter-rf1", "value"),
        Input("v2-filter-rf2", "value"),
        Input("v2-filter-rf3", "value"),
        Input("v2-filter-rf4", "value"),
        Input("v2-filter-universe", "value"),
        Input("v2-filter-family", "value"),
        Input("v2-filter-check", "value"),
        Input("v2-filter-sev", "value"),
        Input("v2-filter-business-date", "value"),
        Input("v2-filter-group-by", "value"),
        Input("v2-filter-summary-scope", "value"),
        Input("v2-filter-regime", "value"),
        Input("v2-filter-show-only", "value"),
        Input("v2-filter-range", "start_date"),
        Input("v2-filter-range", "end_date"),
        State("v2-store", "data"),
        prevent_initial_call=True,
    )
    def sync_filters(a, ccy, rf1, rf2, rf3, rf4, u, f, c, s, business_date, group_by, summary_scope, regime, show_only, start, end, state):
        cur = dict(state or {})
        cur["filters"] = {
            "asset_class": a or [],
            "ccy": ccy or [],
            "rf_level1": rf1 or [],
            "rf_level2": rf2 or [],
            "rf_level3": rf3 or [],
            "rf_level4": rf4 or [],
            "universe": u or [],
            "family": f or [],
            "check_id": c or [],
            "severity": s or [],
            "business_date": business_date or "",
            "group_by": group_by or "asset_class",
            "summary_scope": summary_scope or "latest_flagged",
            "regime": regime or ["all"],
            "show_only": show_only or "all",
            "start_date": start,
            "end_date": end,
        }
        return cur

    @app.callback(
        Output("v2-store", "data", allow_duplicate=True),
        Input("v2-tree", "selectedRows"),
        State("v2-store", "data"),
        prevent_initial_call=True,
    )
    def sync_tree_selection(rows, state):
        if not rows:
            return dash.no_update
        row = rows[0]
        cur = dict(state or {})
        cur["selected_branch_path"] = row.get("hierarchy", [])
        if row.get("is_leaf") and row.get("risk_factor_id"):
            cur["selected_risk_factor_id"] = row.get("risk_factor_id")
        return cur

    @app.callback(
        Output("v2-store", "data", allow_duplicate=True),
        Output("v2-tabs", "value", allow_duplicate=True),
        Input("v2-health-matrix", "clickData"),
        Input("v2-top10", "selectedRows"),
        Input("v2-compare-ranked", "selectedRows"),
        Input("v2-peer-health", "selectedRows"),
        State("v2-store", "data"),
        prevent_initial_call=True,
    )
    def nav_to_drilldown(heatmap_click, top10_rows, compare_rows, peer_rows, state):
        cur = dict(state or {})
        trig = dash.ctx.triggered_id
        if trig == "v2-health-matrix" and heatmap_click:
            p = heatmap_click.get("points", [{}])[0]
            fam = p.get("x")
            grp_val = p.get("y")
            filters = dict(cur.get("filters", {}))
            group_mode = str(filters.get("group_by", "asset_class"))
            if grp_val and group_mode == "asset_class":
                filters["asset_class"] = [grp_val]
            elif grp_val and group_mode.startswith("rf1"):
                filters["rf_level1"] = [str(grp_val).split(" | ")[0]]
            if fam:
                filters["family"] = [fam]
                filters["check_id"] = []
            cur["filters"] = filters
            cur["selected_branch_path"] = []
            return cur, "tab2"
        if trig == "v2-top10" and top10_rows:
            rf = top10_rows[0].get("risk_factor_id")
            if rf:
                cur["selected_risk_factor_id"] = rf
                return cur, "tab2"
        if trig == "v2-compare-ranked" and compare_rows:
            rf = compare_rows[0].get("risk_factor_id")
            if rf:
                cur["selected_risk_factor_id"] = rf
                return cur, "tab2"
        if trig == "v2-peer-health" and peer_rows:
            rf = peer_rows[0].get("selected_factor") or peer_rows[0].get("worst_member")
            if rf:
                cur["selected_risk_factor_id"] = rf
                return cur, "tab2"
        return dash.no_update, dash.no_update

    @app.callback(
        Output("v2-regime-banner", "children"),
        Output("v2-kpis", "children"),
        Output("v2-health-matrix", "figure"),
        Output("v2-alert-trend", "figure"),
        Output("v2-breakdown", "figure"),
        Output("v2-checkid-breakdown", "figure"),
        Output("v2-top10", "rowData"),
        Output("v2-debug-info", "children"),
        Input("v2-store", "data"),
        Input("v2-checkid-family-filter", "value"),
        Input("v2-top-filter-asset", "value"),
        Input("v2-top-filter-family", "value"),
        Input("v2-top-filter-check", "value"),
        Input("v2-top-n", "value"),
    )
    def refresh_summary(state, checkid_family_filter, top_asset_filter, top_family_filter, top_check_filter, top_n):
        r, m = _apply_filters(state)
        if r.empty:
            return "No rows for current filters", [], _empty_fig("DQ Health Matrix"), _empty_fig("Alerts"), _empty_fig("Breakdown of Severity Rank"), _empty_fig("Alert Distribution by Check"), [], str(state or {})

        filters = (state or {}).get("filters", {})
        summary_scope = str(filters.get("summary_scope", "latest_flagged"))
        group_mode = str(filters.get("group_by", "asset_class"))
        latest = _latest_date(r)
        flagged_any = r[r["flag"]].copy()
        snapshot_date = latest
        if summary_scope in {"entire_range", "selected_range", "range"}:
            f_scope = flagged_any.copy()
            if not flagged_any.empty:
                snapshot_date = pd.to_datetime(flagged_any["date_norm"], errors="coerce").max().normalize()
        else:
            f_scope = flagged_any[flagged_any["date_norm"] == snapshot_date].copy()
            if f_scope.empty and not flagged_any.empty:
                snapshot_date = pd.to_datetime(flagged_any["date_norm"], errors="coerce").max().normalize()
                f_scope = flagged_any[flagged_any["date_norm"] == snapshot_date].copy()

        # Market movers are intentionally hidden from Tab 1 UI for now.
        # Keep logic centralized here for easy re-enable with the final mover list.
        # market_movers = _market_movers_snapshot(r, f_scope)
        sd_txt = str(filters.get("start_date", "")).strip()
        ed_txt = str(filters.get("end_date", "")).strip()
        sd = pd.to_datetime(sd_txt, errors="coerce")
        ed = pd.to_datetime(ed_txt, errors="coerce")
        if pd.isna(sd):
            sd = pd.to_datetime(r["date_norm"], errors="coerce").min()
        if pd.isna(ed):
            ed = pd.to_datetime(r["date_norm"], errors="coerce").max()
        if pd.notna(sd) and pd.notna(ed):
            range_txt = f"{sd.normalize().date()} -> {ed.normalize().date()}"
        else:
            range_txt = "unavailable"

        if summary_scope in {"selected_range", "range"}:
            subtitle = f"Latest data date: {latest.date()} | Summary scope: selected range {range_txt}"
        elif summary_scope == "entire_range":
            full_start = pd.to_datetime(dq["date_norm"], errors="coerce").min()
            full_end = pd.to_datetime(dq["date_norm"], errors="coerce").max()
            if pd.notna(full_start) and pd.notna(full_end):
                full_txt = f"{full_start.normalize().date()} -> {full_end.normalize().date()}"
            else:
                full_txt = "unavailable"
            subtitle = f"Latest data date: {latest.date()} | Summary scope: entire range {full_txt}"
        else:
            subtitle = f"Latest data date: {latest.date()} | Latest flagged date: {snapshot_date.date()} | Active range: {range_txt}"
        banner = html.Div([html.Div(subtitle)])

        keys = f_scope[["risk_factor_id", "check_id"]].drop_duplicates()
        flagged_checks = int(len(keys))
        l7 = r[(r["flag"]) & (r["date_norm"] > snapshot_date - pd.Timedelta(days=7)) & (r["date_norm"] <= snapshot_date)].shape[0]
        p7 = r[(r["flag"]) & (r["date_norm"] > snapshot_date - pd.Timedelta(days=14)) & (r["date_norm"] <= snapshot_date - pd.Timedelta(days=7))].shape[0]
        if summary_scope == "entire_range":
            flagged_label = "Flagged in Entire Range"
        elif summary_scope in {"selected_range", "range"}:
            flagged_label = "Flagged in Selected Range"
        else:
            flagged_label = "Flagged @ Latest Flagged Date"

        kpis = [
            html.Div([html.B("Total Series"), html.Div(f"{int(m['risk_factor_id'].nunique()):,}")], style={"border": "1px solid #d0d7de", "padding": "8px"}),
            html.Div([html.B(flagged_label), html.Div(f"{int(f_scope.shape[0]):,}")], style={"border": "1px solid #d0d7de", "padding": "8px"}),
            html.Div([html.B("Flagged Checks"), html.Div(f"{flagged_checks:,}")], style={"border": "1px solid #d0d7de", "padding": "8px"}),
            html.Div([html.B("Critical"), html.Div(f"{int((f_scope['severity'] == 'Critical').sum()):,}")], style={"border": "1px solid #d0d7de", "padding": "8px"}),
            html.Div([html.B("7d Trend"), html.Div(_trend_arrow(l7, p7))], style={"border": "1px solid #d0d7de", "padding": "8px"}),
        ]

        hm_src = f_scope.copy()
        if not hm_src.empty:
            hm_src[RF_HIERARCHY_GROUP_COL] = _dqOutliersSum_grouping(hm_src, group_mode)
        hm = hm_src.groupby([RF_HIERARCHY_GROUP_COL, "family"], as_index=False).agg(severity_rank=("severity_rank", "max"), flags=("risk_factor_id", "count"), top_reason=("reason_code", lambda s: s.astype(str).value_counts().index[0] if not s.empty else "NA")) if not hm_src.empty else pd.DataFrame()
        fig_hm = _empty_fig("DQ Health Matrix") if hm.empty else px.density_heatmap(
            hm,
            x="family",
            y=RF_HIERARCHY_GROUP_COL,
            z="severity_rank",
            hover_data={"flags": True, "top_reason": True},
            color_continuous_scale="YlOrRd",
            title="DQ Health Heatmap Matrix",
        )

        ta = r[r["flag"]].groupby("date_norm", as_index=False).size().rename(columns={"size": "alerts"})
        fig_tr = _empty_fig("Alerts") if ta.empty else px.line(ta, x="date_norm", y="alerts", title="Alerts over time")
        for rw in regimes:
            fig_tr.add_vrect(x0=rw["start"], x1=rw["end"], fillcolor="#f8b4b4" if rw["tag"] == "stress" else "#ffcf99", opacity=0.18, line_width=0, annotation_text=rw["id"], annotation_position="top left")

        b_src = f_scope.copy()
        if not b_src.empty:
            b_src[RF_HIERARCHY_GROUP_COL] = _dqOutliersSum_grouping(b_src, group_mode)
        b = b_src.groupby([RF_HIERARCHY_GROUP_COL, "severity"], as_index=False).size().rename(columns={"size": "count"}) if not b_src.empty else pd.DataFrame()
        fig_b = (
            _empty_fig("Breakdown of Severity Rank")
            if b.empty
            else px.bar(
                b,
                x=RF_HIERARCHY_GROUP_COL,
                y="count",
                color="severity",
                barmode="stack",
                category_orders={"severity": ["Critical", "High", "Med", "Low"]},
                color_discrete_map=SEV_COLOR_MAP,
                title="Breakdown of Severity Rank",
            )
        )

        cb_src = f_scope.copy()
        if not cb_src.empty and str(checkid_family_filter or "__ALL__") != "__ALL__":
            cb_src = cb_src[cb_src["family"].astype(str) == str(checkid_family_filter)]
        if not cb_src.empty and "check_id" not in cb_src.columns:
            cb_src["check_id"] = "unknown"
        if not cb_src.empty:
            cb_src["check_id"] = cb_src["check_id"].fillna("unknown").astype(str)
        cb = (
            cb_src.groupby(["check_id", "severity"], as_index=False)
            .size()
            .rename(columns={"size": "alerts"})
            if not cb_src.empty
            else pd.DataFrame()
        )
        if cb.empty:
            fig_cb = _empty_fig("Alert Distribution by Check")
        else:
            order = (
                cb.groupby("check_id", as_index=False)["alerts"]
                .sum()
                .sort_values("alerts", ascending=False)["check_id"]
                .astype(str)
                .tolist()
            )
            title_suffix = " (All Families)" if str(checkid_family_filter or "__ALL__") == "__ALL__" else f" ({checkid_family_filter})"
            fig_cb = px.bar(
                cb,
                x="check_id",
                y="alerts",
                color="severity",
                category_orders={"check_id": order, "severity": ["Critical", "High", "Med", "Low"]},
                color_discrete_map=SEV_COLOR_MAP,
                title="Alert Distribution by Check and Severity" + title_suffix,
            )
            fig_cb.update_layout(barmode="stack")
            fig_cb.update_layout(xaxis_tickangle=-45)
        top_rows = []
        if not f_scope.empty:
            top_src = f_scope.copy()
            if str(top_asset_filter or "__ALL__") != "__ALL__":
                top_src = top_src[top_src["asset_class"].astype(str) == str(top_asset_filter)]
            if str(top_family_filter or "__ALL__") != "__ALL__":
                top_src = top_src[top_src["family"].astype(str) == str(top_family_filter)]
            if str(top_check_filter or "__ALL__") != "__ALL__":
                top_src = top_src[top_src["check_id"].astype(str) == str(top_check_filter)]

            if not top_src.empty:
                top_src["norm_score"] = pd.to_numeric(top_src["norm_score"], errors="coerce")
                if "raw_score" not in top_src.columns:
                    top_src["raw_score"] = np.nan
                top_src["raw_score"] = pd.to_numeric(top_src["raw_score"], errors="coerce")

                best = top_src.sort_values(["norm_score", "severity_rank"], ascending=[False, False]).drop_duplicates(subset=["risk_factor_id"], keep="first").copy()
                worst = top_src.groupby("risk_factor_id", as_index=False)["severity_rank"].max().rename(columns={"severity_rank": "worst_rank"})
                peer = top_src.groupby("risk_factor_id", as_index=False)["peer_confirmed"].max()
                best = best.drop(columns=["peer_confirmed"], errors="ignore")
                best = best.merge(worst, on="risk_factor_id", how="left").merge(peer, on="risk_factor_id", how="left")
                best["worst_severity"] = best["worst_rank"].map(REV_SEV)

                # Enrich shortlist rows with timeseries values for the flagged date.
                ts_enrich = _filtered_ts(state)
                if not ts_enrich.empty:
                    prev_candidates = ["prevValue", "prev_value", "prev_close_value", "prevCloseValue"]
                    prev_col = next((c for c in prev_candidates if c in ts_enrich.columns), None)
                    keep = ["risk_factor_id", "date_norm"]
                    if "value" in ts_enrich.columns:
                        keep.append("value")
                    if "shift" in ts_enrich.columns:
                        keep.append("shift")
                    if prev_col:
                        keep.append(prev_col)
                    tsv = ts_enrich[keep].copy().drop_duplicates(subset=["risk_factor_id", "date_norm"], keep="last")
                    ren = {}
                    if "shift" in tsv.columns:
                        ren["shift"] = "shifts"
                    if prev_col:
                        ren[prev_col] = "prevValue"
                    tsv = tsv.rename(columns=ren)
                    best = best.merge(tsv, on=["risk_factor_id", "date_norm"], how="left")
                if "value" not in best.columns:
                    best["value"] = np.nan
                if "shifts" not in best.columns:
                    best["shifts"] = np.nan
                if "prevValue" not in best.columns:
                    best["prevValue"] = np.nan
                best["date"] = pd.to_datetime(best["date_norm"], errors="coerce").dt.strftime("%Y-%m-%d")

                try:
                    top_n_int = int(top_n) if top_n is not None else 10
                except Exception:
                    top_n_int = 10
                top_n_int = max(1, min(top_n_int, 1000))

                top_rows = (
                    best.sort_values(["norm_score", "worst_rank"], ascending=[False, False])
                    .head(top_n_int)[["risk_factor_id", "date", "value", "shifts", "prevValue", "asset_class", "family", "check_id", "raw_score", "norm_score", "worst_severity", "peer_confirmed"]]
                    .round(4)
                    .to_dict("records")
                )

        dbg = {
            "filters": (state or {}).get("filters", {}),
            "selected_risk_factor_id": (state or {}).get("selected_risk_factor_id"),
            "selected_branch_path": (state or {}).get("selected_branch_path"),
            "rows_filtered": int(len(r)),
            "members_filtered": int(m["risk_factor_id"].nunique()) if not m.empty else 0,
            "latest_date": str(latest.date()),
            "snapshot_date": str(snapshot_date.date()),
            "flags_today": int(len(f_scope)),
        }
        return banner, kpis, fig_hm, fig_tr, fig_b, fig_cb, top_rows, str(dbg)

    @app.callback(
        Output("v2-tree", "rowData"),
        Output("v2-tab2-kpis", "children"),
        Output("v2-branch-trend", "figure"),
        Output("v2-branch-reason", "figure"),
        Output("v2-series", "figure"),
        Output("v2-model-overlay", "figure"),
        Output("v2-tab2-series-check", "options"),
        Output("v2-tab2-rf-exact", "options"),
        Output("v2-tab2-rf-select", "options"),
        Output("v2-context", "children"),
        Input("v2-store", "data"),
        Input("v2-tree", "selectedRows"),
        Input("v2-overlay-toggle", "value"),
        Input("v2-tab2-mode", "value"),
        Input("v2-tab2-group-by", "value"),
        Input("v2-tab2-rf-exact", "value"),
        Input("v2-tab2-rf-select", "value"),
        Input("v2-tab2-asset", "value"),
        Input("v2-tab2-ccy", "value"),
        Input("v2-tab2-rf1", "value"),
        Input("v2-tab2-rf2", "value"),
        Input("v2-tab2-rf3", "value"),
        Input("v2-tab2-rf4", "value"),
        Input("v2-tab2-family", "value"),
        Input("v2-tab2-check", "value"),
        Input("v2-tab2-severity", "value"),
        Input("v2-tab2-min-score", "value"),
        Input("v2-tab2-peer-confirmed", "value"),
        Input("v2-tab2-top-n", "value"),
        Input("v2-tab2-series-check", "value"),
        Input("v2-tab2-series-view", "value"),
        Input("v2-tab2-series-range", "start_date"),
        Input("v2-tab2-series-range", "end_date"),
        Input("v2-tab2-show-flag-window", "value"),
    )
    def refresh_drilldown(
        state,
        selected_rows,
        overlays,
        tab2_mode,
        tab2_group_by,
        rf_exact,
        rf_select,
        tab2_asset,
        tab2_ccy,
        tab2_rf1,
        tab2_rf2,
        tab2_rf3,
        tab2_rf4,
        tab2_family,
        tab2_check,
        tab2_severity,
        tab2_min_score,
        tab2_peer_confirmed,
        tab2_top_n,
        tab2_series_check,
        tab2_series_view,
        series_start_date,
        series_end_date,
        show_flag_window,
    ):
        mode = str(tab2_mode or "hierarchy")
        group_mode = str(tab2_group_by or "rf1_rf2")

        r = dq.copy()
        m = mem.copy()
        ts_view = ts.copy()

        exact_txt = str(rf_exact or "").strip()
        exact_ids: list[str] = []
        if exact_txt:
            exact_ids = (
                mem[mem["risk_factor_id"].astype(str).str.lower() == exact_txt.lower()]["risk_factor_id"]
                .astype(str)
                .drop_duplicates()
                .tolist()
            )
        exact_filter_applied = bool(exact_txt and exact_ids)
        if exact_filter_applied:
            m = mem[mem["risk_factor_id"].astype(str).isin(exact_ids)].copy()
        else:
            for col, vals in [
                ("asset_class", tab2_asset),
                ("ccy", tab2_ccy),
                ("rf_level1", tab2_rf1),
                ("rf_level2", tab2_rf2),
                ("rf_level3", tab2_rf3),
                ("rf_level4", tab2_rf4),
            ]:
                if vals:
                    m = m[m[col].astype(str).isin([str(v) for v in vals])]

        member_ids = m["risk_factor_id"].astype(str).unique().tolist()
        if member_ids:
            r = r[r["risk_factor_id"].astype(str).isin(member_ids)]
            ts_view = ts_view[ts_view["risk_factor_id"].astype(str).isin(member_ids)]
        else:
            r = r.iloc[0:0].copy()
            ts_view = ts_view.iloc[0:0].copy()

        if tab2_family:
            r = r[r["family"].astype(str).isin([str(v) for v in tab2_family])]
        if tab2_check:
            r = r[r["check_id"].astype(str).isin([str(v) for v in tab2_check])]
        if tab2_severity:
            r = r[r["severity"].astype(str).isin([str(v) for v in tab2_severity])]

        min_score = float(tab2_min_score or 0.0)
        r = r[pd.to_numeric(r["norm_score"], errors="coerce").fillna(0.0) >= min_score]

        if str(tab2_peer_confirmed or "all") in {"true", "false"}:
            want = str(tab2_peer_confirmed) == "true"
            r = r[r["peer_confirmed"].fillna(False).astype(bool) == want]

        flagged_scope = r[r["flag"]].copy()
        latest_flagged = _latest_date(flagged_scope if not flagged_scope.empty else r)
        flags_30d = flagged_scope[(flagged_scope["date_norm"] >= latest_flagged - pd.Timedelta(days=29)) & (flagged_scope["date_norm"] <= latest_flagged)].copy()
        tree_rows = _tree_rows(m, flagged_scope, flags_30d, path_mode=mode, group_mode=group_mode)

        rf_all = sorted(m["risk_factor_id"].dropna().astype(str).unique().tolist()) if not m.empty else []
        rf_candidates = rf_all
        rf_options = [{"label": x, "value": x} for x in rf_candidates[:2000]]

        sel = (selected_rows or [{}])[0]
        path = sel.get("hierarchy") or (state or {}).get("selected_branch_path", [])
        ids = _branch_members(m, [str(x) for x in path], path_mode=mode, group_mode=group_mode)
        if ids.empty:
            ids = m["risk_factor_id"].astype(str)

        branch_flags = flagged_scope[flagged_scope["risk_factor_id"].astype(str).isin(ids.astype(str))].copy()

        kpi_flagged_rfs = int(branch_flags["risk_factor_id"].nunique()) if not branch_flags.empty else 0
        kpi_flagged_checks = int(len(branch_flags[["risk_factor_id", "check_id"]].drop_duplicates())) if not branch_flags.empty else 0
        kpi_critical_pct = float((branch_flags["severity"] == "Critical").mean() * 100.0) if not branch_flags.empty else 0.0
        kpi_peer_pct = float(branch_flags["peer_confirmed"].fillna(False).astype(bool).mean() * 100.0) if not branch_flags.empty else 0.0
        kpi_median_norm = float(pd.to_numeric(branch_flags["norm_score"], errors="coerce").median()) if not branch_flags.empty else 0.0
        kpi_top_reason = str(branch_flags["reason_code"].astype(str).value_counts().index[0]) if not branch_flags.empty else "NA"
        tab2_kpis = [
            html.Div([html.B("Flagged RFs"), html.Div(f"{kpi_flagged_rfs:,}")], style={"border": "1px solid #d0d7de", "padding": "8px"}),
            html.Div([html.B("Flagged Checks"), html.Div(f"{kpi_flagged_checks:,}")], style={"border": "1px solid #d0d7de", "padding": "8px"}),
            html.Div([html.B("% Critical"), html.Div(f"{kpi_critical_pct:.1f}%")], style={"border": "1px solid #d0d7de", "padding": "8px"}),
            html.Div([html.B("% Peer Confirmed"), html.Div(f"{kpi_peer_pct:.1f}%")], style={"border": "1px solid #d0d7de", "padding": "8px"}),
            html.Div([html.B("Median norm_score"), html.Div(f"{kpi_median_norm:.4f}")], style={"border": "1px solid #d0d7de", "padding": "8px"}),
            html.Div([html.B("Top reason_code"), html.Div(kpi_top_reason)], style={"border": "1px solid #d0d7de", "padding": "8px"}),
        ]

        bt = branch_flags.groupby("date_norm", as_index=False).size().rename(columns={"size": "alerts"}) if not branch_flags.empty else pd.DataFrame()
        fig_bt = _empty_fig("Branch Alerts Over Time") if bt.empty else px.line(bt, x="date_norm", y="alerts", title="Branch Alerts Over Time")

        br = branch_flags.groupby("reason_code", as_index=False).size().rename(columns={"size": "alerts"}) if not branch_flags.empty else pd.DataFrame()
        if br.empty:
            fig_reason = _empty_fig("Reason Code Distribution")
        else:
            br = br.sort_values("alerts", ascending=False).head(30)
            fig_reason = px.bar(br, x="reason_code", y="alerts", title="Reason Code Distribution")
            fig_reason.update_layout(xaxis_tickangle=-35)

        rf = (state or {}).get("selected_risk_factor_id")
        if sel.get("is_leaf") and sel.get("risk_factor_id"):
            rf = sel.get("risk_factor_id")
        if exact_filter_applied and rf_all:
            rf = rf_all[0]
        if rf_select:
            rf = str(rf_select)
        if not rf and rf_candidates:
            rf = rf_candidates[0]

        if not rf:
            msg = html.Div("Select a tree node and/or select risk_factor_id to investigate flagged points.")
            return tree_rows, tab2_kpis, fig_bt, fig_reason, _empty_fig("Select risk_factor_id"), _empty_fig("Check score comparison"), [], rf_options, rf_options, msg

        t = get_risk_factor_series(ts_view, rf, series_start_date, series_end_date)
        issues_all = get_flagged_points(r, rf, None, series_start_date, series_end_date)
        check_pool = r[r["risk_factor_id"].astype(str) == str(rf)]
        check_vals = sorted(check_pool.get("check_id", pd.Series(dtype=str)).dropna().astype(str).unique().tolist())
        check_options = [{"label": x, "value": x} for x in check_vals]
        selected_checks = [str(x) for x in (tab2_series_check or []) if str(x) in check_vals][:16]
        if not selected_checks and check_vals:
            selected_checks = check_vals
        issues = get_flagged_points(r, rf, selected_checks, series_start_date, series_end_date)
        flagged_with_values = _join_flagged_with_series(issues, t)

        if "flag_window" in (show_flag_window or []) and not flagged_with_values.empty:
            d0 = pd.to_datetime(flagged_with_values["date_norm"], errors="coerce").min() - pd.Timedelta(days=5)
            d1 = pd.to_datetime(flagged_with_values["date_norm"], errors="coerce").max() + pd.Timedelta(days=5)
            t = t[(t["date_norm"] >= d0) & (t["date_norm"] <= d1)].copy()
            flagged_with_values = _join_flagged_with_series(issues, t)

        mode_plot = str(tab2_series_view or "overlay")
        if mode_plot == "overlay":
            fig_series = build_overlay_figure(t, flagged_with_values, rf)
        else:
            fig_series = build_separate_figures_layout(t, flagged_with_values, rf, selected_checks, mode="small_multiples" if mode_plot == "small_multiples" else "separate")

        if "peer_band" in (overlays or []) and not t.empty and mode_plot == "overlay":
            meta = m[m["risk_factor_id"].astype(str) == str(rf)]
            if not meta.empty:
                mm = meta.iloc[0]
                peers = m[(m["rf_level1"] == mm.get("rf_level1")) & (m["rf_level2"] == mm.get("rf_level2")) & (m["rf_level3"] == mm.get("rf_level3"))]["risk_factor_id"].astype(str)
                p = ts_view[(ts_view["risk_factor_id"].astype(str).isin(peers)) & (ts_view["date_norm"].isin(t["date_norm"]))]
                if not p.empty:
                    pa = p.groupby("date_norm", as_index=False)["value"].agg(peer_median="median", peer_std="std")
                    jj = t.merge(pa, on="date_norm", how="left")
                    fig_series.add_trace(go.Scatter(x=jj["date_norm"], y=jj["peer_median"], mode="lines", name="peer median", line={"dash": "dash"}))
                    fig_series.add_trace(go.Scatter(x=jj["date_norm"], y=jj["peer_median"] + jj["peer_std"].fillna(0.0), mode="lines", name="peer +1s", line={"dash": "dot"}))
                    fig_series.add_trace(go.Scatter(x=jj["date_norm"], y=jj["peer_median"] - jj["peer_std"].fillna(0.0), mode="lines", name="peer -1s", line={"dash": "dot"}))

        fig_model = _empty_fig("Flagged points by check_id")
        if not flagged_with_values.empty:
            score_col = "normalized_score" if "normalized_score" in flagged_with_values.columns else "norm_score" if "norm_score" in flagged_with_values.columns else None
            y_col = score_col or "value"
            fig_model = px.line(
                flagged_with_values.sort_values("date_norm"),
                x="date_norm",
                y=y_col,
                color="check_id",
                markers=True,
                title="Flagged points by check_id",
            )

        first_flag = pd.to_datetime(flagged_with_values["date_norm"], errors="coerce").min() if not flagged_with_values.empty else pd.NaT
        last_flag = pd.to_datetime(flagged_with_values["date_norm"], errors="coerce").max() if not flagged_with_values.empty else pd.NaT
        peer_rate = float(flagged_with_values["peer_confirmed"].fillna(False).astype(bool).mean() * 100.0) if not flagged_with_values.empty and "peer_confirmed" in flagged_with_values.columns else 0.0
        depth_counts: dict[int, int] = {}
        for rw in tree_rows:
            depth = len(rw.get("hierarchy", []))
            depth_counts[depth] = depth_counts.get(depth, 0) + 1
        depth_debug = ", ".join(f"L{k}:{depth_counts[k]}" for k in sorted(depth_counts)) if depth_counts else "none"
        summary = html.Div(
            [
                html.Div(f"risk_factor_id: {rf}"),
                html.Div(f"exact filter: {'applied' if exact_filter_applied else ('not found' if exact_txt else 'off')}"),
                html.Div(f"selected checks: {len(selected_checks)}"),
                html.Div(f"flagged events: {int(len(flagged_with_values))}"),
                html.Div(f"first flagged date: {first_flag.date() if pd.notna(first_flag) else 'N/A'}"),
                html.Div(f"last flagged date: {last_flag.date() if pd.notna(last_flag) else 'N/A'}"),
                html.Div(f"peer confirmed rate: {peer_rate:.1f}%"),
                html.Div(f"debug: tree_nodes={len(tree_rows)}, tree_depths={depth_debug}, rf_options={len(rf_options)}, raw_points={len(t)}, flagged_points={len(flagged_with_values)}"),
            ],
            style={"display": "grid", "gap": "4px"},
        )

        return tree_rows, tab2_kpis, fig_bt, fig_reason, fig_series, fig_model, check_options, rf_options, rf_options, summary

    @app.callback(
        Output("v2-compare-ranked", "columnDefs"),
        Output("v2-compare-ranked", "rowData"),
        Output("v2-overlap", "figure"),
        Output("v2-disagreement", "columnDefs"),
        Output("v2-disagreement", "rowData"),
        Output("v2-score-corr", "figure"),
        Output("v2-model-metrics", "children"),
        Output("v2-model-perf", "figure"),
        Output("v2-severity-dist", "figure"),
        Output("v2-score-hist", "figure"),
        Input("v2-compare-universe", "value"),
        Input("v2-compare-models", "value"),
        Input("v2-compare-range", "start_date"),
        Input("v2-compare-range", "end_date"),
        Input("v2-compare-solo", "value"),
        State("v2-store", "data"),
        State("v2-triage-labels", "data"),
    )
    def refresh_compare(universe, models, start, end, solo, state, triage_labels):
        filters = (state or {}).get("filters", {})
        group_mode = str(filters.get("group_by", "asset_class"))
        r, _ = _apply_filters(state)
        if universe and "universe_name" in r.columns:
            r = r[r["universe_name"] == universe]
        if start:
            r = r[r["date_norm"] >= pd.to_datetime(start).normalize()]
        if end:
            r = r[r["date_norm"] <= pd.to_datetime(end).normalize()]
        if r.empty:
            return [], [], _empty_fig("Overlap"), [], [], _empty_fig("Score correlation"), "No rows", _empty_fig("Performance"), _empty_fig("Severity"), _empty_fig("Histogram")

        sel_models = [str(m) for m in (models or []) if str(m).strip()]
        if not sel_models:
            sel_models = r.groupby("check_id")["flag"].sum().sort_values(ascending=False).head(3).index.astype(str).tolist()
        sel_models = sel_models[:4]

        f = r[r["check_id"].astype(str).isin(sel_models)].copy()
        if "solo" in (solo or []):
            c = f[f["flag"]].groupby(["risk_factor_id", "date_norm"], as_index=False)["check_id"].nunique().rename(columns={"check_id": "n"})
            keys = c[c["n"] == 1][["risk_factor_id", "date_norm"]]
            f = f.merge(keys, on=["risk_factor_id", "date_norm"], how="inner")
        if f.empty:
            return [], [], _empty_fig("Overlap"), [], [], _empty_fig("Score correlation"), "No rows after model filters", _empty_fig("Performance"), _empty_fig("Severity"), _empty_fig("Histogram")

        score = f.groupby(["risk_factor_id", "check_id"], as_index=False)["norm_score"].max().pivot(index="risk_factor_id", columns="check_id", values="norm_score")
        fp = f.groupby(["risk_factor_id", "check_id"], as_index=False)["flag"].max().pivot(index="risk_factor_id", columns="check_id", values="flag").fillna(False).astype(bool)

        ranked = pd.DataFrame(index=score.index.union(fp.index))
        ranked.index.name = "risk_factor_id"
        ranked = ranked.reset_index()
        for m in sel_models:
            ranked[f"score_{m}"] = score.get(m, pd.Series(dtype=float)).reindex(ranked["risk_factor_id"]).values
            ranked[f"flag_{m}"] = fp.get(m, pd.Series(dtype=bool)).reindex(ranked["risk_factor_id"]).fillna(False).values
        ranked["max_norm_score"] = ranked[[c for c in ranked.columns if c.startswith("score_")]].max(axis=1, skipna=True)
        ranked["consensus"] = ranked[[c for c in ranked.columns if c.startswith("flag_")]].sum(axis=1)
        meta_cols = [c for c in ["risk_factor_id", "asset_class", "ccy", "rf_level1", "rf_level2", "rf_level3", "rf_level4", "rf_level5"] if c in mem.columns]
        ranked = ranked.merge(mem[meta_cols].drop_duplicates(subset=["risk_factor_id"]), on="risk_factor_id", how="left")
        ranked["group_key"] = _dqOutliersSum_grouping(ranked, group_mode)
        ranked = ranked.sort_values("max_norm_score", ascending=False).head(800)

        cdefs = [{"field": "risk_factor_id"}, {"field": "asset_class"}, {"field": "ccy"}, {"field": "group_key"}, {"field": "max_norm_score"}, {"field": "consensus"}]
        for m in sel_models:
            cdefs.extend([{"field": f"score_{m}"}, {"field": f"flag_{m}"}])

        sets = {m: set(f[(f["check_id"].astype(str) == m) & (f["flag"])]["risk_factor_id"].astype(str).unique().tolist()) for m in sel_models}
        combos = []
        all_ids = sorted(set().union(*sets.values())) if sets else []
        for rf in all_ids:
            bits = tuple(1 if rf in sets[m] else 0 for m in sel_models)
            combos.append({"signature": "|".join([sel_models[i] for i, b in enumerate(bits) if b == 1]) or "none", "bits": "".join(str(b) for b in bits)})
        ov = pd.DataFrame(combos).groupby(["bits", "signature"], as_index=False).size().rename(columns={"size": "count"}) if combos else pd.DataFrame()
        fig_ov = _empty_fig("Overlap") if ov.empty else px.bar(ov.sort_values("count", ascending=False), x="signature", y="count", title="Model agreement overlap (Upset-style)")

        ddefs = [{"field": "risk_factor_id"}, {"field": "date"}, {"field": "model_a"}, {"field": "model_b"}, {"field": "score_a"}, {"field": "score_b"}, {"field": "flag_a"}, {"field": "flag_b"}]
        drows: list[dict[str, Any]] = []
        fig_corr = _empty_fig("Score correlation")
        if len(sel_models) >= 2:
            a, b = sel_models[:2]
            base = f[f["check_id"].astype(str).isin([a, b])].groupby(["risk_factor_id", "date_norm", "check_id"], as_index=False).agg(score=("norm_score", "max"), flag=("flag", "max"))
            a_df = base[base["check_id"].astype(str) == a].rename(columns={"score": "score_a", "flag": "flag_a"})
            b_df = base[base["check_id"].astype(str) == b].rename(columns={"score": "score_b", "flag": "flag_b"})
            cmp = a_df[["risk_factor_id", "date_norm", "score_a", "flag_a"]].merge(b_df[["risk_factor_id", "date_norm", "score_b", "flag_b"]], on=["risk_factor_id", "date_norm"], how="outer")
            cmp[["flag_a", "flag_b"]] = cmp[["flag_a", "flag_b"]].fillna(False)
            dis = cmp[cmp["flag_a"] != cmp["flag_b"]].head(1000)
            if not dis.empty:
                dis["date"] = pd.to_datetime(dis["date_norm"]).dt.strftime("%Y-%m-%d")
                dis["model_a"] = a
                dis["model_b"] = b
                drows = dis[["risk_factor_id", "date", "model_a", "model_b", "score_a", "score_b", "flag_a", "flag_b"]].to_dict("records")

            corr = f[f["check_id"].astype(str).isin([a, b])].groupby(["risk_factor_id", "check_id"], as_index=False)["norm_score"].max().pivot(index="risk_factor_id", columns="check_id", values="norm_score").dropna().reset_index()
            if not corr.empty and a in corr.columns and b in corr.columns:
                corr["group"] = "all"
                fig_corr = px.scatter(corr, x=a, y=b, color="group", title=f"Score correlation: {a} vs {b}")

        sev = f[f["flag"]].groupby(["check_id", "severity"], as_index=False).size().rename(columns={"size": "count"})
        fig_sev = _empty_fig("Severity distribution") if sev.empty else px.bar(sev, x="check_id", y="count", color="severity", title="Severity distribution per model")
        fig_hist = _empty_fig("Score histogram") if f.empty else px.histogram(f, x="norm_score", color="check_id", nbins=40, barmode="overlay", title="Score histogram")

        metrics = "No triage labels yet"
        fig_perf = _empty_fig("Model performance")
        lbl = pd.DataFrame(triage_labels or [])
        if not lbl.empty and {"risk_factor_id", "action"}.issubset(lbl.columns):
            lbl["date"] = pd.to_datetime(lbl.get("date"), errors="coerce").dt.normalize()
            lbl["truth"] = lbl["action"].map(_action_truth)
            lbl = lbl[lbl["truth"].notna()]
            if not lbl.empty:
                events_df = lbl[["risk_factor_id", "date", "truth"]].dropna().drop_duplicates()
                preds = r[r["check_id"].astype(str).isin(sel_models)].groupby(["risk_factor_id", "date_norm", "check_id"], as_index=False)["flag"].max().rename(columns={"date_norm": "date"})
                rows = []
                for m in sel_models:
                    pm = preds[preds["check_id"].astype(str) == m][["risk_factor_id", "date", "flag"]]
                    j = events_df.merge(pm, on=["risk_factor_id", "date"], how="left")
                    j["flag"] = j["flag"].fillna(False)
                    tp = int(((j["truth"] == 1) & (j["flag"])).sum())
                    fp = int(((j["truth"] == 0) & (j["flag"])).sum())
                    fn = int(((j["truth"] == 1) & (~j["flag"])).sum())
                    precision = tp / (tp + fp) if (tp + fp) > 0 else np.nan
                    recall = tp / (tp + fn) if (tp + fn) > 0 else np.nan
                    far = fp / (tp + fp) if (tp + fp) > 0 else np.nan
                    rows.append({"model": m, "precision": precision, "recall": recall, "false_alarm_rate": far})
                perf = pd.DataFrame(rows)
                if not perf.empty:
                    fig_perf = px.bar(perf.melt(id_vars=["model"], value_vars=["precision", "recall", "false_alarm_rate"], var_name="metric", value_name="value"), x="model", y="value", color="metric", barmode="group", title="Model performance from triage labels")
                    metrics = html.Ul([html.Li(f"{x['model']}: precision={x['precision']:.3f} recall={x['recall']:.3f} false_alarm_rate={x['false_alarm_rate']:.3f}") for _, x in perf.iterrows()])

        return cdefs, ranked.round(4).to_dict("records"), fig_ov, ddefs, drows, fig_corr, metrics, fig_perf, fig_sev, fig_hist

    @app.callback(
        Output("v2-sup-summary", "children"),
        Output("v2-sup-ablation", "rowData"),
        Output("v2-sup-prob-by-severity", "figure"),
        Output("v2-sup-false-alarm-by-severity", "figure"),
        Output("v2-sup-feature-importance", "figure"),
        Output("v2-sup-feature-drift", "figure"),
        Output("v2-sup-top-global", "rowData"),
        Output("v2-sup-top-local", "rowData"),
        Input("v2-store", "data"),
    )
    def refresh_supervised_diagnostics(state):
        r, _ = _apply_filters(state)
        p_bad = pd.to_numeric(r["p_bad_data"], errors="coerce") if "p_bad_data" in r.columns else pd.Series(index=r.index, dtype=float)
        p_false = pd.to_numeric(r["false_alarm_probability"], errors="coerce") if "false_alarm_probability" in r.columns else pd.Series(index=r.index, dtype=float)
        s = r.get("severity", pd.Series("Low", index=r.index)).astype(str) if not r.empty else pd.Series(dtype=str)
        prob_df = pd.DataFrame({"p_bad_data": p_bad, "false_alarm_probability": p_false, "severity": s})

        fig_pbad = _empty_fig("p_bad_data by severity")
        tmp_bad = prob_df.dropna(subset=["p_bad_data"])
        if not tmp_bad.empty:
            fig_pbad = px.histogram(tmp_bad, x="p_bad_data", color="severity", nbins=40, title="p_bad_data by severity")

        fig_false = _empty_fig("False alarm probability by severity")
        tmp_false = prob_df.dropna(subset=["false_alarm_probability"])
        if not tmp_false.empty:
            fig_false = px.histogram(tmp_false, x="false_alarm_probability", color="severity", nbins=40, title="False alarm probability by severity")

        artifact = {}
        if "triage_artifacts_json" in r.columns:
            for v in r["triage_artifacts_json"].dropna().astype(str):
                parsed = _parse_json_dict(v)
                if parsed:
                    artifact = parsed
                    break

        triage_info = {}
        ablation_rows: list[dict[str, Any]] = []
        if not triage_model_data.empty:
            tm = triage_model_data.iloc[-1].to_dict()
            details = _parse_json_dict(tm.get("details", {}))
            triage_info = {
                "enabled": bool(tm.get("enabled", False)),
                "model_name": str(tm.get("model_name", "")),
                "auc": tm.get("auc"),
                "accuracy": tm.get("accuracy"),
                "precision": tm.get("precision"),
                "recall": tm.get("recall"),
                "candidates_tried": _parse_json_list(tm.get("candidates_tried", [])),
                "details": details,
            }
            ablation_rows = _parse_json_list(details.get("ablation_results", []))
            if not ablation_rows:
                ablation_rows = _parse_json_list(tm.get("ablation_results", []))

        summary_items = [
            html.Li(f"Supervised enabled: {bool(artifact.get('supervised_enabled', False) or triage_info.get('enabled', False))}"),
            html.Li(f"Selected model: {triage_info.get('model_name') or artifact.get('supervised_model', 'N/A')}"),
            html.Li(f"Target label: {artifact.get('target_label_col', 'N/A')}"),
            html.Li(f"Training mode: {artifact.get('training_mode', 'N/A')}"),
            html.Li(f"Calibration: {artifact.get('calibration_method', 'none')} (applied={artifact.get('calibration_applied', False)})"),
            html.Li(f"Rows with p_bad_data: {int(p_bad.notna().sum())} / {len(r)}"),
            html.Li(f"Filtered dq rows: {len(r)}"),
            html.Li(f"feature_importance_global rows: {len(fi_global_data)} | feature_importance_local rows: {len(fi_local_data)}"),
        ]
        if len(r) == 0:
            summary_items.append(html.Li("No dq rows under current filters/date; adjust top-level filters/date range."))
        if "p_bad_data" not in r.columns and len(r) > 0:
            summary_items.append(html.Li("Loaded dq_results has no p_bad_data column. Use Layer 6 triaged_preview dataset for supervised diagnostics."))
        if triage_info:
            summary_items.extend(
                [
                    html.Li(f"AUC: {float(triage_info.get('auc')):.4f}" if pd.notna(triage_info.get("auc")) else "AUC: N/A"),
                    html.Li(f"Accuracy: {float(triage_info.get('accuracy')):.4f}" if pd.notna(triage_info.get("accuracy")) else "Accuracy: N/A"),
                    html.Li(f"Precision: {float(triage_info.get('precision')):.4f}" if pd.notna(triage_info.get("precision")) else "Precision: N/A"),
                    html.Li(f"Recall: {float(triage_info.get('recall')):.4f}" if pd.notna(triage_info.get("recall")) else "Recall: N/A"),
                    html.Li(f"Candidates tried: {', '.join(triage_info.get('candidates_tried', [])) or 'N/A'}"),
                ]
            )
        summary = html.Ul(summary_items)

        fig_fi = _empty_fig("Global feature importance")
        top_global_rows: list[dict[str, Any]] = []
        if not fi_global_data.empty:
            g = fi_global_data.copy()
            if "importance_norm" not in g.columns:
                g["importance"] = pd.to_numeric(g.get("importance"), errors="coerce").fillna(0.0)
                total = float(g["importance"].sum())
                g["importance_norm"] = g["importance"] / total if total > 0.0 else 0.0
            g = g.sort_values("importance_norm", ascending=False).head(30)
            fig_fi = px.bar(g, x="feature", y="importance_norm", color="source_model" if "source_model" in g.columns else None, title="Global feature importance (top 30)")
            top_global_rows = g[[c for c in ["feature", "importance_norm", "source_model", "importance_method"] if c in g.columns]].round(6).to_dict("records")

        fig_drift = _empty_fig("Feature drift")
        if not fi_drift_components_data.empty and "abs_delta" in fi_drift_components_data.columns:
            d = fi_drift_components_data.copy().sort_values("abs_delta", ascending=False).head(25)
            fig_drift = px.bar(d, x="feature", y="abs_delta", title="Feature importance drift (abs_delta, top 25)")
        elif not fi_drift_data.empty and {"psi_total", "psi_threshold"}.issubset(fi_drift_data.columns):
            d = fi_drift_data.copy().head(1)
            d = pd.DataFrame(
                {
                    "metric": ["psi_total", "psi_threshold"],
                    "value": [float(pd.to_numeric(d["psi_total"], errors="coerce").fillna(0.0).iloc[0]), float(pd.to_numeric(d["psi_threshold"], errors="coerce").fillna(0.0).iloc[0])],
                }
            )
            fig_drift = px.bar(d, x="metric", y="value", title="Feature importance drift summary")

        top_local_rows: list[dict[str, Any]] = []
        if not fi_local_data.empty:
            l = fi_local_data.copy()
            l["abs_contribution"] = pd.to_numeric(l.get("abs_contribution"), errors="coerce")
            l["p_bad_data"] = pd.to_numeric(l.get("p_bad_data"), errors="coerce")
            if "date" in l.columns:
                l["date"] = pd.to_datetime(l["date"], errors="coerce").dt.strftime("%Y-%m-%d")
            l = l.sort_values(["p_bad_data", "local_rank"], ascending=[False, True]).head(300)
            cols = [c for c in ["risk_factor_id", "date", "feature", "abs_contribution", "local_rank", "p_bad_data"] if c in l.columns]
            top_local_rows = l[cols].round(6).to_dict("records")

        return summary, ablation_rows, fig_pbad, fig_false, fig_fi, fig_drift, top_global_rows, top_local_rows

    @app.callback(
        Output("v2-peer-group", "options"),
        Output("v2-peer-group", "value"),
        Input("v2-peer-asset", "value"),
        Input("v2-peer-universe", "value"),
        State("v2-peer-group", "value"),
    )
    def peer_group_options(asset, universe, current):
        x = mem.copy()
        if asset:
            x = x[x["asset_class"] == asset]
        if universe and "universe_name" in x.columns:
            x = x[x["universe_name"] == universe]
        vals = sorted(x.get("rf_level3", pd.Series(dtype=str)).dropna().astype(str).unique().tolist())
        return [{"label": v, "value": v} for v in vals], current if current in vals else (vals[0] if vals else None)

    @app.callback(
        Output("v2-peer-date-map", "data"),
        Output("v2-peer-date-slider", "min"),
        Output("v2-peer-date-slider", "max"),
        Output("v2-peer-date-slider", "value"),
        Output("v2-peer-date-slider", "marks"),
        Input("v2-peer-asset", "value"),
        Input("v2-peer-universe", "value"),
        Input("v2-peer-group", "value"),
        Input("v2-peer-range", "start_date"),
        Input("v2-peer-range", "end_date"),
        State("v2-store", "data"),
    )
    def peer_date_slider(asset, universe, group, start_date, end_date, state):
        x = mem.copy()
        if asset:
            x = x[x["asset_class"] == asset]
        if universe and "universe_name" in x.columns:
            x = x[x["universe_name"] == universe]
        if group:
            x = x[x["rf_level3"] == group]
        ids = x["risk_factor_id"].astype(str).unique().tolist()
        ts_view = _filtered_ts(state)
        t = ts_view[ts_view["risk_factor_id"].isin(ids)]
        if start_date:
            t = t[t["date_norm"] >= pd.to_datetime(start_date).normalize()]
        if end_date:
            t = t[t["date_norm"] <= pd.to_datetime(end_date).normalize()]
        dates = sorted(pd.to_datetime(t.get("date_norm", pd.Series(dtype="datetime64[ns]")), errors="coerce").dropna().dt.normalize().unique().tolist())
        dmap = [str(pd.Timestamp(d).date()) for d in dates]
        if not dmap:
            return [], 0, 0, 0, {0: "N/A"}
        marks = {0: dmap[0], len(dmap) // 2: dmap[len(dmap) // 2], len(dmap) - 1: dmap[-1]}
        return dmap, 0, len(dmap) - 1, len(dmap) - 1, marks

    @app.callback(
        Output("v2-peer-multiline", "figure"),
        Output("v2-peer-cross", "figure"),
        Output("v2-peer-corr", "figure"),
        Output("v2-peer-health", "rowData"),
        Output("v2-factor-vs-peer", "figure"),
        Input("v2-peer-asset", "value"),
        Input("v2-peer-universe", "value"),
        Input("v2-peer-group", "value"),
        Input("v2-peer-range", "start_date"),
        Input("v2-peer-range", "end_date"),
        Input("v2-peer-date-map", "data"),
        Input("v2-peer-date-slider", "value"),
        Input("v2-peer-health", "selectedRows"),
        State("v2-store", "data"),
    )
    def refresh_peer(asset, universe, group, start_date, end_date, date_map, slider_idx, peer_rows, state):
        x = mem.copy()
        if asset:
            x = x[x["asset_class"] == asset]
        if universe and "universe_name" in x.columns:
            x = x[x["universe_name"] == universe]
        gf = x.copy()
        if group:
            gf = gf[gf["rf_level3"] == group]

        ids = sorted(gf["risk_factor_id"].astype(str).unique().tolist())[:200]
        if not ids:
            return _empty_fig("Peer multiline"), _empty_fig("Cross-section"), _empty_fig("Peer correlation"), [], _empty_fig("Factor vs peer")

        ts_view = _filtered_ts(state)
        p = ts_view[ts_view["risk_factor_id"].isin(ids)].copy()
        if start_date:
            p = p[p["date_norm"] >= pd.to_datetime(start_date).normalize()]
        if end_date:
            p = p[p["date_norm"] <= pd.to_datetime(end_date).normalize()]
        if p.empty:
            return _empty_fig("Peer multiline"), _empty_fig("Cross-section"), _empty_fig("Peer correlation"), [], _empty_fig("Factor vs peer")

        p = p.sort_values(["risk_factor_id", "date_norm"])
        base = p.groupby("risk_factor_id", as_index=False)["value"].first().rename(columns={"value": "base"})
        z = p.merge(base, on="risk_factor_id", how="left")
        z["indexed"] = np.where(z["base"].abs() > 1.0e-12, 100.0 * z["value"] / z["base"], np.nan)
        fig_multi = px.line(z, x="date_norm", y="indexed", color="risk_factor_id", title="Peer group indexed series")
        med = z.groupby("date_norm", as_index=False)["indexed"].median().rename(columns={"indexed": "peer_median"})
        fig_multi.add_trace(go.Scatter(x=med["date_norm"], y=med["peer_median"], mode="lines", name="peer median", line={"width": 3, "dash": "dash"}))

        chosen = None
        if date_map and isinstance(slider_idx, (int, float)):
            ii = int(slider_idx)
            if 0 <= ii < len(date_map):
                chosen = pd.to_datetime(date_map[ii]).normalize()
        if chosen is None:
            chosen = pd.to_datetime(z["date_norm"]).max().normalize()
        snap = z[z["date_norm"] == chosen]
        fig_cross = _empty_fig("Cross-section") if snap.empty else px.scatter(snap, x="risk_factor_id", y="indexed", title=f"Cross-section at {chosen.date()}")

        piv = z.pivot_table(index="date_norm", columns="risk_factor_id", values="indexed", aggfunc="last")
        corr = piv.pct_change().corr(min_periods=20)
        fig_corr = _empty_fig("Peer correlation heatmap")
        if not corr.empty:
            c = corr.reset_index().melt(id_vars="risk_factor_id", var_name="peer", value_name="corr")
            fig_corr = px.density_heatmap(c, x="risk_factor_id", y="peer", z="corr", color_continuous_scale="RdBu", title="Peer correlation heatmap")

        latest = _latest_date(dq)
        lf = dq[(dq["flag"]) & (dq["date_norm"] == latest)]

        health = []
        for gname, gm in x.groupby("rf_level3"):
            mids = gm["risk_factor_id"].astype(str).unique().tolist()
            if not mids:
                continue
            gl = lf[lf["risk_factor_id"].isin(mids)]
            n = len(mids)
            flagged = gl["risk_factor_id"].astype(str).nunique()
            flagged_pct = 100.0 * flagged / n if n > 0 else 0.0
            sv = z[(z["risk_factor_id"].isin(mids)) & (z["date_norm"] == chosen)]["indexed"]
            disp = float((sv - sv.median()).abs().median()) if not sv.empty else np.nan
            worst = ""
            if not gl.empty:
                wm = gl.groupby("risk_factor_id", as_index=False)["norm_score"].max().sort_values("norm_score", ascending=False)
                worst = str(wm.iloc[0]["risk_factor_id"]) if not wm.empty else ""
            gp = piv[[c for c in mids if c in piv.columns]]
            avg_corr = np.nan
            corr_stability = np.nan
            if gp.shape[1] >= 2:
                cm = gp.pct_change().corr(min_periods=20).values
                if cm.size > 0:
                    up = cm[np.triu_indices_from(cm, k=1)]
                    up = up[~np.isnan(up)]
                    if up.size > 0:
                        avg_corr = float(np.mean(up))
                vals = []
                rets = gp.pct_change().dropna()
                for i in range(20, len(rets) + 1):
                    w = rets.iloc[i - 20 : i]
                    cwin = w.corr().values
                    up2 = cwin[np.triu_indices_from(cwin, k=1)]
                    up2 = up2[~np.isnan(up2)]
                    if up2.size > 0:
                        vals.append(float(np.mean(up2)))
                if vals:
                    corr_stability = float(np.std(vals))
            health.append({"peer_group": str(gname), "member_count": n, "flagged_pct": round(flagged_pct, 2), "dispersion_mad": round(disp, 4) if pd.notna(disp) else None, "worst_member": worst, "avg_corr": round(avg_corr, 4) if pd.notna(avg_corr) else None, "corr_stability": round(corr_stability, 4) if pd.notna(corr_stability) else None, "selected_factor": worst})
        health = sorted(health, key=lambda x: x.get("flagged_pct") or 0.0, reverse=True)

        sf = None
        if peer_rows:
            sf = peer_rows[0].get("selected_factor") or peer_rows[0].get("worst_member")
        if not sf:
            sf = (state or {}).get("selected_risk_factor_id")
        if not sf or sf not in ids:
            sf = ids[0]

        fig_factor = _empty_fig("Factor vs peer")
        fd = z[z["risk_factor_id"] == sf].copy()
        if not fd.empty:
            pm = z.groupby("date_norm", as_index=False)["indexed"].median().rename(columns={"indexed": "peer_median"})
            j = fd[["date_norm", "indexed"]].merge(pm, on="date_norm", how="left")
            j["factor_minus_peer"] = j["indexed"] - j["peer_median"]
            val = z.pivot_table(index="date_norm", columns="risk_factor_id", values="indexed", aggfunc="last")
            if sf in val.columns and val.shape[1] >= 2:
                cent = val.drop(columns=[sf], errors="ignore").mean(axis=1)
                rc = val[sf].rolling(60, min_periods=20).corr(cent)
            else:
                rc = pd.Series(index=j["date_norm"], dtype=float)
            fig_factor = go.Figure()
            fig_factor.add_trace(go.Scatter(x=j["date_norm"], y=j["indexed"], mode="lines", name=f"{sf} indexed"))
            fig_factor.add_trace(go.Scatter(x=j["date_norm"], y=j["peer_median"], mode="lines", name="peer median", line={"dash": "dash"}))
            fig_factor.add_trace(go.Scatter(x=j["date_norm"], y=j["factor_minus_peer"], mode="lines", name="factor - peer", yaxis="y2"))
            fig_factor.add_trace(go.Scatter(x=rc.index, y=rc.values, mode="lines", name="rolling corr(60)", yaxis="y2"))
            fig_factor.update_layout(title=f"Factor vs Peer: {sf}", yaxis={"title": "Indexed"}, yaxis2={"overlaying": "y", "side": "right", "title": "Spread / Corr"}, template="plotly_white")

        return fig_multi, fig_cross, fig_corr, health, fig_factor

    return app


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run Dash UI v2 for Advanced DQ Checks on RF.")
    parser.add_argument("--results-path", default=str(PROJECT_ROOT / "data" / "processed" / "dq_results"))
    parser.add_argument("--raw-path", default=str(PROJECT_ROOT / "data" / "raw" / "timeseries_raw"))
    parser.add_argument("--membership-path", default=str(PROJECT_ROOT / "data" / "processed" / "universe_membership"))
    parser.add_argument("--config-path", default=str(PROJECT_ROOT / "configs" / "model_catalog.yaml"))
    parser.add_argument("--triage-path", default=str(PROJECT_ROOT / "data" / "processed" / "triage_labels" / "triage_labels.parquet"))
    parser.add_argument("--triage-model-path", default="", help="Optional path to triage_model parquet/csv from Layer 6 demo.")
    parser.add_argument("--feature-importance-global-path", default="", help="Optional path to feature_importance_global parquet/csv.")
    parser.add_argument("--feature-importance-local-path", default="", help="Optional path to feature_importance_local parquet/csv.")
    parser.add_argument("--feature-importance-drift-path", default="", help="Optional path to feature_importance_drift parquet/csv.")
    parser.add_argument(
        "--feature-importance-drift-components-path",
        default="",
        help="Optional path to feature_importance_drift_components parquet/csv.",
    )
    parser.add_argument("--business-date", default="", help="Optional business_date filter (YYYY-MM-DD) applied at load time.")
    parser.add_argument("--debug-load", action="store_true", help="Print detailed loader diagnostics before launching UI.")
    parser.add_argument("--debug-load-only", action="store_true", help="Print loader diagnostics and exit.")
    parser.add_argument("--analyst-id", default=os.getenv("USERNAME", "analyst"))
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8061)
    parser.add_argument("--debug", action="store_true")
    return parser.parse_args()

def parse_args_test() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run Dash UI v2 for Advanced DQ Checks on RF.")
    parser.add_argument("--results-path", default=str(PROJECT_ROOT / "data" / "demo_ui_full" / "processed" / "dq_results"))
    parser.add_argument("--raw-path", default=str(PROJECT_ROOT / "data" / "demo_ui_full" / "raw" / "timeseries_raw"))
    parser.add_argument("--membership-path", default=str(PROJECT_ROOT / "data" / "demo_ui_full" / "processed" / "universe_membership"))
    parser.add_argument("--config-path", default=str(PROJECT_ROOT / "configs" / "demo_ui_full" / "model_catalog_ui_full.yaml"))
    parser.add_argument("--triage-path", default=str(PROJECT_ROOT / "data" / "processed" / "triage_labels" / "triage_labels.parquet"))
    parser.add_argument("--triage-model-path", default="")
    parser.add_argument("--feature-importance-global-path", default="")
    parser.add_argument("--feature-importance-local-path", default="")
    parser.add_argument("--feature-importance-drift-path", default="")
    parser.add_argument("--feature-importance-drift-components-path", default="")
    parser.add_argument("--business-date", default="2026-01-31", help="Optional business_date filter (YYYY-MM-DD) applied at load time.")
    parser.add_argument("--analyst-id", default=os.getenv("USERNAME", "analyst"))
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8061)
    parser.add_argument("--debug", action="store_true")
    return parser.parse_args()

def parse_args_layer6_v1() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run Dash UI v2 for Layer 6 MARS_SUBSET artifacts.")

    parser.add_argument("--run-id", default="layer6_demo_20260310_161709_029468", help="Layer 6 run id value (without 'run_id=' prefix).")
    parser.add_argument("--universe-name", default="MARS_SUBSET")
    parser.add_argument("--business-date", default="2026-02-27")

    parser.add_argument("--results-path", default="")
    parser.add_argument("--raw-path", default=str(PROJECT_ROOT / "data" / "raw" / "timeseries_raw"))
    parser.add_argument("--membership-path", default="")
    parser.add_argument("--config-path", default=str(PROJECT_ROOT / "configs" / "model_catalog.yaml"))

    parser.add_argument("--triage-path", default=str(PROJECT_ROOT / "data" / "processed" / "triage_labels" / "triage_labels.parquet"))

    parser.add_argument("--triage-model-path", default="")
    parser.add_argument("--feature-importance-global-path", default="")
    parser.add_argument("--feature-importance-local-path", default="")
    parser.add_argument("--feature-importance-drift-path", default="")
    parser.add_argument("--feature-importance-drift-components-path", default="")

    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8061)
    parser.add_argument("--debug", action="store_true")
    parser.add_argument("--analyst-id", default=os.getenv("USERNAME", "analyst"))
    parser.add_argument("--start-date", default="", help="Initial UI date-range start (YYYY-MM-DD).")
    parser.add_argument("--end-date", default="", help="Initial UI date-range end (YYYY-MM-DD).")

    args = parser.parse_args()

    base = (
        PROJECT_ROOT
        / "data"
        / "processed"
        / "layer6_false_alarm_demo"
        / f"business_date={args.business_date}"
        / f"universe_name={args.universe_name}"
        / f"run_id={args.run_id}"
    )

    if not args.results_path:
        triaged_preview = base / "triaged_preview.parquet"
        if triaged_preview.exists():
            args.results_path = str(triaged_preview)
        else:
            args.results_path = str(
                PROJECT_ROOT
                / "data"
                / "processed"
                / "layer3_dq_checks_demo"
                / f"business_date={args.business_date}"
                / f"universe_name={args.universe_name}"
                / "dq_results_full.parquet"
            )
    if not args.membership_path:
        args.membership_path = str(
            PROJECT_ROOT
            / "data"
            / "processed"
            / "layer3_dq_checks_demo"
            / f"business_date={args.business_date}"
            / f"universe_name={args.universe_name}"
            / "membership_input.parquet"
        )
    if not args.triage_model_path:
        args.triage_model_path = str(base / "triage_model.parquet")
    if not args.feature_importance_global_path:
        args.feature_importance_global_path = str(base / "feature_importance_global.parquet")
    if not args.feature_importance_local_path:
        args.feature_importance_local_path = str(base / "feature_importance_local.parquet")
    if not args.feature_importance_drift_path:
        args.feature_importance_drift_path = str(base / "feature_importance_drift.parquet")
    if not args.feature_importance_drift_components_path:
        args.feature_importance_drift_components_path = str(base / "feature_importance_drift_components.parquet")

    return args
def parse_args_layer6() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run Dash UI v2 for Layer 6 MARS_SUBSET artifacts.")

    parser.add_argument("--run-id", default="layer6_demo_20260315_165724_377102", help="Layer 6 run id value (without 'run_id=' prefix).")
    parser.add_argument("--universe-name", default="MARS_SUBSET")
    parser.add_argument("--business-date", default="2026-02-27")

    parser.add_argument("--results-path", default="")
    parser.add_argument("--raw-path", default=str(PROJECT_ROOT / "data" / "raw" / "timeseries_raw"))
    parser.add_argument("--membership-path", default="")
    parser.add_argument("--config-path", default=str(PROJECT_ROOT / "configs" / "model_catalog.yaml"))

    parser.add_argument("--triage-path", default=str(PROJECT_ROOT / "data" / "processed" / "triage_labels" / "triage_labels.parquet"))

    parser.add_argument("--triage-model-path", default="")
    parser.add_argument("--feature-importance-global-path", default="")
    parser.add_argument("--feature-importance-local-path", default="")
    parser.add_argument("--feature-importance-drift-path", default="")
    parser.add_argument("--feature-importance-drift-components-path", default="")

    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8061)
    parser.add_argument("--debug", action="store_true")
    parser.add_argument("--analyst-id", default=os.getenv("USERNAME", "analyst"))
    parser.add_argument("--start-date", default="", help="Initial UI date-range start (YYYY-MM-DD).")
    parser.add_argument("--end-date", default="", help="Initial UI date-range end (YYYY-MM-DD).")

    args = parser.parse_args()

    base = (
        PROJECT_ROOT
        / "data"
        / "processed"
        / "layer6_false_alarm_demo"
        / f"business_date={args.business_date}"
        / f"universe_name={args.universe_name}"
        / f"run_id={args.run_id}"
    )

    if not args.results_path:
        triaged_preview = base / "triaged_full.parquet" #triaged_preview.parquet
        if triaged_preview.exists():
            args.results_path = str(triaged_preview)
        else:
            args.results_path = str(
                PROJECT_ROOT
                / "data"
                / "processed"
                / "layer3_dq_checks_demo"
                / f"business_date={args.business_date}"
                / f"universe_name={args.universe_name}"
                / "dq_results_full.parquet"
            )


    if not args.membership_path:
        args.membership_path = str(
            PROJECT_ROOT
            / "data"
            / "processed"
            / "layer3_dq_checks_demo"
            / f"business_date={args.business_date}"
            / f"universe_name={args.universe_name}"
            / "membership_input.parquet"
        )
    if not args.triage_model_path:
        args.triage_model_path = str(base / "triage_model.parquet")
    if not args.feature_importance_global_path:
        args.feature_importance_global_path = str(base / "feature_importance_global.parquet")
    if not args.feature_importance_local_path:
        args.feature_importance_local_path = str(base / "feature_importance_local.parquet")
    if not args.feature_importance_drift_path:
        args.feature_importance_drift_path = str(base / "feature_importance_drift.parquet")
    if not args.feature_importance_drift_components_path:
        args.feature_importance_drift_components_path = str(base / "feature_importance_drift_components.parquet")

    return args
def main() -> None:
    args = parse_args_layer6()


    debug_load = getattr(args, "debug_load", False)
    debug_load_only = getattr(args, "debug_load_only", False)

    if debug_load or debug_load_only:
        data, report = load_data_with_debug(
            args.results_path,
            args.raw_path,
            args.membership_path,
            business_date=args.business_date or None,
        )
        print(json.dumps(report, indent=2))
        if args.debug_load_only:
            return
    else:
        print("args.results_path "+ args.results_path)
        print("args.raw_path " + args.raw_path)
        print("args.membership_path " + args.membership_path)

        p = Path(args.membership_path)
        df = pd.read_parquet(p)
        print(df.shape)
        print(df.columns.tolist())
        data = load_data(
            args.results_path,
            args.raw_path,
            args.membership_path,
            business_date=args.business_date or None,
        )
        if "risk_factor_id" not in data["membership"].columns or data["membership"].empty:
            raise ValueError(f"Invalid membership input: {args.membership_path}")


    app = create_app(
        data,
        config_path=args.config_path,
        triage_path=args.triage_path,
        analyst_id=args.analyst_id,
        initial_start_date=args.start_date or None,
        initial_end_date=args.end_date or None,
        triage_model_df=_load_optional_table(args.triage_model_path),
        feature_importance_global_df=_load_optional_table(args.feature_importance_global_path),
        feature_importance_local_df=_load_optional_table(args.feature_importance_local_path),
        feature_importance_drift_df=_load_optional_table(args.feature_importance_drift_path),
        feature_importance_drift_components_df=_load_optional_table(args.feature_importance_drift_components_path),
    )
    app.run(host=args.host, port=args.port, debug=args.debug)


if __name__ == "__main__":
    main()
