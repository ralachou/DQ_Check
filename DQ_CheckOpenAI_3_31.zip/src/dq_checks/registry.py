from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable

from dq_checks.adapters import ADTKAdapterCheck, MerlionAdapterCheck, PyODAdapterCheck
from dq_checks.base import DQCheck
from dq_checks.ensemble import EnsembleCheck
from dq_checks.local_checks import (
    CUSUMDriftCheck,
    ForecastARIMAResidualCheck,
    IQRCheck,
    JumpSpikeCheck,
    MeanStdShift4SigmaCheck,
    MissingGapsCheck,
    PeerMADCheck,
    PeerMedianDeviationCheck,
    PeerPercentileCheck,
    PeerRobustZCheck,
    QuantileBandCheck,
    RollingKSCheck,
    RollingZScoreCheck,
    RobustZScoreMeanStdCheck,
    RobustZScoreCheck,
    StaleNoChangeCheck,
    RuleAbsShiftGtCheck,
    ZScoreMeanStdCheck,
)
from dq_checks.taxonomy import canonicalize_family


@dataclass
class ModelSpec:
    id: str
    backend: str
    model_name: str
    family: str
    fit_policy: str
    params: dict[str, Any] = field(default_factory=dict)
    normalization_profile: str = "ecdf_profile"
    severity_profile: str = "default"
    enabled: bool = True
    version_tag: str = "1.0.0"


class ModelRegistry:
    def __init__(self) -> None:
        self._registry: dict[str, Callable[..., DQCheck]] = {}
        self._required_params: dict[str, set[str]] = {}
        self._register_defaults()

    def register(self, key: str, ctor: Callable[..., DQCheck], required_params: set[str] | None = None) -> None:
        self._registry[key] = ctor
        self._required_params[key] = required_params or set()

    def _register_defaults(self) -> None:
        # Statistical basic
        self.register("mean_std_shift_4", MeanStdShift4SigmaCheck, {"window", "threshold"})
        self.register("mean_std_shift_4sigma", MeanStdShift4SigmaCheck, {"window", "threshold"})
        self.register("legacy_4sigma_shift", MeanStdShift4SigmaCheck, {"window", "threshold"})
        self.register("zscore_mean_std", ZScoreMeanStdCheck, {"window", "threshold"})
        self.register("rolling_zscore", RollingZScoreCheck, {"window", "threshold"})

        # Statistical robust
        self.register("robust_zscore", RobustZScoreCheck, {"window", "threshold"})
        self.register("robust_zscore_median_mad", RobustZScoreCheck, {"window", "threshold"})
        self.register("robust_zscore_mean_std", RobustZScoreMeanStdCheck, {"window", "threshold"})
        self.register("quantile_band", QuantileBandCheck, {"window"})
        self.register("iqr", IQRCheck, {"window"})
        self.register("jump_spike", JumpSpikeCheck, {"window", "threshold"})
        self.register("cusum_drift", CUSUMDriftCheck, {"threshold"})
        self.register("rolling_ks", RollingKSCheck, {"window", "reference", "threshold"})

        # Rule based
        self.register("rule_abs_shift_gt", RuleAbsShiftGtCheck, {"threshold"})
        self.register("stale_values", StaleNoChangeCheck, {"stale_days"})
        self.register("missing_gaps", MissingGapsCheck, set())

        # Forecast based
        self.register("arima_residual", ForecastARIMAResidualCheck, set())

        # Peer cross-group
        self.register("peer_median_dev", PeerMedianDeviationCheck, set())
        self.register("peer_mad", PeerMADCheck, set())
        self.register("peer_robust_z", PeerRobustZCheck, set())
        self.register("peer_percentile", PeerPercentileCheck, set())

    def validate(self, spec: ModelSpec) -> None:
        key = spec.model_name
        if spec.backend == "local" and key != "ensemble":
            if key not in self._registry:
                raise ValueError(f"Unknown local model_name '{key}' for model '{spec.id}'.")
            required = self._required_params.get(key, set())
            missing = sorted(required - set(spec.params.keys()))
            if missing:
                raise ValueError(f"Model '{spec.id}' missing required params: {missing}")

    def build_from_spec(self, spec: ModelSpec, check_lookup: dict[str, DQCheck] | None = None) -> DQCheck:
        self.validate(spec)
        if spec.backend == "local":
            if spec.model_name == "ensemble":
                children_ids = spec.params.get("children", [])
                children = [check_lookup[c] for c in children_ids if c in (check_lookup or {})]
                return EnsembleCheck(
                    children=children,
                    method=spec.params.get("strategy", spec.params.get("method", "weighted_avg")),
                    weights=spec.params.get("weights"),
                    threshold=spec.params.get("threshold", 0.95),
                    fit_policy=spec.fit_policy,
                )
            ctor = self._registry[spec.model_name]
            check = ctor(**spec.params)
            check.fit_policy = spec.fit_policy
            return check
        if spec.backend == "pyod":
            return PyODAdapterCheck(model_name=spec.model_name, fit_policy=spec.fit_policy, **spec.params)
        if spec.backend == "adtk":
            return ADTKAdapterCheck(model_name=spec.model_name, fit_policy=spec.fit_policy, **spec.params)
        if spec.backend == "merlion":
            return MerlionAdapterCheck(model_name=spec.model_name, fit_policy=spec.fit_policy, **spec.params)
        raise ValueError(f"Unsupported backend '{spec.backend}' for model '{spec.id}'.")

    @staticmethod
    def _check_applies_to_universe(
        common_check: dict[str, Any],
        universe_name: str,
        universe_filters: dict[str, Any],
    ) -> bool:
        # Primary selector: explicit universe names.
        by_universe = common_check.get("apply_to_universes")
        if by_universe:
            allowed = {str(x) for x in (by_universe if isinstance(by_universe, list) else [by_universe])}
            return universe_name in allowed

        # Backward-compatible fallback: rf_level1 selector.
        by_rf1 = common_check.get("apply_to_rf_level1")
        if not by_rf1:
            return True
        allowed_rf1 = {str(x) for x in (by_rf1 if isinstance(by_rf1, list) else [by_rf1])}
        rf1 = universe_filters.get("rf_level1")
        if rf1 is None:
            return True
        if isinstance(rf1, list):
            return any(str(x) in allowed_rf1 for x in rf1)
        return str(rf1) in allowed_rf1

    def load_universe_specs(self, catalog: dict[str, Any], universe_name: str) -> list[ModelSpec]:
        uni = catalog.get("universes", {}).get(universe_name, {})
        checks = list(uni.get("checks", []))
        common_cfg = catalog.get("common_checks", {}) if isinstance(catalog, dict) else {}
        include_common = bool(uni.get("use_common_checks", common_cfg.get("enabled_by_default", False)))
        if include_common:
            universe_filters = uni.get("filters", {}) or {}
            common_checks = []
            for row in common_cfg.get("checks", []) or []:
                if not isinstance(row, dict):
                    continue
                if not self._check_applies_to_universe(row, universe_name, universe_filters):
                    continue
                common_checks.append(dict(row))
            # Universe checks override common checks when id matches.
            by_id: dict[str, dict[str, Any]] = {}
            for row in common_checks + checks:
                if isinstance(row, dict) and row.get("id"):
                    by_id[str(row["id"])] = row
            checks = list(by_id.values())

        version = str(catalog.get("globals", {}).get("version", "1.0.0"))
        specs: list[ModelSpec] = []
        for c in checks:
            family = canonicalize_family(c.get("family"), c.get("model_name"), c.get("backend"))
            specs.append(
                ModelSpec(
                    id=c["id"],
                    backend=c["backend"],
                    model_name=c["model_name"],
                    family=family,
                    fit_policy=c.get("fit_policy", "per_series"),
                    params=c.get("params", {}),
                    normalization_profile=c.get("normalization_profile", "ecdf_profile"),
                    severity_profile=c.get("severity_profile", "default"),
                    enabled=bool(c.get("enabled", True)),
                    version_tag=f"{version}:{c['id']}",
                )
            )
        return specs
