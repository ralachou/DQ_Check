from __future__ import annotations

import copy
import importlib.util
import os
import sys
from pathlib import Path
from typing import Any

import pandas as pd

try:
    from IPython.display import clear_output, display
except Exception:
    def display(obj):
        print(obj)

    def clear_output(wait: bool = False):
        del wait
        return None

try:
    import ipywidgets as widgets
except Exception:
    widgets = None


PROJECT_ROOT = Path.cwd()
if not (PROJECT_ROOT / "src").exists() and (PROJECT_ROOT.parent / "src").exists():
    PROJECT_ROOT = PROJECT_ROOT.parent

SRC_PATH = PROJECT_ROOT / "src"
if str(SRC_PATH) not in sys.path:
    sys.path.insert(0, str(SRC_PATH))

TESTS_PATH = PROJECT_ROOT / "tests"
if str(TESTS_PATH) not in sys.path:
    sys.path.insert(0, str(TESTS_PATH))

from dq_checks.registry import ModelRegistry, ModelSpec
from dq_checks.taxonomy import canonicalize_family


def _load_single_factor_module():
    mod_path = PROJECT_ROOT / "tests" / "layer3_single_risk_factor_tuning_notebook.py"
    spec = importlib.util.spec_from_file_location("layer3_single_factor_tuning", mod_path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Cannot load module from {mod_path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


single = _load_single_factor_module()

SEVERITY_OPTIONS = ["Low", "Med", "High", "Critical"]
CANONICAL_LOCAL_MODELS = [
    "mean_std_shift_4sigma",
    "zscore_mean_std",
    "rolling_zscore",
    "robust_zscore",
    "robust_zscore_mean_std",
    "quantile_band",
    "iqr",
    "jump_spike",
    "cusum_drift",
    "rolling_ks",
    "rule_abs_shift_gt",
    "stale_values",
    "missing_gaps",
    "arima_residual",
    "peer_median_dev",
    "peer_mad",
    "peer_robust_z",
    "peer_percentile",
]
DEFAULT_REQ_PARAMS: dict[str, Any] = {
    "window": 60,
    "threshold": 3.0,
    "reference": 120,
    "stale_days": 5,
}
_CTX_CACHE: dict[str, Any] | None = None


def _in_notebook() -> bool:
    try:
        from IPython import get_ipython
        shell = get_ipython()
        if shell is None:
            return False
        if shell.__class__.__name__ == "ZMQInteractiveShell":
            return True
        if hasattr(shell, "kernel"):
            return True
        if os.environ.get("JPY_PARENT_PID"):
            return True
        cfg = getattr(shell, "config", {}) or {}
        return "IPKernelApp" in cfg
    except Exception:
        return False


def _required_params_for(registry: ModelRegistry, model_name: str) -> dict[str, Any]:
    req = registry._required_params.get(model_name, set())  # noqa: SLF001
    params: dict[str, Any] = {}
    for key in req:
        if key in DEFAULT_REQ_PARAMS:
            params[key] = DEFAULT_REQ_PARAMS[key]
        else:
            params[key] = 1.0
    return params


def _adhoc_spec(
    *,
    spec_id: str,
    backend: str,
    model_name: str,
    fit_policy: str,
    params: dict[str, Any],
) -> ModelSpec:
    return ModelSpec(
        id=spec_id,
        backend=backend,
        model_name=model_name,
        family=canonicalize_family(None, model_name, backend),
        fit_policy=fit_policy,
        params=params,
        normalization_profile="ecdf_profile",
        severity_profile="default",
        enabled=True,
        version_tag="adhoc",
    )


def _build_extended_specs(config_specs: list[ModelSpec]) -> list[ModelSpec]:
    specs = [copy.deepcopy(s) for s in config_specs]
    by_id = {s.id for s in specs}

    registry = ModelRegistry()
    existing_local_models = {s.model_name for s in specs if s.backend == "local"}
    for model_name in CANONICAL_LOCAL_MODELS:
        if model_name in existing_local_models:
            continue
        fit_policy = "per_peer_group" if model_name.startswith("peer_") else "per_series"
        spec_id = f"{model_name}_adhoc"
        if spec_id in by_id:
            continue
        specs.append(
            _adhoc_spec(
                spec_id=spec_id,
                backend="local",
                model_name=model_name,
                fit_policy=fit_policy,
                params=_required_params_for(registry, model_name),
            )
        )
        by_id.add(spec_id)

    adapter_defaults = [
        ("pyod_iforest_adhoc", "pyod", "iforest", "per_peer_group", {"contamination": 0.002, "threshold": 0.98}),
        ("adtk_levelshift_adhoc", "adtk", "LevelShiftAD", "per_series", {"threshold": 0.9}),
        ("merlion_stl_adhoc", "merlion", "stl", "per_series", {"threshold": 0.9}),
    ]
    existing_backend_model = {(s.backend, s.model_name.lower()) for s in specs}
    for spec_id, backend, model_name, fit_policy, params in adapter_defaults:
        key = (backend, model_name.lower())
        if key in existing_backend_model or spec_id in by_id:
            continue
        specs.append(
            _adhoc_spec(
                spec_id=spec_id,
                backend=backend,
                model_name=model_name,
                fit_policy=fit_policy,
                params=params,
            )
        )
        by_id.add(spec_id)

    return sorted(specs, key=lambda x: (x.backend, x.fit_policy, x.id))


def _load_context(force_reload: bool = False) -> dict[str, Any]:
    global _CTX_CACHE
    if _CTX_CACHE is not None and not force_reload:
        return _CTX_CACHE

    settings = single.load_runtime_settings(PROJECT_ROOT)
    settings["selected_check_ids"] = []
    prepared = single.prepare_universe_and_specs(settings)
    all_specs = _build_extended_specs(prepared["selected_specs"])

    _CTX_CACHE = {
        "settings": settings,
        "prepared": prepared,
        "all_specs": all_specs,
    }
    return _CTX_CACHE


def available_checks_df(force_reload: bool = False) -> pd.DataFrame:
    ctx = _load_context(force_reload=force_reload)
    rows = []
    for s in ctx["all_specs"]:
        rows.append(
            {
                "check_id": s.id,
                "backend": s.backend,
                "model_name": s.model_name,
                "family": s.family,
                "fit_policy": s.fit_policy,
                "params": s.params,
            }
        )
    df = pd.DataFrame(rows).sort_values(["backend", "fit_policy", "check_id"]).reset_index(drop=True)
    return df


def run_selected_functions(
    selected_check_ids: list[str],
    severity_source: str = "raw",
    severity_filter: list[str] | None = None,
    use_normalized_flags: bool = True,
    enforce_raw_flag: bool = True,
    show_plot: bool = True,
    launch_browser_ui: bool = False,
) -> dict[str, Any]:
    ctx = _load_context(force_reload=False)
    settings = ctx["settings"]
    prepared = ctx["prepared"]
    all_specs = ctx["all_specs"]

    selected = [str(x) for x in selected_check_ids if str(x).strip()]
    if not selected:
        raise ValueError("No checks selected. Select at least one check_id.")

    selected_set = set(selected)
    selected_specs = [s for s in all_specs if s.id in selected_set]
    if not selected_specs:
        raise ValueError("Selected checks are not available in the built spec list.")

    prepared_run = dict(prepared)
    prepared_run["selected_specs"] = selected_specs

    target_payload = single.load_target_series(settings, prepared_run)
    raw_results = single.run_selected_checks(settings, prepared_run, target_payload)
    normalized_payload = single.normalize_and_build_view(settings, prepared_run, raw_results)
    results_view = normalized_payload["results_view"]

    flag_col, flagged_only = single.build_flagged_rows(
        results_view,
        use_normalized_flags=use_normalized_flags,
        severity_filter=severity_filter,
        severity_source=severity_source,
        enforce_raw_flag=enforce_raw_flag,
    )

    fig = None
    if show_plot:
        fig = single.plot_raw_vs_flags(
            target_series=target_payload["target_series"],
            flagged_rows=flagged_only,
            target_risk_factor_id=target_payload["target_risk_factor_id"],
            flag_col=flag_col,
        )

    summary = single.build_model_summary(results_view)
    outputs = {
        "settings": settings,
        "prepared": prepared_run,
        "target_payload": target_payload,
        "raw_results": raw_results,
        "normalized_payload": normalized_payload,
        "results_view": results_view,
        "flag_col": flag_col,
        "flagged_only": flagged_only,
        "figure": fig,
        "summary": summary,
    }
    if launch_browser_ui:
        single.launch_browser_filter_ui(outputs)
    return outputs


def notebook_controls():
    if widgets is None:
        print("ipywidgets is not installed. Install with: pip install ipywidgets")
        return None

    check_df = available_checks_df(force_reload=True)
    options = [
        (
            f"{r.check_id} | {r.backend}:{r.model_name} | {r.fit_policy}",
            r.check_id,
        )
        for r in check_df.itertuples(index=False)
    ]
    default_ids = tuple([r.check_id for r in check_df.head(min(5, len(check_df))).itertuples(index=False)])

    check_widget = widgets.SelectMultiple(options=options, value=default_ids, rows=14, description="checks")
    sev_source_widget = widgets.ToggleButtons(
        options=[("Raw/preNorm", "raw"), ("PostNorm", "norm")],
        value="raw",
        description="severity_source",
    )
    sev_filter_widget = widgets.SelectMultiple(options=SEVERITY_OPTIONS, value=(), rows=4, description="severity_filter")
    norm_flag_widget = widgets.Checkbox(value=True, description="use_normalized_flags")
    enforce_raw_widget = widgets.Checkbox(value=True, description="enforce_raw_flag")
    show_plot_widget = widgets.Checkbox(value=True, description="show_plot")
    launch_browser_widget = widgets.Checkbox(value=False, description="launch_browser_ui")
    run_button = widgets.Button(description="Run Selected Checks", button_style="primary")
    out = widgets.Output()

    def _on_run(_):
        with out:
            clear_output(wait=True)
            selected = list(check_widget.value)
            sev = list(sev_filter_widget.value) if sev_filter_widget.value else None
            _ = run_selected_functions(
                selected_check_ids=selected,
                severity_source=str(sev_source_widget.value),
                severity_filter=sev,
                use_normalized_flags=bool(norm_flag_widget.value),
                enforce_raw_flag=bool(enforce_raw_widget.value),
                show_plot=bool(show_plot_widget.value),
                launch_browser_ui=bool(launch_browser_widget.value),
            )

    run_button.on_click(_on_run)

    display(check_df)
    ui = widgets.VBox(
        [
            widgets.HTML("<b>Layer 3 Function Tester</b>"),
            check_widget,
            sev_source_widget,
            sev_filter_widget,
            widgets.HBox([norm_flag_widget, enforce_raw_widget, show_plot_widget, launch_browser_widget]),
            run_button,
            out,
        ]
    )
    display(ui)
    return ui


def _read(prompt: str) -> str:
    try:
        return input(prompt).strip()
    except (EOFError, KeyboardInterrupt):
        return ""


def terminal_controls_and_run():
    check_df = available_checks_df(force_reload=True)
    print("\nAvailable checks:")
    for i, r in enumerate(check_df.itertuples(index=False), start=1):
        print(f"{i:3d}. {r.check_id} | {r.backend}:{r.model_name} | {r.fit_policy}")

    raw_sel = _read("\nSelect checks by number (comma list) or type 'all': ")
    selected_ids: list[str] = []
    if raw_sel.lower() == "all":
        selected_ids = check_df["check_id"].astype(str).tolist()
    else:
        for t in [x.strip() for x in raw_sel.split(",") if x.strip()]:
            try:
                idx = int(t)
                if 1 <= idx <= len(check_df):
                    selected_ids.append(str(check_df.iloc[idx - 1]["check_id"]))
            except ValueError:
                pass
    if not selected_ids:
        selected_ids = check_df.head(min(5, len(check_df)))["check_id"].astype(str).tolist()
        print("No valid selection; defaulting to first checks:", selected_ids)

    print("\nseverity_source options:")
    print("  1. Raw/preNorm")
    print("  2. PostNorm")
    sev_source_raw = _read("Choose severity_source [1]: ")
    severity_source = "norm" if sev_source_raw == "2" else "raw"

    print("\nseverity_filter options:")
    for i, s in enumerate(SEVERITY_OPTIONS, start=1):
        print(f"  {i}. {s}")
    print("Use comma numbers; Enter for no filter")
    sev_raw = _read("Choose severity_filter: ")
    severity_filter: list[str] | None = None
    if sev_raw:
        picks: list[str] = []
        for t in [x.strip() for x in sev_raw.split(",") if x.strip()]:
            try:
                idx = int(t)
                if 1 <= idx <= len(SEVERITY_OPTIONS):
                    picks.append(SEVERITY_OPTIONS[idx - 1])
            except ValueError:
                pass
        severity_filter = sorted(set(picks)) if picks else None

    launch_browser = _read("Launch browser filter UI after run? [y/N]: ").lower() in {"y", "yes", "1", "true"}
    _ = run_selected_functions(
        selected_check_ids=selected_ids,
        severity_source=severity_source,
        severity_filter=severity_filter,
        use_normalized_flags=True,
        enforce_raw_flag=True,
        show_plot=True,
        launch_browser_ui=launch_browser,
    )


def run():
    if _in_notebook() and widgets is not None:
        return notebook_controls()
    return terminal_controls_and_run()


if __name__ == "__main__":
    run()
