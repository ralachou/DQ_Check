
from __future__ import annotations

import copy
import sys
import time
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import plotly.graph_objects as go

try:
    from IPython.display import display
except Exception:
    def display(obj):
        print(obj)


PROJECT_ROOT = Path.cwd()
if not (PROJECT_ROOT / "src").exists() and (PROJECT_ROOT.parent / "src").exists():
    PROJECT_ROOT = PROJECT_ROOT.parent

SRC_PATH = PROJECT_ROOT / "src"
if str(SRC_PATH) not in sys.path:
    sys.path.insert(0, str(SRC_PATH))

PROJECT_ROOT


from common.schemas import config_hash, load_yaml
from common.taxonomy import TAXONOMY_PEER_KEYS, normalize_taxonomy_frame
from data_access.parquet_repository import ParquetTimeSeriesRepository
from dq_checks.feature_builder import FeatureBuilder
from dq_checks.registry import ModelRegistry, ModelSpec
from normalization.normalizer import normalize_results
from universe.builder import UniverseBuilder
from universe.definitions import UniverseDefinition


def _build_universe_definition(catalog_dict: dict[str, Any], universe_name: str) -> UniverseDefinition:
    uni = catalog_dict.get("universes", {}).get(universe_name)
    if not uni:
        raise ValueError(f"Universe '{universe_name}' not found in YAML.")
    return UniverseDefinition(
        name=universe_name,
        description=str(uni.get("description", "")),
        filter_rules=uni.get("filters", {}),
    )


def _apply_analysis_field(series_df: pd.DataFrame, requested_field: str) -> tuple[pd.DataFrame, str]:
    field = str(requested_field or "value").strip()
    if field in series_df.columns:
        selected = field
    elif "value" in series_df.columns:
        selected = "value"
        print(f"Warning: analysis field '{field}' not found. Falling back to 'value'.")
    else:
        raise ValueError(f"Neither '{field}' nor 'value' exists. Columns: {list(series_df.columns)}")

    out = series_df.copy()
    out["date"] = pd.to_datetime(out["date"], errors="coerce")
    out["value"] = pd.to_numeric(out[selected], errors="coerce")
    out = out.dropna(subset=["risk_factor_id", "date", "value"]).sort_values(["risk_factor_id", "date"]).reset_index(drop=True)
    return out, selected


def _apply_check_overrides(specs: list[ModelSpec], override_cfg: dict[str, Any]) -> list[ModelSpec]:
    override_map = override_cfg.get("overrides", {}).get("checks", {}) or {}
    out: list[ModelSpec] = []
    for spec in specs:
        spec2 = copy.deepcopy(spec)
        row = override_map.get(spec2.id, {})
        if isinstance(row, dict):
            if "fit_policy" in row:
                spec2.fit_policy = str(row["fit_policy"])
            if "normalization_profile" in row:
                spec2.normalization_profile = str(row["normalization_profile"])
            if "severity_profile" in row:
                spec2.severity_profile = str(row["severity_profile"])
            if "enabled" in row:
                spec2.enabled = bool(row["enabled"])
            params_override = row.get("params", {})
            if isinstance(params_override, dict) and params_override:
                p = dict(spec2.params)
                p.update(params_override)
                spec2.params = p
        if spec2.enabled:
            out.append(spec2)
    return out


def _display_specs(specs: list[ModelSpec]) -> pd.DataFrame:
    return pd.DataFrame(
        [
            {
                "check_id": s.id,
                "backend": s.backend,
                "model_name": s.model_name,
                "family": s.family,
                "fit_policy": s.fit_policy,
                "normalization_profile": s.normalization_profile,
                "params": s.params,
            }
            for s in specs
        ]
    )


def _build_check_profiles(specs: list[ModelSpec], catalog_dict: dict[str, Any]) -> dict[str, dict[str, Any]]:
    profiles_cfg = catalog_dict.get("normalization", {}).get("profiles", {})
    defaults_cfg = catalog_dict.get("normalization", {}).get("defaults", {})
    sev_cfg = catalog_dict.get("globals", {}).get("default_severity_thresholds", {})
    out: dict[str, dict[str, Any]] = {}
    for spec in specs:
        profile_cfg = profiles_cfg.get(spec.normalization_profile, {})
        out[spec.id] = {
            "normalization_strategy": profile_cfg.get("strategy", defaults_cfg.get("strategy", "ecdf")),
            "normalization_params": profile_cfg,
            "backend": spec.backend,
            "severity_mode": "fixed",
            "severity_thresholds": sev_cfg.get("quantile", {}),
            "fixed_thresholds": sev_cfg.get("fixed", {}),
            "model_version": spec.version_tag,
        }
    return out


def load_runtime_settings(project_root: Path, local_override_rel: str = "configs/local_single_factor_tuning.yaml") -> dict[str, Any]:
    local_override_path = project_root / local_override_rel
    local_cfg = load_yaml(local_override_path)

    paths_cfg = local_cfg.get("paths", {})
    run_cfg = local_cfg.get("run", {})

    base_config_path = project_root / str(paths_cfg.get("base_config_path", "configs/model_catalog.yaml"))
    raw_path = project_root / str(paths_cfg.get("raw_path", "data/raw"))
    artifact_root = project_root / str(paths_cfg.get("artifact_root", "data/artifacts/normalization/notebook_single_factor"))

    settings = {
        "local_override_path": local_override_path,
        "local_cfg": local_cfg,
        "base_config_path": base_config_path,
        "raw_path": raw_path,
        "artifact_root": artifact_root,
        "universe_name": str(run_cfg.get("universe_name", "MARS_SUBSET")),
        "business_date": str(run_cfg.get("business_date", "2026-02-27")),
        "start_date": str(run_cfg.get("start_date", "2019-01-02")),
        "end_date": str(run_cfg.get("end_date", "2020-12-31")),
        "analysis_field": str(run_cfg.get("analysis_field", "shift")),
        "target_risk_factor_id": run_cfg.get("target_risk_factor_id"),
        "selected_check_ids": [str(x) for x in run_cfg.get("selected_check_ids", []) if str(x).strip()],
    }

    print("Local override YAML:", settings["local_override_path"])
    print("Base model config:", settings["base_config_path"])
    print("Universe:", settings["universe_name"])
    print("Business date:", settings["business_date"])
    return settings


def prepare_universe_and_specs(settings: dict[str, Any]) -> dict[str, Any]:
    catalog = load_yaml(settings["base_config_path"])
    cfg_hash = config_hash(catalog)

    repo = ParquetTimeSeriesRepository(base_path=settings["raw_path"])
    definition = _build_universe_definition(catalog, settings["universe_name"])
    membership = UniverseBuilder(repo).build(definition)
    membership = normalize_taxonomy_frame(membership, require_risk_factor_id=True)

    registry = ModelRegistry()
    base_specs = [s for s in registry.load_universe_specs(catalog, settings["universe_name"]) if s.enabled]
    effective_specs = _apply_check_overrides(base_specs, settings["local_cfg"])
    selected_check_ids = set(settings["selected_check_ids"])
    selected_specs = [s for s in effective_specs if s.id in selected_check_ids] if selected_check_ids else effective_specs

    if not selected_specs:
        raise ValueError("No checks selected after applying local overrides/selection.")

    print(f"Universe members: {membership['risk_factor_id'].nunique():,}")
    print(f"Enabled checks in base config: {len(base_specs)}")
    print(f"Checks selected to run: {len(selected_specs)}")
    print("Config hash:", cfg_hash[:16], "...")
    display(_display_specs(selected_specs))

    return {
        "catalog": catalog,
        "cfg_hash": cfg_hash,
        "repo": repo,
        "membership": membership,
        "registry": registry,
        "selected_specs": selected_specs,
    }


def load_target_series(settings: dict[str, Any], prepared: dict[str, Any]) -> dict[str, Any]:
    membership = prepared["membership"]
    repo = prepared["repo"]

    target_risk_factor_id = settings["target_risk_factor_id"]
    if target_risk_factor_id is None:
        target_risk_factor_id = str(membership["risk_factor_id"].iloc[0])
    else:
        target_risk_factor_id = str(target_risk_factor_id)

    universe_ids = set(membership["risk_factor_id"].astype(str))
    if target_risk_factor_id not in universe_ids:
        raise ValueError(f"target_risk_factor_id '{target_risk_factor_id}' not in universe '{settings['universe_name']}'.")

    target_series_raw = repo.get_series(
        risk_factor_ids=[target_risk_factor_id],
        start_date=settings["start_date"],
        end_date=settings["end_date"],
        business_date=settings["business_date"],
    )
    target_series, analysis_field_used = _apply_analysis_field(target_series_raw, settings["analysis_field"])
    if target_series.empty:
        raise ValueError("No target series rows found. Check date range, business date, and risk_factor_id.")

    print("Target risk_factor_id:", target_risk_factor_id)
    print("Analysis field used:", analysis_field_used)
    print("Rows:", len(target_series))
    display(target_series.head(5))
    display(target_series.tail(5))

    return {
        "target_risk_factor_id": target_risk_factor_id,
        "analysis_field_used": analysis_field_used,
        "target_series": target_series,
    }


def run_selected_checks(settings: dict[str, Any], prepared: dict[str, Any], target_payload: dict[str, Any]) -> pd.DataFrame:
    membership = prepared["membership"]
    repo = prepared["repo"]
    registry = prepared["registry"]
    selected_specs = prepared["selected_specs"]
    target_series = target_payload["target_series"]
    target_risk_factor_id = target_payload["target_risk_factor_id"]

    target_meta = membership[membership["risk_factor_id"].astype(str) == target_risk_factor_id].iloc[0]
    peer_keys = [k for k in TAXONOMY_PEER_KEYS if k in membership.columns]

    peer_mask = pd.Series(True, index=membership.index)
    for k in peer_keys:
        peer_mask &= membership[k].astype(str) == str(target_meta[k])

    peer_membership = membership[peer_mask].copy()
    peer_ids = sorted(peer_membership["risk_factor_id"].astype(str).unique().tolist())

    needs_peer = any(s.fit_policy == "per_peer_group" for s in selected_specs)
    needs_global = any(s.fit_policy == "global" for s in selected_specs)

    peer_series = pd.DataFrame()
    if needs_peer:
        peer_raw = repo.get_series(
            risk_factor_ids=peer_ids,
            start_date=settings["start_date"],
            end_date=settings["end_date"],
            business_date=settings["business_date"],
        )
        peer_series, _ = _apply_analysis_field(peer_raw, settings["analysis_field"])
        print("Peer-group size:", peer_series["risk_factor_id"].nunique())

    global_series = pd.DataFrame()
    if needs_global:
        all_ids = membership["risk_factor_id"].astype(str).tolist()
        global_raw = repo.get_series(
            risk_factor_ids=all_ids,
            start_date=settings["start_date"],
            end_date=settings["end_date"],
            business_date=settings["business_date"],
        )
        global_series, _ = _apply_analysis_field(global_raw, settings["analysis_field"])
        print("Global series factors:", global_series["risk_factor_id"].nunique())

    checks: dict[str, Any] = {}
    for spec in selected_specs:
        checks[spec.id] = registry.build_from_spec(spec, checks)

    feature_builder = FeatureBuilder()
    raw_parts: list[pd.DataFrame] = []

    for spec in selected_specs:
        check = checks[spec.id]
        t0 = time.perf_counter()

        if spec.fit_policy == "per_series":
            df_in = target_series[["risk_factor_id", "date", "value"]].copy().sort_values("date").reset_index(drop=True)
            ctx = {"risk_factor_id": target_risk_factor_id}
            state = check.fit(df_in, ctx)
            scored = check.score(df_in, ctx, state)

        elif spec.fit_policy == "per_peer_group":
            if peer_series.empty:
                raise ValueError(f"Peer-group data empty for check '{spec.id}'.")
            if peer_series["risk_factor_id"].nunique() < 3:
                parts = []
                for rf_id, sdf in peer_series.groupby("risk_factor_id", sort=False):
                    sdf = sdf[["risk_factor_id", "date", "value"]].copy().sort_values("date").reset_index(drop=True)
                    feat = feature_builder.build_features(sdf)
                    ctx = {"risk_factor_id": str(rf_id)}
                    st = check.fit(feat, ctx)
                    parts.append(check.score(feat, ctx, st))
                scored_all = pd.concat(parts, ignore_index=True) if parts else pd.DataFrame()
            else:
                feat_grp = feature_builder.build_batch(peer_series[["risk_factor_id", "date", "value"]].copy(), max_workers=4)
                ctx = {"peer_group": True}
                st = check.fit(feat_grp, ctx)
                scored_all = check.score(feat_grp, ctx, st)
            scored = scored_all[scored_all["risk_factor_id"].astype(str) == target_risk_factor_id].copy()

        elif spec.fit_policy == "global":
            if global_series.empty:
                raise ValueError(f"Global data empty for check '{spec.id}'.")
            feat_all = feature_builder.build_batch(global_series[["risk_factor_id", "date", "value"]].copy(), max_workers=4)
            ctx = {"global": True}
            st = check.fit(feat_all, ctx)
            scored_all = check.score(feat_all, ctx, st)
            scored = scored_all[scored_all["risk_factor_id"].astype(str) == target_risk_factor_id].copy()

        else:
            raise ValueError(f"Unsupported fit_policy '{spec.fit_policy}' for check '{spec.id}'.")

        elapsed = time.perf_counter() - t0
        scored["check_id"] = spec.id
        scored["backend"] = spec.backend
        scored["family"] = spec.family
        scored["fit_policy"] = spec.fit_policy
        scored["run_seconds"] = round(elapsed, 4)
        raw_parts.append(scored)
        print(f"{spec.id:35s} | {spec.fit_policy:14s} | rows={len(scored):5d} | sec={elapsed:8.3f}")

    raw_results = pd.concat(raw_parts, ignore_index=True) if raw_parts else pd.DataFrame()
    if raw_results.empty:
        raise ValueError("No check outputs produced.")
    raw_results["date"] = pd.to_datetime(raw_results["date"], errors="coerce")
    raw_results = raw_results.sort_values(["date", "check_id"]).reset_index(drop=True)
    display(raw_results.head(10))
    return raw_results


def normalize_and_build_view(settings: dict[str, Any], prepared: dict[str, Any], raw_results: pd.DataFrame) -> dict[str, Any]:
    selected_specs = prepared["selected_specs"]
    catalog = prepared["catalog"]
    cfg_hash = prepared["cfg_hash"]

    profiles = _build_check_profiles(selected_specs, catalog)
    run_id = f"nb_single_factor_{pd.Timestamp.utcnow().strftime('%Y%m%d_%H%M%S')}"
    artifact_root = Path(settings["artifact_root"])
    artifact_root.mkdir(parents=True, exist_ok=True)

    norm_results = normalize_results(
        results_df=raw_results.copy(),
        check_profiles=profiles,
        run_id=run_id,
        config_hash=cfg_hash,
        business_date=str(pd.to_datetime(settings["business_date"]).date()),
        artifact_root=artifact_root,
    )

    keys = ["risk_factor_id", "date", "check_id"]
    raw_flag_view = raw_results[keys + ["flag", "severity", "threshold"]].rename(
        columns={"flag": "flag_raw", "severity": "severity_raw", "threshold": "threshold_raw"}
    )
    results_view = norm_results.rename(
        columns={"flag": "flag_norm", "severity": "severity_norm", "threshold": "threshold_norm"}
    ).merge(raw_flag_view, on=keys, how="left")

    results_view = results_view[
        [
            "risk_factor_id",
            "date",
            "check_id",
            "backend",
            "family",
            "fit_policy",
            "raw_score",
            "norm_score",
            "threshold_raw",
            "threshold_norm",
            "flag_raw",
            "flag_norm",
            "severity_raw",
            "severity_norm",
            "reason_code",
            "explain",
            "run_seconds",
        ]
    ].sort_values(["date", "check_id"]).reset_index(drop=True)

    print("Normalization artifacts:", artifact_root)
    print("Run ID:", run_id)
    display(results_view.tail(20))

    return {"run_id": run_id, "results_view": results_view}


def build_flagged_rows(results_view: pd.DataFrame, use_normalized_flags: bool = True) -> tuple[str, pd.DataFrame]:
    flag_col = "flag_norm" if use_normalized_flags else "flag_raw"
    flagged_only = results_view[results_view[flag_col].fillna(False)].copy()
    print("Flag column:", flag_col)
    print("Flagged rows:", len(flagged_only))
    display(
        flagged_only[
            [
                "date",
                "check_id",
                "raw_score",
                "norm_score",
                "flag_raw",
                "flag_norm",
                "severity_raw",
                "severity_norm",
                "reason_code",
                "explain",
            ]
        ].sort_values(["date", "check_id"]).reset_index(drop=True)
    )
    return flag_col, flagged_only


def plot_raw_vs_flags(target_series: pd.DataFrame, results_view: pd.DataFrame, target_risk_factor_id: str, flag_col: str) -> go.Figure:
    plot_df = target_series[["date", "value"]].drop_duplicates().sort_values("date")
    fig = go.Figure()
    fig.add_trace(
        go.Scatter(
            x=plot_df["date"],
            y=plot_df["value"],
            mode="lines",
            name="raw value",
            line=dict(color="royalblue", width=1.5),
        )
    )

    plot_flags = results_view[results_view[flag_col].fillna(False)].copy().merge(plot_df, on="date", how="left")
    for check_id, g in plot_flags.groupby("check_id", sort=False):
        fig.add_trace(
            go.Scatter(
                x=g["date"],
                y=g["value"],
                mode="markers",
                name=f"flag:{check_id}",
                marker=dict(size=9, line=dict(width=1)),
                customdata=np.stack(
                    [
                        g["check_id"],
                        g["raw_score"].round(6),
                        g["norm_score"].round(6),
                        g["severity_raw"].astype(str),
                        g["severity_norm"].astype(str),
                        g["reason_code"].astype(str),
                    ],
                    axis=-1,
                ),
                hovertemplate=(
                    "date=%{x|%Y-%m-%d}<br>"
                    "value=%{y:.6f}<br>"
                    "check=%{customdata[0]}<br>"
                    "raw_score=%{customdata[1]}<br>"
                    "norm_score=%{customdata[2]}<br>"
                    "severity_raw=%{customdata[3]}<br>"
                    "severity_norm=%{customdata[4]}<br>"
                    "reason=%{customdata[5]}<extra></extra>"
                ),
            )
        )
    fig.update_layout(
        template="plotly_white",
        title=f"{target_risk_factor_id} | Raw Series + Flags ({flag_col})",
        xaxis_title="date",
        yaxis_title="value",
        legend_title="series/check",
        height=560,
    )
    fig.show()
    return fig


def build_model_summary(results_view: pd.DataFrame) -> pd.DataFrame:
    summary = (
        results_view.groupby(["check_id", "backend", "family", "fit_policy"], as_index=False)
        .agg(
            points=("date", "count"),
            flags_raw=("flag_raw", "sum"),
            flags_norm=("flag_norm", "sum"),
            max_raw_score=("raw_score", "max"),
            max_norm_score=("norm_score", "max"),
            mean_norm_score=("norm_score", "mean"),
            run_seconds=("run_seconds", "max"),
        )
        .sort_values(["flags_norm", "max_norm_score", "flags_raw"], ascending=[False, False, False])
        .reset_index(drop=True)
    )
    display(summary)
    return summary


def main(use_normalized_flags: bool = True, show_plot: bool = True) -> dict[str, Any]:
    """
    to help my team pick one single-risk-factor and debug it
    """
    print("Step 1: load_runtime_settings()")
    settings = load_runtime_settings(PROJECT_ROOT)

    print("Step 2: prepare_universe_and_specs()")
    prepared = prepare_universe_and_specs(settings)

    print("Step 3: load_target_series()")
    target_payload = load_target_series(settings, prepared)

    print("Step 4: run_selected_checks()")
    raw_results = run_selected_checks(settings, prepared, target_payload)

    print("Step 5: normalize_and_build_view()")
    normalized_payload = normalize_and_build_view(settings, prepared, raw_results)
    results_view = normalized_payload["results_view"]

    print("Step 6: build_flagged_rows()")
    flag_col, flagged_only = build_flagged_rows(results_view, use_normalized_flags=use_normalized_flags)

    fig = None
    if show_plot:
        print("Step 7: plot_raw_vs_flags()")
        fig = plot_raw_vs_flags(
            target_series=target_payload["target_series"],
            results_view=results_view,
            target_risk_factor_id=target_payload["target_risk_factor_id"],
            flag_col=flag_col,
        )

    print("Step 8: build_model_summary()")
    summary = build_model_summary(results_view)

    return {
        "settings": settings,
        "prepared": prepared,
        "target_payload": target_payload,
        "raw_results": raw_results,
        "normalized_payload": normalized_payload,
        "results_view": results_view,
        "flag_col": flag_col,
        "flagged_only": flagged_only,
        "figure": fig,
        "summary": summary,
    }



# ## main  Pipeline
#`use_normalized_flags=True`-->  uses normalized flag/severity for  plot.
def runPipeline():
    outputs = main(use_normalized_flags=True, show_plot=True)
    outputs["summary"].head()


if __name__ == "__main__":
    runPipeline()



