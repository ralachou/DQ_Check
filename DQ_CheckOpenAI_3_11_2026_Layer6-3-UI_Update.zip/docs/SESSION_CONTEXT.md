# Session Context Handoff

Date: 2026-03-02
Project: Advanced DQ Checks on RF
Repository: DQ_CheckOpenAI

## Scope
This file captures key implementation context and operational notes from the current build-out, so work can continue on another machine/session without losing continuity.

## Architecture Summary
Layered system implemented in `src/`:
- Layer 1 Data Access: repository abstraction and parquet/sqlite/rest backends.
- Layer 2 Universe Layer: config-driven universe membership and hierarchy normalization.
- Layer 3 DQ Model Library: local statistical checks + adapters (PyOD/ADTK/Merlion) + ensemble.
- Layer 4 Config Layer: YAML-driven model catalog and activation.
- Layer 5 Run Engine: orchestrates membership, loading, checks, normalization, persistence.
- Layer 6 False Alarm/Triage: peer consistency, regime/event awareness, supervised option.
- Layer 7 UI: Dash dashboards (`ui.app`, `ui.app_v2`) for summary/drilldown/comparison/peer analysis.

## Key Data Contracts
Time-series canonical schema:
- `business_date`, `risk_factor_id`, `date`, `value`

DQ result core schema includes:
- `run_id`, `universe_name`, `business_date`, `risk_factor_id`, `date`, `check_id`,
- `backend`, `family`, `raw_score`, `norm_score`, `threshold`, `flag`, `severity`,
- `reason_code`, `explain`, `artifacts_json`

## Major Enhancements Implemented
1. Business-date-first processing
- Data loading and storage are business-date partition aware.
- `ui.app` and `ui.app_v2` support load-time business-date filtering.

2. UI v2 filter support
- Added UI business-date selector in `app_v2`.
- Store/filter state includes `business_date`.
- Compare/peer/drilldown paths apply business-date filtering.

3. Large demo generation and scaling controls
- Full hierarchy demo runner supports per-asset-class cap:
  - `--max-factors-per-asset-class`
- Dedicated `demo_ui_full` raw/processed/artifact roots.

4. Integration pathway for external manual dataset
- Added integration demo script:
  - `src/pipeline/run_demo_integrate_with_Mar.py`
- Added validation notebook:
  - `tests/validate_integration_withMar.ipynb`
- Supports staging manual `.csv/.xlsx` into existing raw table layout.

5. Multi-universe run support in integration demo
- Added:
  - `--universe-names`
  - `--run-all-compatible-universes`
- Engine can run all compatible universes inferred from staged metadata.

6. Layer 6 supervised triage improvements
- Added XGBoost/LightGBM/RF/LogReg candidate pipeline in false-alarm reducer.
- Added supervised probability calibration (`sigmoid`/`isotonic`/`none`).
- Added CLI controls:
  - `--supervised-candidates`
  - `--calibration-method`

## Important Runtime Notes
1. Module import resolution
- On new machines, missing `ui` module usually means `src` not on `PYTHONPATH` or package not installed.
- Recommended setup:
  - `pip install -r requirements.txt`
  - `pip install -e .`

2. Version consistency
- UI compare-tab issues were observed with outdated pandas.
- Ensure environment matches repo constraints (`requirements.txt` / `pyproject.toml`).

3. Business-date behavior
- Use `--business-date` explicitly when launching UI to avoid loading unintended partitions.

## High-Value Commands
1. Launch app_v2 with explicit paths and business date
```cmd
python -m ui.app_v2 --results-path data/demo_ui_full/processed/dq_results --raw-path data/demo_ui_full/raw/timeseries_raw --membership-path data/demo_ui_full/processed/universe_membership --config-path data/demo_ui_full/processed/ui_full_demo/model_catalog_ui_full.yaml --business-date 2026-01-31 --port 8060
```

2. Debug Dash callback behavior
```cmd
python -m pipeline.run_demo_layer7_dash_ui --app-version v2 --results-path data/demo_ui_full/processed/dq_results --raw-path data/demo_ui_full/raw/timeseries_raw --membership-path data/demo_ui_full/processed/universe_membership --run-callback refresh_compare --sample-args --no-print-layout-tree --no-print-callbacks --no-validate-callback-ids
```

3. Integrate manual dataset and run all compatible universes
```cmd
python -m pipeline.run_demo_integrate_with_Mar --source-path data/incoming/manual_dataset.xlsx --raw-path data/raw_manual --processed-path data/processed_manual --config-path configs/model_catalog.yaml --business-date 2026-01-31 --run-engine --run-all-compatible-universes
```

4. Layer 6 supervised demo forcing XGBoost + calibration
```cmd
python -m pipeline.run_demo_layer6_false_alarm --universe-name CP_RATE_CORP --start-date 2024-01-01 --end-date 2024-12-31 --business-date 2024-12-31 --with-supervised --generate-demo-labels --label-rate 0.2 --supervised-candidates xgboost --calibration-method sigmoid --output-format parquet
```

## Rehydration Prompt (for new AI session)
Use this to rebuild context in a fresh session:
- Read AGENTS.md.
- Read README.md and numbered docs under `docs/`.
- Read:
  - `src/common/schemas.py`
  - `src/data_access/base.py`
  - `src/data_access/parquet_repository.py`
  - `src/engine/run_engine.py`
  - `src/ui/app.py`
  - `src/ui/app_v2.py`
  - `src/pipeline/run_demo_*.py` (all key demo runners)
  - `src/pipeline/run_demo_integrate_with_Mar.py`
  - `tests/validate_integration_withMar.ipynb`
- Then summarize architecture, implemented enhancements, run commands, open risks, and ask for next step.

## Current Open Risks/Watch Items
- Optional dependency availability differs by machine (pyod/adtk/merlion/xgboost/lightgbm).
- Dash/AG Grid/pandas version drift can impact callback behavior.
- For manual integration, ensure source columns map correctly and date/value coercions are validated before engine run.

## Update: MARS_SUBSET Worklog (2026-03-10)
### Goal
Replicate a manual MARS-style dataset and run Layer 3 / Layer 6 / UI for `MARS_SUBSET` using `analysis_field=shift`.

### Config Fix Applied
- File: `configs/model_catalog.yaml`
- Fixed malformed universe block so common checks are actually active:
  - `MARS_SUBSET.description` set to plain string
  - `filters: {}`
  - `use_common_checks: true`
  - `checks: []` (not `check: []`)

### New Generator Added
- File: `src/pipeline/run_demo_generate_mars_subset.py`
- Purpose: one-command synthetic replication for MARS_SUBSET raw files.
- Output schema generated:
  - `raw/risk_factors/*`: `risk_factor_id, asset_class, ccy, rf_level1..rf_level5`
  - `raw/timeseries_raw/business_date=YYYY-MM-DD/*`: `business_date, risk_factor_id, date, value, prev_close_value, shift, driver_id`
- Supports:
  - `--output-format parquet|excel|both`
  - `--clean-target` to clear existing raw parquet files before write
  - business-date partitioned output under `timeseries_raw/business_date=.../`

### MARS_SUBSET Synthetic Shape Implemented
- Requested date scope:
  - `start_date=2019-01-02`
  - `end_date=2020-12-31`
  - `business_date=2026-02-27`
- Implemented factor counts:
  - `CP_RATE=401` (`CDS=254`, `CORP=117`, `CMBS=21`, `RMBSLTCMO=9`)
  - `IR_RATE_BASISFXSOFR=373`
  - `EQ_VOL_CURV_M06_M09=156`
  - Total risk factors: `930`
- Note: RMBS shift mean interpreted as `-9.11283e-05` (user note had `-9.11283e05`, likely typo).

### Commands Used/Validated
1. Generate MARS raw dataset into main raw path:
```cmd
python -m pipeline.run_demo_generate_mars_subset --raw-path data/raw --start-date 2019-01-02 --end-date 2020-12-31 --business-date 2026-02-27 --output-format parquet --clean-target
```

2. Layer 3 on MARS_SUBSET:
```cmd
python -m pipeline.run_demo_layer3_dqChecks --no-generate-demo-data --universe-name MARS_SUBSET --analysis-field shift --start-date 2019-01-02 --end-date 2020-12-31 --business-date 2026-02-27 --raw-path data/raw --processed-path data/processed --config-path configs/model_catalog.yaml --max-series 0 --output-format parquet
```

3. Layer 6 on MARS_SUBSET:
```cmd
python -m pipeline.run_demo_layer6_false_alarm --no-generate-demo-data --universe-name MARS_SUBSET --analysis-field shift --start-date 2019-01-02 --end-date 2020-12-31 --business-date 2026-02-27 --raw-path data/raw --processed-path data/processed --artifact-root data/artifacts/normalization --config-path configs/model_catalog.yaml --max-series 0 --output-format parquet
```

4. app_v2 for canonical outputs (Layer 5/RunEngine path):
```cmd
python -m ui.app_v2 --results-path data/processed/dq_results --raw-path data/raw/timeseries_raw --membership-path data/processed/universe_membership --config-path configs/model_catalog.yaml --business-date 2026-02-27 --port 8061
```

5. app_v2 for Layer 6 demo artifacts (replace `<RUN_ID>`):
```cmd
python -m ui.app_v2 --results-path data/processed/layer6_false_alarm_demo/business_date=2026-02-27/universe_name=MARS_SUBSET/run_id=<RUN_ID>/triaged_preview.parquet --raw-path data/raw/timeseries_raw --membership-path data/processed/layer3_dq_checks_demo/business_date=2026-02-27/universe_name=MARS_SUBSET/membership_input.parquet --config-path configs/model_catalog.yaml --business-date 2026-02-27 --triage-model-path data/processed/layer6_false_alarm_demo/business_date=2026-02-27/universe_name=MARS_SUBSET/run_id=<RUN_ID>/triage_model.parquet --feature-importance-global-path data/processed/layer6_false_alarm_demo/business_date=2026-02-27/universe_name=MARS_SUBSET/run_id=<RUN_ID>/feature_importance_global.parquet --feature-importance-local-path data/processed/layer6_false_alarm_demo/business_date=2026-02-27/universe_name=MARS_SUBSET/run_id=<RUN_ID>/feature_importance_local.parquet --feature-importance-drift-path data/processed/layer6_false_alarm_demo/business_date=2026-02-27/universe_name=MARS_SUBSET/run_id=<RUN_ID>/feature_importance_drift.parquet --feature-importance-drift-components-path data/processed/layer6_false_alarm_demo/business_date=2026-02-27/universe_name=MARS_SUBSET/run_id=<RUN_ID>/feature_importance_drift_components.parquet --port 8061
```

### UI/Data Loader Improvements Completed Today
- `src/ui/app.py`:
  - Fixed single-file parquet loading with business-date filtering.
  - Added loader diagnostics:
    - `--debug-load`
    - `--debug-load-only`
    - `load_data_with_debug(...)` report helper.
- `src/ui/app_v2.py`:
  - Wired same debug-load flags through to shared loader diagnostics.

## Update: UI v2 + Layer 3 Follow-up (2026-03-11)
### UI v2 changes finalized
File:
- `src/ui/app_v2.py`

What changed:
- Title changed to:
  - `Advanced DQ Checks on RF - Reports and Insights`
- Tab 1 renamed:
  - `DQ Outliers Summary`
- Added metadata-first filter semantics:
  - `asset_class`, `ccy`, `rf_level1`
- Added summary grouping options:
  - `asset_class`
  - `rf_level1`
  - `rf_level1 + rf_level2`
  - `rf_level1 + rf_level2 + rf_level3`
  - `rf_level1 + rf_level2 + rf_level3 + rf_level4`
  - `rf_level1 + rf_level2 + rf_level3 + rf_level4 + rf_level5`
- Added summary scope options:
  - `latest flagged date`
  - `entire range`
  - `selected UI range`
- Added visible `Summary Range` picker with mode-aware hint and disable behavior.
- Kept `latest flagged date` while still allowing UI range edits.
- Added startup range args:
  - `--start-date`
  - `--end-date`

Regime banner behavior:
- `VIX`, `MOVE`, `CDX IG` cards always render.
- If missing from dataset, fallback proxy values are derived from stress ratio.

### Layer 3 mismatch investigation and fix
File:
- `src/pipeline/run_demo_layer3_dqChecks.py`

Observed mismatch:
- Console summary showed all checks/alerts.
- `membership_input.parquet` was incorrectly assumed to be DQ alerts.
- `dq_results_preview` and `flags_preview` were biased by `head(...)`.

Fixes:
- Added balanced preview sampling across `check_id` via `_sample_per_check(...)`.
- Added full parquet outputs by default:
  - `dq_results_full.parquet`
  - `dq_flags_full.parquet`
- Added flag:
  - `--write-full-results` (default true)

Recommended analysis files:
- `summary_by_check.parquet` for per-check alert counts
- `dq_flags_full.parquet` for all flagged rows
- `dq_results_full.parquet` for full Layer 3 output
